#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__37(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__37\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006814_;
    wasmetal_core__DOT___006814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006815_;
    wasmetal_core__DOT___006815_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016172_;
    wasmetal_core__DOT___016172_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016227_;
    wasmetal_core__DOT___016227_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016229_;
    wasmetal_core__DOT___016229_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016247_;
    wasmetal_core__DOT___016247_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016261_;
    wasmetal_core__DOT___016261_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016262_;
    wasmetal_core__DOT___016262_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016273_;
    wasmetal_core__DOT___016273_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016274_;
    wasmetal_core__DOT___016274_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016281_;
    wasmetal_core__DOT___016281_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016311_;
    wasmetal_core__DOT___016311_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016312_;
    wasmetal_core__DOT___016312_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016314_;
    wasmetal_core__DOT___016314_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022709_;
    wasmetal_core__DOT___022709_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029044_;
    wasmetal_core__DOT___029044_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045276_;
    wasmetal_core__DOT___045276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045277_;
    wasmetal_core__DOT___045277_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045278_;
    wasmetal_core__DOT___045278_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045300_;
    wasmetal_core__DOT___045300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045301_;
    wasmetal_core__DOT___045301_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045302_;
    wasmetal_core__DOT___045302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045480_;
    wasmetal_core__DOT___045480_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045481_;
    wasmetal_core__DOT___045481_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045482_;
    wasmetal_core__DOT___045482_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045504_;
    wasmetal_core__DOT___045504_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045505_;
    wasmetal_core__DOT___045505_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045506_;
    wasmetal_core__DOT___045506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057774_;
    wasmetal_core__DOT___057774_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058544_;
    wasmetal_core__DOT___058544_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058713_;
    wasmetal_core__DOT___058713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058735_;
    wasmetal_core__DOT___058735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058844_;
    wasmetal_core__DOT___058844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059104_;
    wasmetal_core__DOT___059104_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059127_;
    wasmetal_core__DOT___059127_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059133_;
    wasmetal_core__DOT___059133_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059180_;
    wasmetal_core__DOT___059180_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059181_;
    wasmetal_core__DOT___059181_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059184_;
    wasmetal_core__DOT___059184_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059190_;
    wasmetal_core__DOT___059190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059194_;
    wasmetal_core__DOT___059194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059195_;
    wasmetal_core__DOT___059195_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127892___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127892___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127892___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127892___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127892___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127892___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127943___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127943___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127943___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127943___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135442___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135442___DOT__CO__BRA__2__KET__ = 0;
    CData/*3:0*/ __VdfgTmp_hb9735979__0;
    __VdfgTmp_hb9735979__0 = 0;
    CData/*1:0*/ __VdfgTmp_haf03c95c__0;
    __VdfgTmp_haf03c95c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h88996eeb__0;
    __VdfgTmp_h88996eeb__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc9b9f3ff__0;
    __VdfgTmp_hc9b9f3ff__0 = 0;
    CData/*4:0*/ __VdfgTmp_h7386a859__0;
    __VdfgTmp_h7386a859__0 = 0;
    CData/*2:0*/ __VdfgTmp_h352b51f3__0;
    __VdfgTmp_h352b51f3__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3d212b86__0;
    __VdfgTmp_h3d212b86__0 = 0;
    CData/*1:0*/ __VdfgTmp_h19f5d4dc__0;
    __VdfgTmp_h19f5d4dc__0 = 0;
    CData/*1:0*/ __VdfgTmp_h84de2564__0;
    __VdfgTmp_h84de2564__0 = 0;
    CData/*2:0*/ __VdfgTmp_h4c4dfcd4__0;
    __VdfgTmp_h4c4dfcd4__0 = 0;
    CData/*1:0*/ __VdfgTmp_hafce6df8__0;
    __VdfgTmp_hafce6df8__0 = 0;
    CData/*1:0*/ __VdfgTmp_he6980ace__0;
    __VdfgTmp_he6980ace__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbced8ce8__0;
    __VdfgTmp_hbced8ce8__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb7173042__0;
    __VdfgTmp_hb7173042__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8c714845__0;
    __VdfgTmp_h8c714845__0 = 0;
    CData/*1:0*/ __VdfgTmp_he5f9d86a__0;
    __VdfgTmp_he5f9d86a__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022698_)
            ? (IData)(vlSelf->wasmetal_core__DOT___022705_)
            : (IData)(vlSelf->wasmetal_core__DOT___022698_));
    vlSelf->wasmetal_core__DOT____Vcellout___127596___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023756_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023755_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023754_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023753_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023688_)))));
    vlSelf->wasmetal_core__DOT___023693_ = ((IData)(vlSelf->wasmetal_core__DOT___023756_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d));
    vlSelf->wasmetal_core__DOT___058722_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0))))));
    vlSelf->wasmetal_core__DOT___023760_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d))));
    vlSelf->wasmetal_core__DOT___058741_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0))))));
    vlSelf->wasmetal_core__DOT___023759_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d))));
    vlSelf->wasmetal_core__DOT___023758_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d))));
    vlSelf->wasmetal_core__DOT___058884_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d))))));
    vlSelf->wasmetal_core__DOT___058921_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0))))));
    vlSelf->wasmetal_core__DOT___058723_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058708_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058707_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058706_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___023757_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d))));
    vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d) {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127452___O 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                 ? (IData)(vlSelf->wasmetal_core__DOT___022639_)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022639_)));
    vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036988_)));
    vlSelf->wasmetal_core__DOT___016473_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058528_))))));
    vlSelf->wasmetal_core__DOT___036393_ = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128860___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       >> 1U)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    vlSelf->__VdfgTmp_h29bb7b8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_h7b6ee7cc__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                    >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___127564___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003807_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003805_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023471_)))));
    vlSelf->wasmetal_core__DOT___023475_ = ((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127581___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013635_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h62ff3be8__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023592_)))));
    vlSelf->wasmetal_core__DOT___023596_ = ((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127474___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022801_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022800_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022799_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022798_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022765_)))));
    vlSelf->wasmetal_core__DOT___022770_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022801_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0))));
    vlSelf->wasmetal_core__DOT___022805_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))))));
    vlSelf->wasmetal_core__DOT___059179_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))))));
    vlSelf->wasmetal_core__DOT___022804_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0))))));
    wasmetal_core__DOT___059184_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0))))));
    vlSelf->wasmetal_core__DOT___022803_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0))))));
    vlSelf->wasmetal_core__DOT___059182_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h36468d91__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d))))));
    vlSelf->wasmetal_core__DOT___059126_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))))));
    vlSelf->wasmetal_core__DOT___022802_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))))));
    wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034317_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034379_));
    vlSelf->wasmetal_core__DOT____Vcellout___128120___O 
        = ((1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___CO) 
                  >> 3U)) ^ ((0x3ffffffeU & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___CO) 
                                              >> 2U) 
                                             & ((IData)(vlSelf->wasmetal_core__DOT___028836_) 
                                                << 1U))) 
                             | (IData)(vlSelf->wasmetal_core__DOT___028836_)));
    wasmetal_core__DOT___029044_ = ((IData)(vlSelf->wasmetal_core__DOT___029078_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128137___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029078_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029077_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029075_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029074_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029039_)))));
    vlSelf->__VdfgTmp_h57a1bcce__0 = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128898___Q) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044897_));
    vlSelf->wasmetal_core__DOT___062970_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128896___Q) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044897_))));
    vlSelf->wasmetal_core__DOT___053592_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053429_))));
    vlSelf->wasmetal_core__DOT___053430_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044897_)))));
    vlSelf->wasmetal_core__DOT___053589_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053586_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052693_)))));
    vlSelf->wasmetal_core__DOT___052917_ = (1U & (IData)(
                                                         (0xbfbfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052864_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1a7964bb__0))))))));
    vlSelf->wasmetal_core__DOT___062990_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052578_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)))))));
    vlSelf->wasmetal_core__DOT___052712_ = (1U & (0x7f7f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052700_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050380_)))))));
    vlSelf->wasmetal_core__DOT___052711_ = (1U & (IData)(
                                                         (0x7f7f7f7f7f7f7fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052679_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052706_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052705_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050364_)))))))));
    vlSelf->wasmetal_core__DOT___071293_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071292_))));
    vlSelf->wasmetal_core__DOT___071288_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071287_))));
    wasmetal_core__DOT___127892___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026692_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026626_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d));
    vlSelf->wasmetal_core__DOT___054390_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054396_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054392_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054394_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127943___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027162_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027096_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d));
    vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026494_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___054389_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054395_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054391_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054393_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026962_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026896_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d));
    vlSelf->wasmetal_core__DOT___054036_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054035_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054034_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054033_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x4100004100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054021_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b7__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b3__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004744_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b6__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004448_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x1001000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054019_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054018_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b23__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b22__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003348_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b21__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003416_))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054012_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054011_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054010_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xb00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054001_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054000_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053999_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b2__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004818_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b0__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x1001000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054006_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054005_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b13__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b12__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004152_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b10__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003484_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (6U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b15__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003706_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___052681_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045389_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045355_))));
    vlSelf->wasmetal_core__DOT___045072_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071109_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071108_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071107_))))))));
    vlSelf->wasmetal_core__DOT___045096_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071109_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071108_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071107_)))))))));
    vlSelf->wasmetal_core__DOT___045071_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071094_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071093_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071092_)))))))));
    vlSelf->wasmetal_core__DOT___045095_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071094_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071092_)))))))));
    vlSelf->wasmetal_core__DOT___045862_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdb6fbe09__0)))))));
    vlSelf->wasmetal_core__DOT___045886_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003208_)))))))));
    vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h45ac64ad__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026761_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d));
    vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034482_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___135442___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030246_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030181_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d));
    vlSelf->wasmetal_core__DOT___063291_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063288_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063287_)))))));
    vlSelf->wasmetal_core__DOT___063267_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063264_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063263_)))))));
    vlSelf->wasmetal_core__DOT___063273_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063270_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063269_)))))));
    vlSelf->wasmetal_core__DOT___063279_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063276_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063275_)))))));
    vlSelf->wasmetal_core__DOT___063285_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063282_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063281_)))))));
    vlSelf->wasmetal_core__DOT___044866_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4ddf67d8__0)))))))))));
    vlSelf->wasmetal_core__DOT___044890_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4ddf67d8__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d))))))));
    vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027360_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b34__05d));
    vlSelf->__VdfgTmp_he6ade5b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_he6a1153d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_he5c4f457__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O)));
    vlSelf->wasmetal_core__DOT___023204_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022472_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O))))));
    vlSelf->wasmetal_core__DOT___023201_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022474_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___023200_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022475_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            >> 3U))))));
    __VdfgTmp_he5f9d86a__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022476_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022532_));
    wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128555___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022699_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022699_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d) {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d;
        vlSelf->wasmetal_core__DOT___023895_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023895_ = vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023757_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023693_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d));
    vlSelf->wasmetal_core__DOT___006829_ = (1U & (0xbf000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___017895_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O))))));
    vlSelf->wasmetal_core__DOT___048705_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                  >> 1U) | (IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___051511_ = (1U & (IData)(
                                                         (0xb000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h29bb7b8d__0))))))));
    vlSelf->__VdfgTmp_h04da727f__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h29bb7b8d__0));
    vlSelf->wasmetal_core__DOT___050098_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127564___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003811_))));
    vlSelf->wasmetal_core__DOT___050094_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127564___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003808_))));
    vlSelf->__VdfgTmp_h27384d82__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127564___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003807_));
    vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006400_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023475_));
    vlSelf->__VdfgTmp_hb00ae252__0 = (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127581___O) 
                                                    >> 1U)));
    vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__0__KET__ 
        = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023596_));
    vlSelf->wasmetal_core__DOT____Vcellout___127494___O 
        = ((4U | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)) 
                         << 1U)) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d))))) 
           ^ (((IData)(wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022943_)))));
    vlSelf->wasmetal_core__DOT___059186_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059184_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059183_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0)))))))))));
    vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022802_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022770_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127486___O 
        = (((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)) 
                   << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d)) 
                                     << 1U)) | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
                 : (IData)(wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022880_)))));
    vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034318_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128138___O 
        = ((1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___CO) 
                  >> 3U)) ^ ((0x3ffffffeU & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___CO) 
                                              >> 2U) 
                                             & ((IData)(wasmetal_core__DOT___029044_) 
                                                << 1U))) 
                             | (IData)(wasmetal_core__DOT___029044_)));
    vlSelf->wasmetal_core__DOT___019791_ = (1U & (IData)(
                                                         (0xf3a2a2a200000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052688_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052999_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053592_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048483_)))))))));
    vlSelf->wasmetal_core__DOT___019788_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053429_))));
    vlSelf->wasmetal_core__DOT___019790_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053428_))));
    vlSelf->wasmetal_core__DOT___039572_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051570_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b96__05d)))))));
    vlSelf->wasmetal_core__DOT___039632_ = (1U & (0xaea2aeaeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051572_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051568_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill)))))));
    vlSelf->wasmetal_core__DOT___039755_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039629_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039633_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039634_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039635_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039636_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039637_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039638_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039639_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039640_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039663_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039652_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039651_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039650_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039649_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___040059_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039641_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039648_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039646_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039645_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039644_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039643_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039653_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039654_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039655_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039668_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039662_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039670_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039672_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039664_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___040056_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039656_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___039642_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT___039683_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT___039671_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___039669_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b35__05d)))))));
    vlSelf->wasmetal_core__DOT___039661_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT___039657_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___039667_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT___039659_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT___039666_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___039660_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT___039673_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT___039674_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___039675_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___039689_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT___039682_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___039691_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b47__05d)))))));
    vlSelf->wasmetal_core__DOT___039698_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT___039684_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___040055_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT___039676_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT___039665_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___039681_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b53__05d)))))));
    vlSelf->wasmetal_core__DOT___039692_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___039690_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___039685_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b56__05d)))))));
    vlSelf->wasmetal_core__DOT___039688_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b57__05d)))))));
    vlSelf->wasmetal_core__DOT___039677_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___039687_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b59__05d)))))));
    vlSelf->wasmetal_core__DOT___039679_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b60__05d)))))));
    vlSelf->wasmetal_core__DOT___039686_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___039693_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b62__05d)))))));
    vlSelf->wasmetal_core__DOT___039694_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___039695_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003150_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b64__05d)))))));
    vlSelf->wasmetal_core__DOT___039696_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b65__05d)))))));
    vlSelf->wasmetal_core__DOT___039697_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004783_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b66__05d)))))));
    vlSelf->wasmetal_core__DOT___039678_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b67__05d)))))));
    vlSelf->wasmetal_core__DOT___039680_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004487_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b68__05d)))))));
    vlSelf->wasmetal_core__DOT___039700_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004339_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b69__05d)))))));
    vlSelf->wasmetal_core__DOT___039701_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b70__05d)))))));
    vlSelf->wasmetal_core__DOT___039702_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004561_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b71__05d)))))));
    vlSelf->wasmetal_core__DOT___039703_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003745_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b72__05d)))))));
    vlSelf->wasmetal_core__DOT___039704_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003597_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b73__05d)))))));
    vlSelf->wasmetal_core__DOT___039705_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003449_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b74__05d)))))));
    vlSelf->wasmetal_core__DOT___039706_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b75__05d)))))));
    vlSelf->wasmetal_core__DOT___039707_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004117_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b76__05d)))))));
    vlSelf->wasmetal_core__DOT___039727_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004191_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b77__05d)))))));
    vlSelf->wasmetal_core__DOT___039719_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004635_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b78__05d)))))));
    vlSelf->wasmetal_core__DOT___039718_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b79__05d)))))));
    vlSelf->wasmetal_core__DOT___039717_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003969_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b80__05d)))))));
    vlSelf->wasmetal_core__DOT___039716_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004265_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b81__05d)))))));
    vlSelf->wasmetal_core__DOT___039699_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b82__05d)))))));
    vlSelf->wasmetal_core__DOT___039708_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b83__05d)))))));
    vlSelf->wasmetal_core__DOT___039715_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b84__05d)))))));
    vlSelf->wasmetal_core__DOT___039713_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003399_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b85__05d)))))));
    vlSelf->wasmetal_core__DOT___039712_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b86__05d)))))));
    vlSelf->wasmetal_core__DOT___039711_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b87__05d)))))));
    vlSelf->wasmetal_core__DOT___039710_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b88__05d)))))));
    vlSelf->wasmetal_core__DOT___039720_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005351_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b89__05d)))))));
    vlSelf->wasmetal_core__DOT___039742_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b90__05d)))))));
    vlSelf->wasmetal_core__DOT___039731_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005011_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b91__05d)))))));
    vlSelf->wasmetal_core__DOT___039730_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b92__05d)))))));
    vlSelf->wasmetal_core__DOT___039728_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b93__05d)))))));
    vlSelf->wasmetal_core__DOT___040050_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b94__05d)))))));
    vlSelf->wasmetal_core__DOT___039721_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005599_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b95__05d)))))));
    vlSelf->wasmetal_core__DOT___039709_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b96__05d)))))));
    vlSelf->wasmetal_core__DOT___039725_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b97__05d)))))));
    vlSelf->wasmetal_core__DOT___039729_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b98__05d)))))));
    vlSelf->wasmetal_core__DOT___039724_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b99__05d)))))));
    vlSelf->wasmetal_core__DOT___039723_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b100__05d)))))));
    vlSelf->wasmetal_core__DOT___039732_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b101__05d)))))));
    vlSelf->wasmetal_core__DOT___039733_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b102__05d)))))));
    vlSelf->wasmetal_core__DOT___039734_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b103__05d)))))));
    vlSelf->wasmetal_core__DOT___039752_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b104__05d)))))));
    vlSelf->wasmetal_core__DOT___039746_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b105__05d)))))));
    vlSelf->wasmetal_core__DOT___039745_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b106__05d)))))));
    vlSelf->wasmetal_core__DOT___039744_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b107__05d)))))));
    vlSelf->wasmetal_core__DOT___039743_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b108__05d)))))));
    vlSelf->wasmetal_core__DOT___039726_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b109__05d)))))));
    vlSelf->wasmetal_core__DOT___039735_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b110__05d)))))));
    vlSelf->wasmetal_core__DOT___039722_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b111__05d)))))));
    vlSelf->wasmetal_core__DOT___039740_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b112__05d)))))));
    vlSelf->wasmetal_core__DOT___039739_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b113__05d)))))));
    vlSelf->wasmetal_core__DOT___039738_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b114__05d)))))));
    vlSelf->wasmetal_core__DOT___039737_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b115__05d)))))));
    vlSelf->wasmetal_core__DOT___039747_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b116__05d)))))));
    vlSelf->wasmetal_core__DOT___039748_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b117__05d)))))));
    vlSelf->wasmetal_core__DOT___039749_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b118__05d)))))));
    vlSelf->wasmetal_core__DOT___039759_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005129_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b119__05d)))))));
    vlSelf->wasmetal_core__DOT___039757_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b120__05d)))))));
    vlSelf->wasmetal_core__DOT___039756_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005333_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b121__05d)))))));
    vlSelf->wasmetal_core__DOT___039754_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b122__05d)))))));
    vlSelf->wasmetal_core__DOT___039753_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004993_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b123__05d)))))));
    vlSelf->wasmetal_core__DOT___040047_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004857_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b124__05d)))))));
    vlSelf->wasmetal_core__DOT___039750_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005265_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b125__05d)))))));
    vlSelf->wasmetal_core__DOT___039736_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005197_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b126__05d)))))));
    vlSelf->wasmetal_core__DOT___039751_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b127__05d)))))));
    vlSelf->wasmetal_core__DOT___040104_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053923_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1cU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___039592_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053924_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039564_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053925_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039571_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053926_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039569_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053927_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & vlSelf->insn_y) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039568_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053928_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039567_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053929_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039566_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053930_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039573_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053931_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039574_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053932_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039591_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053933_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 6U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039585_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053934_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 7U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039584_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053935_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 8U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039583_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053936_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 9U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039582_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053937_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039570_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053938_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xbU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039575_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053939_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xcU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039565_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053940_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039580_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053941_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xeU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039579_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053942_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xfU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039578_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053943_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x10U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039577_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053944_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x11U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039586_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053945_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x12U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039587_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053946_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039588_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053947_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x14U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039597_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053948_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x15U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039595_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053949_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039594_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053950_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039593_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053951_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039576_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053952_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039581_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053953_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039589_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053954_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1bU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039627_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039601_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039600_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039599_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039603_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039604_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039619_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039615_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039614_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039613_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039612_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039602_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039605_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039598_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039610_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039609_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039608_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039607_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039616_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039620_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039611_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039617_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039606_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039618_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039621_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039622_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039623_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039624_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039625_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039626_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039630_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039628_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___071294_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071293_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___071289_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071288_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d)))))))));
    wasmetal_core__DOT___127892___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026693_)
            ? (IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d));
    vlSelf->wasmetal_core__DOT___070732_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054394_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1fU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d)))))));
    wasmetal_core__DOT___127943___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027163_)
            ? (IData)(wasmetal_core__DOT___127943___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d));
    vlSelf->wasmetal_core__DOT___127874___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___070835_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054393_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1fU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026963_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d));
    vlSelf->wasmetal_core__DOT___054187_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054036_))));
    vlSelf->wasmetal_core__DOT___053095_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052681_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052645_))));
    vlSelf->wasmetal_core__DOT___052683_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052681_))));
    vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hd87e5f33__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128671___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034483_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034482_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034481_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034480_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034536_)))));
    vlSelf->wasmetal_core__DOT___034540_ = ((IData)(vlSelf->wasmetal_core__DOT___034483_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___135442___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___135442___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046632_)))));
    vlSelf->wasmetal_core__DOT___046636_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)) 
                                            & (IData)(wasmetal_core__DOT___135442___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030247_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127959___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027361_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027360_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027359_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027358_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027292_)))));
    vlSelf->wasmetal_core__DOT___027296_ = ((IData)(vlSelf->wasmetal_core__DOT___027361_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b35__05d));
    vlSelf->__VdfgTmp_h098b01ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he5f9d86a__0)));
    vlSelf->__VdfgTmp_h1ea78a97__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_he5f9d86a__0)))));
    vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022477_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)) 
           & (IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022700_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022700_));
    vlSelf->wasmetal_core__DOT____Vcellout___127631___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024017_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d) {
        vlSelf->wasmetal_core__DOT___024022_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024022_ = vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023895_;
    }
    vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023758_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127615___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023890_)))));
    vlSelf->wasmetal_core__DOT___058425_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006829_))));
    vlSelf->wasmetal_core__DOT___016219_ = (1U & (IData)(
                                                         (0xa0a0f0f00cc00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006930_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006933_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006944_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006940_)))))))));
    vlSelf->wasmetal_core__DOT___016188_ = (1U & (0xff10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8599270c__0))));
    vlSelf->wasmetal_core__DOT___006887_ = (1U & (0xff100000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6ef172e0__0))));
    vlSelf->wasmetal_core__DOT___058424_ = ((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                                                ? (0xf05cc00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he163c644__0))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___003811_))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___016256_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (0xf05cc00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h690a20a1__0))));
        vlSelf->wasmetal_core__DOT___016232_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (0xf05cc00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he163c644__0))));
        vlSelf->wasmetal_core__DOT___016376_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (0xf053300U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9c807cdf__0))));
    } else {
        vlSelf->wasmetal_core__DOT___016256_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___003806_))));
        vlSelf->wasmetal_core__DOT___016232_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___003811_))));
        vlSelf->wasmetal_core__DOT___016376_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    }
    vlSelf->wasmetal_core__DOT___016233_ = (1U & (0xff100000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedae78d9__0))));
    vlSelf->wasmetal_core__DOT___016257_ = ((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                                                ? (0xf053300U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9c807cdf__0))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___016375_ = ((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                                                ? (0xf05cc00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690a20a1__0))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___003806_))));
    vlSelf->__VdfgTmp_h934029c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051557_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_haa0d8025__0)))));
    vlSelf->wasmetal_core__DOT___048950_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005663_))));
    vlSelf->wasmetal_core__DOT___017896_ = (1U & (0xf0d5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7b6ee7cc__0)))));
    vlSelf->wasmetal_core__DOT___006821_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051510_))));
    vlSelf->wasmetal_core__DOT___058470_ = (1U & (0x1000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x4fU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))))))));
    vlSelf->__VdfgTmp_h363b6dc6__0 = ((4U & ((0x4fU 
                                              >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h96af251d__0));
    vlSelf->wasmetal_core__DOT___016377_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x4fU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))));
    vlSelf->wasmetal_core__DOT___006819_ = (1U & (0xb000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04da727f__0))));
    vlSelf->wasmetal_core__DOT___006820_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (0x4fU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))));
    vlSelf->wasmetal_core__DOT___006818_ = (1U & (0xb000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04da727f__0))));
    vlSelf->wasmetal_core__DOT___006891_ = (1U & (0xb000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04da727f__0))));
    if (vlSelf->wasmetal_core__DOT___006829_) {
        if (vlSelf->wasmetal_core__DOT___006900_) {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006932_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hb02141c6__0))));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006918_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006916_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006917_)))));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006919_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006915_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006914_)))));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006898_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006896_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006897_)))));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006899_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006895_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006894_)))));
        } else {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006932_)));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006918_)));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006919_)));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006898_)));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006899_)));
        }
        vlSelf->wasmetal_core__DOT___006888_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006933_)) 
                                                   & (0xdU 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha11b0f77__0))));
        wasmetal_core__DOT___016273_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                               ? (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___006942_))
                                               : (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___006941_))));
    } else {
        if (vlSelf->wasmetal_core__DOT___006900_) {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006919_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hf64b2678__0))));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___016206_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h63494727__0))));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006918_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h4068d69c__0))));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___016197_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h42a31070__0))));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006898_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h3bcc9f30__0))));
        } else {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006919_)));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___016206_)));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006918_)));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___016197_)));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006898_)));
        }
        vlSelf->wasmetal_core__DOT___006888_ = (1U 
                                                & (0xefU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006932_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb02141c6__0)))));
        wasmetal_core__DOT___016273_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                               ? (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___006943_))
                                               : (IData)(vlSelf->wasmetal_core__DOT___006947_)));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127634___O 
        = ((6U | (1U & (0x4fU >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))) 
           ^ (0xeU & ((- (IData)((1U & (~ (0x4fU >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))))) 
                      << 1U)));
    vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006204_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013705_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022803_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0))));
    vlSelf->__VdfgTmp_h7695852b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127486___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006215_));
    vlSelf->__VdfgTmp_h5f0989ee__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127486___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006144_));
    vlSelf->__VdfgTmp_hd540c232__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127486___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034319_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045028_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071294_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___045004_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071294_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054186_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054189_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071292_))))));
    vlSelf->wasmetal_core__DOT___045027_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071289_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___045003_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071289_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054174_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                   << 1U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054178_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071287_))))));
    wasmetal_core__DOT___127892___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026694_)
            ? (IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d));
    vlSelf->wasmetal_core__DOT___070734_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054392_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)))))))))));
    vlSelf->wasmetal_core__DOT___070733_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070732_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054392_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___127943___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027164_)
            ? (IData)(wasmetal_core__DOT___127943___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127874___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026495_) 
             & (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__2__KET__)) 
            << 3U) | (IData)(vlSelf->wasmetal_core__DOT___127874___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127874___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026495_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026494_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026493_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026492_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127874___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026520_)));
    vlSelf->wasmetal_core__DOT___070837_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054391_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070835_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)))))))))));
    vlSelf->wasmetal_core__DOT___070836_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070835_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054391_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026964_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d));
    vlSelf->wasmetal_core__DOT___053103_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053098_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053097_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053095_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h461b3fd9__0))))))));
    vlSelf->wasmetal_core__DOT___052689_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052684_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052683_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h461b3fd9__0)))));
    vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h218f194f__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d));
    vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034484_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034540_));
    vlSelf->wasmetal_core__DOT___030253_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135442___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))))));
    vlSelf->wasmetal_core__DOT___030252_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135442___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))))));
    vlSelf->wasmetal_core__DOT___030251_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135442___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))))));
    vlSelf->wasmetal_core__DOT___030250_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135442___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))))));
    vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___046636_));
    vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030248_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127975___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
           ^ (((IData)(wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027422_)))));
    vlSelf->wasmetal_core__DOT___027427_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063294_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128368___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128456___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063296_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128368___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128456___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063298_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128368___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128456___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027362_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027296_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b36__05d));
    vlSelf->wasmetal_core__DOT___023203_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                   ? (IData)(
                                                             (0xf0c0f0d1f0c05555ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h1ea78a97__0)))
                                                   : 
                                                  (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h098b01ee__0))));
    vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022478_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128555___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128555___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033443_)))));
    vlSelf->wasmetal_core__DOT___033447_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)) 
                                            & (IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___022709_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022713_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___022713_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127460___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022713_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022700_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022699_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022698_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022705_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d) {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024022_;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023759_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d));
    wasmetal_core__DOT___058844_ = (1U & (0xf8U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                     >> 2U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                                       >> 3U)))))));
    vlSelf->__VdfgTmp_hfcfdf45d__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005711_));
    vlSelf->__VdfgTmp_h43b7a5ac__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006215_));
    vlSelf->__VdfgTmp_hf7bb201a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006144_));
    vlSelf->__VdfgTmp_h2307c8f1__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    __VdfgTmp_h3d212b86__0 = (((IData)(vlSelf->wasmetal_core__DOT___016190_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016219_));
    __VdfgTmp_h19f5d4dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___006889_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006888_));
    __VdfgTmp_haf03c95c__0 = (((IData)(vlSelf->wasmetal_core__DOT___016233_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016232_));
    __VdfgTmp_h88996eeb__0 = (((IData)(vlSelf->wasmetal_core__DOT___016257_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016255_));
    __VdfgTmp_h84de2564__0 = (((IData)(vlSelf->wasmetal_core__DOT___016188_) 
                               << 1U) | (1U & (IData)(
                                                      (0xf5f3f0f000000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h934029c5__0)))));
    __VdfgTmp_hc9b9f3ff__0 = ((2U & ((IData)((0xf5f3f0f0ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___006887_));
    vlSelf->wasmetal_core__DOT___017945_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048950_))));
    vlSelf->wasmetal_core__DOT___014612_ = (1U & (0xf0eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005711_))))));
    wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___017896_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___058544_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017895_))));
    vlSelf->wasmetal_core__DOT___052585_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017896_))));
    vlSelf->wasmetal_core__DOT___051319_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x4fU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017895_)))));
    __VdfgTmp_hb9735979__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                     << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017896_))));
    vlSelf->wasmetal_core__DOT___058438_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051511_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051510_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006819_)))));
    vlSelf->wasmetal_core__DOT___058494_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0x4fU 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))))))));
    vlSelf->wasmetal_core__DOT___058492_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                     >> 3U) 
                                                    & (0x700000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h363b6dc6__0)))))));
    vlSelf->wasmetal_core__DOT___058468_ = ((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                            & (IData)(
                                                      (0xfff0fff0ffff4444ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016377_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016376_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016375_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___016255_)))))))));
    wasmetal_core__DOT___016281_ = (1U & ((~ (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                               >> 2U) 
                                              & (IData)(
                                                        (0xb000000000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                           << 5U) 
                                                          | ((0x10U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                                 << 4U)) 
                                                             | ((8U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h29bb7b8d__0))))))))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___006829_)
                                              ? (0xfcfaU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___016288_)))))
                                              : (0xfcfaU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___006942_))))))));
    vlSelf->wasmetal_core__DOT___016313_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006891_))));
    vlSelf->wasmetal_core__DOT___016301_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h363b6dc6__0)))));
    vlSelf->wasmetal_core__DOT___016242_ = (1U & (0xa0003U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8655efce__0))))));
    vlSelf->wasmetal_core__DOT___016222_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058425_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006818_)))));
    wasmetal_core__DOT___016311_ = (1U & (0x55fcU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0xf5f3f0f0ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006887_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006889_))))));
    wasmetal_core__DOT___016314_ = (1U & (IData)((0xaa00ff0f0f0c0cULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016256_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016257_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016258_)))))))));
    vlSelf->wasmetal_core__DOT___016220_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016288_)))))))));
    vlSelf->wasmetal_core__DOT___016302_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016232_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016233_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006890_)))))));
    vlSelf->wasmetal_core__DOT___016248_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016188_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xf5f3f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___016191_)))))));
    wasmetal_core__DOT___016229_ = (1U & (0x70000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 4U) 
                                              | ((8U 
                                                  & ((0x4fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                     << 3U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h96af251d__0))))));
    wasmetal_core__DOT___016262_ = (1U & (0xf0faaccU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058425_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016289_)))))));
    wasmetal_core__DOT___016261_ = (1U & (IData)((0xf0f0aaaaff00ccccULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h04c27d81__0))))))));
    vlSelf->wasmetal_core__DOT___016240_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006943_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006942_)))))))));
    wasmetal_core__DOT___016274_ = (1U & (IData)((0xf0faaaaff00ccccULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016290_)))))))));
    wasmetal_core__DOT___006815_ = (1U & (IData)((0x111111110000ff0fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016377_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016375_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016376_)))))))));
    vlSelf->wasmetal_core__DOT___016241_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006944_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006930_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006940_)))))))));
    vlSelf->wasmetal_core__DOT___016221_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h04c27d81__0)))));
    wasmetal_core__DOT___016247_ = (1U & (0xf0f000eeU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058424_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016192_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006829_)))))));
    wasmetal_core__DOT___016227_ = (1U & (IData)((0xaaaacccc000f000fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016376_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016375_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h161c803b__0))))))));
    vlSelf->wasmetal_core__DOT___016171_ = (1U & (IData)(
                                                         (0xff00aa0c0c0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058424_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016256_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h161c803b__0))))))));
    vlSelf->wasmetal_core__DOT___005689_ = (1U & ((1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O))
                                                   ? 
                                                  (0x331030U 
                                                   >> 
                                                   ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))))))
                                                   : (IData)(
                                                             (0x3000f0002000a00ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                                         << 2U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h7b6ee7cc__0)))))))));
    vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003810_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013692_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022804_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0))));
    vlSelf->wasmetal_core__DOT___022809_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7695852b__0))))));
    wasmetal_core__DOT___059127_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127494___O) 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7695852b__0))))));
    vlSelf->wasmetal_core__DOT___022807_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0))))));
    wasmetal_core__DOT___059104_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059089_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059088_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127494___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)))))))))));
    wasmetal_core__DOT___059195_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059191_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h7695852b__0)))))))))));
    vlSelf->wasmetal_core__DOT___022806_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd540c232__0))))));
    wasmetal_core__DOT___059180_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd540c232__0))))));
    wasmetal_core__DOT___059190_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd540c232__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128641___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034320_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034319_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034318_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034317_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034379_)))));
    vlSelf->wasmetal_core__DOT___034384_ = ((IData)(vlSelf->wasmetal_core__DOT___034320_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127892___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026695_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026694_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026693_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026692_)))) 
           ^ (((IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026626_)))));
    vlSelf->wasmetal_core__DOT___026630_ = ((IData)(vlSelf->wasmetal_core__DOT___026695_)
                                             ? (IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d));
    vlSelf->wasmetal_core__DOT___045232_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070733_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___045208_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070734_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054394_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1fU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054390_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070733_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127943___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027165_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027164_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027163_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027162_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127943___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127943___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127943___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027096_)))));
    vlSelf->wasmetal_core__DOT___027100_ = ((IData)(vlSelf->wasmetal_core__DOT___027165_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127943___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d));
    wasmetal_core__DOT___045482_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071382_) 
                                                       << 4U) 
                                                      | ((4U 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071381_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071380_))))))));
    wasmetal_core__DOT___045506_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071382_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071381_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071380_))))))));
    wasmetal_core__DOT___045278_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071445_) 
                                                       << 4U) 
                                                      | ((4U 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071444_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071443_))))))));
    wasmetal_core__DOT___045302_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071445_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071444_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071443_))))))));
    wasmetal_core__DOT___045480_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071376_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071375_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071374_))))))));
    wasmetal_core__DOT___045504_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071376_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071375_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071374_)))))))));
    wasmetal_core__DOT___045481_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071379_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071378_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071377_))))))));
    wasmetal_core__DOT___045505_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071379_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071378_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071377_)))))))));
    wasmetal_core__DOT___045276_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071439_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071438_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071437_))))))));
    wasmetal_core__DOT___045300_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071439_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071438_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071437_)))))))));
    wasmetal_core__DOT___045277_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071442_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071441_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071440_))))))));
    wasmetal_core__DOT___045301_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071442_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071441_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071440_)))))))));
    vlSelf->wasmetal_core__DOT___044960_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070836_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054389_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___044936_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070837_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054393_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1fU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054389_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070836_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127926___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026965_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026964_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026963_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026962_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026896_)))));
    vlSelf->wasmetal_core__DOT___026900_ = ((IData)(vlSelf->wasmetal_core__DOT___026965_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d));
    vlSelf->wasmetal_core__DOT___072262_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052690_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052689_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052688_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127909___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h877e6c65__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h218f194f__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hd87e5f33__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h45ac64ad__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026761_)))));
    vlSelf->wasmetal_core__DOT___026765_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h877e6c65__0)))
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d));
    vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034485_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128253___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030249_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030248_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030247_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030246_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030181_)))));
    vlSelf->wasmetal_core__DOT___030185_ = ((IData)(vlSelf->wasmetal_core__DOT___030249_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d));
    vlSelf->wasmetal_core__DOT___044867_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3d4d4e87__0)))))))))));
    vlSelf->wasmetal_core__DOT___044891_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h3d4d4e87__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d))))))));
    vlSelf->__VdfgTmp_h93b91d72__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d)))));
    vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027427_));
    vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027363_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b37__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127442___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022479_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022478_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022477_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022476_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022532_)))));
    vlSelf->wasmetal_core__DOT___022536_ = ((IData)(vlSelf->wasmetal_core__DOT___022479_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033447_));
    vlSelf->wasmetal_core__DOT____Vcellout___127461___O 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)
                 ? (IData)(wasmetal_core__DOT___022709_)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)) 
               << 1U) | (IData)(wasmetal_core__DOT___022709_)));
    vlSelf->wasmetal_core__DOT___043037_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                     >> 1U)) 
                                                                 | ((2U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043041_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                             >> 1U))))))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d) {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127597___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023760_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023759_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023758_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023757_)))) 
           ^ (((IData)(wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023693_)))));
    vlSelf->wasmetal_core__DOT___023697_ = ((IData)(vlSelf->wasmetal_core__DOT___023760_)
                                             ? (IData)(wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d));
    vlSelf->wasmetal_core__DOT___017451_ = (1U & (IData)(
                                                         (0xb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058845_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058844_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005921_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005955_)))))))));
    vlSelf->wasmetal_core__DOT___058899_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d))))));
    vlSelf->wasmetal_core__DOT___023765_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d))));
    vlSelf->wasmetal_core__DOT___058873_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d))));
    wasmetal_core__DOT___058713_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0))))));
    vlSelf->wasmetal_core__DOT___023764_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d))));
    vlSelf->wasmetal_core__DOT___058898_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0))))))));
    vlSelf->wasmetal_core__DOT___058752_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058742_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058741_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)))))))))));
    vlSelf->wasmetal_core__DOT___023762_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d))));
    vlSelf->wasmetal_core__DOT___058897_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0))))))));
    wasmetal_core__DOT___058735_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058730_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058729_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)))))))))));
    vlSelf->wasmetal_core__DOT___023761_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d))));
    wasmetal_core__DOT___006814_ = (1U & (IData)((0x11111111f0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_haf03c95c__0))))))));
    __VdfgTmp_h352b51f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                               << 2U) | (IData)(__VdfgTmp_h88996eeb__0));
    if (vlSelf->wasmetal_core__DOT___006891_) {
        vlSelf->wasmetal_core__DOT___016173_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016190_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xf5f3f0f000000000ULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016188_))))));
        vlSelf->wasmetal_core__DOT___006816_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006888_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006887_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf5f3f0f0ULL 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h934029c5__0)))))))));
        vlSelf->wasmetal_core__DOT___016249_ = (1U 
                                                & (0x450fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016256_))))));
    } else {
        vlSelf->wasmetal_core__DOT___016173_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016192_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016191_)))));
        vlSelf->wasmetal_core__DOT___006816_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006890_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006889_)))));
        vlSelf->wasmetal_core__DOT___016249_ = (1U 
                                                & (0x32ffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_h352b51f3__0))));
    }
    wasmetal_core__DOT___016172_ = (1U & (0x302fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h88996eeb__0)))));
    vlSelf->wasmetal_core__DOT___016277_ = (1U & (0xee0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016192_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h84de2564__0))))));
    vlSelf->wasmetal_core__DOT___016267_ = (1U & (0xee0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006890_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hc9b9f3ff__0))))));
    vlSelf->wasmetal_core__DOT___060224_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017945_))));
    vlSelf->wasmetal_core__DOT____Vcellout___134186___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___017895_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                        << 2U) | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                             >> 1U)) 
                                         << 1U)) | 
                                  (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036988_)))));
    vlSelf->wasmetal_core__DOT___036992_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___017895_)) 
                                                  | (IData)(wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___016496_ = (1U & (0x10000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 4U)) 
                                                   | (((IData)(wasmetal_core__DOT___058544_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058528_)))))));
    vlSelf->wasmetal_core__DOT___016474_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058544_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->wasmetal_core__DOT___058557_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___036996_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052585_))))));
    vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d 
        = (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051319_)))));
    vlSelf->wasmetal_core__DOT___051320_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016255_)))));
    wasmetal_core__DOT___057774_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___051319_))));
    vlSelf->wasmetal_core__DOT___005688_ = (1U & (IData)(
                                                         (0xdf5dcc00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                                  << 1U)) 
                                                              | (IData)(__VdfgTmp_hb9735979__0))))));
    vlSelf->wasmetal_core__DOT___005687_ = (1U & (IData)(
                                                         (0xdf5dcc00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                                  << 2U)) 
                                                              | (IData)(__VdfgTmp_hb9735979__0))))));
    vlSelf->wasmetal_core__DOT___058516_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058470_))));
    vlSelf->wasmetal_core__DOT___058515_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058492_))));
    vlSelf->__VdfgTmp_h4af9777a__0 = (((IData)(vlSelf->wasmetal_core__DOT___058492_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006821_));
    vlSelf->__VdfgTmp_h2327e099__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058468_));
    vlSelf->wasmetal_core__DOT___058451_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___016281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->__VdfgTmp_h8d40b9ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016313_));
    vlSelf->wasmetal_core__DOT___016357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016301_))));
    vlSelf->wasmetal_core__DOT___058441_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->wasmetal_core__DOT___058440_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016222_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006820_)))));
    vlSelf->wasmetal_core__DOT___058444_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___016262_))));
    vlSelf->wasmetal_core__DOT___016250_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006818_)
                                                ? (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016261_)))
                                                : (0xf0f5533U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___016262_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h3d212b86__0)))))));
    vlSelf->wasmetal_core__DOT___016336_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___016261_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h3d212b86__0))))));
    __VdfgTmp_hafce6df8__0 = (((IData)(wasmetal_core__DOT___016261_) 
                               << 1U) | (IData)(wasmetal_core__DOT___016262_));
    __VdfgTmp_h4c4dfcd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___016240_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                          << 1U) | 
                                         (1U & (0x5cU 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8655efce__0))))));
    vlSelf->wasmetal_core__DOT___058448_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___016274_))));
    __VdfgTmp_hbced8ce8__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 1U) | (IData)(wasmetal_core__DOT___006815_));
    __VdfgTmp_h7386a859__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___016241_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___016240_) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006888_)))));
    wasmetal_core__DOT___016312_ = (1U & (0xcdU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___016241_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___006888_)))));
    if (vlSelf->wasmetal_core__DOT___006818_) {
        vlSelf->wasmetal_core__DOT___016315_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h3d212b86__0))));
        vlSelf->wasmetal_core__DOT___016228_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___006889_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(__VdfgTmp_hc9b9f3ff__0))));
        vlSelf->wasmetal_core__DOT___016268_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016273_))));
        vlSelf->wasmetal_core__DOT___016300_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006820_)) 
                                                & (IData)(wasmetal_core__DOT___016312_));
    } else {
        vlSelf->wasmetal_core__DOT___016315_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016191_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h84de2564__0)))));
        vlSelf->wasmetal_core__DOT___016228_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___006890_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(__VdfgTmp_haf03c95c__0))));
        vlSelf->wasmetal_core__DOT___016268_ = (1U 
                                                & (0xf0f0aaccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___016274_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h19f5d4dc__0))))));
        vlSelf->wasmetal_core__DOT___016300_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006820_)) 
                                                & (IData)(wasmetal_core__DOT___016311_));
    }
    vlSelf->wasmetal_core__DOT___016348_ = (1U & (IData)(
                                                         (0xff00aaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016191_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h3d212b86__0))))))));
    vlSelf->wasmetal_core__DOT___016278_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(wasmetal_core__DOT___016281_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006818_)
                                                    ? 
                                                   (0x32U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___016219_))))
                                                    : 
                                                   (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016191_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___016190_)))))));
    vlSelf->__VdfgTmp_hb91597d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016220_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016219_)))));
    vlSelf->wasmetal_core__DOT___016342_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___016273_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h19f5d4dc__0))))));
    __VdfgTmp_he6980ace__0 = (((IData)(wasmetal_core__DOT___016273_) 
                               << 1U) | (IData)(wasmetal_core__DOT___016274_));
    __VdfgTmp_h8c714845__0 = (((IData)(wasmetal_core__DOT___016314_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___016247_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016313_)));
    vlSelf->__VdfgTmp_hf4bdf179__0 = (((IData)(wasmetal_core__DOT___016247_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006818_));
    vlSelf->__VdfgTmp_hce0a7704__0 = (((IData)(wasmetal_core__DOT___016314_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016247_));
    vlSelf->__VdfgTmp_h64b5570f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016247_));
    vlSelf->__VdfgTmp_h31cd2dad__0 = (((IData)(wasmetal_core__DOT___016227_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006818_));
    __VdfgTmp_hb7173042__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 1U) | (IData)(wasmetal_core__DOT___016227_));
    vlSelf->wasmetal_core__DOT____Vcellout___127565___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003809_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006400_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023475_)))));
    vlSelf->wasmetal_core__DOT___023479_ = ((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127582___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013712_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0db23397__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023596_)))));
    vlSelf->wasmetal_core__DOT___023600_ = ((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127475___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022805_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022804_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022803_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022802_)))) 
           ^ (((IData)(wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022770_)))));
    vlSelf->wasmetal_core__DOT___022774_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022805_)
                                                   ? (IData)(wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))));
    wasmetal_core__DOT___059133_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059127_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059126_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127494___O) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hd540c232__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0)))))))))));
    vlSelf->wasmetal_core__DOT___059163_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059105_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059104_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059103_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127487___O) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O) 
                                                                                >> 1U)) 
                                                                              | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))))))))))));
    wasmetal_core__DOT___059181_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059180_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059179_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0)))))))))));
    wasmetal_core__DOT___059194_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059190_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059189_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0)))))))))));
    vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034321_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034384_));
    vlSelf->wasmetal_core__DOT___071298_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071297_))));
    vlSelf->wasmetal_core__DOT___127877___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026697_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026630_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d));
    vlSelf->wasmetal_core__DOT___054402_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054404_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054398_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054400_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127928___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027167_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027100_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d));
    vlSelf->wasmetal_core__DOT___045469_ = ((IData)(vlSelf->wasmetal_core__DOT___045515_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045514_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045512_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045511_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045510_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045509_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045508_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045507_)
                                                       ? 
                                                      ((IData)(wasmetal_core__DOT___045506_)
                                                        ? 
                                                       ((IData)(wasmetal_core__DOT___045505_)
                                                         ? 
                                                        ((IData)(wasmetal_core__DOT___045504_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045503_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045523_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045522_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045521_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045520_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045519_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045518_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045517_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045516_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045513_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045502_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045478_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045489_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045492_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045493_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045494_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045495_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045496_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045497_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045498_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045499_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045479_))
                                                          : (IData)(wasmetal_core__DOT___045480_))
                                                         : (IData)(wasmetal_core__DOT___045481_))
                                                        : (IData)(wasmetal_core__DOT___045482_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045483_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045484_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045485_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045486_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045487_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045488_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045490_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045491_));
    vlSelf->wasmetal_core__DOT___045265_ = ((IData)(vlSelf->wasmetal_core__DOT___045311_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045310_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045308_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045307_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045306_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045305_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045304_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045303_)
                                                       ? 
                                                      ((IData)(wasmetal_core__DOT___045302_)
                                                        ? 
                                                       ((IData)(wasmetal_core__DOT___045301_)
                                                         ? 
                                                        ((IData)(wasmetal_core__DOT___045300_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045299_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045319_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045318_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045317_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045316_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045315_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045314_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045313_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045312_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045309_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045298_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045274_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045285_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045288_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045289_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045290_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045291_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045292_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045293_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045294_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045295_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045275_))
                                                          : (IData)(wasmetal_core__DOT___045276_))
                                                         : (IData)(wasmetal_core__DOT___045277_))
                                                        : (IData)(wasmetal_core__DOT___045278_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045279_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045280_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045281_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045282_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045283_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045284_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045286_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045287_));
    vlSelf->wasmetal_core__DOT___054401_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054403_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054397_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054399_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127911___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026967_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026900_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d));
    vlSelf->wasmetal_core__DOT___045073_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071124_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071123_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071122_))))))));
    vlSelf->wasmetal_core__DOT___045097_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071124_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071123_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071122_)))))))));
    vlSelf->wasmetal_core__DOT___045863_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                                  << 3U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc8d209ec__0))))));
    vlSelf->wasmetal_core__DOT___045887_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004388_)))))))));
    vlSelf->wasmetal_core__DOT___127894___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_he040c9e4__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026765_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d));
    vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034486_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128254___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030250_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030185_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d));
    vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027364_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b38__05d));
    vlSelf->__VdfgTmp_h85d5ffaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_h85c84d1a__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_h850cecd0__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O)));
    vlSelf->wasmetal_core__DOT___023199_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022476_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O))))));
    vlSelf->wasmetal_core__DOT___023197_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022478_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___023196_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022479_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            >> 3U))))));
    vlSelf->__VdfgTmp_h85009285__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                    >> 1U)));
    vlSelf->wasmetal_core__DOT___127428___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022480_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022536_));
    vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___051266_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O))))));
    vlSelf->wasmetal_core__DOT___024134_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___002961_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___058724_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058714_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058713_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)))))))))));
    vlSelf->wasmetal_core__DOT___058751_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058736_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058735_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127628___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127627___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)))))))))));
    vlSelf->wasmetal_core__DOT___127598___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023761_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023697_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d));
    vlSelf->__VdfgTmp_h94e3de73__0 = (((IData)(wasmetal_core__DOT___006815_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___006814_));
    vlSelf->wasmetal_core__DOT___058489_ = ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                            & (IData)(
                                                      (0xcdf0000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h352b51f3__0)))))));
    vlSelf->__VdfgTmp_h8cd41eba__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016172_));
    vlSelf->__VdfgTmp_h10570a51__0 = (((IData)(wasmetal_core__DOT___016172_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016171_));
    vlSelf->wasmetal_core__DOT___058469_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___006814_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006818_)))));
    vlSelf->wasmetal_core__DOT___134187___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036992_)));
    vlSelf->wasmetal_core__DOT___060165_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058557_))));
    vlSelf->wasmetal_core__DOT___018964_ = (1U & (0x80ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058557_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                           << 5U)) 
                                                                       | ((0x1cU 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                              << 1U)) 
                                                                          | ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O))))))) 
                                                             << 2U)) 
                                                         | (((IData)(wasmetal_core__DOT___058544_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___036996_)))))));
    vlSelf->wasmetal_core__DOT___057797_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017831_))));
    vlSelf->wasmetal_core__DOT___017141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017849_))));
    vlSelf->wasmetal_core__DOT___057784_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016258_))));
    vlSelf->wasmetal_core__DOT___057776_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017829_))));
    vlSelf->wasmetal_core__DOT___017017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017821_))));
    vlSelf->wasmetal_core__DOT___057811_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xefU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hedae78d9__0))))));
    vlSelf->wasmetal_core__DOT___057794_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017910_))));
    vlSelf->wasmetal_core__DOT___057816_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xefU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8599270c__0))))));
    vlSelf->wasmetal_core__DOT___057821_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017874_))));
    vlSelf->wasmetal_core__DOT___057863_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xefU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6ef172e0__0))))));
    vlSelf->wasmetal_core__DOT___057866_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017887_))));
    vlSelf->wasmetal_core__DOT___057872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017888_))));
    vlSelf->wasmetal_core__DOT___017113_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057877_))));
    vlSelf->wasmetal_core__DOT___057839_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057838_))));
    vlSelf->wasmetal_core__DOT___057854_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006947_))));
    vlSelf->wasmetal_core__DOT___057844_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006941_))));
    vlSelf->wasmetal_core__DOT___057848_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006943_))));
    vlSelf->wasmetal_core__DOT___057882_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006942_))));
    vlSelf->wasmetal_core__DOT___057892_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016288_))));
    vlSelf->wasmetal_core__DOT___057895_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016290_))));
    vlSelf->wasmetal_core__DOT___057886_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016289_))));
    vlSelf->wasmetal_core__DOT___057924_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057774_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b63__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058516_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b62__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058515_))));
    vlSelf->__VdfgTmp_h307b9eba__0 = (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2327e099__0)))))));
    vlSelf->wasmetal_core__DOT___058487_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2327e099__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006819_)))));
    vlSelf->wasmetal_core__DOT___058445_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->wasmetal_core__DOT___016392_ = (1U & (IData)(
                                                         (0xf5f0f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hafce6df8__0))))))));
    vlSelf->wasmetal_core__DOT___058455_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hafce6df8__0)))));
    vlSelf->wasmetal_core__DOT___016316_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hafce6df8__0)))));
    vlSelf->__VdfgTmp_hecea8d31__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h4c4dfcd4__0)));
    vlSelf->wasmetal_core__DOT___016299_ = (1U & (0x110f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h4c4dfcd4__0)))));
    vlSelf->wasmetal_core__DOT___058449_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->wasmetal_core__DOT___016331_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h7386a859__0)))));
    vlSelf->wasmetal_core__DOT___016354_ = ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006818_)
                                                ? (IData)(wasmetal_core__DOT___016312_)
                                                : (IData)(wasmetal_core__DOT___016311_)));
    if (vlSelf->wasmetal_core__DOT___006819_) {
        vlSelf->wasmetal_core__DOT___058490_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016281_))));
        vlSelf->wasmetal_core__DOT___058450_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016342_)))
                                                    : 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                                            << 1U) 
                                                           | (IData)(wasmetal_core__DOT___006814_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___058490_ = (1U 
                                                & (0xf0f000eeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016348_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___016171_)))))));
        vlSelf->wasmetal_core__DOT___058450_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hbced8ce8__0)))));
    }
    vlSelf->wasmetal_core__DOT___016328_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb91597d0__0)))));
    vlSelf->wasmetal_core__DOT___058502_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (0x3333f0f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016342_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___006814_))))))
                                                : (0x40U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hbced8ce8__0)))));
    vlSelf->wasmetal_core__DOT___016325_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_he6980ace__0)))));
    vlSelf->__VdfgTmp_h0d217f15__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he6980ace__0)));
    vlSelf->wasmetal_core__DOT___058511_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0x33aa0f0000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h8c714845__0)))))));
    vlSelf->wasmetal_core__DOT___058475_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & (IData)(
                                                      (0x3300aa000f0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h8c714845__0)))))));
    vlSelf->__VdfgTmp_h6fab7a0a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hce0a7704__0));
    vlSelf->__VdfgTmp_h76f112be__0 = (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h64b5570f__0));
    vlSelf->wasmetal_core__DOT___058427_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                        ? 
                                                       (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___016242_))
                                                        : 
                                                       (0xf0fff11U 
                                                        >> (IData)(__VdfgTmp_h7386a859__0))))) 
                                                  & (IData)(
                                                            (0xfff0fff0ff00ffddULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___016229_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016228_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h31cd2dad__0)))))))));
    vlSelf->wasmetal_core__DOT___058463_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___016229_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016228_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hb7173042__0))))))));
    vlSelf->__VdfgTmp_h4bc72baa__0 = (((IData)(wasmetal_core__DOT___016229_) 
                                       << 2U) | (IData)(__VdfgTmp_hb7173042__0));
    vlSelf->__VdfgTmp_hdd3525a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___016302_) 
                                       << 2U) | (IData)(__VdfgTmp_hb7173042__0));
    vlSelf->wasmetal_core__DOT___050111_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005855_))))));
    vlSelf->wasmetal_core__DOT___050095_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003809_))))));
    vlSelf->wasmetal_core__DOT___127553___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005982_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023479_));
    vlSelf->wasmetal_core__DOT___013826_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002034_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002030_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002028_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___013761_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002191_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002188_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002029_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002033_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127581___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___013756_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002028_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002027_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002031_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127581___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___127570___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013690_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023600_));
    vlSelf->wasmetal_core__DOT___127476___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022806_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022774_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hd540c232__0))));
    vlSelf->wasmetal_core__DOT___059164_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059135_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059134_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059133_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((8U 
                                                                               >> 
                                                                               ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O)) 
                                                                              | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0))))))))))))));
    vlSelf->wasmetal_core__DOT___059188_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059182_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059181_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h607e9020__0)))))))))));
    vlSelf->wasmetal_core__DOT___059199_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059195_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059194_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059193_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he0f48724__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h607e9020__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0)))))))))));
}
