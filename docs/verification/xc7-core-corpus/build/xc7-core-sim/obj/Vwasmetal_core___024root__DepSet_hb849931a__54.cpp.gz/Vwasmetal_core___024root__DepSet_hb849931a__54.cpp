#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__4(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__4\n"); );
    // Body
    vlSelf->__VdfgTmp_hfa0f79c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___004693_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004692_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004691_))));
    vlSelf->wasmetal_core__DOT___052264_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd35a9dc8__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052196_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha87e62b8__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b45__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052196_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha87e62b8__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd35a9dc8__0))))))));
    vlSelf->__VdfgTmp_h3fc388f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___004249_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004248_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004247_))));
    vlSelf->wasmetal_core__DOT___052263_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h31a231e1__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052261_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h807ad9d2__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b44__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052261_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h807ad9d2__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h31a231e1__0))))))));
    vlSelf->__VdfgTmp_ha15d8995__0 = (((IData)(vlSelf->wasmetal_core__DOT___004175_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004174_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004173_))));
    vlSelf->wasmetal_core__DOT___052507_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc1c0d33f__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052498_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h456da093__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b43__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052498_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h456da093__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc1c0d33f__0))))))));
    vlSelf->__VdfgTmp_he2dbc386__0 = (((IData)(vlSelf->wasmetal_core__DOT___003581_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003580_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003579_))));
    vlSelf->wasmetal_core__DOT___052506_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h01d0ee79__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052494_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc5f6f937__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b42__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052494_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc5f6f937__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h01d0ee79__0))))))));
    vlSelf->__VdfgTmp_haaa3ad0b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003507_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003506_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003505_))));
    vlSelf->wasmetal_core__DOT___052138_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he23a6b26__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052135_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd28cbf2a__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b41__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052135_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd28cbf2a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he23a6b26__0))))))));
    vlSelf->__VdfgTmp_h3ec183f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___003655_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003654_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003653_))));
    vlSelf->wasmetal_core__DOT___052137_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h07a3b670__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052112_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb4397905__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b40__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052112_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb4397905__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h07a3b670__0))))))));
    vlSelf->__VdfgTmp_ha7c76017__0 = (((IData)(vlSelf->wasmetal_core__DOT___003803_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003802_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003801_))));
    vlSelf->wasmetal_core__DOT___052417_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he0dafd81__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052410_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hce8a559f__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b39__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052410_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hce8a559f__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he0dafd81__0))))))));
    vlSelf->__VdfgTmp_h97352ffe__0 = (((IData)(vlSelf->wasmetal_core__DOT___004619_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004618_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004617_))));
    vlSelf->wasmetal_core__DOT___052416_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h2b977022__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052406_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc5320df5__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b38__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052406_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc5320df5__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2b977022__0))))))));
    vlSelf->__VdfgTmp_h01ca3900__0 = (((IData)(vlSelf->wasmetal_core__DOT___004471_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004470_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004469_))));
    vlSelf->wasmetal_core__DOT___052508_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd438e6c0__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052501_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd6e95fa8__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b37__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052501_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd6e95fa8__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd438e6c0__0))))))));
    vlSelf->__VdfgTmp_h2bc911a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___004397_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004396_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004395_))));
    vlSelf->wasmetal_core__DOT___052505_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h50f5670e__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052490_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8fdaff69__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b36__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052490_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8fdaff69__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h50f5670e__0))))))));
    vlSelf->__VdfgTmp_hc61dfdcc__0 = (((IData)(vlSelf->wasmetal_core__DOT___004545_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004544_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004543_))));
    vlSelf->wasmetal_core__DOT___052190_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he2ad86dc__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052150_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb26c7187__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b35__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052150_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb26c7187__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he2ad86dc__0))))))));
    vlSelf->__VdfgTmp_h33ea4c85__0 = (((IData)(vlSelf->wasmetal_core__DOT___004767_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004766_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004765_))));
    vlSelf->wasmetal_core__DOT___052192_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h4cb51258__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052181_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf3a0142d__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b34__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052181_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf3a0142d__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h4cb51258__0))))))));
    vlSelf->__VdfgTmp_heeded769__0 = (((IData)(vlSelf->wasmetal_core__DOT___004841_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004840_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004839_))));
    vlSelf->wasmetal_core__DOT___052191_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h319b52f0__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052154_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h13262e9c__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b33__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052154_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h13262e9c__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h319b52f0__0))))))));
    vlSelf->__VdfgTmp_h2f17a8a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___003297_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000698_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___000697_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003295_))));
    vlSelf->wasmetal_core__DOT___052418_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h0683198f__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052414_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1512c46f__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b32__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052414_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h1512c46f__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h0683198f__0))))))));
    vlSelf->__VdfgTmp_h51a3fd4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___003217_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000674_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___000673_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003215_))));
    vlSelf->wasmetal_core__DOT___052235_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h7752095d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052230_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h149fa621__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b31__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052230_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h149fa621__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h7752095d__0))))))));
    vlSelf->__VdfgTmp_hbfbeb842__0 = (((IData)(vlSelf->wasmetal_core__DOT___005627_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000684_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___000683_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005625_))));
    vlSelf->wasmetal_core__DOT___052256_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he7820a50__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052205_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6a684ffb__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b1__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052205_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6a684ffb__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he7820a50__0))))))));
    vlSelf->__VdfgTmp_h37d1cc77__0 = (((IData)(vlSelf->wasmetal_core__DOT___003279_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001861_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001860_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003277_))));
    vlSelf->wasmetal_core__DOT___052558_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he9245313__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052540_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h173fc958__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b0__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052540_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h173fc958__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he9245313__0))))))));
    vlSelf->__VdfgTmp_hc5249891__0 = (((IData)(vlSelf->wasmetal_core__DOT___003199_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001837_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001836_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003197_))));
    vlSelf->wasmetal_core__DOT___028966_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052236_))));
    vlSelf->wasmetal_core__DOT___067098_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b25__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b25__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___028965_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052237_))));
    vlSelf->wasmetal_core__DOT___067024_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b24__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x18U))))));
    vlSelf->wasmetal_core__DOT___028962_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052403_))));
    vlSelf->wasmetal_core__DOT___066792_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b21__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b21__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x15U))))));
    vlSelf->wasmetal_core__DOT___028961_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052402_))));
    vlSelf->wasmetal_core__DOT___066709_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b20__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b20__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___028958_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052560_))));
    vlSelf->wasmetal_core__DOT___066547_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b18__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b18__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x12U))))));
    vlSelf->wasmetal_core__DOT___028957_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052559_))));
    vlSelf->wasmetal_core__DOT___066466_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b17__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b17__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___028956_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052529_))));
    vlSelf->wasmetal_core__DOT___066384_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b16__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x10U))))));
    vlSelf->wasmetal_core__DOT___052295_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052276_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052275_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbad05108__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd77c56a5__0)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf6cb6b1e__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b893d79__0)))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h61430f62__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___048038_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004784_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004783_)));
    vlSelf->__VdfgTmp_h5877aba2__0 = (((IData)(vlSelf->wasmetal_core__DOT___004783_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004784_));
    vlSelf->wasmetal_core__DOT___062330_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b66__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b66__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b66__05d)))))));
    vlSelf->wasmetal_core__DOT___005390_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004926_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004925_)));
    vlSelf->__VdfgTmp_h9c9d0618__0 = (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004926_));
    vlSelf->__VdfgTmp_h79a44c81__0 = (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004802_));
    vlSelf->wasmetal_core__DOT___048178_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004944_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004943_)));
    vlSelf->__VdfgTmp_h79b790c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004944_));
    vlSelf->wasmetal_core__DOT___048197_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003450_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003449_)));
    vlSelf->__VdfgTmp_hfd746550__0 = (((IData)(vlSelf->wasmetal_core__DOT___003449_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003450_));
    vlSelf->wasmetal_core__DOT___052827_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003449_))));
    vlSelf->__VdfgTmp_h45475158__0 = (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003468_));
    vlSelf->wasmetal_core__DOT___048153_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004710_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004709_)));
    vlSelf->__VdfgTmp_hdb8b9d9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004710_));
    vlSelf->wasmetal_core__DOT___062333_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b67__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b67__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b67__05d)))))));
    vlSelf->wasmetal_core__DOT___048031_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004488_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004487_)));
    vlSelf->__VdfgTmp_h9699bb18__0 = (((IData)(vlSelf->wasmetal_core__DOT___004487_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004488_));
    vlSelf->wasmetal_core__DOT___005400_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004994_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004993_)));
    vlSelf->__VdfgTmp_h928bb96c__0 = (((IData)(vlSelf->wasmetal_core__DOT___004993_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004994_));
    vlSelf->wasmetal_core__DOT___005410_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004858_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004857_)));
    vlSelf->__VdfgTmp_hf0d36e17__0 = (((IData)(vlSelf->wasmetal_core__DOT___004857_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004858_));
    vlSelf->wasmetal_core__DOT___005420_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005266_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005265_)));
    vlSelf->__VdfgTmp_h778ea1a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005265_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005266_));
    vlSelf->wasmetal_core__DOT___048157_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004340_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004339_)));
    vlSelf->__VdfgTmp_h1d34c5b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___004339_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004340_));
    vlSelf->wasmetal_core__DOT___005457_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005198_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005197_)));
    vlSelf->__VdfgTmp_ha95ffc90__0 = (((IData)(vlSelf->wasmetal_core__DOT___005197_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005198_));
    vlSelf->wasmetal_core__DOT___048012_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004414_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004413_)));
    vlSelf->__VdfgTmp_h92dd6962__0 = (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004414_));
    vlSelf->__VdfgTmp_h103d8e23__0 = (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004728_));
    vlSelf->__VdfgTmp_hbbacc71f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004506_));
    vlSelf->wasmetal_core__DOT___052829_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004339_))));
    vlSelf->__VdfgTmp_h6b621180__0 = (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004358_));
    vlSelf->__VdfgTmp_h880089dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004432_));
    vlSelf->wasmetal_core__DOT___052819_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004993_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005011_))));
    vlSelf->wasmetal_core__DOT___048259_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005012_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005011_)));
    vlSelf->__VdfgTmp_h5f30aa50__0 = (((IData)(vlSelf->wasmetal_core__DOT___005011_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005012_));
    vlSelf->wasmetal_core__DOT___069909_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b91__05d))));
    vlSelf->wasmetal_core__DOT___062399_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b91__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b91__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b91__05d)))))));
    vlSelf->wasmetal_core__DOT___048184_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004876_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004875_)));
    vlSelf->__VdfgTmp_hc83e3035__0 = (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004876_));
    vlSelf->wasmetal_core__DOT___052822_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004857_))));
    vlSelf->wasmetal_core__DOT___048239_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005284_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005283_)));
    vlSelf->__VdfgTmp_h4e776e09__0 = (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005284_));
    vlSelf->wasmetal_core__DOT___048263_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003524_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003523_)));
    vlSelf->__VdfgTmp_h1b5c1c30__0 = (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003524_));
    vlSelf->wasmetal_core__DOT___050352_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005216_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005198_))));
    vlSelf->wasmetal_core__DOT___048172_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005216_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005215_)));
    vlSelf->__VdfgTmp_h77d6a635__0 = (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005216_));
    vlSelf->wasmetal_core__DOT___048185_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004118_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004117_)));
    vlSelf->__VdfgTmp_hc2378e95__0 = (((IData)(vlSelf->wasmetal_core__DOT___004117_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004118_));
    vlSelf->wasmetal_core__DOT___048234_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004192_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004191_)));
    vlSelf->__VdfgTmp_h3e014765__0 = (((IData)(vlSelf->wasmetal_core__DOT___004191_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004192_));
    vlSelf->__VdfgTmp_h1dfe6e3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003542_));
    vlSelf->wasmetal_core__DOT___048189_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004636_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004635_)));
    vlSelf->__VdfgTmp_hb797ade1__0 = (((IData)(vlSelf->wasmetal_core__DOT___004635_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004636_));
    vlSelf->wasmetal_core__DOT___052812_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004117_))));
    vlSelf->__VdfgTmp_hc85d0f69__0 = (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004136_));
    vlSelf->wasmetal_core__DOT___052813_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004191_))));
    vlSelf->__VdfgTmp_h9d0797f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004210_));
    vlSelf->__VdfgTmp_he9b54a3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004654_));
    vlSelf->wasmetal_core__DOT___048135_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003234_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003233_)));
    vlSelf->__VdfgTmp_h5b4e7e80__0 = (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003234_));
    vlSelf->wasmetal_core__DOT___005447_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005334_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005333_)));
    vlSelf->__VdfgTmp_hb476a254__0 = (((IData)(vlSelf->wasmetal_core__DOT___005333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005334_));
    vlSelf->__VdfgTmp_h5702c3be__0 = (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003252_));
    vlSelf->wasmetal_core__DOT___051953_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005352_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005334_))));
    vlSelf->wasmetal_core__DOT___052820_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005351_))));
    vlSelf->wasmetal_core__DOT___048245_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005352_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005351_)));
    vlSelf->__VdfgTmp_h8511382f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005351_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005352_));
    vlSelf->wasmetal_core__DOT___069868_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b89__05d))));
    vlSelf->wasmetal_core__DOT___062394_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b89__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b89__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b89__05d)))))));
    vlSelf->wasmetal_core__DOT___048230_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003598_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003597_)));
    vlSelf->__VdfgTmp_hc0be46f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___003597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003598_));
    vlSelf->wasmetal_core__DOT___062351_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b73__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 8U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b73__05d)))))));
    vlSelf->wasmetal_core__DOT___069510_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069506_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069505_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b73__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 7U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->wasmetal_core__DOT___069509_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 6U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 9U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___052828_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003597_))));
    vlSelf->__VdfgTmp_hacafc5c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003616_));
    vlSelf->wasmetal_core__DOT___048016_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004044_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004043_)));
    vlSelf->__VdfgTmp_h2e498b5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004044_));
    vlSelf->__VdfgTmp_h0fc0fcd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004062_));
    vlSelf->wasmetal_core__DOT___005467_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003902_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003901_)));
    vlSelf->__VdfgTmp_h063ae0f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003902_));
    vlSelf->wasmetal_core__DOT___005477_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003382_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003381_)));
    vlSelf->__VdfgTmp_ha36008d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003382_));
    vlSelf->wasmetal_core__DOT___005487_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003314_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003313_)));
    vlSelf->__VdfgTmp_hab2bfea3__0 = (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003314_));
    vlSelf->wasmetal_core__DOT___048139_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003828_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003827_)));
    vlSelf->__VdfgTmp_hc135e20a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003828_));
    vlSelf->wasmetal_core__DOT___052665_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003828_))));
    vlSelf->__VdfgTmp_hbe45befc__0 = (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003846_));
    vlSelf->wasmetal_core__DOT___048043_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003920_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003919_)));
    vlSelf->__VdfgTmp_h74dbdf51__0 = (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003920_));
    vlSelf->wasmetal_core__DOT___048060_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003400_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003399_)));
    vlSelf->__VdfgTmp_ha6dc66a3__0 = (((IData)(vlSelf->wasmetal_core__DOT___003399_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003400_));
    vlSelf->wasmetal_core__DOT___052811_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003399_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003313_))))));
    vlSelf->wasmetal_core__DOT___048047_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003332_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003331_)));
    vlSelf->__VdfgTmp_h0f5e432a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003332_));
    vlSelf->wasmetal_core__DOT___048075_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004266_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004265_)));
    vlSelf->__VdfgTmp_he315da1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___004265_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004266_));
    vlSelf->wasmetal_core__DOT___052815_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004265_))));
    vlSelf->__VdfgTmp_hcbd0c1b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004284_));
    vlSelf->wasmetal_core__DOT___048023_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003151_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003150_)));
    vlSelf->__VdfgTmp_hd0bdda62__0 = (((IData)(vlSelf->wasmetal_core__DOT___003150_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003151_));
    vlSelf->wasmetal_core__DOT___005437_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005062_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005061_)));
    vlSelf->__VdfgTmp_h24206284__0 = (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005062_));
    vlSelf->__VdfgTmp_hffad8cfa__0 = (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003172_));
    vlSelf->wasmetal_core__DOT___048196_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003746_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003745_)));
    vlSelf->__VdfgTmp_h477043a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___003745_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003746_));
    vlSelf->wasmetal_core__DOT___051941_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005080_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005062_))));
    vlSelf->wasmetal_core__DOT___048176_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005080_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005079_)));
    vlSelf->__VdfgTmp_h3ac48b87__0 = (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005080_));
    vlSelf->wasmetal_core__DOT___069847_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b88__05d))));
    vlSelf->wasmetal_core__DOT___062392_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b88__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b88__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x17U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b88__05d)))))));
    vlSelf->__VdfgTmp_h350dca3c__0 = (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003764_));
    vlSelf->wasmetal_core__DOT___048011_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003970_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003969_)));
    vlSelf->__VdfgTmp_hf3cb0d91__0 = (((IData)(vlSelf->wasmetal_core__DOT___003969_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003970_));
    vlSelf->wasmetal_core__DOT___052809_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003969_))));
    vlSelf->__VdfgTmp_h154ca593__0 = (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003988_));
    vlSelf->wasmetal_core__DOT___052085_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052062_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052061_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052060_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h06d51d42__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h56438591__0)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0b6168e4__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h57451afb__0)))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed1d041c__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___052084_ = (1U & (IData)(
                                                         (0xac00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052080_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052079_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052078_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052077_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha5352532__0)))))))))));
    vlSelf->wasmetal_core__DOT___052371_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052355_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052354_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052353_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc39d0419__0)))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcd3797e9__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xac00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052345_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052344_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052343_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052342_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h14a07dbf__0)))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8b2f01bd__0)))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd9daf5f7__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___047990_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005582_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005581_)));
    vlSelf->__VdfgTmp_hbd4ae96e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005582_));
    vlSelf->wasmetal_core__DOT___048067_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004562_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004561_)));
    vlSelf->__VdfgTmp_hce00e764__0 = (((IData)(vlSelf->wasmetal_core__DOT___004561_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004562_));
    vlSelf->wasmetal_core__DOT___052808_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004561_))));
    vlSelf->__VdfgTmp_h903282ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004580_));
    vlSelf->wasmetal_core__DOT___048004_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005600_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005599_)));
    vlSelf->__VdfgTmp_h66a2df13__0 = (((IData)(vlSelf->wasmetal_core__DOT___005599_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005600_));
    vlSelf->wasmetal_core__DOT___048696_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003672_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003671_)));
    vlSelf->__VdfgTmp_h5f949c7c__0 = (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003672_));
    vlSelf->__VdfgTmp_h4b62075b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003690_));
    vlSelf->wasmetal_core__DOT___005497_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005130_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005129_)));
    vlSelf->__VdfgTmp_hb797e152__0 = (((IData)(vlSelf->wasmetal_core__DOT___005129_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005130_));
    vlSelf->wasmetal_core__DOT___048071_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005148_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005147_)));
    vlSelf->__VdfgTmp_h26cb2e9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005148_));
    vlSelf->__VdfgTmp_h965c3061__0 = (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005636_));
    vlSelf->wasmetal_core__DOT___034342_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001330_))));
    vlSelf->__VdfgTmp_h39540d35__0 = (((IData)(vlSelf->wasmetal_core__DOT___001165_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001164_));
    vlSelf->wasmetal_core__DOT___052821_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005265_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001169_))));
    vlSelf->wasmetal_core__DOT___005455_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005244_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001169_)));
    vlSelf->__VdfgTmp_hf266c674__0 = (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005244_));
    vlSelf->wasmetal_core__DOT___034341_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001169_))));
    vlSelf->wasmetal_core__DOT___069197_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x1dU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_hffec0e42__0 = (((IData)(vlSelf->wasmetal_core__DOT___001143_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001142_));
    vlSelf->wasmetal_core__DOT___045151_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001330_)))))))));
    vlSelf->wasmetal_core__DOT___045175_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001330_)))))))));
    vlSelf->wasmetal_core__DOT___005418_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005312_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001147_)));
    vlSelf->__VdfgTmp_h26fdb0d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005312_));
    vlSelf->wasmetal_core__DOT___034340_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001147_))));
    vlSelf->wasmetal_core__DOT___069132_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x1bU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))))));
    vlSelf->__VdfgTmp_h15e8b450__0 = (((IData)(vlSelf->wasmetal_core__DOT___001121_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001120_));
    vlSelf->__VdfgTmp_h14b4bf2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___052189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052188_));
    vlSelf->wasmetal_core__DOT___052770_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001125_))));
    vlSelf->wasmetal_core__DOT___005408_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004904_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001125_)));
    vlSelf->__VdfgTmp_hc23ff14f__0 = (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004904_));
    vlSelf->wasmetal_core__DOT___034339_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001125_))));
    vlSelf->wasmetal_core__DOT___069083_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069081_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069080_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x1aU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))))));
    vlSelf->__VdfgTmp_h638471cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___001099_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001098_));
    vlSelf->__VdfgTmp_hbd97d07b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___004904_)));
    vlSelf->__VdfgTmp_he56eea3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005040_));
    vlSelf->wasmetal_core__DOT___034337_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001103_))));
    vlSelf->wasmetal_core__DOT___069053_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b59__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x1aU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_h82a219c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___001077_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001076_));
    vlSelf->wasmetal_core__DOT___045150_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001103_)))))))));
    vlSelf->wasmetal_core__DOT___045174_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001081_)))))))));
    vlSelf->wasmetal_core__DOT___005388_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004972_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001081_)));
    vlSelf->__VdfgTmp_h99cf87be__0 = (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004972_));
    vlSelf->wasmetal_core__DOT___034336_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001081_))));
    vlSelf->wasmetal_core__DOT___069004_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x19U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_h60872440__0 = (((IData)(vlSelf->wasmetal_core__DOT___001055_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001054_));
    vlSelf->__VdfgTmp_hbd712dd8__0 = (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005380_));
    vlSelf->wasmetal_core__DOT___034335_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001059_))));
    vlSelf->wasmetal_core__DOT___068955_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b57__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x18U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_h881dfff7__0 = (((IData)(vlSelf->wasmetal_core__DOT___001033_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001032_));
    vlSelf->__VdfgTmp_hfe9e3bd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___004972_)));
    vlSelf->__VdfgTmp_hb3e18d1b__0 = (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001037_));
    vlSelf->__VdfgTmp_hd5ee5b41__0 = (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005108_));
    vlSelf->wasmetal_core__DOT___034334_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001037_))));
    vlSelf->wasmetal_core__DOT___068887_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068885_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x16U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d)))))))));
    vlSelf->__VdfgTmp_h69848182__0 = (((IData)(vlSelf->wasmetal_core__DOT___001011_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001010_));
    vlSelf->wasmetal_core__DOT___045172_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001015_)))))))));
    vlSelf->__VdfgTmp_ha04b46b6__0 = (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005176_));
    vlSelf->wasmetal_core__DOT___034333_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001015_))));
    vlSelf->wasmetal_core__DOT___068839_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068838_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068837_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x15U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d)))))))));
    vlSelf->__VdfgTmp_hf825dcba__0 = (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003876_));
    vlSelf->wasmetal_core__DOT___034329_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000927_))));
    vlSelf->__VdfgTmp_hd7f74d59__0 = (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004092_));
    vlSelf->wasmetal_core__DOT___034328_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000897_))));
    vlSelf->__VdfgTmp_h426f01c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000989_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000988_));
    vlSelf->__VdfgTmp_h23d702b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___052449_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052448_));
    vlSelf->wasmetal_core__DOT___005485_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003360_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000993_)));
    vlSelf->__VdfgTmp_h59798d13__0 = (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003360_));
    vlSelf->wasmetal_core__DOT___034332_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000993_))));
    vlSelf->wasmetal_core__DOT___068809_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x15U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___052766_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000927_))));
    vlSelf->wasmetal_core__DOT___045146_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003876_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000927_)))))))));
    vlSelf->wasmetal_core__DOT___045170_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003876_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000927_)))))))));
    vlSelf->__VdfgTmp_hef5b3f20__0 = (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004314_));
    vlSelf->wasmetal_core__DOT___034326_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000896_))));
    vlSelf->__VdfgTmp_ha7c65fb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000977_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000976_));
    vlSelf->__VdfgTmp_h92d5757b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003360_)));
    vlSelf->wasmetal_core__DOT___005475_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003428_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000981_)));
    vlSelf->__VdfgTmp_h4b249985__0 = (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003428_));
    vlSelf->wasmetal_core__DOT___034331_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000981_))));
    vlSelf->wasmetal_core__DOT___068739_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068738_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d)))))))));
    vlSelf->__VdfgTmp_hfec86816__0 = (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004018_));
    vlSelf->wasmetal_core__DOT___034325_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000873_))));
    vlSelf->__VdfgTmp_h3ff94b24__0 = (((IData)(vlSelf->wasmetal_core__DOT___001324_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001323_));
    vlSelf->__VdfgTmp_h7b969d91__0 = (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003876_)));
    vlSelf->wasmetal_core__DOT___052767_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000926_))));
    vlSelf->wasmetal_core__DOT___045147_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003360_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000993_)))))))));
    vlSelf->wasmetal_core__DOT___045171_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000926_)))))))));
    vlSelf->wasmetal_core__DOT___005465_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003948_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000926_)));
    vlSelf->__VdfgTmp_h5d0edfe8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003948_));
    vlSelf->wasmetal_core__DOT___034330_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000926_))));
    vlSelf->wasmetal_core__DOT___068695_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068692_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x12U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d)))))))));
    vlSelf->__VdfgTmp_h73e9a4a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___004018_)));
    vlSelf->__VdfgTmp_h97b1be8c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003720_));
    vlSelf->wasmetal_core__DOT___034324_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000872_))));
    vlSelf->wasmetal_core__DOT___045145_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004684_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004018_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000873_)))))))));
    vlSelf->wasmetal_core__DOT___045169_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004018_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004684_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000849_)))))))));
    vlSelf->__VdfgTmp_h2cbbdbef__0 = (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004684_));
    vlSelf->wasmetal_core__DOT___034323_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000849_))));
    vlSelf->__VdfgTmp_h1fd76cb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004240_));
    vlSelf->wasmetal_core__DOT___034322_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000848_))));
    vlSelf->__VdfgTmp_ha17b8b2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___004684_)));
    vlSelf->__VdfgTmp_h598b279f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004166_));
    vlSelf->wasmetal_core__DOT___034321_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000824_))));
    vlSelf->wasmetal_core__DOT___045144_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000824_)))))))));
    vlSelf->wasmetal_core__DOT___045168_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000825_)))))))));
    vlSelf->__VdfgTmp_h8d1b60d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003572_));
    vlSelf->wasmetal_core__DOT___034320_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000825_))));
    vlSelf->__VdfgTmp_h38fb75d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003498_));
    vlSelf->wasmetal_core__DOT___034319_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000796_))));
    vlSelf->__VdfgTmp_had3e30f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003498_)));
    vlSelf->__VdfgTmp_hfe166c9c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003646_));
    vlSelf->wasmetal_core__DOT___034318_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000795_))));
    vlSelf->wasmetal_core__DOT___052764_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000849_)))))))));
    vlSelf->wasmetal_core__DOT___045143_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003498_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000796_)))))))));
    vlSelf->wasmetal_core__DOT___045167_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003498_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000796_)))))))));
    vlSelf->__VdfgTmp_h0ee6a0be__0 = (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003794_));
    vlSelf->wasmetal_core__DOT___034317_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000772_))));
    vlSelf->__VdfgTmp_h94bf9d34__0 = (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004610_));
    vlSelf->wasmetal_core__DOT___034315_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000771_))));
    vlSelf->__VdfgTmp_hf21c6828__0 = (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003794_)));
    vlSelf->__VdfgTmp_h58f52bdc__0 = (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004462_));
    vlSelf->wasmetal_core__DOT___034314_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000747_))));
    vlSelf->wasmetal_core__DOT___045142_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004388_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000747_)))))))));
    vlSelf->wasmetal_core__DOT___045166_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004388_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000748_)))))))));
    vlSelf->__VdfgTmp_hcf95a844__0 = (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004388_));
    vlSelf->wasmetal_core__DOT___034313_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000748_))));
    vlSelf->__VdfgTmp_h20a4ea67__0 = (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004536_));
    vlSelf->wasmetal_core__DOT___034312_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000723_))));
    vlSelf->__VdfgTmp_hc8d209ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___004388_)));
    vlSelf->__VdfgTmp_hf98ad324__0 = (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004758_));
    vlSelf->wasmetal_core__DOT___034311_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000724_))));
    vlSelf->wasmetal_core__DOT___045141_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000724_)))))))));
    vlSelf->wasmetal_core__DOT___045165_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000724_)))))))));
    vlSelf->__VdfgTmp_h84433958__0 = (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004832_));
    vlSelf->wasmetal_core__DOT___034310_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000694_))));
    vlSelf->__VdfgTmp_hd2ae5a25__0 = (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003288_));
    vlSelf->wasmetal_core__DOT___034309_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000693_))));
    vlSelf->__VdfgTmp_hdb6fbe09__0 = (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003288_)));
    vlSelf->wasmetal_core__DOT___052765_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000724_)))))))));
    vlSelf->__VdfgTmp_ha7f22436__0 = (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000665_));
    vlSelf->__VdfgTmp_h4bbfe337__0 = (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003208_));
    vlSelf->wasmetal_core__DOT___034308_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000665_))));
    vlSelf->wasmetal_core__DOT___052818_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005617_))));
    vlSelf->wasmetal_core__DOT___028485_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005617_))));
    vlSelf->wasmetal_core__DOT___048006_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005618_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005617_)));
    vlSelf->__VdfgTmp_h3edf8090__0 = (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005618_));
    vlSelf->wasmetal_core__DOT___052583_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02ewide))));
    vlSelf->__VdfgTmp_hb653ab3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000654_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000653_));
    vlSelf->wasmetal_core__DOT___028972_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052234_))));
    vlSelf->wasmetal_core__DOT___028660_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052234_))));
    vlSelf->wasmetal_core__DOT___054035_ = (1U & (0xb00bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b30__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b31__05d))))));
    vlSelf->wasmetal_core__DOT___051951_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005600_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005582_)))))))));
    vlSelf->wasmetal_core__DOT___028484_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000658_))));
    vlSelf->wasmetal_core__DOT___048169_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005232_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000658_)));
    vlSelf->__VdfgTmp_h5c9b01b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005232_));
    vlSelf->wasmetal_core__DOT___067444_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0x1dU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_h3063303a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000632_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000631_));
    vlSelf->wasmetal_core__DOT___028970_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052233_))));
    vlSelf->wasmetal_core__DOT___028658_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052233_))));
    vlSelf->wasmetal_core__DOT___044537_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005617_)))))))));
    vlSelf->wasmetal_core__DOT___044549_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005617_)))))))));
    vlSelf->wasmetal_core__DOT___028482_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000636_))));
    vlSelf->wasmetal_core__DOT___048240_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005300_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000636_)));
    vlSelf->__VdfgTmp_hc454ae75__0 = (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005300_));
    vlSelf->wasmetal_core__DOT___067396_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b29__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b29__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x1dU))))));
    vlSelf->__VdfgTmp_h69cbf44b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000610_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000609_));
    vlSelf->wasmetal_core__DOT___028969_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052232_))));
    vlSelf->__VdfgTmp_h7bad9dec__0 = (((IData)(vlSelf->wasmetal_core__DOT___052233_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052232_));
    vlSelf->wasmetal_core__DOT___028657_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052232_))));
    vlSelf->__VdfgTmp_h4c543443__0 = (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000614_)));
    vlSelf->wasmetal_core__DOT___045139_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004892_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000636_)))))))));
    vlSelf->wasmetal_core__DOT___028481_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000614_))));
    vlSelf->wasmetal_core__DOT___048181_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004892_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000614_)));
    vlSelf->__VdfgTmp_hb30bed30__0 = (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004892_));
    vlSelf->wasmetal_core__DOT___067295_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b28__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b28__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x1cU))))));
    vlSelf->__VdfgTmp_h81d9a883__0 = (((IData)(vlSelf->wasmetal_core__DOT___000588_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000587_));
    vlSelf->wasmetal_core__DOT___028968_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052567_))));
    vlSelf->wasmetal_core__DOT___028656_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052567_))));
    vlSelf->wasmetal_core__DOT___054028_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b31__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b27__05d))))));
    vlSelf->wasmetal_core__DOT___028480_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000592_))));
    vlSelf->wasmetal_core__DOT___048256_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005028_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000592_)));
    vlSelf->__VdfgTmp_hc7b7ff9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005028_));
    vlSelf->wasmetal_core__DOT___067252_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b27__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b27__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x1bU))))));
    vlSelf->__VdfgTmp_h1d8dd092__0 = (((IData)(vlSelf->wasmetal_core__DOT___000561_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000560_));
    vlSelf->wasmetal_core__DOT___028967_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052566_))));
    vlSelf->wasmetal_core__DOT___028655_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052566_))));
    vlSelf->wasmetal_core__DOT___051952_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005012_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004994_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004960_)))))))));
    vlSelf->wasmetal_core__DOT___044546_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000592_)))))))));
    vlSelf->wasmetal_core__DOT___044558_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000565_)))))))));
    vlSelf->wasmetal_core__DOT___045443_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052566_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052232_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052567_)))))))));
    vlSelf->wasmetal_core__DOT___045455_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052232_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052567_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052566_)))))))));
    vlSelf->wasmetal_core__DOT___028479_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000565_))));
    vlSelf->wasmetal_core__DOT___048179_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004960_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000565_)));
    vlSelf->__VdfgTmp_h2c2ac443__0 = (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004960_));
    vlSelf->wasmetal_core__DOT___067142_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0x19U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_h0989e186__0 = (((IData)(vlSelf->wasmetal_core__DOT___000539_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000538_));
    vlSelf->wasmetal_core__DOT___028654_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005368_))));
    vlSelf->__VdfgTmp_hb9b6103f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b25__05d));
    vlSelf->wasmetal_core__DOT___052664_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005148_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005130_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004876_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004858_)))))))));
    vlSelf->wasmetal_core__DOT___045159_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000565_)))))))));
    vlSelf->wasmetal_core__DOT___028478_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000543_))));
    vlSelf->wasmetal_core__DOT___048242_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005368_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000543_)));
    vlSelf->__VdfgTmp_h27758395__0 = (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005368_));
    vlSelf->__VdfgTmp_h93789414__0 = (((IData)(vlSelf->wasmetal_core__DOT___000517_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000516_));
    vlSelf->wasmetal_core__DOT___053997_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b26__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005096_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b24__05d))))));
    vlSelf->wasmetal_core__DOT___028653_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005096_))));
    vlSelf->__VdfgTmp_hf95886a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000521_));
    vlSelf->wasmetal_core__DOT___028477_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005096_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000521_))));
    vlSelf->wasmetal_core__DOT___048173_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005096_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000521_)));
    vlSelf->__VdfgTmp_h09cdcbfb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005096_));
    vlSelf->__VdfgTmp_h62980089__0 = (((IData)(vlSelf->wasmetal_core__DOT___000495_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000494_));
    vlSelf->wasmetal_core__DOT___028964_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052527_))));
    vlSelf->wasmetal_core__DOT___028652_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052527_))));
    vlSelf->wasmetal_core__DOT___044557_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000499_)))))))));
    vlSelf->wasmetal_core__DOT___045454_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052527_)))))))));
    vlSelf->__VdfgTmp_hbaa2fe71__0 = (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000499_));
    vlSelf->wasmetal_core__DOT___028476_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000499_))));
    vlSelf->wasmetal_core__DOT___048068_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005164_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000499_)));
    vlSelf->__VdfgTmp_heec1cc96__0 = (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005164_));
    vlSelf->wasmetal_core__DOT___066953_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b23__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b23__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x17U))))));
    vlSelf->__VdfgTmp_hb2af30db__0 = (((IData)(vlSelf->wasmetal_core__DOT___000473_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000472_));
    vlSelf->__VdfgTmp_he4fb154e__0 = (((IData)(vlSelf->wasmetal_core__DOT___052528_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052527_));
    vlSelf->wasmetal_core__DOT___028963_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052528_))));
    vlSelf->wasmetal_core__DOT___028651_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052528_))));
    vlSelf->wasmetal_core__DOT___028475_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000477_))));
    vlSelf->wasmetal_core__DOT___048044_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003348_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000477_)));
    vlSelf->__VdfgTmp_h898dd08d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003348_));
    vlSelf->wasmetal_core__DOT___066874_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b22__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b22__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x16U))))));
    vlSelf->__VdfgTmp_hba3bfb32__0 = (((IData)(vlSelf->wasmetal_core__DOT___000461_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000460_));
    vlSelf->wasmetal_core__DOT___028650_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003416_))));
    vlSelf->wasmetal_core__DOT___028474_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003416_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000465_))));
    vlSelf->wasmetal_core__DOT___048057_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003416_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000465_)));
    vlSelf->__VdfgTmp_h5d92aff2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003416_));
    vlSelf->wasmetal_core__DOT___050343_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004802_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004784_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004432_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004414_)))))))));
    vlSelf->wasmetal_core__DOT___028472_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003269_))));
    vlSelf->wasmetal_core__DOT___048137_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003270_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003269_)));
    vlSelf->__VdfgTmp_h365733f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003270_));
    vlSelf->__VdfgTmp_h5a48cd94__0 = (((IData)(vlSelf->wasmetal_core__DOT___000429_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000428_));
    vlSelf->wasmetal_core__DOT___054006_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003936_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b20__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003348_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b22__05d))))));
    vlSelf->wasmetal_core__DOT___028649_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003936_))));
    vlSelf->wasmetal_core__DOT___044544_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000477_)))))))));
    vlSelf->wasmetal_core__DOT___044556_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000433_)))))))));
    vlSelf->wasmetal_core__DOT___045441_ = (1U & (IData)(
                                                         (0x2baf0a2b2b2b0a0aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052528_)))))))));
    vlSelf->wasmetal_core__DOT___045453_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052528_)))))))));
    vlSelf->wasmetal_core__DOT___028473_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003936_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000433_))));
    vlSelf->wasmetal_core__DOT___048040_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003936_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000433_)));
    vlSelf->__VdfgTmp_h4a3667e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003936_));
    vlSelf->wasmetal_core__DOT___050349_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004506_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004488_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003234_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003190_)))))))));
    vlSelf->wasmetal_core__DOT___044536_ = (1U & (0x2b22U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003269_))))));
    vlSelf->wasmetal_core__DOT___044548_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003189_))))));
    vlSelf->wasmetal_core__DOT___128640___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003269_)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT___003189_))));
    vlSelf->__VdfgTmp_h4ae0787e__0 = (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003189_));
    vlSelf->wasmetal_core__DOT___048020_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003190_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003189_)));
    vlSelf->__VdfgTmp_he3cb924f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003190_));
    vlSelf->__VdfgTmp_h76eadb80__0 = (((IData)(vlSelf->wasmetal_core__DOT___000413_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000412_));
    vlSelf->wasmetal_core__DOT___028959_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052555_))));
    vlSelf->wasmetal_core__DOT___054010_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003862_))));
    vlSelf->wasmetal_core__DOT___028647_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003862_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052555_))));
    vlSelf->wasmetal_core__DOT___051940_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___003876_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003862_))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___003988_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003970_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___004018_)))));
    vlSelf->wasmetal_core__DOT___045157_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003862_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003936_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003416_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000433_)))))))));
    vlSelf->wasmetal_core__DOT___028471_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003862_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000420_))));
    vlSelf->wasmetal_core__DOT___048141_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003862_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000420_)));
    vlSelf->__VdfgTmp_hb2653381__0 = (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003862_));
    vlSelf->wasmetal_core__DOT___066623_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b19__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b19__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x13U))))));
    vlSelf->__VdfgTmp_h58ec7cd3__0 = (((IData)(vlSelf->wasmetal_core__DOT___001643_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001642_));
    vlSelf->wasmetal_core__DOT___054019_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b20__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003936_))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b18__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___004078_)))))));
    vlSelf->wasmetal_core__DOT___028646_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004078_))));
    vlSelf->wasmetal_core__DOT___052666_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004078_))));
    vlSelf->wasmetal_core__DOT___028470_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001647_))));
    vlSelf->wasmetal_core__DOT___048018_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004078_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001647_)));
    vlSelf->__VdfgTmp_h68543eec__0 = (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004078_));
    vlSelf->__VdfgTmp_hf275be9a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001621_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001620_));
    vlSelf->wasmetal_core__DOT___028645_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004300_))));
    vlSelf->wasmetal_core__DOT___044543_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003876_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000420_)))))))));
    vlSelf->wasmetal_core__DOT___044555_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003876_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000420_)))))))));
    vlSelf->wasmetal_core__DOT___045440_ = (1U & (IData)(
                                                         (0x2baf0a2b2b2b0a0aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052555_)))))))));
    vlSelf->wasmetal_core__DOT___045452_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052555_)))))))));
    vlSelf->wasmetal_core__DOT___052750_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000420_))))));
    vlSelf->wasmetal_core__DOT___028469_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001625_))));
    vlSelf->wasmetal_core__DOT___048072_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004300_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001625_)));
    vlSelf->__VdfgTmp_h57521c49__0 = (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004300_));
    vlSelf->__VdfgTmp_h4781af3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___001609_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001608_));
    vlSelf->wasmetal_core__DOT___053999_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b16__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b17__05d))))));
    vlSelf->wasmetal_core__DOT___054029_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b16__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b18__05d))))));
    vlSelf->wasmetal_core__DOT___028644_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052529_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004004_))));
    vlSelf->wasmetal_core__DOT___050344_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004284_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004266_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003920_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003902_)))))))));
    vlSelf->wasmetal_core__DOT___045156_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001647_)))))))));
    vlSelf->wasmetal_core__DOT___028468_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001613_))));
    vlSelf->wasmetal_core__DOT___048008_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004004_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001613_)));
    vlSelf->__VdfgTmp_h0b995397__0 = (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004004_));
    vlSelf->__VdfgTmp_h808c51bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___001577_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001576_));
    vlSelf->wasmetal_core__DOT___028955_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052400_))));
    vlSelf->wasmetal_core__DOT___028643_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052400_))));
    vlSelf->wasmetal_core__DOT___028467_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001581_))));
    vlSelf->wasmetal_core__DOT___048693_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003706_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001581_)));
    vlSelf->__VdfgTmp_hed5e83f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003706_));
    vlSelf->wasmetal_core__DOT___066298_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0xeU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_haaaaa9f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___001565_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001564_));
    vlSelf->wasmetal_core__DOT___028954_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052401_))));
    vlSelf->wasmetal_core__DOT___054011_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b14__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b17__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004300_))))));
    vlSelf->wasmetal_core__DOT___028642_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052401_))));
    vlSelf->wasmetal_core__DOT___050340_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003690_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003672_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004684_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004670_)))))))));
    vlSelf->wasmetal_core__DOT___044542_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004684_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004018_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001613_)))))))));
    vlSelf->wasmetal_core__DOT___044554_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004018_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004684_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001569_)))))))));
    vlSelf->wasmetal_core__DOT___045439_ = (1U & (IData)(
                                                         (0x3bbf02233b3b0202ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052401_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052529_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052400_)))))))));
    vlSelf->wasmetal_core__DOT___045451_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052529_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052401_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052400_)))))))));
    vlSelf->wasmetal_core__DOT___028466_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001569_))));
    vlSelf->wasmetal_core__DOT___048191_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004670_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001569_)));
    vlSelf->__VdfgTmp_h11733417__0 = (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004670_));
    vlSelf->wasmetal_core__DOT___066202_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0xdU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_h60633cb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___001533_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001532_));
    vlSelf->wasmetal_core__DOT___028953_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052257_))));
    vlSelf->wasmetal_core__DOT___028641_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052257_))));
    vlSelf->wasmetal_core__DOT___050339_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004226_))));
    vlSelf->wasmetal_core__DOT___045155_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001569_)))))))));
    vlSelf->wasmetal_core__DOT___028465_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001537_))));
    vlSelf->wasmetal_core__DOT___048236_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004226_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001537_)));
    vlSelf->__VdfgTmp_h20a47ce2__0 = (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004226_));
    vlSelf->wasmetal_core__DOT___066065_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0xcU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_hc1bc9aa3__0 = (((IData)(vlSelf->wasmetal_core__DOT___001521_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001520_));
    vlSelf->wasmetal_core__DOT___028952_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052255_))));
    vlSelf->wasmetal_core__DOT___054012_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b14__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b12__05d))))));
    vlSelf->wasmetal_core__DOT___028640_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052255_))));
    vlSelf->wasmetal_core__DOT___028464_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001525_))));
    vlSelf->wasmetal_core__DOT___048187_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004152_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001525_)));
    vlSelf->__VdfgTmp_h71467b4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004152_));
    vlSelf->wasmetal_core__DOT___066004_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066003_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066002_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[0U] 
                                                                        >> 0xaU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d)))))))));
    vlSelf->__VdfgTmp_h38c61391__0 = (((IData)(vlSelf->wasmetal_core__DOT___001422_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001421_));
    vlSelf->wasmetal_core__DOT___028951_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052477_))));
    vlSelf->wasmetal_core__DOT___053996_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003558_))));
    vlSelf->wasmetal_core__DOT___028639_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052477_))));
    vlSelf->wasmetal_core__DOT___044541_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001525_)))))))));
    vlSelf->wasmetal_core__DOT___044553_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001426_)))))))));
    vlSelf->wasmetal_core__DOT___045438_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052477_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052257_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052255_)))))))));
    vlSelf->wasmetal_core__DOT___045450_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052477_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052257_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052255_)))))))));
    vlSelf->wasmetal_core__DOT___028463_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001426_))));
    vlSelf->wasmetal_core__DOT___048260_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003558_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001426_)));
    vlSelf->__VdfgTmp_h51a5c0e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003558_));
    vlSelf->wasmetal_core__DOT___065884_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0xaU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_h7b1a2166__0 = (((IData)(vlSelf->wasmetal_core__DOT___001410_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001409_));
    vlSelf->wasmetal_core__DOT___028950_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052476_))));
    vlSelf->wasmetal_core__DOT___028638_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052476_))));
    vlSelf->wasmetal_core__DOT___050338_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003484_))));
    vlSelf->wasmetal_core__DOT___045154_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003484_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001426_)))))))));
    vlSelf->wasmetal_core__DOT___028462_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001414_))));
    vlSelf->wasmetal_core__DOT___048199_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003484_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001414_)));
    vlSelf->__VdfgTmp_h11929a69__0 = (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003484_));
    vlSelf->wasmetal_core__DOT___065788_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 9U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_h35d7421d__0 = (((IData)(vlSelf->wasmetal_core__DOT___001378_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001377_));
    vlSelf->wasmetal_core__DOT___028980_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052398_))));
    vlSelf->wasmetal_core__DOT___028668_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052398_))));
    vlSelf->wasmetal_core__DOT___050348_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003468_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003450_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004654_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004636_)))))))));
    vlSelf->wasmetal_core__DOT___028492_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001382_))));
    vlSelf->wasmetal_core__DOT___048232_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003632_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001382_)));
    vlSelf->__VdfgTmp_h25819d29__0 = (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003632_));
    vlSelf->wasmetal_core__DOT___065723_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 8U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_hd822ef23__0 = (((IData)(vlSelf->wasmetal_core__DOT___001366_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001365_));
    vlSelf->wasmetal_core__DOT___052451_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052401_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052400_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052399_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052398_)))))))));
    vlSelf->wasmetal_core__DOT___028979_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052399_))));
    vlSelf->wasmetal_core__DOT___054024_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003484_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b10__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b8__05d))))));
    vlSelf->wasmetal_core__DOT___051956_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004136_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004118_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003616_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003598_)))))))));
    vlSelf->wasmetal_core__DOT___028667_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052399_))));
    vlSelf->wasmetal_core__DOT___044540_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003498_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001414_)))))))));
    vlSelf->wasmetal_core__DOT___044552_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003498_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001414_)))))))));
    vlSelf->wasmetal_core__DOT___045437_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052399_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052476_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052398_)))))))));
    vlSelf->wasmetal_core__DOT___045449_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052476_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052399_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052398_)))))))));
    vlSelf->wasmetal_core__DOT___052752_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001569_)))))))));
    vlSelf->wasmetal_core__DOT___028491_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001370_))));
    vlSelf->wasmetal_core__DOT___048193_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003780_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001370_)));
    vlSelf->__VdfgTmp_h3c8de641__0 = (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003780_));
    vlSelf->wasmetal_core__DOT___065592_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 7U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_hae88697a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001484_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001483_));
    vlSelf->wasmetal_core__DOT___028978_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052557_))));
    vlSelf->wasmetal_core__DOT___028666_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052557_))));
    vlSelf->wasmetal_core__DOT___045153_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001382_)))))))));
    vlSelf->wasmetal_core__DOT___028490_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001488_))));
    vlSelf->wasmetal_core__DOT___048064_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004596_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001488_)));
    vlSelf->__VdfgTmp_h01ed509a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004596_));
    vlSelf->wasmetal_core__DOT___065502_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065500_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[0U] 
                                                                        >> 5U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b7__05d)))))))));
    vlSelf->__VdfgTmp_h2996e40e__0 = (((IData)(vlSelf->wasmetal_core__DOT___001472_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001471_));
    vlSelf->wasmetal_core__DOT___028977_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052556_))));
    vlSelf->wasmetal_core__DOT___051986_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004580_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004562_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004448_)))))))));
    vlSelf->wasmetal_core__DOT___028665_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052556_))));
    vlSelf->wasmetal_core__DOT___028489_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001476_))));
    vlSelf->wasmetal_core__DOT___048014_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004448_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001476_)));
    vlSelf->__VdfgTmp_h0ad4d6dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004448_));
    vlSelf->wasmetal_core__DOT___065396_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065394_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[0U] 
                                                                        >> 4U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b6__05d)))))))));
    vlSelf->__VdfgTmp_hcab9d929__0 = (((IData)(vlSelf->wasmetal_core__DOT___001440_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001439_));
    vlSelf->wasmetal_core__DOT___028976_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052474_))));
    vlSelf->wasmetal_core__DOT___028664_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004374_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052474_))));
    vlSelf->wasmetal_core__DOT___044539_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004388_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001476_)))))))));
    vlSelf->wasmetal_core__DOT___044551_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004388_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001444_)))))))));
    vlSelf->wasmetal_core__DOT___045436_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052474_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052557_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052556_)))))))));
    vlSelf->wasmetal_core__DOT___045448_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052557_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052556_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052474_)))))))));
    vlSelf->wasmetal_core__DOT___028488_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004374_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001444_))));
    vlSelf->wasmetal_core__DOT___048154_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004374_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001444_)));
    vlSelf->__VdfgTmp_hcc6273ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004374_));
    vlSelf->wasmetal_core__DOT___065283_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 4U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_h4a4b1d7e__0 = (((IData)(vlSelf->wasmetal_core__DOT___001434_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001433_));
    vlSelf->__VdfgTmp_h91f69850__0 = (((IData)(vlSelf->wasmetal_core__DOT___052475_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052474_));
    vlSelf->wasmetal_core__DOT___028975_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052475_))));
    vlSelf->wasmetal_core__DOT___054001_ = (1U & (IData)(
                                                         (0xb0bb00000000b0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004374_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004522_)))))))));
    vlSelf->wasmetal_core__DOT___028663_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052475_))));
    vlSelf->wasmetal_core__DOT___045152_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004374_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004448_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001444_)))))))));
    vlSelf->wasmetal_core__DOT___028487_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001438_))));
    vlSelf->wasmetal_core__DOT___048028_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004522_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001438_)));
    vlSelf->__VdfgTmp_h04643804__0 = (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004522_));
    vlSelf->wasmetal_core__DOT___065157_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065155_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[0U] 
                                                                        >> 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b4__05d)))))))));
    vlSelf->__VdfgTmp_h99694808__0 = (((IData)(vlSelf->wasmetal_core__DOT___001883_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001882_));
    vlSelf->wasmetal_core__DOT___028974_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052253_))));
    vlSelf->wasmetal_core__DOT___028662_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004744_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052253_))));
    vlSelf->wasmetal_core__DOT___028486_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004744_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001887_))));
    vlSelf->wasmetal_core__DOT___048150_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004744_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001887_)));
    vlSelf->__VdfgTmp_haf58c538__0 = (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004744_));
    vlSelf->wasmetal_core__DOT___065044_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065043_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065042_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[0U] 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b3__05d)))))))));
    vlSelf->__VdfgTmp_hb773d3a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___001871_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001870_));
    vlSelf->wasmetal_core__DOT___028971_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052254_))));
    vlSelf->wasmetal_core__DOT___054025_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b2__05d))))));
    vlSelf->wasmetal_core__DOT___051955_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004728_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004710_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004388_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004374_)))))))));
    vlSelf->wasmetal_core__DOT___028659_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052254_))));
    vlSelf->wasmetal_core__DOT___044538_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001887_)))))))));
    vlSelf->wasmetal_core__DOT___044550_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001887_)))))))));
    vlSelf->wasmetal_core__DOT___045435_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052254_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052475_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052253_)))))))));
    vlSelf->wasmetal_core__DOT___045447_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052254_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052253_)))))))));
    vlSelf->wasmetal_core__DOT___052753_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001887_)))))))));
    vlSelf->wasmetal_core__DOT___045149_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004744_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001887_)))))))));
    vlSelf->wasmetal_core__DOT___028483_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001875_))));
    vlSelf->wasmetal_core__DOT___048034_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004818_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001875_)));
    vlSelf->__VdfgTmp_hff7a62d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004818_));
    vlSelf->wasmetal_core__DOT___064883_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064882_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064881_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->cmd_data[0U]) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031069_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___045491_ = (1U & (IData)(
                                                         (0xfffefeeefeeefeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071405_) 
                                                            << 4U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071404_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045515_ = (1U & (IData)(
                                                         (0x1010000101000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071405_) 
                                                            << 3U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071404_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045287_ = (1U & (IData)(
                                                         (0xfffefeeefeeefeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071468_) 
                                                            << 4U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071467_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045311_ = (1U & (IData)(
                                                         (0x1010000101000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071468_) 
                                                            << 3U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071467_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045485_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071391_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071390_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071389_))))));
    vlSelf->wasmetal_core__DOT___045509_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071391_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071390_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071389_))))));
    vlSelf->wasmetal_core__DOT___045281_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071454_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071453_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071452_))))));
    vlSelf->wasmetal_core__DOT___045305_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071454_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071453_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071452_))))));
    vlSelf->wasmetal_core__DOT___045490_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071403_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071402_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071401_))))));
    vlSelf->wasmetal_core__DOT___045514_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071403_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071402_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071401_))))));
    vlSelf->wasmetal_core__DOT___045286_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071466_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071465_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071464_))))));
    vlSelf->wasmetal_core__DOT___045310_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071466_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071465_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071464_))))));
    vlSelf->wasmetal_core__DOT___045484_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071388_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071387_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071386_))))));
    vlSelf->wasmetal_core__DOT___045508_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071388_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071387_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071386_))))));
    vlSelf->wasmetal_core__DOT___045280_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071451_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071450_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071449_))))));
    vlSelf->wasmetal_core__DOT___045304_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071451_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071450_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071449_))))));
    vlSelf->wasmetal_core__DOT___045483_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071385_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071384_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071383_))))));
    vlSelf->wasmetal_core__DOT___045507_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071385_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071384_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071383_))))));
    vlSelf->wasmetal_core__DOT___045279_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071448_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071447_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071446_))))));
    vlSelf->wasmetal_core__DOT___045303_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071448_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071447_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071446_))))));
    vlSelf->wasmetal_core__DOT___045486_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071394_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071393_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071392_))))));
    vlSelf->wasmetal_core__DOT___045510_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071394_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071393_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071392_))))));
    vlSelf->wasmetal_core__DOT___045282_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071457_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071456_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071455_))))));
    vlSelf->wasmetal_core__DOT___045306_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071457_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071456_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071455_))))));
    vlSelf->wasmetal_core__DOT___045488_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071400_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071399_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071398_))))));
    vlSelf->wasmetal_core__DOT___045512_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071400_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071399_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071398_))))));
    vlSelf->wasmetal_core__DOT___045284_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071463_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071462_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071461_))))));
    vlSelf->wasmetal_core__DOT___045308_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071463_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071462_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071461_))))));
    vlSelf->wasmetal_core__DOT___045487_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071397_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071396_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071395_))))));
    vlSelf->wasmetal_core__DOT___045511_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071397_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071396_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071395_))))));
    vlSelf->wasmetal_core__DOT___045283_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071460_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071459_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071458_))))));
    vlSelf->wasmetal_core__DOT___045307_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071460_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071459_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071458_))))));
    vlSelf->wasmetal_core__DOT___064465_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064462_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & vlSelf->insn_imm[0U]) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___064899_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064897_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___064733_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064730_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065413_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065411_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065303_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065301_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 5U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065190_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065187_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 4U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065064_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065058_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 3U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065898_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065896_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xaU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065802_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065800_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 9U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065700_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065698_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 8U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065604_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065602_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 7U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066278_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066276_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xeU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066126_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066123_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xdU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066084_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066081_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xcU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065939_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065936_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xbU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066605_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066602_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x12U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066528_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066525_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x11U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066402_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066399_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x10U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066316_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066313_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xfU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066896_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066893_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x16U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066855_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066852_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x15U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066772_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066769_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x14U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066650_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066647_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x13U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067197_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067156_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067153_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054158_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x19U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067078_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067075_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066973_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066970_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x17U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067456_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067454_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067344_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067342_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067314_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067312_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1bU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___048039_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_heecb7e70__0))))));
    vlSelf->wasmetal_core__DOT__top__05b66__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_heecb7e70__0))))));
    vlSelf->wasmetal_core__DOT___005389_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6b4c794b__0))))));
    vlSelf->wasmetal_core__DOT__top__05b122__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6b4c794b__0))))));
    vlSelf->wasmetal_core__DOT___062418_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b98__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b98__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b98__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hdf4f28bb__0))))));
    vlSelf->__VdfgTmp_h8dbe6334__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004802_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___004801_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hdf4f28bb__0)))))));
    vlSelf->wasmetal_core__DOT___048177_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h45f8df98__0))))));
    vlSelf->wasmetal_core__DOT__top__05b90__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h45f8df98__0))))));
    vlSelf->wasmetal_core__DOT___048198_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2cf790ef__0))))));
    vlSelf->wasmetal_core__DOT__top__05b74__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h2cf790ef__0))))));
    vlSelf->wasmetal_core__DOT___062438_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b106__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b106__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 9U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b106__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b106__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h39365f5c__0))))));
    vlSelf->__VdfgTmp_h52266111__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003468_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003105_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h39365f5c__0)))))));
    vlSelf->wasmetal_core__DOT___048152_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd9d86825__0))))));
    vlSelf->wasmetal_core__DOT__top__05b67__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hd9d86825__0))))));
    vlSelf->wasmetal_core__DOT___048030_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hfb5e3b7e__0))))));
    vlSelf->wasmetal_core__DOT__top__05b68__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hfb5e3b7e__0))))));
    vlSelf->wasmetal_core__DOT___062480_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b123__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b123__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b123__05d)))))));
    vlSelf->wasmetal_core__DOT___005399_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3d9b9896__0))))));
    vlSelf->wasmetal_core__DOT__top__05b123__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h3d9b9896__0))))));
    vlSelf->wasmetal_core__DOT___048156_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1d47507a__0))))));
    vlSelf->wasmetal_core__DOT__top__05b69__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h1d47507a__0))))));
    vlSelf->wasmetal_core__DOT___005409_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h79077a59__0))))));
    vlSelf->wasmetal_core__DOT__top__05b124__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h79077a59__0))))));
    vlSelf->wasmetal_core__DOT___005419_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h13f17749__0))))));
    vlSelf->wasmetal_core__DOT__top__05b125__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h13f17749__0))))));
    vlSelf->wasmetal_core__DOT___005456_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8b941ffe__0))))));
    vlSelf->wasmetal_core__DOT__top__05b126__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8b941ffe__0))))));
    vlSelf->wasmetal_core__DOT___048013_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9b6447c0__0))))));
    vlSelf->wasmetal_core__DOT__top__05b70__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h9b6447c0__0))))));
    vlSelf->wasmetal_core__DOT___062420_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b99__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b99__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b99__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b99__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h887e5924__0))))));
    vlSelf->__VdfgTmp_h7d4fca25__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004728_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___004727_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h887e5924__0)))))));
    vlSelf->wasmetal_core__DOT___070081_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b100__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->cmd_data[3U] 
                                                                >> 3U)) 
                                                            | (1U 
                                                               & (0xf38f2779U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))));
    vlSelf->wasmetal_core__DOT___062423_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b100__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b100__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 3U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b100__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b100__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hf8739cbc__0))))));
    vlSelf->__VdfgTmp_h82d77f97__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004506_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003097_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf8739cbc__0)))))));
    vlSelf->wasmetal_core__DOT___062426_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b101__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b101__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 4U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b101__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b101__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h220272bf__0))))));
    vlSelf->__VdfgTmp_hf0176237__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004358_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003099_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h220272bf__0)))))));
    vlSelf->wasmetal_core__DOT___062428_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b102__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b102__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 5U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b102__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b102__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h193e1c6c__0))))));
    vlSelf->__VdfgTmp_hbacded4f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004432_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003101_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h193e1c6c__0)))))));
    vlSelf->wasmetal_core__DOT___048258_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hfaaa855f__0))))));
    vlSelf->wasmetal_core__DOT__top__05b91__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hfaaa855f__0))))));
    vlSelf->wasmetal_core__DOT___048183_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h331e01c9__0))))));
    vlSelf->wasmetal_core__DOT__top__05b92__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h331e01c9__0))))));
    vlSelf->wasmetal_core__DOT___048238_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h62281c26__0))))));
    vlSelf->wasmetal_core__DOT__top__05b93__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h62281c26__0))))));
    vlSelf->wasmetal_core__DOT___048262_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7482f819__0))))));
    vlSelf->wasmetal_core__DOT__top__05b75__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h7482f819__0))))));
    vlSelf->wasmetal_core__DOT___048171_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h22e3dba7__0))))));
    vlSelf->wasmetal_core__DOT__top__05b94__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h22e3dba7__0))))));
    vlSelf->wasmetal_core__DOT___048186_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf7e0ef4b__0))))));
    vlSelf->wasmetal_core__DOT__top__05b76__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hf7e0ef4b__0))))));
    vlSelf->wasmetal_core__DOT___048235_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h31491600__0))))));
    vlSelf->wasmetal_core__DOT__top__05b77__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h31491600__0))))));
    vlSelf->wasmetal_core__DOT___062443_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b107__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b107__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xaU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b107__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b107__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6d082533__0))))));
    vlSelf->__VdfgTmp_hcde84ebb__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003542_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003107_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h6d082533__0)))))));
    vlSelf->wasmetal_core__DOT___048190_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h19aa2548__0))))));
    vlSelf->wasmetal_core__DOT__top__05b78__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h19aa2548__0))))));
    vlSelf->wasmetal_core__DOT__top__05b108__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbea96df5__0))))));
    vlSelf->__VdfgTmp_h0adea875__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004136_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003117_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hbea96df5__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b109__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h01f51344__0))))));
    vlSelf->__VdfgTmp_h79860539__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004210_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003119_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h01f51344__0)))))));
    vlSelf->wasmetal_core__DOT___062449_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b110__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b110__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xdU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b110__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b110__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7ca24d8b__0))))));
    vlSelf->__VdfgTmp_h5978f26f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004654_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003121_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h7ca24d8b__0)))))));
    vlSelf->wasmetal_core__DOT___048017_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6332189a__0))))));
    vlSelf->wasmetal_core__DOT__top__05b82__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h6332189a__0))))));
    vlSelf->wasmetal_core__DOT___069714_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069710_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069709_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b82__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x10U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT__top__05b114__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb807ebfb__0))))));
    vlSelf->__VdfgTmp_h31225405__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004062_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___004061_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb807ebfb__0)))))));
    vlSelf->wasmetal_core__DOT___048136_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5bb31d88__0))))));
    vlSelf->wasmetal_core__DOT__top__05b65__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h5bb31d88__0))))));
    vlSelf->wasmetal_core__DOT___062475_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b121__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b121__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b121__05d)))))));
    vlSelf->wasmetal_core__DOT___005446_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h630336df__0))))));
    vlSelf->wasmetal_core__DOT__top__05b121__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h630336df__0))))));
    vlSelf->wasmetal_core__DOT___062416_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b97__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b97__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & vlSelf->mem_rdata[3U]) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b97__05d)))))));
    vlSelf->wasmetal_core__DOT___070029_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b97__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b97__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[3U] 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT__top__05b97__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h0a17a2b0__0))))));
    vlSelf->__VdfgTmp_h09328eec__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003252_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003095_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h0a17a2b0__0)))))));
    vlSelf->wasmetal_core__DOT___048231_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2b63e99d__0))))));
    vlSelf->wasmetal_core__DOT__top__05b73__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h2b63e99d__0))))));
    vlSelf->wasmetal_core__DOT___048244_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hec648199__0))))));
    vlSelf->wasmetal_core__DOT__top__05b89__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hec648199__0))))));
    vlSelf->wasmetal_core__DOT___062435_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b105__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b105__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 8U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b105__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b105__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h94e7c39f__0))))));
    vlSelf->__VdfgTmp_hff8a2099__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003616_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003111_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h94e7c39f__0)))))));
    vlSelf->wasmetal_core__DOT___005466_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha2c9478b__0))))));
    vlSelf->wasmetal_core__DOT__top__05b116__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha2c9478b__0))))));
    vlSelf->wasmetal_core__DOT___005476_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1bb342d2__0))))));
    vlSelf->wasmetal_core__DOT__top__05b117__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1bb342d2__0))))));
    vlSelf->wasmetal_core__DOT___005486_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h90194312__0))))));
    vlSelf->wasmetal_core__DOT__top__05b118__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h90194312__0))))));
    vlSelf->wasmetal_core__DOT___052109_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052054_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x8888f00000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___052049_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___004273_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___004051_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc280317b__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h559eadff__0)))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x80000000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___052044_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___052043_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052035_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003241_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003161_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcb1226e0__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb6d33cfc__0)))))))))) 
                                                                            << 2U)) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052030_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003977_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003927_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0f7cbf8b__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5c1149ce__0)))))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051979_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003407_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003339_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfb5e938__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hec05375a__0)))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xac00000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___051972_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051971_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051970_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h106a7f5e__0))))))))))))));
    vlSelf->wasmetal_core__DOT___069735_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xeU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x10U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x13U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b83__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069732_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b83__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b83__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x13U))))))))));
    vlSelf->wasmetal_core__DOT___048140_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd87a9123__0))))));
    vlSelf->wasmetal_core__DOT__top__05b83__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hd87a9123__0))))));
    vlSelf->wasmetal_core__DOT__top__05b115__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hed09e4ce__0))))));
    vlSelf->__VdfgTmp_h70d2167a__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003846_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003845_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hed09e4ce__0)))))));
    vlSelf->wasmetal_core__DOT___048042_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h98759836__0))))));
    vlSelf->wasmetal_core__DOT__top__05b84__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h98759836__0))))));
    vlSelf->wasmetal_core__DOT___069758_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069754_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069753_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b84__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x12U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___048059_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he8c28620__0))))));
    vlSelf->wasmetal_core__DOT__top__05b85__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_he8c28620__0))))));
    vlSelf->wasmetal_core__DOT___069779_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069775_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069774_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b85__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x13U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___048046_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2b07b055__0))))));
    vlSelf->wasmetal_core__DOT__top__05b86__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h2b07b055__0))))));
    vlSelf->wasmetal_core__DOT___069801_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069797_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069796_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b86__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x14U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___048074_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h29035176__0))))));
    vlSelf->wasmetal_core__DOT__top__05b81__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h29035176__0))))));
    vlSelf->wasmetal_core__DOT__top__05b113__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hf4fd0700__0))))));
    vlSelf->__VdfgTmp_h177129ae__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004284_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003115_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf4fd0700__0)))))));
    vlSelf->wasmetal_core__DOT___048022_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7e49e6e6__0))))));
    vlSelf->wasmetal_core__DOT__top__05b64__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h7e49e6e6__0))))));
    vlSelf->wasmetal_core__DOT___005436_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he61be2d5__0))))));
    vlSelf->wasmetal_core__DOT__top__05b120__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he61be2d5__0))))));
    vlSelf->wasmetal_core__DOT__top__05b96__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_ha1faee4b__0))))));
    vlSelf->__VdfgTmp_ha59547bb__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003172_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003091_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha1faee4b__0)))))));
    vlSelf->wasmetal_core__DOT___048195_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h88d138aa__0))))));
    vlSelf->wasmetal_core__DOT__top__05b72__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h88d138aa__0))))));
    vlSelf->wasmetal_core__DOT___048175_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h15796065__0))))));
    vlSelf->wasmetal_core__DOT__top__05b88__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h15796065__0))))));
    vlSelf->wasmetal_core__DOT___052369_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052340_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052338_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he6df8ac0__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_he04a0e99__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h8b084513__0))))))))))));
    vlSelf->wasmetal_core__DOT___062433_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b104__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b104__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 7U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b104__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b104__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8103cb90__0))))));
    vlSelf->__VdfgTmp_h601dd350__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003764_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003109_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h8103cb90__0)))))));
    vlSelf->wasmetal_core__DOT___048010_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf123ec52__0))))));
    vlSelf->wasmetal_core__DOT__top__05b80__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hf123ec52__0))))));
    vlSelf->wasmetal_core__DOT___062454_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b112__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xfU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b112__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b112__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb2ba9050__0))))));
    vlSelf->__VdfgTmp_h71a6f88b__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003988_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003113_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb2ba9050__0)))))));
    vlSelf->wasmetal_core__DOT___047989_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd2cb6624__0))))));
    vlSelf->wasmetal_core__DOT__top__05b127__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd2cb6624__0))))));
    vlSelf->wasmetal_core__DOT___048066_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h41785ae8__0))))));
    vlSelf->wasmetal_core__DOT__top__05b71__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h41785ae8__0))))));
    vlSelf->wasmetal_core__DOT__top__05b103__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7b80a3df__0))))));
    vlSelf->__VdfgTmp_hb7a72eea__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004580_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003103_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h7b80a3df__0)))))));
    vlSelf->wasmetal_core__DOT___048003_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf772eecc__0))))));
    vlSelf->wasmetal_core__DOT__top__05b95__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hf772eecc__0))))));
}
