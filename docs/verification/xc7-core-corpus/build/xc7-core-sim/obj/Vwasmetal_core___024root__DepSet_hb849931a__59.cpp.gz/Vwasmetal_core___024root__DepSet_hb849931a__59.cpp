#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__9(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__9\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___045825_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x15U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x17U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x19U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h22be3b3b__0)))))));
    vlSelf->wasmetal_core__DOT___067306_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd466e7f__0))));
    vlSelf->wasmetal_core__DOT___000572_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_had26118d__0))))));
    vlSelf->wasmetal_core__DOT___028304_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028239_))));
    vlSelf->wasmetal_core__DOT___055783_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008131_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008206_))))));
    vlSelf->__VdfgTmp_h2596a796__0 = (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008131_));
    vlSelf->wasmetal_core__DOT___027352_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b27__05d))));
    vlSelf->wasmetal_core__DOT___060102_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005989_))));
    vlSelf->wasmetal_core__DOT___071970_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071966_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___000635_)))))));
    vlSelf->wasmetal_core__DOT___071967_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071966_)))));
    vlSelf->wasmetal_core__DOT___067202_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h992e16df__0))));
    vlSelf->__VdfgTmp_h7da480c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___063932_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063931_));
    vlSelf->wasmetal_core__DOT___001657_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdba97a87__0))))));
    vlSelf->wasmetal_core__DOT___028303_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028238_))));
    vlSelf->wasmetal_core__DOT___055761_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008123_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008198_))))));
    vlSelf->__VdfgTmp_h03e9ae47__0 = (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008123_));
    vlSelf->wasmetal_core__DOT___027351_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b26__05d))));
    vlSelf->wasmetal_core__DOT___026492_ = (1U & (IData)(
                                                         (0xfff0f0f88ff8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071969_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071971_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071910_)))))))));
    vlSelf->wasmetal_core__DOT___049034_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005321_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hea3adbd3__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b25__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002681_)))))))));
    vlSelf->wasmetal_core__DOT___067161_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9e2f527__0))));
    vlSelf->wasmetal_core__DOT___042362_ = (1U & (IData)(
                                                         (0xbb2bffff2b220000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070508_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2be29f89__0))))))));
    vlSelf->wasmetal_core__DOT___042161_ = (1U & (IData)(
                                                         (0xf571ffff71500000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd856a856__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h879a663d__0))))))));
    vlSelf->wasmetal_core__DOT___000179_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf4e6deac__0))))));
    vlSelf->wasmetal_core__DOT___044426_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063245_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063251_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063257_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6e6c7922__0))))))));
    vlSelf->wasmetal_core__DOT___044450_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063257_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063251_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054158_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063245_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054135_)))))))));
    vlSelf->wasmetal_core__DOT___028302_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028237_))));
    vlSelf->wasmetal_core__DOT___055753_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008115_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008190_))))));
    vlSelf->__VdfgTmp_h6deef1cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008115_));
    vlSelf->wasmetal_core__DOT___027350_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b25__05d))));
    vlSelf->wasmetal_core__DOT___060056_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006022_))));
    vlSelf->wasmetal_core__DOT___042091_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3948b92c__0)))))));
    vlSelf->wasmetal_core__DOT___045824_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x12U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x14U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x16U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3948b92c__0)))))));
    vlSelf->wasmetal_core__DOT___049037_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005049_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h04914456__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b24__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002642_)))))))));
    vlSelf->wasmetal_core__DOT___067083_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfc0b7a98__0))));
    vlSelf->wasmetal_core__DOT___063872_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0))))));
    vlSelf->wasmetal_core__DOT___001656_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6cb2731d__0))))));
    vlSelf->wasmetal_core__DOT___028301_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028236_))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135196___B 
        = ((0x3ff80U & ((- (IData)((1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x555533330f0f00ffULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008168_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008469_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055036_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___055046_)))))))))))))) 
                        << 7U)) | ((0x40U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                << 1U) 
                                               | (1U 
                                                  & (IData)(
                                                            (0x555533330f0f00ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008160_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008461_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054990_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___055000_))))))))))) 
                                             << 6U)) 
                                   | ((0x20U & ((4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0x555533330f0f00ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008152_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008453_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054951_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054959_))))))))))) 
                                                << 5U)) 
                                      | ((0x10U & (
                                                   (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008144_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008445_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054901_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054909_))))))))))) 
                                                   << 4U)) 
                                         | ((8U & (
                                                   (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008131_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008432_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054865_))))))))))) 
                                                   << 3U)) 
                                            | ((4U 
                                                & ((4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008123_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008424_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054810_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054820_))))))))))) 
                                                   << 2U)) 
                                               | ((2U 
                                                   & ((4U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008115_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008416_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054770_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054781_))))))))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008107_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008408_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054698_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054674_)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___055723_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008107_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008182_))))));
    vlSelf->__VdfgTmp_hc63c8631__0 = (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008107_));
    vlSelf->wasmetal_core__DOT___027349_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b24__05d))));
    vlSelf->wasmetal_core__DOT___060032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006106_))));
    vlSelf->wasmetal_core__DOT___061460_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061458_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061457_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007335_)))))))));
    vlSelf->wasmetal_core__DOT___052802_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052761_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4c543443__0)) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052759_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052758_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___052757_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8f3a812b__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052584_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremainder_op))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001568_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001612_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000432_))))))))))))))))))))))))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x8000000000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052780_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052779_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052778_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x4000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052770_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034476_))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052776_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))))))))))))))))))))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052583_)))));
    vlSelf->wasmetal_core__DOT___050426_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050424_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050423_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050422_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001612_)))))))));
    vlSelf->wasmetal_core__DOT___049068_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005117_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc2abfe6d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b23__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002924_)))))))));
    vlSelf->wasmetal_core__DOT___066979_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c78c397__0))));
    vlSelf->wasmetal_core__DOT___042103_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063942_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd856a856__0))))));
    vlSelf->wasmetal_core__DOT___000178_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4438b1a5__0))))));
    vlSelf->wasmetal_core__DOT___028300_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028235_))));
    vlSelf->__VdfgTmp_h78e7e4d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___008093_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008168_));
    vlSelf->__VdfgTmp_hd8562240__0 = (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008093_));
    vlSelf->wasmetal_core__DOT___027348_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b23__05d))));
    vlSelf->wasmetal_core__DOT___060000_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005868_))));
    vlSelf->wasmetal_core__DOT___051505_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006106_))));
    vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006106_) 
           | (IData)(vlSelf->wasmetal_core__DOT___005868_));
    vlSelf->wasmetal_core__DOT___054854_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5b76ab14__0))))))));
    vlSelf->__VdfgTmp_h1dd2f13b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5b76ab14__0)));
    vlSelf->wasmetal_core__DOT___066897_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cc94077__0))));
    vlSelf->wasmetal_core__DOT___042184_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063952_))));
    vlSelf->wasmetal_core__DOT___001655_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf22a37d9__0))))));
    vlSelf->__VdfgTmp_hd9d9e38d__0 = (((IData)(vlSelf->wasmetal_core__DOT___008085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008160_));
    vlSelf->__VdfgTmp_hf0027c26__0 = (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008085_));
    vlSelf->wasmetal_core__DOT___044425_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063227_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063239_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h42ef1750__0))))))));
    vlSelf->wasmetal_core__DOT___044449_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063239_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063227_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054123_)))))))));
    vlSelf->wasmetal_core__DOT___028299_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028234_))));
    vlSelf->wasmetal_core__DOT___027347_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b22__05d))));
    vlSelf->wasmetal_core__DOT___010955_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha38d193b__0))))))));
    vlSelf->__VdfgTmp_h1e1103c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha38d193b__0)));
    vlSelf->wasmetal_core__DOT___042090_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hbb13730a__0)))))));
    vlSelf->wasmetal_core__DOT___045823_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xfU)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x12U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbb13730a__0))))));
    vlSelf->wasmetal_core__DOT___071961_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071956_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071960_)))));
    vlSelf->wasmetal_core__DOT___071957_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071952_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071956_)))));
    vlSelf->wasmetal_core__DOT___066860_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1479cba4__0))));
    vlSelf->wasmetal_core__DOT___000177_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2a3dbf89__0))))));
    vlSelf->wasmetal_core__DOT___063816_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063813_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063812_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((6U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h379ad787__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((6U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h375e931a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb948b455__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h5dede88d__0)))))))))));
    vlSelf->__VdfgTmp_h90a7e66d__0 = (((IData)(vlSelf->wasmetal_core__DOT___008077_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008152_));
    vlSelf->__VdfgTmp_h7ef390f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008077_));
    vlSelf->wasmetal_core__DOT___028298_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028233_))));
    vlSelf->wasmetal_core__DOT___027346_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b21__05d))));
    vlSelf->wasmetal_core__DOT___054851_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf20faaf0__0))))))));
    vlSelf->__VdfgTmp_h9e64b929__0 = (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf20faaf0__0)));
    vlSelf->wasmetal_core__DOT___066773_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h19f2f351__0))));
    vlSelf->wasmetal_core__DOT___042102_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063952_))));
    vlSelf->wasmetal_core__DOT___063878_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0))))));
    vlSelf->wasmetal_core__DOT___001654_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8b010904__0))))));
    vlSelf->__VdfgTmp_hc06d6619__0 = (((IData)(vlSelf->wasmetal_core__DOT___008069_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008144_));
    vlSelf->__VdfgTmp_h9ba8d2dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008069_));
    vlSelf->wasmetal_core__DOT___028297_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028232_))));
    vlSelf->wasmetal_core__DOT___027345_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b20__05d))));
    vlSelf->wasmetal_core__DOT___054805_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb187f8bb__0))))))));
    vlSelf->__VdfgTmp_h7208d2a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007333_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb187f8bb__0)));
    vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001444_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128076___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028486_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028483_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028472_) 
                                   << 1U) | (1U & (~ 
                                                   (9U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4ae0787e__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028454_ = ((IData)(vlSelf->wasmetal_core__DOT___028486_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___004744_));
    vlSelf->wasmetal_core__DOT___049092_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003815_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he16d2f4f__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b19__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000156_)))))))));
    vlSelf->wasmetal_core__DOT___066651_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5145bf91__0))));
    vlSelf->wasmetal_core__DOT___042183_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063950_))));
    vlSelf->wasmetal_core__DOT___000176_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h898e287a__0))))));
    vlSelf->__VdfgTmp_h9a7588ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___008056_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008131_));
    vlSelf->__VdfgTmp_h0cb45e24__0 = (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008056_));
    vlSelf->wasmetal_core__DOT___044424_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063209_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063215_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063221_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5eac1f1__0))))))));
    vlSelf->wasmetal_core__DOT___044448_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063221_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063215_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063209_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054111_)))))))));
    vlSelf->wasmetal_core__DOT___028295_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028230_))));
    vlSelf->wasmetal_core__DOT___027343_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b19__05d))));
    vlSelf->wasmetal_core__DOT___061898_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8499ba72__0))));
    vlSelf->wasmetal_core__DOT___010986_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8499ba72__0))))))));
    vlSelf->__VdfgTmp_habef704b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8499ba72__0)));
    vlSelf->wasmetal_core__DOT___042089_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4c89c552__0)))))));
    vlSelf->wasmetal_core__DOT___045822_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xcU)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0xfU)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4c89c552__0))))));
    vlSelf->wasmetal_core__DOT___071955_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071950_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071954_)))));
    vlSelf->wasmetal_core__DOT___071951_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071946_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071950_)))));
    vlSelf->wasmetal_core__DOT___066610_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb776b144__0))));
    vlSelf->wasmetal_core__DOT___001498_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3613bfb2__0))))));
    vlSelf->__VdfgTmp_h384cc7f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008048_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008123_));
    vlSelf->__VdfgTmp_ha7321d4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008048_));
    vlSelf->wasmetal_core__DOT___028294_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028229_))));
    vlSelf->wasmetal_core__DOT___027342_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b18__05d))));
    vlSelf->wasmetal_core__DOT___059857_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003808_))));
    vlSelf->wasmetal_core__DOT___061830_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h80fea7fc__0))));
    vlSelf->wasmetal_core__DOT___010980_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h80fea7fc__0))))))));
    vlSelf->__VdfgTmp_hcd50fd36__0 = (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h80fea7fc__0)));
    vlSelf->wasmetal_core__DOT___071953_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071948_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071952_)))));
    vlSelf->wasmetal_core__DOT___066529_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h061491a4__0))));
    vlSelf->wasmetal_core__DOT___042101_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063951_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063950_))));
    vlSelf->__VdfgTmp_h66324e1d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x6996U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((0x96U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2e3bd00c__0)) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___072034_))))))));
    vlSelf->wasmetal_core__DOT___001731_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9e6b526c__0))))));
    vlSelf->__VdfgTmp_hfa99a91b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008040_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008115_));
    vlSelf->__VdfgTmp_h2c8d302e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008040_));
    vlSelf->wasmetal_core__DOT___028293_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028228_))));
    vlSelf->wasmetal_core__DOT___048760_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048759_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048757_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))))))))));
    vlSelf->wasmetal_core__DOT___027341_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b17__05d))));
    vlSelf->wasmetal_core__DOT___061758_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h551248b6__0))));
    vlSelf->wasmetal_core__DOT___010192_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h551248b6__0))))))));
    vlSelf->__VdfgTmp_hf6b3ca0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007246_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h551248b6__0)));
    vlSelf->__VdfgTmp_h8ecdfd77__0 = (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052833_));
    vlSelf->__VdfgTmp_h7e6b8024__0 = (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052833_));
    vlSelf->wasmetal_core__DOT___066403_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd14327b4__0))));
    vlSelf->wasmetal_core__DOT___042182_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063945_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063951_))));
    vlSelf->wasmetal_core__DOT___063877_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he924c244__0))))));
    vlSelf->wasmetal_core__DOT___001497_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he924c244__0))))));
    vlSelf->__VdfgTmp_h9ea6e74c__0 = (((IData)(vlSelf->wasmetal_core__DOT___008032_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008107_));
    vlSelf->__VdfgTmp_h84d44246__0 = (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008032_));
    vlSelf->wasmetal_core__DOT___044423_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063191_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063203_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfa74de2f__0))))))));
    vlSelf->wasmetal_core__DOT___044447_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063203_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063191_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054099_)))))))));
    vlSelf->wasmetal_core__DOT___028292_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028227_))));
    vlSelf->wasmetal_core__DOT___048821_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048818_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))))))))))));
    vlSelf->wasmetal_core__DOT___027340_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b16__05d))));
    vlSelf->__VdfgTmp_he473afc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003807_));
    vlSelf->wasmetal_core__DOT___061459_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007336_)))))))));
    vlSelf->wasmetal_core__DOT___042088_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc87c06e6__0)))))));
    vlSelf->wasmetal_core__DOT___045821_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 9U)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0xcU)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc87c06e6__0))))));
    vlSelf->wasmetal_core__DOT___071949_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071944_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071948_)))));
    vlSelf->wasmetal_core__DOT___071945_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071940_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071944_)))));
    vlSelf->wasmetal_core__DOT___066323_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89e0a965__0))));
    vlSelf->wasmetal_core__DOT___067488_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066281_)))));
    vlSelf->wasmetal_core__DOT___001730_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h238b010e__0))))));
    vlSelf->__VdfgTmp_h69142c13__0 = (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008007_));
    vlSelf->wasmetal_core__DOT___028291_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028226_))));
    vlSelf->wasmetal_core__DOT___048733_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___047862_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048731_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047861_)))))))));
    vlSelf->wasmetal_core__DOT___027339_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b15__05d))));
    vlSelf->wasmetal_core__DOT___061654_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061651_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048403_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061649_)))))))));
    vlSelf->wasmetal_core__DOT___066266_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h688ac52f__0))));
    vlSelf->wasmetal_core__DOT___042100_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063945_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063935_))));
    vlSelf->wasmetal_core__DOT___001496_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7dd7d539__0))))));
    vlSelf->__VdfgTmp_h8f3d454e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007999_));
    vlSelf->wasmetal_core__DOT___028290_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028225_))));
    vlSelf->wasmetal_core__DOT___048826_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048825_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048823_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h132c3402__0))))))))))));
    vlSelf->wasmetal_core__DOT___027338_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b14__05d))));
    vlSelf->wasmetal_core__DOT___059752_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006204_))));
    vlSelf->wasmetal_core__DOT___066131_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09210432__0))));
    vlSelf->wasmetal_core__DOT___042181_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063954_))));
    vlSelf->wasmetal_core__DOT___001729_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9040377d__0))))));
    vlSelf->__VdfgTmp_h744f9b35__0 = (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007991_));
    vlSelf->wasmetal_core__DOT___044422_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063173_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063179_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063185_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcc1441d8__0))))))));
    vlSelf->wasmetal_core__DOT___044446_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063185_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063179_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063173_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054087_)))))))));
    vlSelf->wasmetal_core__DOT___028289_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028224_))));
    vlSelf->wasmetal_core__DOT___048813_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048812_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h98d262dd__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048810_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))))))))));
    vlSelf->wasmetal_core__DOT___027337_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b13__05d))));
    vlSelf->wasmetal_core__DOT___042087_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdd349d37__0)))))));
    vlSelf->wasmetal_core__DOT___045820_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 6U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 8U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xaU)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdd349d37__0)))))));
    vlSelf->wasmetal_core__DOT___066074_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hea943ba9__0))));
    vlSelf->wasmetal_core__DOT___063892_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0))))));
    vlSelf->wasmetal_core__DOT___001495_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb5d0a138__0))))));
    vlSelf->__VdfgTmp_h413b142d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007983_));
    vlSelf->wasmetal_core__DOT___028288_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028223_))));
    vlSelf->wasmetal_core__DOT___048837_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048836_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048834_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))))))))));
    vlSelf->wasmetal_core__DOT___027336_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b12__05d))));
    vlSelf->__VdfgTmp_hadeaba1a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->wasmetal_core__DOT___057235_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc5a57f40__0))))));
    vlSelf->wasmetal_core__DOT___065929_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfdfbee0__0))));
    vlSelf->wasmetal_core__DOT___042099_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063955_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063954_))));
    vlSelf->__VdfgTmp_h3a315b1c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5b878e76__0)))));
    vlSelf->wasmetal_core__DOT___001726_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdd9104ee__0))))));
    vlSelf->__VdfgTmp_h64194573__0 = (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007970_));
    vlSelf->wasmetal_core__DOT___028287_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028222_))));
    vlSelf->wasmetal_core__DOT___048776_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048775_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048773_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))))))))));
    vlSelf->wasmetal_core__DOT___027335_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b11__05d))));
    vlSelf->wasmetal_core__DOT___057005_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdc04b3f0__0))))));
    vlSelf->wasmetal_core__DOT___026570_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071947_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071939_))))));
    vlSelf->wasmetal_core__DOT___065905_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e67285f__0))));
    vlSelf->wasmetal_core__DOT___042180_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063939_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063955_))));
    vlSelf->wasmetal_core__DOT___001342_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9d768121__0))))));
    vlSelf->__VdfgTmp_h67f18e55__0 = (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007962_));
    vlSelf->wasmetal_core__DOT___044421_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063155_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063161_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063167_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h33545cb0__0))))))));
    vlSelf->wasmetal_core__DOT___044445_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063167_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063161_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063155_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054075_)))))))));
    vlSelf->wasmetal_core__DOT___028286_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028221_))));
    vlSelf->wasmetal_core__DOT___048783_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048782_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h585a3ceb__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048780_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))))))))))));
    vlSelf->wasmetal_core__DOT___027334_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b10__05d))));
    vlSelf->__VdfgTmp_h28ae1e0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->wasmetal_core__DOT___052677_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052671_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052670_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x100000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___051956_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___051955_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051954_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___004210_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004192_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004152_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x1000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051941_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051940_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005096_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003360_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003348_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x1000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___050354_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050353_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050352_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___004944_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004926_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005164_)))))))))))))));
    vlSelf->wasmetal_core__DOT___042086_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4b9179fb__0)))))));
    vlSelf->wasmetal_core__DOT___045819_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 3U)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 6U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4b9179fb__0))))));
    vlSelf->wasmetal_core__DOT___071937_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071932_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071936_)))));
    vlSelf->wasmetal_core__DOT___071933_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071928_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071932_)))));
    vlSelf->wasmetal_core__DOT___065809_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hadcc7972__0))));
    vlSelf->wasmetal_core__DOT___001725_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h06dc5af9__0))))));
    vlSelf->__VdfgTmp_h83053a2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007246_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007954_));
    vlSelf->wasmetal_core__DOT___028316_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028251_))));
    vlSelf->wasmetal_core__DOT___048768_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048767_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048765_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))))))))))));
    vlSelf->wasmetal_core__DOT___027396_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b9__05d))));
    vlSelf->wasmetal_core__DOT___059647_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006015_))));
    vlSelf->wasmetal_core__DOT___061759_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf8763693__0))));
    vlSelf->wasmetal_core__DOT___007250_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8763693__0))))))));
    vlSelf->wasmetal_core__DOT___071935_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071930_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071934_)))));
    vlSelf->wasmetal_core__DOT___071931_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071926_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071930_)))));
    vlSelf->wasmetal_core__DOT___065707_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h42e273c2__0))));
    vlSelf->wasmetal_core__DOT___042098_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063939_))));
    vlSelf->wasmetal_core__DOT___063891_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_haa154e86__0))))));
    vlSelf->wasmetal_core__DOT___001341_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_haa154e86__0))))));
    vlSelf->__VdfgTmp_hfd347d5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007431_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007946_));
    vlSelf->wasmetal_core__DOT___028315_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028250_))));
    vlSelf->wasmetal_core__DOT___048740_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048739_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_he0c10a9d__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048737_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hc231438f__0))))))))))));
    vlSelf->wasmetal_core__DOT___027395_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b8__05d))));
    vlSelf->__VdfgTmp_hbc1c04e5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006092_));
    vlSelf->wasmetal_core__DOT___003128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006400_))));
    vlSelf->__VdfgTmp_h27ece1ce__0 = ((2U & ((0xcaU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_hd163f969__0))) 
                                             << 1U)) 
                                      | (1U & (0xacU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5d6eeee4__0)))));
    vlSelf->__VdfgTmp_heab1a15e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5d6eeee4__0)));
    vlSelf->wasmetal_core__DOT___066321_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066319_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065607_))));
    vlSelf->wasmetal_core__DOT___065616_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8926b37c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065607_))));
    vlSelf->wasmetal_core__DOT___066283_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8926b37c__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065611_)))));
    vlSelf->wasmetal_core__DOT___042179_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063949_))));
    vlSelf->wasmetal_core__DOT___001724_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h61294ca4__0))))));
    vlSelf->__VdfgTmp_h57d78adc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007931_));
    vlSelf->wasmetal_core__DOT___044420_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063137_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063143_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063149_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb28d3ef__0))))))));
    vlSelf->wasmetal_core__DOT___044444_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063149_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063143_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063137_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054063_)))))))));
    vlSelf->wasmetal_core__DOT___028314_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028249_))));
    vlSelf->wasmetal_core__DOT___048753_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048752_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048750_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))))))))));
    vlSelf->wasmetal_core__DOT___027394_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b7__05d))));
    vlSelf->wasmetal_core__DOT___042085_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hbe9a07d7__0)))))));
    vlSelf->wasmetal_core__DOT___045818_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & vlSelf->insn_y) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 2U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 4U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hbe9a07d7__0)))))));
    vlSelf->wasmetal_core__DOT___065424_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf2f5c69c__0))));
    vlSelf->wasmetal_core__DOT___001340_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h03893f91__0))))));
    vlSelf->__VdfgTmp_hc326eb38__0 = (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007923_));
    vlSelf->wasmetal_core__DOT___028313_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028248_))));
    vlSelf->wasmetal_core__DOT___048893_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048892_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048890_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))))))))));
    vlSelf->wasmetal_core__DOT___027393_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b6__05d))));
    vlSelf->wasmetal_core__DOT___059542_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005745_))));
    vlSelf->wasmetal_core__DOT___065307_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46c82ccf__0))));
    vlSelf->wasmetal_core__DOT___063948_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063947_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063946_))));
    vlSelf->__VdfgTmp_h144113a8__0 = ((2U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h5b878e76__0)) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_hdbb03d5c__0))));
    vlSelf->wasmetal_core__DOT___072046_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hdbb03d5c__0)))))))));
    vlSelf->wasmetal_core__DOT___001723_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbfd77ec1__0))))));
    vlSelf->wasmetal_core__DOT___063739_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063734_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063733_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063732_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((6U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h560b7672__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb96516e6__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd3bfd495__0)))))))))));
    vlSelf->__VdfgTmp_h5aecec62__0 = (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (~ (IData)(vlSelf->wasmetal_core__DOT___035269_)))));
    vlSelf->__VdfgTmp_h57efbd27__0 = (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007915_));
    vlSelf->wasmetal_core__DOT___028312_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028247_))));
    vlSelf->wasmetal_core__DOT___048886_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048885_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048883_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))))))))))));
    vlSelf->wasmetal_core__DOT___027388_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b5__05d))));
    vlSelf->__VdfgTmp_hbbe1bed2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005921_));
    vlSelf->wasmetal_core__DOT___042355_ = (1U & (IData)(
                                                         (0xf571ffff71500000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070507_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001476_)))))))));
    vlSelf->wasmetal_core__DOT___065199_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h425ce738__0))));
    vlSelf->wasmetal_core__DOT___042154_ = (1U & (IData)(
                                                         (0xbb2bffff2b220000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0))))))));
    vlSelf->wasmetal_core__DOT___063886_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h776ad714__0))))));
    vlSelf->wasmetal_core__DOT___001339_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h776ad714__0))))));
    vlSelf->wasmetal_core__DOT___011102_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (~ (IData)(vlSelf->wasmetal_core__DOT___035269_))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->__VdfgTmp_hc9c602ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007907_));
    vlSelf->wasmetal_core__DOT___044419_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063119_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063125_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063131_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6661b389__0))))))));
    vlSelf->wasmetal_core__DOT___044443_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063131_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063125_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063119_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054051_)))))))));
    vlSelf->wasmetal_core__DOT___028311_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028246_))));
    vlSelf->wasmetal_core__DOT___048878_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048877_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h7cf17ecc__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048875_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))))))))));
    vlSelf->wasmetal_core__DOT___027377_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b4__05d))));
    vlSelf->__VdfgTmp_he7a338fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    vlSelf->wasmetal_core__DOT___044492_ = ((IData)(vlSelf->wasmetal_core__DOT___044515_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044524_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044523_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044522_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044521_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044520_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044519_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044518_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044517_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044516_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044514_) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044502_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044504_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044505_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044506_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044507_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044508_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044509_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044510_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044511_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044512_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044503_));
    vlSelf->wasmetal_core__DOT___042084_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc7b853f6__0)))))));
    vlSelf->wasmetal_core__DOT___045817_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc7b853f6__0)))))));
    vlSelf->wasmetal_core__DOT___049163_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004697_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hfcbc0180__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001996_)))))))));
    vlSelf->wasmetal_core__DOT___001937_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcc4a801d__0))))));
    vlSelf->wasmetal_core__DOT___010722_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                                   >> 3U)))))))));
    vlSelf->__VdfgTmp_h1327a702__0 = (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007894_));
    vlSelf->wasmetal_core__DOT___028310_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028245_))));
    vlSelf->wasmetal_core__DOT___027366_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b3__05d))));
    vlSelf->wasmetal_core__DOT___061899_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8d9b1452__0))));
    vlSelf->wasmetal_core__DOT___010348_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8d9b1452__0))))))));
    vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026454_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b0__05d));
    vlSelf->wasmetal_core__DOT___071923_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071918_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071922_)))));
    vlSelf->wasmetal_core__DOT___071919_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071914_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071918_)))));
    vlSelf->wasmetal_core__DOT___026592_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071929_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071921_))))));
    vlSelf->wasmetal_core__DOT___026588_ = (1U & (0xcf30aa55U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071921_)))))));
    vlSelf->wasmetal_core__DOT___026590_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071925_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071917_))))));
    vlSelf->wasmetal_core__DOT___026584_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071917_)))));
    vlSelf->wasmetal_core__DOT___044308_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044354_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044353_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044351_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044350_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044349_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044348_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044347_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044346_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044345_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044344_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044343_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044342_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044362_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044361_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044360_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044359_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044358_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044357_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___044356_)
                                                                     ? 
                                                                    ((IData)(vlSelf->wasmetal_core__DOT___044355_)
                                                                      ? 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___044352_)
                                                                       ? 
                                                                      (0xeU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hc01d1a00__0))
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___044328_))
                                                                      : (IData)(vlSelf->wasmetal_core__DOT___044331_))
                                                                     : (IData)(vlSelf->wasmetal_core__DOT___044332_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___044333_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___044334_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___044335_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044336_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044337_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044338_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044318_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044319_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044320_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044321_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044322_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044323_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044324_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044325_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044326_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044327_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044329_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044330_)));
    vlSelf->wasmetal_core__DOT___049155_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004771_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd09f2908__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001951_)))))))));
    vlSelf->wasmetal_core__DOT___064901_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11b4d04e__0))));
    vlSelf->wasmetal_core__DOT___042096_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063934_))));
    vlSelf->wasmetal_core__DOT___063783_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063775_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((6U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h77a25d8c__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0d1a9c72__0)))))));
    vlSelf->wasmetal_core__DOT___010721_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->__VdfgTmp_hef814ba9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007886_));
    vlSelf->wasmetal_core__DOT___044416_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063113_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h66f1f037__0))))))));
    vlSelf->wasmetal_core__DOT___044440_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063113_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063101_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054039_)))))))));
    vlSelf->wasmetal_core__DOT___028307_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028242_))));
    vlSelf->wasmetal_core__DOT___027355_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b2__05d))));
    vlSelf->__VdfgTmp_h68317e95__0 = (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005716_)));
    vlSelf->__VdfgTmp_h4dc07bf4__0 = ((2U & ((IData)(
                                                     (0x1000000000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___061452_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061451_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___007333_)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x1000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___061450_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061449_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007334_))))))))));
    vlSelf->wasmetal_core__DOT___061831_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5af86920__0))));
    vlSelf->wasmetal_core__DOT___010369_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5af86920__0))))))));
    vlSelf->wasmetal_core__DOT___048829_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0643d6d2__0))));
    if (vlSelf->wasmetal_core__DOT___000182_) {
        vlSelf->wasmetal_core__DOT___002288_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001289_));
        vlSelf->wasmetal_core__DOT___002729_ = vlSelf->wasmetal_core__DOT___002111_;
        vlSelf->wasmetal_core__DOT___002852_ = vlSelf->wasmetal_core__DOT___002147_;
        vlSelf->wasmetal_core__DOT___002271_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___000721_));
        vlSelf->wasmetal_core__DOT___000167_ = vlSelf->wasmetal_core__DOT___000722_;
    } else {
        vlSelf->wasmetal_core__DOT___002288_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001286_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001662_))))));
        vlSelf->wasmetal_core__DOT___002729_ = vlSelf->wasmetal_core__DOT___002110_;
        vlSelf->wasmetal_core__DOT___002852_ = vlSelf->wasmetal_core__DOT___002387_;
        vlSelf->wasmetal_core__DOT___002271_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000718_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000574_))))));
        vlSelf->wasmetal_core__DOT___000167_ = vlSelf->wasmetal_core__DOT___000721_;
    }
    vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031073_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___055433_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055423_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055422_)))));
    if (vlSelf->wasmetal_core__DOT___007204_) {
        vlSelf->wasmetal_core__DOT___010287_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha44be0e2__0)));
        vlSelf->wasmetal_core__DOT___010981_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1e9537b6__0)));
        vlSelf->wasmetal_core__DOT___010279_ = vlSelf->wasmetal_core__DOT___007469_;
        vlSelf->wasmetal_core__DOT___010251_ = vlSelf->wasmetal_core__DOT___007488_;
        vlSelf->wasmetal_core__DOT___010239_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h02da39da__0)));
        vlSelf->wasmetal_core__DOT___010987_ = vlSelf->wasmetal_core__DOT___007584_;
        vlSelf->wasmetal_core__DOT___054850_ = vlSelf->wasmetal_core__DOT___007618_;
        vlSelf->wasmetal_core__DOT___010956_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007639_));
        vlSelf->wasmetal_core__DOT___009791_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7b8e4425__0)));
        vlSelf->wasmetal_core__DOT___010191_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h65d58b23__0)));
        vlSelf->wasmetal_core__DOT___009795_ = vlSelf->wasmetal_core__DOT___007717_;
        vlSelf->wasmetal_core__DOT___009814_ = vlSelf->wasmetal_core__DOT___007739_;
        vlSelf->wasmetal_core__DOT___009781_ = vlSelf->wasmetal_core__DOT___007754_;
        vlSelf->wasmetal_core__DOT___010213_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3297ffb7__0)));
        vlSelf->wasmetal_core__DOT___009649_ = vlSelf->wasmetal_core__DOT___007504_;
        vlSelf->wasmetal_core__DOT___054853_ = vlSelf->wasmetal_core__DOT___007659_;
    } else {
        vlSelf->wasmetal_core__DOT___010287_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007283_));
        vlSelf->wasmetal_core__DOT___010981_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha44be0e2__0)));
        vlSelf->wasmetal_core__DOT___010279_ = vlSelf->wasmetal_core__DOT___007310_;
        vlSelf->wasmetal_core__DOT___010251_ = vlSelf->wasmetal_core__DOT___007369_;
        vlSelf->wasmetal_core__DOT___010239_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007395_));
        vlSelf->wasmetal_core__DOT___010987_ = vlSelf->wasmetal_core__DOT___007469_;
        vlSelf->wasmetal_core__DOT___054850_ = vlSelf->wasmetal_core__DOT___007488_;
        vlSelf->wasmetal_core__DOT___010956_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h02da39da__0)));
        vlSelf->wasmetal_core__DOT___009791_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1e9537b6__0)));
        vlSelf->wasmetal_core__DOT___010191_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd9d6cde__0)));
        vlSelf->wasmetal_core__DOT___009795_ = vlSelf->wasmetal_core__DOT___007584_;
        vlSelf->wasmetal_core__DOT___009814_ = vlSelf->wasmetal_core__DOT___007618_;
        vlSelf->wasmetal_core__DOT___009781_ = vlSelf->wasmetal_core__DOT___007639_;
        vlSelf->wasmetal_core__DOT___010213_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h65d58b23__0)));
        vlSelf->wasmetal_core__DOT___009649_ = vlSelf->wasmetal_core__DOT___007422_;
        vlSelf->wasmetal_core__DOT___054853_ = vlSelf->wasmetal_core__DOT___007504_;
    }
    vlSelf->wasmetal_core__DOT___060904_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfd8d7c51__0)))));
    vlSelf->wasmetal_core__DOT___054814_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfd8d7c51__0)))));
    vlSelf->wasmetal_core__DOT___051518_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048599_))));
    vlSelf->wasmetal_core__DOT___048606_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048599_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->__VdfgTmp_h1fbedb27__0 = (((IData)(vlSelf->wasmetal_core__DOT___054821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054820_));
    vlSelf->__VdfgTmp_hf131a410__0 = (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054815_));
    vlSelf->wasmetal_core__DOT___049026_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004913_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9b410c9d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b26__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002800_)))))))));
    vlSelf->wasmetal_core__DOT___061846_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8be24d75__0))))));
    vlSelf->wasmetal_core__DOT___055432_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055425_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055424_)))));
    vlSelf->__VdfgTmp_h7c4aea26__0 = (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007259_));
    vlSelf->wasmetal_core__DOT___027479_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054821_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007280_)))))))));
    vlSelf->wasmetal_core__DOT___007778_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007257_))))));
    vlSelf->__VdfgTmp_h6b40768b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007259_))));
    vlSelf->wasmetal_core__DOT___010371_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007257_)))))))));
    vlSelf->wasmetal_core__DOT___010290_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007260_)))))))));
    vlSelf->__VdfgTmp_h8c85186d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054810_));
    vlSelf->wasmetal_core__DOT___060880_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78fd8e0c__0)))));
    vlSelf->wasmetal_core__DOT___054813_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78fd8e0c__0)))));
    vlSelf->wasmetal_core__DOT___055431_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055427_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055426_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007548_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007549_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h797b2590__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007546_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007547_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007544_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007545_)))))))))))))));
    vlSelf->__VdfgTmp_h66742b2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007547_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007546_));
    vlSelf->wasmetal_core__DOT___010370_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007548_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007549_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007546_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007547_)))))))));
    vlSelf->__VdfgTmp_h98124bc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054821_));
    vlSelf->__VdfgTmp_had16ce46__0 = (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054816_));
    vlSelf->wasmetal_core__DOT___060974_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd70fe4ce__0)))));
    vlSelf->wasmetal_core__DOT___054859_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd70fe4ce__0)))));
    vlSelf->__VdfgTmp_h2cfd74cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054339_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054338_) 
                                                        << 2U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            & (IData)(
                                                                      (0xccaa0000f0f0ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h7678d7b9__0)))))) 
                                                           << 1U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                             & (IData)(
                                                                       (0xccaaf0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                          << 5U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h3c09d3eb__0))))))))));
    vlSelf->__VdfgTmp_ha17fb340__0 = (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054899_));
    vlSelf->wasmetal_core__DOT___051547_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048604_))));
    vlSelf->wasmetal_core__DOT___048605_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048604_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___055779_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___061500_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054866_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054821_))));
    vlSelf->__VdfgTmp_h15fa30e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___054866_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054865_));
    vlSelf->wasmetal_core__DOT___061142_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbb17ca10__0)))));
    vlSelf->wasmetal_core__DOT___054955_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbb17ca10__0)))));
    vlSelf->wasmetal_core__DOT___051579_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048658_))));
    vlSelf->wasmetal_core__DOT___048660_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048658_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___010547_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2fc9f8d__0))));
    vlSelf->__VdfgTmp_h82899d97__0 = (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054909_));
    vlSelf->wasmetal_core__DOT___051611_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048653_))));
    vlSelf->wasmetal_core__DOT___048659_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048653_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___055807_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055594_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___010553_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2fc9f8d__0))));
    vlSelf->__VdfgTmp_hb53fd6c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007729_));
    vlSelf->__VdfgTmp_h5cfad588__0 = (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054959_));
    vlSelf->wasmetal_core__DOT___051628_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048668_))));
    vlSelf->wasmetal_core__DOT___048670_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048668_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___061696_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1f51ea8e__0))))));
    vlSelf->wasmetal_core__DOT___055829_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055652_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055651_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055650_)))));
    vlSelf->wasmetal_core__DOT___007824_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007623_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007624_))))));
    vlSelf->__VdfgTmp_h9c4c7506__0 = (((IData)(vlSelf->wasmetal_core__DOT___055001_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055000_));
    vlSelf->wasmetal_core__DOT___061235_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4d98d40a__0)))));
    vlSelf->wasmetal_core__DOT___054994_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4d98d40a__0)))));
    vlSelf->wasmetal_core__DOT___055501_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055497_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055496_)))));
    vlSelf->wasmetal_core__DOT___061492_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007453_))));
    vlSelf->__VdfgTmp_hca7cb6a3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054860_));
    vlSelf->wasmetal_core__DOT___061692_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4ffde934__0))))));
    vlSelf->wasmetal_core__DOT___055793_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055514_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055517_)))));
    vlSelf->wasmetal_core__DOT___055521_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055517_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055516_)))));
    vlSelf->wasmetal_core__DOT___054913_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4b751076__0)))));
    vlSelf->wasmetal_core__DOT___054963_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2eb2dfca__0)))));
    vlSelf->__VdfgTmp_h223b6529__0 = (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054995_));
    vlSelf->wasmetal_core__DOT___049029_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004981_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h6305c07b__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002842_)))))))));
    vlSelf->wasmetal_core__DOT___061916_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4ab1d453__0))))));
    vlSelf->wasmetal_core__DOT___055781_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055494_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055497_)))));
    vlSelf->wasmetal_core__DOT___055502_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055495_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055494_)))));
    vlSelf->wasmetal_core__DOT___061486_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007259_))));
    vlSelf->__VdfgTmp_hf4e23b72__0 = (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007286_));
    vlSelf->wasmetal_core__DOT___027480_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054866_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007307_)))))))));
    vlSelf->wasmetal_core__DOT___007782_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007284_))))));
    vlSelf->__VdfgTmp_h883d5f24__0 = (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007286_))));
    vlSelf->wasmetal_core__DOT___010350_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007284_)))))))));
    vlSelf->wasmetal_core__DOT___010280_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007287_)))))))));
    vlSelf->__VdfgTmp_h08beb063__0 = (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051496_));
    vlSelf->wasmetal_core__DOT___007586_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf224ceca__0)))));
    vlSelf->wasmetal_core__DOT___007473_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf224ceca__0)))));
    vlSelf->__VdfgTmp_hf89db412__0 = (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007346_));
    vlSelf->wasmetal_core__DOT___027482_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007366_)))))))));
    vlSelf->wasmetal_core__DOT___007786_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007344_))))));
    vlSelf->__VdfgTmp_h379220a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007346_))));
    vlSelf->__VdfgTmp_hba71a165__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007344_))))));
    vlSelf->wasmetal_core__DOT___010252_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007347_)))))))));
    vlSelf->__VdfgTmp_hd8993186__0 = (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054951_));
    vlSelf->wasmetal_core__DOT___060956_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h721400e1__0)))));
    vlSelf->wasmetal_core__DOT___054858_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h721400e1__0)))));
    vlSelf->wasmetal_core__DOT___049008_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005185_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h6b2c9c37__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b30__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002884_)))))))));
    vlSelf->__VdfgTmp_h6b713560__0 = (((IData)(vlSelf->wasmetal_core__DOT___055646_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055649_));
    vlSelf->__VdfgTmp_hfb017232__0 = (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007372_));
    vlSelf->wasmetal_core__DOT___027483_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055001_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007392_)))))))));
    vlSelf->wasmetal_core__DOT___007789_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007370_))))));
    vlSelf->__VdfgTmp_h7b1ed1fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007372_))));
    vlSelf->wasmetal_core__DOT___010333_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007370_)))))))));
    vlSelf->wasmetal_core__DOT___010242_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007373_)))))))));
    vlSelf->__VdfgTmp_h61af7368__0 = (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054990_));
    vlSelf->wasmetal_core__DOT___061979_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2014cd64__0))))));
    vlSelf->wasmetal_core__DOT___055794_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055512_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055515_)))));
    vlSelf->wasmetal_core__DOT___055523_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054899_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055512_)))));
    vlSelf->__VdfgTmp_h496bba40__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053919_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053918_) 
                                                        << 2U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            & (IData)(
                                                                      (0xccaaf0f000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                         << 5U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h504ea901__0))))) 
                                                           << 1U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                             & (IData)(
                                                                       (0xccaa0000f0f0ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                             << 4U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h2cdc7e5b__0)))))))))));
    vlSelf->__VdfgTmp_h8a3dc284__0 = (((IData)(vlSelf->wasmetal_core__DOT___053919_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___053918_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                                         & (IData)(
                                                                   (0x33ff55ff0fff0fffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h6277318a__0))))))) 
                                                        << 1U)) 
                                                    | ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                       & (IData)(
                                                                 (0x33ff55ff0fff0fffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                          << 3U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hbaaa25aa__0))))))))));
    vlSelf->__VdfgTmp_hb33d3cb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054898_));
    vlSelf->wasmetal_core__DOT___061126_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h112f9280__0)))));
    vlSelf->wasmetal_core__DOT___054954_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h112f9280__0)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007569_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007570_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hb4c136ee__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007567_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007568_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007565_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007566_)))))))))))))));
    vlSelf->__VdfgTmp_h0761bbb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007568_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007567_));
    vlSelf->wasmetal_core__DOT___010351_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007570_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007567_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007568_)))))))));
    vlSelf->wasmetal_core__DOT___061495_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054862_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054817_))));
    vlSelf->__VdfgTmp_h28d1a2cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___054862_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054866_));
    vlSelf->__VdfgTmp_h891cd943__0 = (((IData)(vlSelf->wasmetal_core__DOT___054862_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054861_));
    vlSelf->wasmetal_core__DOT___055655_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055645_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055644_)))));
    vlSelf->wasmetal_core__DOT___061208_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h24bf73d0__0)))));
    vlSelf->wasmetal_core__DOT___054993_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h24bf73d0__0)))));
    vlSelf->__VdfgTmp_h3856dbf8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007587_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007588_));
    vlSelf->__VdfgTmp_hb6cab41b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007718_));
    vlSelf->__VdfgTmp_h2a3772ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007718_))));
    vlSelf->wasmetal_core__DOT___054928_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007720_)))))))));
    vlSelf->__VdfgTmp_he9d168d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007719_)));
    vlSelf->__VdfgTmp_hbc236300__0 = (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054907_));
    vlSelf->__VdfgTmp_h973345c0__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h372c3d93__0)))))))) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007601_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007602_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007599_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___007600_))))))))));
    vlSelf->wasmetal_core__DOT___054852_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007234_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007602_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007601_)))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007600_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007599_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007604_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007603_))))));
    vlSelf->__VdfgTmp_h37a4ed19__0 = (((IData)(vlSelf->wasmetal_core__DOT___007601_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007602_));
    vlSelf->wasmetal_core__DOT___061410_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054957_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054959_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054949_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054951_)))))))))))));
    vlSelf->__VdfgTmp_hae784e62__0 = (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007729_));
    vlSelf->__VdfgTmp_he182d032__0 = (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007346_));
    vlSelf->__VdfgTmp_hd5551ada__0 = (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007730_)));
    vlSelf->__VdfgTmp_h0d308a29__0 = (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054957_));
    vlSelf->__VdfgTmp_h8d86a2a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007622_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007621_));
    vlSelf->wasmetal_core__DOT___010332_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007623_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007624_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007621_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007622_)))))))));
    vlSelf->wasmetal_core__DOT___061421_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054997_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055001_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054996_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055000_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054988_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054990_)))))))))))));
    vlSelf->__VdfgTmp_h5d11eb70__0 = (((IData)(vlSelf->wasmetal_core__DOT___054997_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055001_));
    vlSelf->__VdfgTmp_h6e5b7cf0__0 = (((IData)(vlSelf->wasmetal_core__DOT___054997_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054996_));
    vlSelf->wasmetal_core__DOT___048973_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004031_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5d95a729__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b18__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002281_)))))))));
    vlSelf->wasmetal_core__DOT___054812_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc5dd9afa__0)))));
    vlSelf->wasmetal_core__DOT___061678_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1d87626c__0))))));
    vlSelf->wasmetal_core__DOT___055957_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f555500ff3333ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055424_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055427_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055426_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055429_))))))))))));
    vlSelf->__VdfgTmp_h949b8002__0 = (((IData)(vlSelf->wasmetal_core__DOT___055429_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055428_));
    vlSelf->wasmetal_core__DOT___010589_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007691_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007690_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007688_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007689_)))))))));
    vlSelf->wasmetal_core__DOT___010760_ = (1U & (0xf11U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007690_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007691_))))));
    vlSelf->wasmetal_core__DOT___009793_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___007693_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                      ? 
                                                     (0xf1111U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007691_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007690_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007689_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007688_))))))
                                                      : 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007692_))))));
    vlSelf->wasmetal_core__DOT___010289_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007692_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007691_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007690_)))))));
    vlSelf->wasmetal_core__DOT___060941_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054815_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054818_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054807_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054809_))))))))))))));
    vlSelf->wasmetal_core__DOT___010090_ = (1U & (IData)(
                                                         (0xaaf0cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054821_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054819_)))))))));
    vlSelf->__VdfgTmp_hce304a5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054821_))));
    vlSelf->wasmetal_core__DOT___027486_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007281_)))))))));
    vlSelf->__VdfgTmp_hb63b65e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054818_));
    vlSelf->wasmetal_core__DOT___060821_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he2e8a11a__0)))));
    vlSelf->wasmetal_core__DOT___054774_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he2e8a11a__0)))));
    vlSelf->wasmetal_core__DOT___048617_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048616_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051364_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048616_))));
    vlSelf->wasmetal_core__DOT___061673_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3e487a94__0))))));
    vlSelf->wasmetal_core__DOT___055749_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055373_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055375_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055374_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055373_)))));
    vlSelf->__VdfgTmp_hd184a96b__0 = (((IData)(vlSelf->wasmetal_core__DOT___054782_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054781_));
    vlSelf->wasmetal_core__DOT___007447_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc18298c4__0)))));
    vlSelf->wasmetal_core__DOT___060794_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7d64f39__0)))));
    vlSelf->wasmetal_core__DOT___054773_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7d64f39__0)))));
    vlSelf->wasmetal_core__DOT___061782_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h84babf9f__0))))));
    vlSelf->wasmetal_core__DOT___055751_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055369_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055372_)))));
    vlSelf->wasmetal_core__DOT___055377_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055370_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055369_)))));
    vlSelf->wasmetal_core__DOT___007525_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hee719ca8__0)))));
    vlSelf->wasmetal_core__DOT___007232_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hee719ca8__0)))));
    vlSelf->__VdfgTmp_h939caa69__0 = (((IData)(vlSelf->wasmetal_core__DOT___007527_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007526_));
    vlSelf->__VdfgTmp_hd173054d__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h4b751076__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf21032c8__0))))));
    vlSelf->wasmetal_core__DOT___061704_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hee831718__0))))));
    vlSelf->wasmetal_core__DOT___055808_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055595_)))));
    vlSelf->wasmetal_core__DOT___055596_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055594_)))));
    vlSelf->__VdfgTmp_hb9c84dcf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h13d2f137__0)));
    vlSelf->wasmetal_core__DOT___010558_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007743_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007744_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2aa6a52e__0))))));
    vlSelf->__VdfgTmp_h29ef1e90__0 = (((IData)(vlSelf->wasmetal_core__DOT___007744_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007743_));
    vlSelf->wasmetal_core__DOT___061276_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054995_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054998_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054987_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054989_))))))))))))));
    vlSelf->__VdfgTmp_hacafe368__0 = (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054997_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055001_))));
    vlSelf->wasmetal_core__DOT___027490_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007393_)))))))));
    vlSelf->__VdfgTmp_h997e3a26__0 = (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054998_));
    vlSelf->wasmetal_core__DOT___054857_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he6aadab7__0)))));
    vlSelf->wasmetal_core__DOT___061682_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha87b9f86__0))))));
    vlSelf->wasmetal_core__DOT___055780_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055496_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055499_)))));
    vlSelf->wasmetal_core__DOT___055500_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055499_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055498_)))));
    vlSelf->wasmetal_core__DOT___010582_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007707_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007706_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h009b2026__0))))))));
    vlSelf->__VdfgTmp_h7619e45d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007707_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007706_));
    vlSelf->wasmetal_core__DOT___061498_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054819_))));
    vlSelf->wasmetal_core__DOT___061026_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054860_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054863_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051493_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051498_))))))))))))));
    vlSelf->__VdfgTmp_h2ac55b8c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054862_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054866_))));
    vlSelf->wasmetal_core__DOT___027487_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007308_)))))))));
    vlSelf->__VdfgTmp_h6b627b07__0 = (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054863_));
    vlSelf->wasmetal_core__DOT___049095_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003889_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he4dfb545__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b20__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002317_)))))))));
    vlSelf->__VdfgTmp_hcb043302__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055073_) 
                                                     << 3U) 
                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         & (IData)(
                                                                   (0xccaaf0f000000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                      << 5U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h6ab1a2ea__0))))) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054338_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___054339_))))));
    vlSelf->wasmetal_core__DOT___007470_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6ab1a2ea__0)))));
    vlSelf->wasmetal_core__DOT___063764_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063758_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063757_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063756_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf351ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3b966d55__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h957273a9__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003091_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h585a3ceb__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he0c10a9d__0)))))))))));
    vlSelf->wasmetal_core__DOT___049063_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003369_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hadae1421__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002594_)))))))));
    vlSelf->wasmetal_core__DOT___055810_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055588_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055591_)))));
    vlSelf->wasmetal_core__DOT___055598_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055591_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055590_)))));
    vlSelf->__VdfgTmp_h02022f9b__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h642b0391__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h2eb2dfca__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd27b8df6__0)))))));
    vlSelf->wasmetal_core__DOT___054953_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h642b0391__0)))));
    vlSelf->wasmetal_core__DOT___049060_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003301_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd44758f6__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002555_)))))))));
    vlSelf->wasmetal_core__DOT___062098_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h401bf3cf__0))))));
    vlSelf->wasmetal_core__DOT___055654_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055647_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055646_)))));
    vlSelf->wasmetal_core__DOT___054992_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h597612ae__0)))));
    vlSelf->wasmetal_core__DOT___009830_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011713_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011712_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf00001111ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007677_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007678_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd5802a9c__0))))))))))))));
    vlSelf->wasmetal_core__DOT___054772_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e3b944f__0)))));
    vlSelf->wasmetal_core__DOT___054797_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007526_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007527_)))))))));
    vlSelf->wasmetal_core__DOT___055136_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc52c52a3__0)))));
    vlSelf->wasmetal_core__DOT___054780_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc52c52a3__0)))));
    vlSelf->wasmetal_core__DOT___061666_ = (1U & (0xa0c0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h73281823__0))));
    vlSelf->__VdfgTmp_h2966a39c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054150_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054149_) 
                                                        << 2U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            & (IData)(
                                                                      (0xccaa0000f0f0ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h81bae7c4__0)))))) 
                                                           << 1U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                             & (IData)(
                                                                       (0xccaaf0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                          << 5U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hc859778d__0))))))))));
    vlSelf->wasmetal_core__DOT___048618_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048611_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051344_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048611_))));
    vlSelf->wasmetal_core__DOT___060480_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048712_))));
    vlSelf->__VdfgTmp_h5e920d5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048713_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048712_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019197_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___048711_)))));
    vlSelf->wasmetal_core__DOT___010386_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___060688_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3265141f__0)))));
    vlSelf->wasmetal_core__DOT___055089_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3265141f__0)))));
    vlSelf->wasmetal_core__DOT___055338_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055327_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055326_)))));
    vlSelf->__VdfgTmp_hdeccdd32__0 = (((IData)(vlSelf->wasmetal_core__DOT___054739_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054738_));
    vlSelf->__VdfgTmp_hb4fb5a01__0 = (((IData)(vlSelf->wasmetal_core__DOT___007661_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007660_));
    vlSelf->__VdfgTmp_hfc1711e0__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6ad9b652__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h705cf6e2__0))))));
    vlSelf->wasmetal_core__DOT___055336_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055331_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055330_)))));
    vlSelf->__VdfgTmp_hd4d40399__0 = (((IData)(vlSelf->wasmetal_core__DOT___007510_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007509_));
    vlSelf->__VdfgTmp_ha85bab6c__0 = (((IData)(vlSelf->wasmetal_core__DOT___053788_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___053787_));
    vlSelf->wasmetal_core__DOT___061612_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2142849a__0))))));
    vlSelf->__VdfgTmp_h1f7f3a50__0 = (((IData)(vlSelf->wasmetal_core__DOT___055326_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055329_));
    vlSelf->wasmetal_core__DOT___055337_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055329_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055328_)))));
    vlSelf->__VdfgTmp_h86442115__0 = (((IData)(vlSelf->wasmetal_core__DOT___054893_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054894_));
    vlSelf->__VdfgTmp_hae0eb281__0 = (((IData)(vlSelf->wasmetal_core__DOT___007508_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007507_));
    vlSelf->__VdfgTmp_hbc09f2bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053786_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053785_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053784_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___053783_))))));
    vlSelf->__VdfgTmp_he26aa999__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054142_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054141_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054140_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___054139_))))));
    vlSelf->wasmetal_core__DOT___061631_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ef442fa__0))))));
    vlSelf->__VdfgTmp_h73a9d128__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hbbe663c1__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hebcfe313__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h284fdec6__0)))))));
    vlSelf->wasmetal_core__DOT___054727_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xffff3355fffff0f0ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ad9b652__0))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hebcfe313__0))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff3355fffff0f0ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h705cf6e2__0))) 
                                                                                << 2U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h284fdec6__0))))))))))));
    vlSelf->__VdfgTmp_h3d8d5ec6__0 = ((4U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055330_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___055333_)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___055332_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055319_)));
    vlSelf->wasmetal_core__DOT___055335_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055333_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055332_)))));
    vlSelf->wasmetal_core__DOT___010780_ = (1U & (0xf0110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007662_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007663_)))))));
    vlSelf->wasmetal_core__DOT___056201_ = (1U & (0x100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007234_))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053790_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___053789_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff00000eeee0000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053784_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053783_) 
                                                                              << 2U) 
                                                                             | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                & (IData)(
                                                                                (0xccaaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h528a2190__0))))) 
                                                                                << 1U) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                & (IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h38ad22b9__0))))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053788_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053787_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053786_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053785_)))))))))))))));
    vlSelf->__VdfgTmp_hcab0eaad__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054140_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054139_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054149_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___054150_)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff00000eeeeULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054152_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054151_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054142_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___054141_))))))))));
    vlSelf->wasmetal_core__DOT___011622_ = (1U & (0xf11U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054151_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054152_))))));
    vlSelf->wasmetal_core__DOT___054157_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054152_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054151_)))))));
    vlSelf->wasmetal_core__DOT___061761_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055047_))));
    vlSelf->wasmetal_core__DOT___061501_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055001_))));
    vlSelf->__VdfgTmp_haef34542__0 = (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055046_));
    vlSelf->wasmetal_core__DOT___055682_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055672_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055671_)))));
    vlSelf->wasmetal_core__DOT___061482_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061479_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061478_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054709_)))))))));
    vlSelf->wasmetal_core__DOT___061296_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h064a3607__0)))));
    vlSelf->wasmetal_core__DOT___055040_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h064a3607__0)))));
    if (vlSelf->wasmetal_core__DOT___044036_) {
        if (vlSelf->wasmetal_core__DOT___044035_) {
            if (vlSelf->wasmetal_core__DOT___044034_) {
                if (vlSelf->wasmetal_core__DOT___044033_) {
                    if (vlSelf->wasmetal_core__DOT___135372___DOT__CO__BRA__1__KET__) {
                        vlSelf->wasmetal_core__DOT___045623_ = 1U;
                        vlSelf->wasmetal_core__DOT___044026_ 
                            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044039_) 
                                     | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d)));
                        vlSelf->wasmetal_core__DOT___044045_ 
                            = (1U & (0xcU >> (IData)(vlSelf->__VdfgTmp_h3a53928b__0)));
                    } else {
                        vlSelf->wasmetal_core__DOT___045623_ = 0U;
                        vlSelf->wasmetal_core__DOT___044026_ 
                            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___135372___DOT__CO__BRA__1__KET__)));
                        vlSelf->wasmetal_core__DOT___044045_ 
                            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___135372___DOT__CO__BRA__1__KET__)));
                    }
                    vlSelf->wasmetal_core__DOT___045632_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___045636_)
                                  ? (1U >> (IData)(vlSelf->__VdfgTmp_h3a53928b__0))
                                  : (IData)(vlSelf->wasmetal_core__DOT___135372___DOT__CO__BRA__1__KET__)));
                } else {
                    vlSelf->wasmetal_core__DOT___045623_ = 0U;
                    vlSelf->wasmetal_core__DOT___044026_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044033_)));
                    vlSelf->wasmetal_core__DOT___044045_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044033_)));
                    vlSelf->wasmetal_core__DOT___045632_ = 0U;
                }
            } else {
                vlSelf->wasmetal_core__DOT___045623_ = 0U;
                vlSelf->wasmetal_core__DOT___044026_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044034_)));
                vlSelf->wasmetal_core__DOT___044045_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044034_)));
                vlSelf->wasmetal_core__DOT___045632_ = 0U;
            }
        } else {
            vlSelf->wasmetal_core__DOT___045623_ = 0U;
            vlSelf->wasmetal_core__DOT___044026_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044035_)));
            vlSelf->wasmetal_core__DOT___044045_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044035_)));
            vlSelf->wasmetal_core__DOT___045632_ = 0U;
        }
    } else {
        vlSelf->wasmetal_core__DOT___045623_ = 0U;
        vlSelf->wasmetal_core__DOT___044026_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044036_)));
        vlSelf->wasmetal_core__DOT___044045_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044036_)));
        vlSelf->wasmetal_core__DOT___045632_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___061493_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007489_))));
    vlSelf->__VdfgTmp_h49097fbe__0 = (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055041_));
    vlSelf->wasmetal_core__DOT___049011_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005572_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h92d236ac__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003055_)))))))));
    vlSelf->wasmetal_core__DOT___061855_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007398_))));
    vlSelf->wasmetal_core__DOT___061487_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007372_))));
    vlSelf->__VdfgTmp_h13e1c0a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007398_));
    vlSelf->wasmetal_core__DOT___027484_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007419_)))))))));
    vlSelf->wasmetal_core__DOT___007792_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007396_))))));
    vlSelf->wasmetal_core__DOT___009652_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007399_)))))))));
    vlSelf->__VdfgTmp_he0ff0f52__0 = (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007398_))));
    vlSelf->__VdfgTmp_h5d8e5746__0 = (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055036_));
    vlSelf->__VdfgTmp_h22d02546__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007396_))))));
    vlSelf->wasmetal_core__DOT___061483_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061480_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054706_)))))))));
    vlSelf->wasmetal_core__DOT___060701_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he97c005b__0)))));
    vlSelf->wasmetal_core__DOT___055039_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he97c005b__0)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007645_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2df8dd7f__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007642_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007643_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007640_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007641_)))))))))))))));
    vlSelf->__VdfgTmp_hf2283ef8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007643_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007642_));
    vlSelf->wasmetal_core__DOT___010311_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007642_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007643_)))))))));
    vlSelf->wasmetal_core__DOT___061494_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054997_))));
    vlSelf->__VdfgTmp_hde31b2d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055047_));
    vlSelf->__VdfgTmp_hb53c364f__0 = (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055042_));
    vlSelf->wasmetal_core__DOT___053069_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044039_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e8d73de__0))));
    vlSelf->wasmetal_core__DOT___053071_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3a53928b__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e8d73de__0))));
    vlSelf->wasmetal_core__DOT___048629_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048628_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051324_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048628_))));
    vlSelf->wasmetal_core__DOT___061700_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h703df812__0))))));
    vlSelf->wasmetal_core__DOT___055679_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055678_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055677_)))));
    vlSelf->wasmetal_core__DOT___055860_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055675_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055678_)))));
    vlSelf->__VdfgTmp_hce8e9d12__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0ccccff00aaaaULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007419_))))))))) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007759_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007758_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h0fc2ac4f__0)))))))));
    vlSelf->__VdfgTmp_h7e54e6f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007759_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007758_));
    vlSelf->wasmetal_core__DOT___061499_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054999_))));
    vlSelf->wasmetal_core__DOT___061343_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055041_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055044_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055033_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055035_))))))))))))));
    vlSelf->wasmetal_core__DOT___027491_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007420_)))))))));
    vlSelf->__VdfgTmp_hfe0abeab__0 = (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055047_))));
    vlSelf->__VdfgTmp_hd9dc27af__0 = (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055044_));
    vlSelf->__VdfgTmp_h6a47c3d1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007418_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007769_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007659_)));
    vlSelf->wasmetal_core__DOT___055038_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h72b22246__0)))));
    vlSelf->__VdfgTmp_h703a7a56__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___002235_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___000181_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000180_));
    vlSelf->wasmetal_core__DOT___055857_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055665_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055672_)))));
    vlSelf->wasmetal_core__DOT___055020_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb23bd85a__0)))));
    vlSelf->wasmetal_core__DOT___051648_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048663_))));
    vlSelf->wasmetal_core__DOT___048669_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048663_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___014611_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017194_))));
    vlSelf->wasmetal_core__DOT___064538_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063903_))));
    vlSelf->__VdfgTmp_h75b63843__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h8f6175c0__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___063903_));
    vlSelf->__VdfgTmp_h65785f77__0 = ((2U & ((0x40U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                   << 2U) 
                                                  | ((2U 
                                                      & ((9U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001168_)))) 
                                             << 1U)) 
                                      | (1U & (0x41000000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001146_))))))));
    vlSelf->__VdfgTmp_h67b52d18__0 = ((2U & ((0x40U 
                                              >> ((4U 
                                                   & ((9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d)))) 
                                             << 1U)) 
                                      | (1U & (0x41000000U 
                                               >> (
                                                   (0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d))))))));
    vlSelf->wasmetal_core__DOT___042177_ = (1U & (0x90090000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001146_)))))));
    vlSelf->wasmetal_core__DOT___058927_ = (1U & (0xbeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))));
    vlSelf->wasmetal_core__DOT___006248_ = (1U & (0x444fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))));
    vlSelf->wasmetal_core__DOT___054880_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h68f6955f__0)))));
    vlSelf->wasmetal_core__DOT___047927_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047926_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___050690_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047926_))));
    vlSelf->wasmetal_core__DOT___060463_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)))))));
    vlSelf->__VdfgTmp_he55adf41__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___005816_));
    vlSelf->wasmetal_core__DOT___054835_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb1732b67__0)))));
    vlSelf->wasmetal_core__DOT___047928_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047919_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049883_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047919_))));
    vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___014245_));
    vlSelf->wasmetal_core__DOT___042349_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c2489b5__0))))))));
    vlSelf->wasmetal_core__DOT___042148_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c2489b5__0))))))));
    vlSelf->wasmetal_core__DOT___054762_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7f579a2__0)))));
    vlSelf->wasmetal_core__DOT___047945_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047936_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049794_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047936_))));
    vlSelf->wasmetal_core__DOT___047946_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047944_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049746_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047944_))));
    vlSelf->wasmetal_core__DOT___063901_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2489b5__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1e5c31ac__0))))));
    vlSelf->__VdfgTmp_h9cfb7302__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x6996U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((0x96U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h74f7a068__0)) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (6U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h4a43881d__0))))))))));
    vlSelf->wasmetal_core__DOT___061471_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007254_))));
    vlSelf->wasmetal_core__DOT___027478_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007772_)))))))));
    vlSelf->__VdfgTmp_h1b99479d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008333_));
    vlSelf->wasmetal_core__DOT___055670_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008243_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055663_)))));
    vlSelf->wasmetal_core__DOT___055022_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h92b02c04__0)))));
    vlSelf->wasmetal_core__DOT___047870_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005525_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005526_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b47__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047867_))))))))))));
    vlSelf->wasmetal_core__DOT___014037_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048898_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047867_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___042348_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h503e9cd3__0))))))));
    vlSelf->wasmetal_core__DOT___042147_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h503e9cd3__0))))))));
    vlSelf->__VdfgTmp_h42c557be__0 = (((IData)(vlSelf->wasmetal_core__DOT___010309_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010308_));
    vlSelf->wasmetal_core__DOT___054979_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8565eee7__0)))));
    vlSelf->wasmetal_core__DOT___055643_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008235_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055638_)))));
    vlSelf->wasmetal_core__DOT___047872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047860_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049613_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047860_))));
    vlSelf->wasmetal_core__DOT___054943_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4ce8c3b1__0)))));
    vlSelf->wasmetal_core__DOT___047851_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047842_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049497_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047842_))));
    vlSelf->wasmetal_core__DOT___047852_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047850_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049115_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047850_))));
    vlSelf->wasmetal_core__DOT___013739_ = (1U & (0xf0fbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048900_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048899_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha2b229ae__0))))));
    vlSelf->wasmetal_core__DOT___063916_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063914_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h22bd1162__0))))));
    vlSelf->wasmetal_core__DOT___042347_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h22bd1162__0))))))));
    vlSelf->wasmetal_core__DOT___042146_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h22bd1162__0))))))));
    vlSelf->wasmetal_core__DOT___054916_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h34f2d08e__0)))));
    vlSelf->wasmetal_core__DOT___054877_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h31aacdc1__0)))));
    vlSelf->wasmetal_core__DOT___047909_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047900_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048577_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047900_))));
    vlSelf->wasmetal_core__DOT___055421_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008198_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055416_)))));
    vlSelf->wasmetal_core__DOT___055764_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055416_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055419_)))));
    vlSelf->wasmetal_core__DOT___054832_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3fcf358e__0)))));
    vlSelf->wasmetal_core__DOT___047910_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047908_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048578_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047908_))));
    vlSelf->__VdfgTmp_h097d2f7b__0 = (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013737_));
    vlSelf->__VdfgTmp_h4e2d279b__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_he0af74c9__0)))));
    vlSelf->wasmetal_core__DOT___054759_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9d165bb7__0)))));
    vlSelf->wasmetal_core__DOT___047891_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047890_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048579_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047890_))));
    vlSelf->wasmetal_core__DOT___042346_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hae598e91__0))))))));
    vlSelf->wasmetal_core__DOT___042145_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hae598e91__0))))))));
    vlSelf->wasmetal_core__DOT___055726_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055317_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055321_)))));
    vlSelf->wasmetal_core__DOT___055324_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008182_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055317_)))));
    vlSelf->wasmetal_core__DOT___047892_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047882_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048580_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047882_))));
    vlSelf->wasmetal_core__DOT___063915_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063912_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha5696d37__0))))));
    vlSelf->wasmetal_core__DOT___061469_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061467_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061466_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007338_)))))))));
    vlSelf->wasmetal_core__DOT___061621_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5ad8b1f1__0))));
    vlSelf->wasmetal_core__DOT___054720_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb9d2a0bf__0)))));
    vlSelf->wasmetal_core__DOT___055021_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd3c93d4d__0)))));
    vlSelf->wasmetal_core__DOT___047831_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047822_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048583_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047822_))));
    vlSelf->wasmetal_core__DOT___042168_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063961_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___002068_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                   ? 
                                                  (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hca6242ab__0))))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___001846_)));
    vlSelf->__VdfgTmp_hb54a817c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___001290_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001289_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001299_))))))))));
    vlSelf->wasmetal_core__DOT___054980_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7e30f70e__0)))));
    vlSelf->wasmetal_core__DOT___047832_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047830_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048584_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047830_))));
    vlSelf->__VdfgTmp_h7faa2984__0 = (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013785_));
    vlSelf->wasmetal_core__DOT___042345_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h46a92a2b__0))))))));
    vlSelf->wasmetal_core__DOT___042144_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h46a92a2b__0))))))));
    vlSelf->__VdfgTmp_hd61aa5bc__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___001705_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___000722_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___000820_))))))))));
    vlSelf->wasmetal_core__DOT___054942_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h93fbfa25__0)))));
    vlSelf->wasmetal_core__DOT___047813_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047812_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048585_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047812_))));
    vlSelf->wasmetal_core__DOT___054917_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h29bca591__0)))));
    vlSelf->wasmetal_core__DOT___047814_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047804_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048586_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047804_))));
    vlSelf->wasmetal_core__DOT___063922_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46a92a2b__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h101b2914__0))))));
    vlSelf->__VdfgTmp_h1065bf0b__0 = ((2U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_he0af74c9__0)) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_ha0d25e26__0))));
    vlSelf->__VdfgTmp_h162766a7__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___000719_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0fd3d582__0))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___002385_))));
    vlSelf->__VdfgTmp_h4408f503__0 = (((IData)(vlSelf->wasmetal_core__DOT___000718_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hec35f81b__0));
    vlSelf->wasmetal_core__DOT___054878_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9cbd3d8a__0)))));
    vlSelf->wasmetal_core__DOT___048689_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048688_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049141_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048688_))));
    vlSelf->wasmetal_core__DOT___042344_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8c76b9e6__0))))))));
    vlSelf->wasmetal_core__DOT___042143_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8c76b9e6__0))))))));
    vlSelf->wasmetal_core__DOT___054833_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb372eb0f__0)))));
    vlSelf->wasmetal_core__DOT___049365_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049138_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049139_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049138_))));
    vlSelf->wasmetal_core__DOT___048929_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013795_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013798_)))))));
    vlSelf->__VdfgTmp_h81ac2e72__0 = (((IData)(vlSelf->wasmetal_core__DOT___013798_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013795_));
    vlSelf->wasmetal_core__DOT___063814_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063801_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063800_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063799_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___026814_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___026813_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h10697dc9__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf0334e7f__0)))))))))));
    vlSelf->wasmetal_core__DOT___054760_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7da5f58__0)))));
    vlSelf->__VdfgTmp_h958b2749__0 = (((IData)(vlSelf->wasmetal_core__DOT___067729_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067663_));
    vlSelf->wasmetal_core__DOT___048702_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005711_)))))));
    vlSelf->wasmetal_core__DOT___049366_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049136_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049140_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049136_))));
    vlSelf->wasmetal_core__DOT___054721_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h69457925__0)))));
    vlSelf->wasmetal_core__DOT___049367_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049129_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049130_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049129_))));
    vlSelf->__VdfgTmp_hed5eddc9__0 = (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013770_));
    vlSelf->wasmetal_core__DOT___063921_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063918_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7c266aa9__0))))));
    vlSelf->__VdfgTmp_hd78cc544__0 = (((IData)(vlSelf->wasmetal_core__DOT___067663_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067591_));
    vlSelf->__VdfgTmp_h471ef662__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001286_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcbbf7a95__0))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___002181_))));
    vlSelf->wasmetal_core__DOT___055028_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h567d9bb7__0)))));
    vlSelf->__VdfgTmp_h2e505808__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h717e9861__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___063867_));
    vlSelf->wasmetal_core__DOT___064014_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048342_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff00fff1ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff4ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha04cce4c__0)))))))))))))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d)))))))))))));
    vlSelf->wasmetal_core__DOT___042142_ = (1U & (0x8ecf0c8eU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___070494_)))))));
    vlSelf->__VdfgTmp_h607fca11__0 = ((2U & ((0x40U 
                                              >> ((4U 
                                                   & ((9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d)))) 
                                             << 1U)) 
                                      | (1U & (0x4000U 
                                               >> (
                                                   (8U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d)))))));
    vlSelf->__VdfgTmp_hff973d2d__0 = ((2U & ((0x40U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                   << 2U) 
                                                  | ((2U 
                                                      & ((9U 
                                                          >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___000657_)))) 
                                             << 1U)) 
                                      | (1U & (0x4000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000635_)))))));
    vlSelf->wasmetal_core__DOT___042343_ = (1U & (0xbf233b02U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)))))))));
    vlSelf->wasmetal_core__DOT___042166_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063964_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he88617ec__0))))));
    vlSelf->wasmetal_core__DOT___042095_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063937_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (9U 
                                                            >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)))))));
    vlSelf->__VdfgTmp_h0033f05e__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf0c7a5d6__0)))));
    vlSelf->wasmetal_core__DOT___022503_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022490_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022489_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab846b7c__0))));
    vlSelf->wasmetal_core__DOT___022488_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022487_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022486_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha45fb011__0))));
    vlSelf->wasmetal_core__DOT___022485_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022484_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbacebd3b__0))));
    vlSelf->wasmetal_core__DOT___022483_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022482_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0283b263__0))));
    vlSelf->wasmetal_core__DOT___022481_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd64632c9__0))));
    vlSelf->wasmetal_core__DOT___022480_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fed8b62__0))));
    vlSelf->wasmetal_core__DOT___022479_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3cb929d5__0))));
    vlSelf->wasmetal_core__DOT___022478_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfa88dfaf__0))));
    vlSelf->wasmetal_core__DOT___022477_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022476_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89d79bf3__0))));
    vlSelf->wasmetal_core__DOT___022475_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7ef4e0e__0))));
    vlSelf->wasmetal_core__DOT___022474_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h13911493__0))));
    vlSelf->wasmetal_core__DOT___022473_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022472_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc6c88546__0))));
    vlSelf->wasmetal_core__DOT___010182_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___001902_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048808_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048807_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048805_)))))))));
    vlSelf->wasmetal_core__DOT___064734_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h769a413d__0))));
    vlSelf->wasmetal_core__DOT___042175_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063934_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063930_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128094___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028662_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028659_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028648_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028637_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028630_ = ((IData)(vlSelf->wasmetal_core__DOT___028662_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___004744_));
    vlSelf->wasmetal_core__DOT____Vcellout___128121___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028974_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028971_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028960_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028949_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028942_ = ((IData)(vlSelf->wasmetal_core__DOT___028974_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b3__05d));
    vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001437_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001437_)
            : (IData)(vlSelf->wasmetal_core__DOT___032283_));
    vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028763_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026685_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027155_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d));
    vlSelf->wasmetal_core__DOT___026573_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071915_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071912_)))));
    vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026955_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h78b443e9__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->__VdfgTmp_h03ce55f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3c2b613a__0)));
    vlSelf->__VdfgTmp_hcbffb3b6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf37b3ae8__0)));
    vlSelf->__VdfgTmp_h3f5e9baf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h2f9ca2ed__0)));
    vlSelf->__VdfgTmp_h3c35c9c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d));
    vlSelf->__VdfgTmp_h3c506bbe__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->wasmetal_core__DOT___060726_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060718_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h014e1215__0)))));
    vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001437_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034541_));
    vlSelf->wasmetal_core__DOT___064500_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc4a801d__0))));
    vlSelf->wasmetal_core__DOT___063986_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11b4d04e__0))));
    vlSelf->wasmetal_core__DOT___064502_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46c82ccf__0))));
    vlSelf->wasmetal_core__DOT___064501_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61294ca4__0))));
    vlSelf->wasmetal_core__DOT___063985_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h425ce738__0))));
}
