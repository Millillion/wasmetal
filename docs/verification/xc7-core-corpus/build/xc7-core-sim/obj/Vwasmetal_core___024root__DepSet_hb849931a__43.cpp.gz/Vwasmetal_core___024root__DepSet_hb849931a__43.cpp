#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__15(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__15\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___026135_;
    wasmetal_core__DOT___026135_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027710_;
    wasmetal_core__DOT___027710_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029191_;
    wasmetal_core__DOT___029191_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029291_;
    wasmetal_core__DOT___029291_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029352_;
    wasmetal_core__DOT___029352_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029653_;
    wasmetal_core__DOT___029653_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029822_;
    wasmetal_core__DOT___029822_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029883_;
    wasmetal_core__DOT___029883_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029991_;
    wasmetal_core__DOT___029991_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030565_;
    wasmetal_core__DOT___030565_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030756_;
    wasmetal_core__DOT___030756_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031592_;
    wasmetal_core__DOT___031592_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031714_;
    wasmetal_core__DOT___031714_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032073_;
    wasmetal_core__DOT___032073_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032164_;
    wasmetal_core__DOT___032164_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034761_;
    wasmetal_core__DOT___034761_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034894_;
    wasmetal_core__DOT___034894_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035022_;
    wasmetal_core__DOT___035022_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063122_;
    wasmetal_core__DOT___063122_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063128_;
    wasmetal_core__DOT___063128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063134_;
    wasmetal_core__DOT___063134_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063140_;
    wasmetal_core__DOT___063140_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128198___O;
    wasmetal_core__DOT____Vcellout___128198___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128361___O;
    wasmetal_core__DOT____Vcellout___128361___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128449___O;
    wasmetal_core__DOT____Vcellout___128449___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellinp___128517___S;
    wasmetal_core__DOT____Vcellinp___128517___S = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128579___O;
    wasmetal_core__DOT____Vcellout___128579___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128712___O;
    wasmetal_core__DOT____Vcellout___128712___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128713___O;
    wasmetal_core__DOT____Vcellout___128713___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127829___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127829___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127829___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127829___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127829___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127829___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127835___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127835___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127997___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127997___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127997___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127997___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128021___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128021___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128021___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128021___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128037___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128037___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128037___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128037___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128150___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128150___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128150___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128150___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128150___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128150___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128158___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128158___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128158___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128158___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128159___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128159___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128159___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128159___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128166___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128166___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128166___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128166___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128166___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128166___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128191___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128191___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128191___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128191___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128192___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128192___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128192___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128192___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128192___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128192___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128208___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128208___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128208___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128208___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128209___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128209___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128209___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128209___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128209___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128209___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128216___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128216___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128216___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128216___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128216___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128216___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128225___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128225___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128225___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128225___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128226___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128226___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128226___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128226___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128226___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128226___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128277___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128277___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128277___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128277___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128278___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128278___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128278___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128278___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128278___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128278___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128298___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128298___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128305___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128305___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128305___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128305___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128305___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128305___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128337___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128337___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128337___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128337___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128361___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128361___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128361___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128361___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128373___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128373___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128373___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128373___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128374___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128374___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128374___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128374___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128374___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128374___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128378___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128378___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128385___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128385___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128385___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128385___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128385___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128385___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128429___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128429___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128429___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128429___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128429___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128429___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128449___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128449___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128449___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128449___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128475___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128475___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128476___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128476___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128476___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128476___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128476___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128476___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128501___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128501___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128501___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128501___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128679___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128679___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128680___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128680___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128680___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128680___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128680___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128680___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128696___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128696___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128697___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128697___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128697___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128697___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128697___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128697___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128713___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128713___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128713___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128713___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128713___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128713___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h169b252f__0;
    __VdfgTmp_h169b252f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3ceb6137__0;
    __VdfgTmp_h3ceb6137__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___030810_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b30__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030805_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b26__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030801_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b22__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030796_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b18__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030792_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b14__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030788_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b10__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030844_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b61__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030839_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b57__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030835_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b53__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030830_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b49__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030826_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b45__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030822_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b41__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030817_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b37__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030813_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b33__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030808_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b29__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030804_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b25__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030800_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b21__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030795_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b17__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030791_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b13__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030850_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b9__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030843_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b60__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030838_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b56__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030834_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b52__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030829_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b48__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030825_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b44__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030821_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b40__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030816_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b36__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030812_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b32__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030807_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b28__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030803_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b24__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030799_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b20__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030794_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b16__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030790_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b12__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030849_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b8__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___128337___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031214_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031139_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d));
    vlSelf->wasmetal_core__DOT___128361___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031502_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031427_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d));
    vlSelf->wasmetal_core__DOT___128449___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032525_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032450_)
            : (IData)(vlSelf->wasmetal_core__DOT___032397_));
    vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031756_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d));
    vlSelf->wasmetal_core__DOT___031806_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135474___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___031805_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135474___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___031800_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135474___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___031789_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135474___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046933_))))));
    vlSelf->wasmetal_core__DOT___031804_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b63__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031799_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031795_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031791_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031786_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031782_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031777_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031773_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031769_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031764_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031760_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031755_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031751_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031747_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031803_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031798_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031794_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031790_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031785_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031781_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031776_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031772_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031768_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031763_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031759_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031754_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031750_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031746_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031802_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031797_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031793_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031788_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031784_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031780_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031775_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031771_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b33__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031766_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031762_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031758_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031753_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031749_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031808_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031801_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031796_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031792_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031787_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031783_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031779_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031774_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031770_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031765_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031761_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031757_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031752_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031748_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031807_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029915_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d));
    vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029775_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029742_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d));
    wasmetal_core__DOT___127835___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026289_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b6__05d));
    vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032896_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032863_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___070637_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b6__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032704_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032671_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b10__05d) {
        wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
        wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
        wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
    } else {
        wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__ = 0U;
        wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b11__05d) {
        wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b11__05d;
        vlSelf->wasmetal_core__DOT___031875_ = vlSelf->wasmetal_core__DOT__sp__05b11__05d;
        vlSelf->wasmetal_core__DOT___033910_ = vlSelf->wasmetal_core__DOT__sp__05b11__05d;
        vlSelf->wasmetal_core__DOT___032932_ = vlSelf->wasmetal_core__DOT__sp__05b11__05d;
    } else {
        wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___031875_ = wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033910_ = wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032932_ = wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b12__05d) {
        wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        vlSelf->wasmetal_core__DOT___032611_ = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
    } else {
        wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___032611_ = wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031875_;
        wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033910_;
        wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032932_;
    }
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))) {
        vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033129_));
        vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033223_));
        vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033995_));
    }
    vlSelf->wasmetal_core__DOT___052992_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___052856_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048111_))));
    vlSelf->wasmetal_core__DOT___052864_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___051013_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___052652_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___053004_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0))))));
    vlSelf->wasmetal_core__DOT___048517_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0))))));
    vlSelf->wasmetal_core__DOT___052993_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0))))));
    vlSelf->wasmetal_core__DOT___051015_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___048109_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___048480_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0))))));
    vlSelf->wasmetal_core__DOT___048478_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0))))));
    vlSelf->__VdfgTmp_h6c590b04__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048111_));
    vlSelf->wasmetal_core__DOT___062986_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062983_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___062982_))));
    vlSelf->wasmetal_core__DOT___042539_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (1ULL 
                                                                 >> 
                                                                 (vlSelf->insn_op 
                                                                  >> 0x1aU)))))));
    vlSelf->wasmetal_core__DOT___003042_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003043_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003044_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003045_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___042590_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xeU 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 0x18U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003014_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003013_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027832_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b9__05d));
    vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026388_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128036___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028023_)))));
    vlSelf->wasmetal_core__DOT___027996_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032225_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d));
    wasmetal_core__DOT___128475___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032830_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128500___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032992_)))));
    vlSelf->wasmetal_core__DOT___032965_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128191___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128191___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128277___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128277___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b13__05d) {
        wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128005___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b13__05d;
    } else {
        wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__ = 0U;
        wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128421___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___128373___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128373___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128225___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128225___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128165___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029384_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029383_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029413_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029412_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029379_)))));
    wasmetal_core__DOT___029352_ = ((IData)(vlSelf->wasmetal_core__DOT___029384_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b11__05d));
    wasmetal_core__DOT___128208___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128208___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128158___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128158___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128149___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029223_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029222_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029252_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029251_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029218_)))));
    wasmetal_core__DOT___029191_ = ((IData)(vlSelf->wasmetal_core__DOT___029223_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127828___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026167_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026166_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026196_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026195_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026162_)))));
    wasmetal_core__DOT___026135_ = ((IData)(vlSelf->wasmetal_core__DOT___026167_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128536___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b13__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b12__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b11__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b10__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b13__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___071599_ = (1U & (0x7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071595_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071594_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___019451_ = (1U & (IData)(
                                                         (0x7fffffff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (1U 
                                                                              & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___071583_)))))))))))));
    vlSelf->wasmetal_core__DOT___071695_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b65__05d) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hce6e76ca__0))))));
    vlSelf->wasmetal_core__DOT___071672_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hce6e76ca__0))));
    vlSelf->wasmetal_core__DOT___071702_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b69__05d) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9972469d__0))))));
    vlSelf->wasmetal_core__DOT___071706_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b71__05d) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb635a29b__0))))));
    vlSelf->wasmetal_core__DOT___019496_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b17__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfffbe48f__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019561_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b49__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfffbe48f__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019604_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b81__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfffbe48f__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019653_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b113__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfffbe48f__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071676_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd1e6ff3c__0))));
    vlSelf->wasmetal_core__DOT___071646_ = (1U & (0xfa3fU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd54e1937__0))));
    vlSelf->__VdfgTmp_h460a0345__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (IData)(vlSelf->__VdfgTmp_hd54e1937__0))));
    vlSelf->wasmetal_core__DOT___071657_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071611_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071656_)))));
    vlSelf->wasmetal_core__DOT___071612_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071611_))));
    vlSelf->wasmetal_core__DOT___019576_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b57__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h017bc299__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019577_)))));
    vlSelf->wasmetal_core__DOT___071625_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h017bc299__0))))));
    vlSelf->wasmetal_core__DOT___071663_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h017bc299__0))))));
    vlSelf->wasmetal_core__DOT___071687_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h017bc299__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                         >> 1U)))));
    wasmetal_core__DOT___128679___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034696_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128712___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035086_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035147_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035146_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035081_)))));
    wasmetal_core__DOT___035022_ = ((IData)(vlSelf->wasmetal_core__DOT___035086_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d));
    wasmetal_core__DOT___127997___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128949___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127997___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128298___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030809_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b2__05d));
    wasmetal_core__DOT___128337___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128337___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128361___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128361___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128449___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032536_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128449___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032536_))));
    wasmetal_core__DOT___128378___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031767_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d));
    wasmetal_core__DOT___128696___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128215___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029916_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029915_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029945_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029944_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029911_)))));
    wasmetal_core__DOT___029883_ = ((IData)(vlSelf->wasmetal_core__DOT___029916_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d));
    vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029776_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127835___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026290_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026289_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026288_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026287_)))) 
           ^ (((IData)(wasmetal_core__DOT___127835___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026254_)))));
    vlSelf->wasmetal_core__DOT___026258_ = ((IData)(vlSelf->wasmetal_core__DOT___026290_)
                                             ? (IData)(wasmetal_core__DOT___127835___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b7__05d));
    vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032897_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032705_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128257___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030374_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b13__05d) {
        vlSelf->wasmetal_core__DOT___030349_ = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030349_ = wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032611_;
        wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128020___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___DI) 
           ^ (((IData)(wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027894_)))));
    vlSelf->wasmetal_core__DOT___027867_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128396___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031902_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128460___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032637_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128595___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033937_)))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))) {
        vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 3U));
    } else {
        vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128492___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032959_)))));
    vlSelf->wasmetal_core__DOT___052999_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052992_))));
    vlSelf->wasmetal_core__DOT___052996_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___046420_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052856_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___052857_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052856_))));
    vlSelf->wasmetal_core__DOT___052952_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052864_))));
    vlSelf->wasmetal_core__DOT___052987_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051013_))));
    vlSelf->wasmetal_core__DOT___052876_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___052654_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052652_))));
    vlSelf->wasmetal_core__DOT___053005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053004_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___053281_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053004_))));
    vlSelf->wasmetal_core__DOT___052986_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048517_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___052998_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052993_))));
    vlSelf->wasmetal_core__DOT___046418_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052993_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___052859_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___046571_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051015_))));
    vlSelf->wasmetal_core__DOT___052990_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048109_))));
    vlSelf->wasmetal_core__DOT___009510_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048109_))));
    vlSelf->wasmetal_core__DOT___048116_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048109_))));
    vlSelf->busy = (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___048480_) 
                                    << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___048482_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048480_))));
    vlSelf->wasmetal_core__DOT___063422_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063408_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048478_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->mem_fault)))))));
    vlSelf->wasmetal_core__DOT___053558_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048478_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___048484_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048478_))));
    vlSelf->wasmetal_core__DOT___054471_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6c590b04__0))));
    vlSelf->wasmetal_core__DOT___048481_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6c590b04__0))))));
    vlSelf->wasmetal_core__DOT___048114_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6c590b04__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1a7964bb__0))));
    vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027802_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b10__05d));
    vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026358_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d));
    vlSelf->wasmetal_core__DOT___128037___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027996_));
    vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032195_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128475___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032831_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032830_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032829_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032828_)))) 
           ^ (((IData)(wasmetal_core__DOT___128475___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032795_)))));
    vlSelf->wasmetal_core__DOT___032799_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032831_)
                                                   ? (IData)(wasmetal_core__DOT___128475___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___032804_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032803_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032833_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032832_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O)))));
    vlSelf->wasmetal_core__DOT___128501___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032965_));
    wasmetal_core__DOT___128191___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128191___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128277___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d)
            : (IData)(wasmetal_core__DOT___128277___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b14__05d) {
        wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b14__05d;
    } else {
        wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__ = 0U;
        wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128373___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b14__05d)
            : (IData)(wasmetal_core__DOT___128373___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128225___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128225___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128166___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029385_)
            ? (IData)(wasmetal_core__DOT___029352_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b12__05d));
    wasmetal_core__DOT___128208___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128208___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128158___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128158___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128150___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029224_)
            ? (IData)(wasmetal_core__DOT___029191_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d));
    wasmetal_core__DOT___127829___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026168_)
            ? (IData)(wasmetal_core__DOT___026135_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d));
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b54__05d = 0U;
    } else if (vlSelf->wasmetal_core__DOT___019808_) {
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b56__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b55__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054566_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128645___O) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034334_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b55__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b54__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054565_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128644___O) 
                                                                    >> 2U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034333_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b54__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b53__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054564_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128644___O) 
                                                                    >> 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034332_)))))))))));
    }
    vlSelf->__VdfgTmp_h261f62de__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128536___O) 
                                             >> 2U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                               >> 3U)));
    vlSelf->__VdfgTmp_h015c016b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128536___O) 
                                             >> 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128535___O)));
    vlSelf->wasmetal_core__DOT____Vcellout___128570___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b14__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b13__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b12__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b11__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b14__05d)) 
           & (IData)(wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___019519_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b33__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071672_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019624_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b97__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071672_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019533_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b35__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071676_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019635_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b99__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071676_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->__VdfgTmp_h7e4d3970__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___071646_));
    vlSelf->__VdfgTmp_h5e77e03a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___071657_));
    vlSelf->wasmetal_core__DOT___071613_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071612_)))));
    vlSelf->__VdfgTmp_h0be8b807__0 = (((IData)(vlSelf->wasmetal_core__DOT___071612_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___071656_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))))));
    vlSelf->wasmetal_core__DOT___019485_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b9__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071625_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019596_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b73__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071625_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019512_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b25__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071663_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019617_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b89__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071663_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019554_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b41__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071687_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019646_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b105__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071687_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128679___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034697_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034696_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034691_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034680_)))) 
           ^ (((IData)(wasmetal_core__DOT___128679___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034733_)))));
    wasmetal_core__DOT___034761_ = ((IData)(vlSelf->wasmetal_core__DOT___034697_) 
                                    & (IData)(wasmetal_core__DOT___128679___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034638_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128712___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___034637_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128712___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d)))));
    vlSelf->wasmetal_core__DOT___034699_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128712___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d)))));
    vlSelf->wasmetal_core__DOT___034698_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128712___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d)))));
    wasmetal_core__DOT___128713___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035087_)
            ? (IData)(wasmetal_core__DOT___035022_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d));
    wasmetal_core__DOT___127997___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128950___Q) 
           & (IData)(wasmetal_core__DOT___127997___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128298___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030820_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030809_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030798_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030787_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128298___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    wasmetal_core__DOT___030756_ = ((IData)(vlSelf->wasmetal_core__DOT___030820_)
                                     ? (IData)(wasmetal_core__DOT___128298___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b3__05d));
    wasmetal_core__DOT___128337___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d)
            : (IData)(wasmetal_core__DOT___128337___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128361___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d)
            : (IData)(wasmetal_core__DOT___128361___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128449___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032541_)
                  ? (IData)(wasmetal_core__DOT___128449___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032541_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128378___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031778_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031767_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031756_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031745_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128378___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    wasmetal_core__DOT___031714_ = ((IData)(vlSelf->wasmetal_core__DOT___031778_)
                                     ? (IData)(wasmetal_core__DOT___128378___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128696___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128696___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034953_)))));
    wasmetal_core__DOT___034894_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d)) 
                                    & (IData)(wasmetal_core__DOT___128696___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128216___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029917_)
            ? (IData)(wasmetal_core__DOT___029883_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d));
    vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029746_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d));
    vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026291_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026258_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b8__05d));
    vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032867_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032675_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b14__05d) {
        vlSelf->wasmetal_core__DOT___128258___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128258___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030349_;
        wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___128021___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027867_));
    wasmetal_core__DOT____Vcellinp___128517___S = (
                                                   (8U 
                                                    & ((~ 
                                                        ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                         >> 1U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((~ 
                                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                               >> 3U)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                >> 2U))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))) {
        wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O));
        wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O));
        wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O));
    } else {
        wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___052858_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___038870_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052857_))));
    vlSelf->wasmetal_core__DOT___052948_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___038870_))));
    vlSelf->wasmetal_core__DOT___053617_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019414_))));
    vlSelf->wasmetal_core__DOT___053479_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0))))));
    vlSelf->wasmetal_core__DOT___053564_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053005_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052857_))));
    vlSelf->wasmetal_core__DOT___053284_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053005_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052949_))));
    vlSelf->wasmetal_core__DOT___065281_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___065721_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___065882_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___066200_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___068807_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___068953_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___069002_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___069051_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___069195_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___070255_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b112__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___065786_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___066063_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___070064_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b99__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b99__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070108_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b102__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b102__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070140_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b104__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 6U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b104__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070198_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b108__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xaU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b108__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070213_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b109__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xbU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b109__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070228_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b110__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xcU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b110__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070361_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b120__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x16U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b120__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___069277_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b64__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & vlSelf->mem_rdata[2U]))))));
    vlSelf->wasmetal_core__DOT___069307_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b65__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___069334_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b66__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___069358_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b67__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___069383_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b68__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 4U)))))));
    vlSelf->wasmetal_core__DOT___069409_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b69__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 5U)))))));
    vlSelf->wasmetal_core__DOT___069433_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b70__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 6U)))))));
    vlSelf->wasmetal_core__DOT___069459_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b71__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 7U)))))));
    vlSelf->wasmetal_core__DOT___069487_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b72__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 8U)))))));
    vlSelf->wasmetal_core__DOT___069554_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b75__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xbU)))))));
    vlSelf->wasmetal_core__DOT___069623_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b78__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xeU)))))));
    vlSelf->wasmetal_core__DOT___069669_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b80__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x10U)))))));
    vlSelf->wasmetal_core__DOT___069843_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b88__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x18U)))))));
    vlSelf->wasmetal_core__DOT___069864_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b89__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x19U)))))));
    vlSelf->wasmetal_core__DOT___069884_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b90__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1aU)))))));
    vlSelf->wasmetal_core__DOT___069905_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b91__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1bU)))))));
    vlSelf->wasmetal_core__DOT___069925_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b92__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1cU)))))));
    vlSelf->wasmetal_core__DOT___069946_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b93__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1dU)))))));
    vlSelf->wasmetal_core__DOT___070007_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b96__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & vlSelf->mem_rdata[3U]))))));
    vlSelf->wasmetal_core__DOT___069506_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b73__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 9U)))))));
    vlSelf->wasmetal_core__DOT___069530_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b74__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xaU)))))));
    vlSelf->wasmetal_core__DOT___069578_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b76__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xcU)))))));
    vlSelf->wasmetal_core__DOT___069599_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b77__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xdU)))))));
    vlSelf->wasmetal_core__DOT___069691_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b81__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x11U)))))));
    vlSelf->wasmetal_core__DOT___070077_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b100__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b100__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070122_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b103__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b103__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070093_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b101__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070153_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b105__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 7U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b105__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070166_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b106__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 8U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b106__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070180_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b107__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 9U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b107__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070241_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b111__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b111__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070270_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b113__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xfU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b113__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070282_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b114__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x10U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b114__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070294_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b115__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x11U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b115__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070320_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b117__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x13U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b117__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070332_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b118__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x14U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b118__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070344_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b119__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x15U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b119__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070372_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b121__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x17U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b121__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070384_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b122__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x18U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b122__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070396_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b123__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x19U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b123__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070409_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b124__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1aU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b124__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070421_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b125__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1bU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b125__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070434_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b126__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1cU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b126__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070446_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b127__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1dU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b127__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___069964_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b94__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1eU)))))));
    vlSelf->wasmetal_core__DOT___070046_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b98__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 2U)))))));
    vlSelf->__VdfgTmp_h26689d2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052987_));
    vlSelf->wasmetal_core__DOT___046419_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046420_))));
    vlSelf->wasmetal_core__DOT___053539_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))));
    vlSelf->wasmetal_core__DOT___067141_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___067443_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b30__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___067651_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b33__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b33__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___068280_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b44__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b44__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___065282_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b5__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___065722_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b9__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b9__05d))))));
    vlSelf->wasmetal_core__DOT___065883_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b11__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b11__05d))))));
    vlSelf->wasmetal_core__DOT___066201_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b14__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b14__05d))))));
    vlSelf->wasmetal_core__DOT___068808_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b54__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b54__05d))))));
    vlSelf->wasmetal_core__DOT___068954_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b57__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b57__05d))))));
    vlSelf->wasmetal_core__DOT___069003_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b58__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b58__05d))))));
    vlSelf->wasmetal_core__DOT___069052_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b59__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b59__05d))))));
    vlSelf->wasmetal_core__DOT___069196_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b62__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b62__05d))))));
    vlSelf->wasmetal_core__DOT___066383_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___066465_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b17__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___066546_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___066622_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b19__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___066708_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___066791_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b21__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___066873_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___066952_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b23__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___067023_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b24__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b24__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___067097_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b25__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___067251_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___067294_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___067395_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b29__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___067536_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b31__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___068333_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___064715_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b1__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___065591_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b8__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___066297_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___067719_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b34__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___067801_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b35__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b35__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___067854_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___067888_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b37__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b37__05d)))))))));
    vlSelf->wasmetal_core__DOT___068066_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b40__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___068140_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b41__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___068226_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b43__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT___068465_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b47__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b47__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___069079_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b60__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___069227_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b63__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b63__05d)))))))));
    vlSelf->wasmetal_core__DOT___064880_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___065393_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b6__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___065499_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b7__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___067949_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b38__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b38__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___068192_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b42__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___068388_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___065787_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b10__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b10__05d))))));
    vlSelf->wasmetal_core__DOT___066064_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b13__05d))))));
    vlSelf->wasmetal_core__DOT___068541_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b49__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___068592_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b50__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___068691_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b52__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___069128_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b61__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b61__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___068011_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___064449_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___066001_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___067583_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b32__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b32__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___068507_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___068884_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b56__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b56__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___068639_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b51__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT___068736_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b53__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b53__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___068836_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b55__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b55__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b55__05d)))))))));
    vlSelf->wasmetal_core__DOT___065154_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___065041_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___053283_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edone) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052954_)))));
    vlSelf->wasmetal_core__DOT___052860_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02edone))));
    vlSelf->__VdfgTmp_h803b5189__0 = (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052859_));
    vlSelf->__VdfgTmp_hb457b6b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___052990_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052998_));
    vlSelf->wasmetal_core__DOT___052995_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052990_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009510_))));
    vlSelf->wasmetal_core__DOT___053421_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edone))));
    vlSelf->wasmetal_core__DOT___053273_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009510_)))));
    vlSelf->__VdfgTmp_hc49c7557__0 = (((IData)(vlSelf->cmd_valid) 
                                       << 1U) | (IData)(vlSelf->busy));
    vlSelf->wasmetal_core__DOT___063356_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048482_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_kind__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063355_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_kind__05b2__05d))))));
    vlSelf->wasmetal_core__DOT___063098_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128442___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___063104_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128442___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___063110_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128442___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___063116_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128442___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___053613_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048482_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053343_))));
    vlSelf->wasmetal_core__DOT___039850_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039834_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039833_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & vlSelf->function_locals) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039832_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039831_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039822_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039823_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039830_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039828_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 6U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039827_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 7U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039826_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 8U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039825_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 9U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___053562_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053005_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053558_))));
    vlSelf->wasmetal_core__DOT___063097_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128196___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063103_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128196___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063109_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128196___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063115_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128196___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063121_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128197___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063127_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128197___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063133_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128197___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063139_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128197___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069276_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b64__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069306_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b65__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069333_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b66__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b67__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069382_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b68__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069408_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b69__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069432_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b70__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069458_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b71__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069486_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b72__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069553_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b75__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069622_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b78__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069668_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b80__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069842_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b88__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069863_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b89__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069883_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b90__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069904_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b91__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069924_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b92__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069945_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b93__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___070006_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b96__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___070028_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b97__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___067720_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068067_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069080_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069228_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069505_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b73__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069529_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b74__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069577_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b76__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069598_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b77__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069690_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b81__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___064881_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___065394_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___065500_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___067950_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068193_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068389_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069642_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b79__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069709_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b82__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069731_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b83__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069753_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b84__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069774_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b85__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069796_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b86__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069818_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b87__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069983_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b95__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068542_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068593_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068692_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069129_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069963_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b94__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___066002_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___067584_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068508_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068885_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068640_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068737_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068837_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___065155_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___065042_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___053615_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053308_))));
    vlSelf->wasmetal_core__DOT___053348_ = (1U & (0xbfbf00bfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053308_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052990_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052991_)))))));
    vlSelf->wasmetal_core__DOT___053335_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___053614_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052987_))));
    vlSelf->wasmetal_core__DOT___062987_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052654_))));
    vlSelf->wasmetal_core__DOT___063079_ = (1U & (0xf153f3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination_index__05b17__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b17__05d)))))));
    vlSelf->__VdfgTmp_h3e4445d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052987_));
    vlSelf->wasmetal_core__DOT___048485_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048482_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048481_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128012___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027803_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027802_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027832_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027831_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027798_)))));
    vlSelf->wasmetal_core__DOT___027771_ = ((IData)(vlSelf->wasmetal_core__DOT___027803_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127844___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026359_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026358_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026388_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026387_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026354_)))));
    vlSelf->wasmetal_core__DOT___026327_ = ((IData)(vlSelf->wasmetal_core__DOT___026359_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d));
    wasmetal_core__DOT___128037___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128037___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128428___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032196_) 
             << 3U) | (IData)(vlSelf->__VdfgTmp_he13e3256__0)) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032191_)))));
    wasmetal_core__DOT___032164_ = ((IData)(vlSelf->wasmetal_core__DOT___032196_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d));
    wasmetal_core__DOT___128476___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032832_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032799_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O)));
    wasmetal_core__DOT___128501___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128501___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128191___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b12__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128191___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128191___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128191___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029649_)))));
    wasmetal_core__DOT___029653_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b15__05d) 
                                    & (IData)(wasmetal_core__DOT___128191___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128277___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128277___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128277___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128277___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030561_)))));
    wasmetal_core__DOT___030565_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d)
                                     : (IData)(wasmetal_core__DOT___128277___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128005___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128005___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027706_)))));
    wasmetal_core__DOT___027710_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d) 
                                    & (IData)(wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128421___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128421___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032069_)))));
    wasmetal_core__DOT___032073_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d)
                                     : (IData)(wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128373___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128373___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128373___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128373___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031588_)))));
    wasmetal_core__DOT___031592_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b15__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b15__05d)
                                     : (IData)(wasmetal_core__DOT___128373___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128225___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128225___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128225___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128225___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029987_)))));
    wasmetal_core__DOT___029991_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d) 
                                    & (IData)(wasmetal_core__DOT___128225___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128166___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029386_)
            ? (IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128208___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128208___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128208___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128208___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029818_)))));
    wasmetal_core__DOT___029822_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d) 
                                    & (IData)(wasmetal_core__DOT___128208___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128158___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h950b0747__0))) 
           ^ (((IData)(wasmetal_core__DOT___128158___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128158___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128158___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029287_)))));
    wasmetal_core__DOT___029291_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d) 
                                    & (IData)(wasmetal_core__DOT___128158___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128150___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029225_)
            ? (IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d));
    wasmetal_core__DOT___127829___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026169_)
            ? (IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d));
    vlSelf->__VdfgTmp_h3321aa0d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128570___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128570___O) 
                                               >> 2U)));
    vlSelf->__VdfgTmp_h7a9a4b36__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                             >> 2U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128570___O) 
                                               >> 3U)));
    wasmetal_core__DOT____Vcellout___128579___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b15__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b14__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b13__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b12__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b15__05d)) 
           & (IData)(wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___071704_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b70__05d) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0be8b807__0))))));
    wasmetal_core__DOT___128680___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034698_) 
           & (IData)(wasmetal_core__DOT___034761_));
    wasmetal_core__DOT___128713___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035088_)
            ? (IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127997___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128951___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128950___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128949___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128948___Q)))) 
           ^ (((IData)(wasmetal_core__DOT___127997___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127997___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127997___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027641_)))));
    vlSelf->wasmetal_core__DOT___027645_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128951___Q) 
                                            & (IData)(wasmetal_core__DOT___127997___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128305___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030831_)
            ? (IData)(wasmetal_core__DOT___030756_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128337___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___031214_)))) 
           ^ (((IData)(wasmetal_core__DOT___128337___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128337___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128337___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031139_)))));
    vlSelf->wasmetal_core__DOT___031167_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d)
                                             : (IData)(wasmetal_core__DOT___128337___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128361___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___031502_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128361___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128361___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128361___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___031427_)))));
    vlSelf->wasmetal_core__DOT___031455_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d)
                                             : (IData)(wasmetal_core__DOT___128361___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128449___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___032542_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___032541_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032536_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032525_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128449___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128449___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128449___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032450_)))));
    vlSelf->wasmetal_core__DOT___032478_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032542_)
                                                   ? (IData)(wasmetal_core__DOT___128449___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___032542_))));
    wasmetal_core__DOT___128385___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031789_)
            ? (IData)(wasmetal_core__DOT___031714_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d));
    wasmetal_core__DOT___128697___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d)) 
           & (IData)(wasmetal_core__DOT___034894_));
    wasmetal_core__DOT___128216___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029918_)
            ? (IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d));
    wasmetal_core__DOT____Vcellout___128198___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029747_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029746_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029776_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029775_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029742_)))));
    vlSelf->wasmetal_core__DOT___029714_ = ((IData)(vlSelf->wasmetal_core__DOT___029747_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d));
    vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026292_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128484___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032868_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032867_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032897_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032896_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032863_)))));
    vlSelf->wasmetal_core__DOT___032836_ = ((IData)(vlSelf->wasmetal_core__DOT___032868_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128468___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032676_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032675_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032705_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032704_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032671_)))));
    vlSelf->wasmetal_core__DOT___032644_ = ((IData)(vlSelf->wasmetal_core__DOT___032676_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b15__05d) {
        wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___031879_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___033914_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___032936_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
    } else {
        wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128258___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___031879_ = wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033914_ = wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032936_ = wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__;
    }
    wasmetal_core__DOT___128021___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128021___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128517___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128517___S) 
           ^ (((IData)(wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033129_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))) {
        vlSelf->wasmetal_core__DOT___033133_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033227_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033999_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033133_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033227_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033999_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128525___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128517___S) 
           ^ (((IData)(wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033223_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128602___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128517___S) 
           ^ (((IData)(wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033995_)))));
    vlSelf->wasmetal_core__DOT___053423_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052949_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052948_))));
    vlSelf->wasmetal_core__DOT___053565_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->busy) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052876_)))));
    vlSelf->wasmetal_core__DOT___063459_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h26689d2d__0))));
    vlSelf->wasmetal_core__DOT___053540_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046420_))));
    vlSelf->wasmetal_core__DOT___064717_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064715_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b1__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___066299_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066297_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xdU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b15__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067721_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067719_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->mem_rdata[1U]) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b34__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067803_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067801_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b35__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067856_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067854_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b36__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067890_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067888_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b37__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068068_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068066_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 6U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b40__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068142_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068140_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 7U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b41__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068228_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068226_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 9U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b43__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068467_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068465_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xdU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b47__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069081_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069079_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x1aU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b60__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069229_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069227_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x1dU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___064882_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064880_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->mem_rdata[0U]) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b2__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065395_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065393_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065501_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065499_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b7__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067951_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067949_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b38__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068194_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068192_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 8U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b42__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068390_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068388_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xcU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b46__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068543_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068541_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xfU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b49__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068594_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068592_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x10U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b50__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068693_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x12U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b52__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069130_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069128_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x1bU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b61__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068013_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068011_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b39__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___064451_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064449_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___066003_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066001_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xaU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b12__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067585_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067583_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b32__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068509_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068507_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xeU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b48__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068886_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068884_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x16U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068641_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068639_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x11U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b51__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068738_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068736_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x13U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b53__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068838_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068836_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x15U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b55__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065156_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065154_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b4__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065043_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065041_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___053287_ = (1U & (0xbb0bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052860_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052990_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02edone)))))));
    vlSelf->wasmetal_core__DOT___065284_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065282_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065281_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b5__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065724_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065721_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b9__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065885_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065883_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065882_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066203_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066200_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xbU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b14__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___068810_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068808_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068807_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b54__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___068956_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068954_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068953_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b57__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069005_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069003_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069002_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b58__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069054_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069052_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b59__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069198_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069196_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069195_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x1bU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b62__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065789_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065787_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065786_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b10__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066066_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066064_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066063_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b13__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___070490_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->cmd_kind) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___070486_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->cmd_kind) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___053094_ = (1U & (0xfe0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->cmd_kind)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->cmd_kind) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->cmd_kind)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->cmd_kind) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___052861_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052858_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___053619_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053613_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052987_)))));
    vlSelf->wasmetal_core__DOT___053476_ = (1U & (0x1f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053348_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052940_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048286_))))));
    vlSelf->wasmetal_core__DOT___053345_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053335_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053308_))));
    vlSelf->wasmetal_core__DOT___063057_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053614_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination_kind__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___063100_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063098_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063097_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128213___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128354___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063106_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063104_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063103_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128213___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128354___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063112_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063110_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063109_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128213___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128354___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063118_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063116_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063115_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128213___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128354___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063359_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046930_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048485_))));
    vlSelf->wasmetal_core__DOT___053616_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048485_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053614_))));
    vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027804_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027771_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b12__05d));
    vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026360_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026327_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b12__05d));
    wasmetal_core__DOT___128037___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128037___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045539_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b9__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___045551_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b8__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b9__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b10__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                             >> 2U))))))))));
    wasmetal_core__DOT___128429___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032197_)
            ? (IData)(wasmetal_core__DOT___032164_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d));
    wasmetal_core__DOT___128476___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032833_)
                  ? (IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                     >> 1U)));
    wasmetal_core__DOT___128501___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d)
            : (IData)(wasmetal_core__DOT___128501___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128192___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b16__05d) 
           & (IData)(wasmetal_core__DOT___029653_));
    vlSelf->wasmetal_core__DOT___039835_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xaU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039836_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xbU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039837_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xcU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039851_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xdU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d)))))));
    wasmetal_core__DOT___128278___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)
            : (IData)(wasmetal_core__DOT___030565_));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b16__05d) {
        wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027710_;
        wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b16__05d;
    } else {
        wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__ = 0U;
        wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___032073_;
    }
    wasmetal_core__DOT___128374___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b16__05d)
            : (IData)(wasmetal_core__DOT___031592_));
    wasmetal_core__DOT___128226___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d) 
           & (IData)(wasmetal_core__DOT___029991_));
    wasmetal_core__DOT___128166___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029387_)
            ? (IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b14__05d));
    wasmetal_core__DOT___128209___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d) 
           & (IData)(wasmetal_core__DOT___029822_));
    wasmetal_core__DOT___128159___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d) 
           & (IData)(wasmetal_core__DOT___029291_));
    wasmetal_core__DOT___128150___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029226_)
            ? (IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d));
    wasmetal_core__DOT___127829___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026170_)
            ? (IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d));
    __VdfgTmp_h3ceb6137__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___128579___O)) 
                              | (1U & ((IData)(wasmetal_core__DOT____Vcellout___128579___O) 
                                       >> 2U)));
    __VdfgTmp_h169b252f__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O) 
                                     >> 2U)) | (1U 
                                                & (IData)(wasmetal_core__DOT____Vcellout___128579___O)));
    vlSelf->wasmetal_core__DOT____Vcellout___128588___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b16__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b15__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b14__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b13__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b16__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___128680___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034699_) 
           & (IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128713___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035089_)
            ? (IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d));
    vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128952___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027645_));
    wasmetal_core__DOT___128305___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030842_)
            ? (IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b5__05d));
    vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031167_));
    vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031455_));
    wasmetal_core__DOT___063122_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128449___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063128_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128449___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063134_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128449___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063140_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128449___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032543_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032478_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032543_))));
    wasmetal_core__DOT___128385___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031800_)
            ? (IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d));
    wasmetal_core__DOT___128697___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d)) 
           & (IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128216___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029919_)
            ? (IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d));
    vlSelf->wasmetal_core__DOT___063145_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128198___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063151_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128198___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063157_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128198___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063163_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128198___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029748_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029714_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d));
    vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026262_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b10__05d));
    vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032869_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032836_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___070640_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b9__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032677_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032644_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b16__05d) {
        wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___032615_ = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
    } else {
        wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___032615_ = wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031879_;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033914_;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032936_;
    }
    wasmetal_core__DOT___128021___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128021___DOT__CO__BRA__1__KET__));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))) {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033133_));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033227_));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033999_));
    }
    vlSelf->wasmetal_core__DOT___053561_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053284_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053423_))));
    vlSelf->wasmetal_core__DOT___063461_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063459_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052859_)))));
    vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027805_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b13__05d));
    vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026361_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128037___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_he965b193__0))) 
           ^ (((IData)(wasmetal_core__DOT___128037___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128037___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128037___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027996_)))));
    vlSelf->wasmetal_core__DOT___028000_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d) 
                                            & (IData)(wasmetal_core__DOT___128037___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128429___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032198_)
            ? (IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d));
    wasmetal_core__DOT___128476___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032803_)
                  ? (IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128501___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128501___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128501___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128501___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032965_)))));
    vlSelf->wasmetal_core__DOT___032969_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d)
                                             : (IData)(wasmetal_core__DOT___128501___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128192___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b17__05d) 
           & (IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128278___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d)
            : (IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b17__05d) {
        wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b17__05d;
    } else {
        wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__ = 0U;
        wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___128374___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b17__05d)
            : (IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128226___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d) 
           & (IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128166___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029388_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029387_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029386_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029385_)))) 
           ^ (((IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029352_)))));
    vlSelf->wasmetal_core__DOT___029356_ = ((IData)(vlSelf->wasmetal_core__DOT___029388_)
                                             ? (IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b15__05d));
    wasmetal_core__DOT___128209___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d) 
           & (IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128159___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d) 
           & (IData)(wasmetal_core__DOT___128159___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128150___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029227_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029226_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029225_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029224_)))) 
           ^ (((IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029191_)))));
    vlSelf->wasmetal_core__DOT___029195_ = ((IData)(vlSelf->wasmetal_core__DOT___029227_)
                                             ? (IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127829___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026171_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026170_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026169_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026168_)))) 
           ^ (((IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026135_)))));
    vlSelf->wasmetal_core__DOT___026139_ = ((IData)(vlSelf->wasmetal_core__DOT___026171_)
                                             ? (IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d));
    vlSelf->wasmetal_core__DOT___064033_ = (1U & (IData)(
                                                         (0x5ffffffffffffff3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(__VdfgTmp_h3ceb6137__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(__VdfgTmp_h169b252f__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128579___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O) 
                                                                                << 4U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O) 
                                                                                << 2U)) 
                                                                                | ((8U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___128579___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(__VdfgTmp_h3ceb6137__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(__VdfgTmp_h169b252f__0)))))))))))))))))));
    vlSelf->__VdfgTmp_hc47ce573__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128588___O) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128588___O) 
                                               >> 3U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128537___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b17__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b16__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b15__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b14__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b17__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___128680___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034637_) 
           & (IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128713___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035090_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035089_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035088_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035087_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035022_)))));
    vlSelf->wasmetal_core__DOT___035026_ = ((IData)(vlSelf->wasmetal_core__DOT___035090_)
                                             ? (IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d));
    vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128953___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128305___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030847_)
            ? (IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b6__05d));
    vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063124_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063122_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063121_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128214___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128361___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063130_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063128_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063127_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128214___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128361___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063136_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063134_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063133_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128214___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___128361___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063142_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063140_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063139_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128214___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128361___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032544_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032544_))));
    wasmetal_core__DOT___128385___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031805_)
            ? (IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d));
    wasmetal_core__DOT___128697___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d)) 
           & (IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128216___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029920_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029919_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029918_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029917_)))) 
           ^ (((IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029883_)))));
    vlSelf->wasmetal_core__DOT___029887_ = ((IData)(vlSelf->wasmetal_core__DOT___029920_)
                                             ? (IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d));
    vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029749_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127836___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026263_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026262_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026292_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026291_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026258_)))));
    vlSelf->wasmetal_core__DOT___026231_ = ((IData)(vlSelf->wasmetal_core__DOT___026263_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b11__05d));
    vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032870_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032678_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128258___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128258___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030349_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b17__05d) {
        vlSelf->wasmetal_core__DOT___030353_ = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030353_ = wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032615_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128021___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_ha938949d__0))) 
           ^ (((IData)(wasmetal_core__DOT___128021___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128021___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128021___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027867_)))));
    vlSelf->wasmetal_core__DOT___027871_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
                                            & (IData)(wasmetal_core__DOT___128021___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128397___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031875_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128461___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032611_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128596___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033910_)))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))) {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 3U));
    } else {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128493___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032932_)))));
    vlSelf->wasmetal_core__DOT___053563_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052858_))));
    wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027806_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b14__05d));
    wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026362_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d));
    vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___028000_));
    wasmetal_core__DOT___128429___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032199_)
            ? (IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128476___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032804_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032803_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032833_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032832_)))) 
           ^ (((IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032799_)))));
    vlSelf->wasmetal_core__DOT___032772_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032804_)
                                                   ? (IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___032808_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032807_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032806_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b13__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032805_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b12__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O)))));
    vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032969_));
    wasmetal_core__DOT___128192___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128278___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d)
            : (IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b18__05d) {
        wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b18__05d;
    } else {
        wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__ = 0U;
        wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128374___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b18__05d)
            : (IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128226___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029389_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029356_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b16__05d));
    wasmetal_core__DOT___128209___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128159___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128159___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h93fa449d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O)) 
                                      | (1U & (1U >> 
                                               ((0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                    << 4U)) 
                                                | ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O)))))))));
    vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029228_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029195_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d));
    vlSelf->__VdfgTmp_he2c88566__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O)) 
                                      | (1U & (1U >> 
                                               ((0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                    << 4U)) 
                                                | ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O)))))))));
    vlSelf->wasmetal_core__DOT___127830___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026172_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026139_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128571___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b18__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b17__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b16__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b15__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b18__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128680___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034638_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034637_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034699_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034698_)))) 
           ^ (((IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034761_)))));
    vlSelf->wasmetal_core__DOT___034702_ = ((IData)(vlSelf->wasmetal_core__DOT___034638_) 
                                            & (IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034642_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128713___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d)))));
    vlSelf->wasmetal_core__DOT___034641_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128713___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d)))));
    vlSelf->wasmetal_core__DOT___034640_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128713___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d)))));
    vlSelf->wasmetal_core__DOT___034639_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128713___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d)))));
    vlSelf->wasmetal_core__DOT___128714___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035091_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035026_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d));
    vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128954___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128305___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030848_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030847_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030842_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030831_)))) 
           ^ (((IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030756_)))));
    vlSelf->wasmetal_core__DOT___030784_ = ((IData)(vlSelf->wasmetal_core__DOT___030848_)
                                             ? (IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b7__05d));
    vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032482_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032482_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128385___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031806_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031805_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031800_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031789_)))) 
           ^ (((IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031714_)))));
    vlSelf->wasmetal_core__DOT___031742_ = ((IData)(vlSelf->wasmetal_core__DOT___031806_)
                                             ? (IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128697___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034894_)))));
    vlSelf->wasmetal_core__DOT___034898_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d)) 
                                            & (IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029921_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029887_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d));
    vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029750_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d));
    vlSelf->wasmetal_core__DOT___127837___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026264_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026231_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b12__05d));
    vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032871_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032679_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    vlSelf->wasmetal_core__DOT___128259___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030353_));
    vlSelf->wasmetal_core__DOT___128022___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027871_));
    vlSelf->wasmetal_core__DOT____Vcellinp___128518___S 
        = ((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                      >> 1U)) << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O)) 
                                                << 2U)) 
                                         | ((2U & (
                                                   (~ 
                                                    ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                     >> 3U)) 
                                                   << 1U)) 
                                            | (1U & 
                                               (~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                   >> 2U))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))) {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O));
    } else {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___019780_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053563_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053562_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052857_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128013___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027807_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027806_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027805_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027804_)))) 
           ^ (((IData)(wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027771_)))));
    vlSelf->wasmetal_core__DOT___027775_ = ((IData)(vlSelf->wasmetal_core__DOT___027807_)
                                             ? (IData)(wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127845___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026363_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026362_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026361_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026360_)))) 
           ^ (((IData)(wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026327_)))));
    vlSelf->wasmetal_core__DOT___026331_ = ((IData)(vlSelf->wasmetal_core__DOT___026363_)
                                             ? (IData)(wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b15__05d));
    vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128429___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032200_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032199_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032198_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032197_)))) 
           ^ (((IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032164_)))));
    vlSelf->wasmetal_core__DOT___032168_ = ((IData)(vlSelf->wasmetal_core__DOT___032200_)
                                             ? (IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp__labels_memory__02e0__02e0__ADDRBWRADDR 
        = (0x800fU | ((0x4000U & ((0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                              << 2U) 
                                             | ((2U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
                                                    >> 1U)) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                      >> 2U))))) 
                                  << 0xeU)) | ((0x2000U 
                                                & ((0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O)) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                              >> 1U))))) 
                                                   << 0xdU)) 
                                               | ((0x1000U 
                                                   & ((0xcaU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
                                                               << 1U)) 
                                                           | (1U 
                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O))))) 
                                                      << 0xcU)) 
                                                  | ((0x800U 
                                                      & ((0xcaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
                                                                  >> 2U)) 
                                                              | (1U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                                    >> 3U))))) 
                                                         << 0xbU)) 
                                                     | ((0x400U 
                                                         & ((0xcaU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
                                                                     >> 1U)) 
                                                                 | (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                                       >> 2U))))) 
                                                            << 0xaU)) 
                                                        | ((0x200U 
                                                            & ((0xcaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                                          >> 1U))))) 
                                                               << 9U)) 
                                                           | ((0x100U 
                                                               & ((0xcaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O))))) 
                                                                  << 8U)) 
                                                              | ((0x80U 
                                                                  & ((0xcaU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                                                >> 3U))))) 
                                                                     << 7U)) 
                                                                 | ((0x40U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O) 
                                                                                >> 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                                                >> 2U))))) 
                                                                        << 6U)) 
                                                                    | ((0x20U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                                                >> 1U))))) 
                                                                           << 5U)) 
                                                                       | (0x10U 
                                                                          & ((0xcaU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O))))) 
                                                                             << 4U)))))))))))));
    vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032805_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032772_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O)));
    vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128192___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029653_)))));
    vlSelf->wasmetal_core__DOT___029657_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128278___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030565_)))));
    vlSelf->wasmetal_core__DOT___030569_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128006___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128422___DI) 
           ^ (((IData)(wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027710_)))));
    vlSelf->wasmetal_core__DOT___027714_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128422___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032073_)))));
    vlSelf->wasmetal_core__DOT___032077_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128374___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031592_)))));
    vlSelf->wasmetal_core__DOT___031596_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128226___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029991_)))));
    vlSelf->wasmetal_core__DOT___029995_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029390_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128209___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029822_)))));
    vlSelf->wasmetal_core__DOT___029826_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128159___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128159___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128159___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128159___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029291_)))));
}
