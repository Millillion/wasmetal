#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__32(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__32\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___005700_;
    wasmetal_core__DOT___005700_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___005911_;
    wasmetal_core__DOT___005911_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013630_;
    wasmetal_core__DOT___013630_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017488_;
    wasmetal_core__DOT___017488_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017508_;
    wasmetal_core__DOT___017508_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017522_;
    wasmetal_core__DOT___017522_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017594_;
    wasmetal_core__DOT___017594_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017643_;
    wasmetal_core__DOT___017643_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017655_;
    wasmetal_core__DOT___017655_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017694_;
    wasmetal_core__DOT___017694_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017719_;
    wasmetal_core__DOT___017719_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017745_;
    wasmetal_core__DOT___017745_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017759_;
    wasmetal_core__DOT___017759_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017797_;
    wasmetal_core__DOT___017797_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019013_;
    wasmetal_core__DOT___019013_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022998_;
    wasmetal_core__DOT___022998_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023003_;
    wasmetal_core__DOT___023003_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023007_;
    wasmetal_core__DOT___023007_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023081_;
    wasmetal_core__DOT___023081_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023085_;
    wasmetal_core__DOT___023085_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023090_;
    wasmetal_core__DOT___023090_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023268_;
    wasmetal_core__DOT___023268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023272_;
    wasmetal_core__DOT___023272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023276_;
    wasmetal_core__DOT___023276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023285_;
    wasmetal_core__DOT___023285_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023290_;
    wasmetal_core__DOT___023290_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023294_;
    wasmetal_core__DOT___023294_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035284_;
    wasmetal_core__DOT___035284_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035288_;
    wasmetal_core__DOT___035288_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035297_;
    wasmetal_core__DOT___035297_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035301_;
    wasmetal_core__DOT___035301_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035306_;
    wasmetal_core__DOT___035306_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035336_;
    wasmetal_core__DOT___035336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035455_;
    wasmetal_core__DOT___035455_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035459_;
    wasmetal_core__DOT___035459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035463_;
    wasmetal_core__DOT___035463_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035472_;
    wasmetal_core__DOT___035472_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035477_;
    wasmetal_core__DOT___035477_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035571_;
    wasmetal_core__DOT___035571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035575_;
    wasmetal_core__DOT___035575_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035580_;
    wasmetal_core__DOT___035580_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035589_;
    wasmetal_core__DOT___035589_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035593_;
    wasmetal_core__DOT___035593_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035598_;
    wasmetal_core__DOT___035598_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035918_;
    wasmetal_core__DOT___035918_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035927_;
    wasmetal_core__DOT___035927_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035931_;
    wasmetal_core__DOT___035931_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035935_;
    wasmetal_core__DOT___035935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035940_;
    wasmetal_core__DOT___035940_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035944_;
    wasmetal_core__DOT___035944_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035949_;
    wasmetal_core__DOT___035949_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035953_;
    wasmetal_core__DOT___035953_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036333_;
    wasmetal_core__DOT___036333_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036338_;
    wasmetal_core__DOT___036338_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036346_;
    wasmetal_core__DOT___036346_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036360_;
    wasmetal_core__DOT___036360_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036370_;
    wasmetal_core__DOT___036370_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036373_;
    wasmetal_core__DOT___036373_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036374_;
    wasmetal_core__DOT___036374_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036512_;
    wasmetal_core__DOT___036512_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036516_;
    wasmetal_core__DOT___036516_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036520_;
    wasmetal_core__DOT___036520_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___042814_;
    wasmetal_core__DOT___042814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043028_;
    wasmetal_core__DOT___043028_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043031_;
    wasmetal_core__DOT___043031_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043032_;
    wasmetal_core__DOT___043032_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051536_;
    wasmetal_core__DOT___051536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053557_;
    wasmetal_core__DOT___053557_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059246_;
    wasmetal_core__DOT___059246_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071743_;
    wasmetal_core__DOT___071743_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071746_;
    wasmetal_core__DOT___071746_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ecommon_totalUnderflow;
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ecommon_totalUnderflow = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry;
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d;
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127497___O;
    wasmetal_core__DOT____Vcellout___127497___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127498___O;
    wasmetal_core__DOT____Vcellout___127498___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127499___O;
    wasmetal_core__DOT____Vcellout___127499___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127500___O;
    wasmetal_core__DOT____Vcellout___127500___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127520___O;
    wasmetal_core__DOT____Vcellout___127520___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127521___O;
    wasmetal_core__DOT____Vcellout___127521___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127525___O;
    wasmetal_core__DOT____Vcellout___127525___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127530___O;
    wasmetal_core__DOT____Vcellout___127530___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127531___O;
    wasmetal_core__DOT____Vcellout___127531___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127532___O;
    wasmetal_core__DOT____Vcellout___127532___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127534___O;
    wasmetal_core__DOT____Vcellout___127534___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128736___O;
    wasmetal_core__DOT____Vcellout___128736___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128738___O;
    wasmetal_core__DOT____Vcellout___128738___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128739___O;
    wasmetal_core__DOT____Vcellout___128739___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128854___O;
    wasmetal_core__DOT____Vcellout___128854___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128857___O;
    wasmetal_core__DOT____Vcellout___128857___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128858___O;
    wasmetal_core__DOT____Vcellout___128858___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128875___O;
    wasmetal_core__DOT____Vcellout___128875___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127497___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127497___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127497___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127497___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127497___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127497___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127504___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127504___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127504___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127504___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127504___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127504___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127505___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127505___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127505___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127505___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127505___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127505___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127517___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127517___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127517___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127517___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127518___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127518___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127518___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127518___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127518___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127518___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127522___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127522___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127522___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127522___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127522___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127522___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127523___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127523___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127523___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127523___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127523___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127523___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127524___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127524___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127524___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127524___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127524___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127524___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127525___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127525___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128738___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128738___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128739___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128739___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128739___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128739___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128739___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128739___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128740___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128740___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128740___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128740___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128740___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128740___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128741___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128741___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128741___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128741___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128741___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128741___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128742___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128742___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128742___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128742___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128742___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128742___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128743___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128743___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128743___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128743___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128753___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128753___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128753___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128753___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128754___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128754___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128754___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128754___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128754___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128754___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128755___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128755___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128755___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128755___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128755___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128755___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128758___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128758___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128762___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128762___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128762___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128762___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128762___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128762___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128768___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128768___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128768___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128768___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128768___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128768___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128769___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128769___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128769___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128769___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128769___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128769___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128770___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128770___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128770___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128770___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128770___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128770___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128796___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128796___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128796___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128796___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128796___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128796___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128797___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128797___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128797___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128797___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128797___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128797___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128798___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128798___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128798___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128798___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128798___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128798___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128799___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128799___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128799___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128799___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128799___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128799___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128805___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128805___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128805___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128805___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128805___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128805___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128806___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128806___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128806___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128806___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128806___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128806___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128807___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128807___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128807___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128807___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128807___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128807___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128808___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128808___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128808___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128808___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128808___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128808___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128809___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128809___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128809___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128809___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128809___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128809___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128850___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128850___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128850___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128850___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128850___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128850___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128856___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128856___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128856___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128856___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128857___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128857___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128857___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128857___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128857___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128857___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128858___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128858___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128858___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128858___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128871___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128871___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128871___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128871___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134162___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134162___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hb9cb0b08__0;
    __VdfgTmp_hb9cb0b08__0 = 0;
    CData/*3:0*/ __VdfgTmp_hf524d067__0;
    __VdfgTmp_hf524d067__0 = 0;
    CData/*1:0*/ __VdfgTmp_he3e5ec17__0;
    __VdfgTmp_he3e5ec17__0 = 0;
    CData/*1:0*/ __VdfgTmp_h102458ff__0;
    __VdfgTmp_h102458ff__0 = 0;
    CData/*5:0*/ __VdfgTmp_ha1de3516__0;
    __VdfgTmp_ha1de3516__0 = 0;
    CData/*5:0*/ __VdfgTmp_hff06bcdd__0;
    __VdfgTmp_hff06bcdd__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4bfbe6f9__0;
    __VdfgTmp_h4bfbe6f9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0968f04c__0;
    __VdfgTmp_h0968f04c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0c3747f4__0;
    __VdfgTmp_h0c3747f4__0 = 0;
    CData/*1:0*/ __VdfgTmp_hffea5a13__0;
    __VdfgTmp_hffea5a13__0 = 0;
    CData/*1:0*/ __VdfgTmp_h01dc1976__0;
    __VdfgTmp_h01dc1976__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb1f3bce1__0;
    __VdfgTmp_hb1f3bce1__0 = 0;
    CData/*5:0*/ __VdfgTmp_h3874720c__0;
    __VdfgTmp_h3874720c__0 = 0;
    CData/*5:0*/ __VdfgTmp_h58192683__0;
    __VdfgTmp_h58192683__0 = 0;
    CData/*2:0*/ __VdfgTmp_h25b244b0__0;
    __VdfgTmp_h25b244b0__0 = 0;
    CData/*1:0*/ __VdfgTmp_h77ea5fdf__0;
    __VdfgTmp_h77ea5fdf__0 = 0;
    // Body
    vlSelf->__VdfgTmp_h0d37526f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127496___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h3a7e26d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127496___O) 
                                                         >> 2U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___127497___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h2a4257a8__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023017_));
    vlSelf->wasmetal_core__DOT____Vcellout___128849___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h46466860__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_h9ce496ce__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h3d32f603__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9110e1f3__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036342_)))));
    wasmetal_core__DOT___036346_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h46466860__0)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h1e507ca5__0 = (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017531_));
    vlSelf->__VdfgTmp_h6bcf76cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017548_));
    vlSelf->__VdfgTmp_h71876852__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017561_)));
    vlSelf->__VdfgTmp_h5bb2fc7d__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017576_)));
    vlSelf->__VdfgTmp_h8d1d0ffb__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___013519_)));
    vlSelf->__VdfgTmp_h6171bc25__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017676_)));
    vlSelf->__VdfgTmp_haf11557d__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017701_)));
    vlSelf->__VdfgTmp_heb003047__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017610_)));
    vlSelf->__VdfgTmp_h43b37fbe__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017623_)));
    vlSelf->__VdfgTmp_h69609ee5__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017728_)));
    vlSelf->wasmetal_core__DOT___035366_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf30cf57d__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071728_))))));
    vlSelf->wasmetal_core__DOT___035387_ = (1U & (0x3cc35aa5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xacU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019751_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (IData)(
                                                                                (0xaaaaf0f0ff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058060_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058059_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058057_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058061_)))))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071728_)))))));
    vlSelf->wasmetal_core__DOT___035364_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071721_))))));
    vlSelf->wasmetal_core__DOT___035356_ = (1U & (IData)(
                                                         (0xf1000eff0efff100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f5f0f300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019706_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51855551__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf1e8a9a9__0)))))))))));
    wasmetal_core__DOT___071746_ = (1U & (IData)((0x55330f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf1e8a9a9__0)))));
    vlSelf->wasmetal_core__DOT___035360_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b28__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013627_))))));
    vlSelf->wasmetal_core__DOT___035374_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071748_))))));
    vlSelf->wasmetal_core__DOT___035341_ = (1U & (0x5ca3a35cU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9195d647__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071748_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                   ? 
                                                                  (2U 
                                                                   >> 
                                                                   (1U 
                                                                    & (IData)(
                                                                              (0xaaaaf0f0ff00ccccULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058030_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058029_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058028_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057971_))))))))))
                                                                   : 
                                                                  (0xfafcU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019710_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he15aac2f__0)))))))))))));
    vlSelf->wasmetal_core__DOT___035370_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04542857__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071739_))))));
    vlSelf->wasmetal_core__DOT___035390_ = (1U & (0x3cc3a55aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b5__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((0xf0f0ccaaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057982_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058030_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058029_)))))) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___071737_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071739_)))))));
    vlSelf->wasmetal_core__DOT___035355_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b23__05d) 
                                                       << 1U) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                         & (IData)(
                                                                   (0xff00ff0f33335555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019698_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019697_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hf6f65f53__0))))))))))));
    vlSelf->wasmetal_core__DOT___035339_ = (1U & (0x69U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b7__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___013631_)
                                                              ? 
                                                             (2U 
                                                              >> 
                                                              (1U 
                                                               & (0xf0f0ccaaU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058067_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058025_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___058024_))))))))
                                                              : 
                                                             (0xcaU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf6f65f53__0))))
                                                             : 
                                                            ((~ (IData)(vlSelf->wasmetal_core__DOT___013631_)) 
                                                             | (0x32U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019698_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___019697_)))))))))));
    vlSelf->wasmetal_core__DOT___035381_ = (1U & (0x807f7f80U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h77324dc0__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019734_)))))));
    vlSelf->wasmetal_core__DOT___035363_ = (1U & (IData)(
                                                         (0x50c0af3faf3f50c0ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019734_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058071_)))))))));
    vlSelf->wasmetal_core__DOT___128771___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035701_) 
           | (IData)(vlSelf->wasmetal_core__DOT___035676_));
    vlSelf->wasmetal_core__DOT___035362_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058065_))))));
    vlSelf->wasmetal_core__DOT___035354_ = (1U & (IData)(
                                                         (0xf1000eff0efff100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b22__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x5300U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hc1e5da71__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071742_)))))))));
    wasmetal_core__DOT___071743_ = (1U & (IData)((0xf0f553300000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xf0f0ccaaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058064_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_ha0dc9087__0))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hc1e5da71__0))))))));
    vlSelf->wasmetal_core__DOT___035346_ = (1U & (0xe11eU 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x305000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h06185798__0))))))) 
                                                             << 1U)) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                ? 
                                                               (1U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___019728_))
                                                                : 
                                                               (0xf0f5533U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4eafc8bd__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b1__05d 
        = (1U & (0xc3a5U >> (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                              << 3U) | ((4U & ((0xdf2f20dU 
                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                               << 2U)) 
                                        | ((2U & ((IData)(
                                                          (0x1111f0f0ff00ff00ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019728_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058064_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0x5030000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)))))))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (1U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___058061_))))))))))) 
                                                  << 1U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___058065_))))));
    vlSelf->wasmetal_core__DOT___035349_ = (1U & (0x5ca3a35cU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071760_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                   ? 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019744_))
                                                                   : 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___014357_)
                                                                    ? 
                                                                   (0xacU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014373_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___014371_))))
                                                                    : 
                                                                   (0xcaU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014374_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___019676_)))))))))))));
    vlSelf->wasmetal_core__DOT___035380_ = (1U & (0x3cc35aa5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((0xfdf0000U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___071723_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057972_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058037_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h625062d0__0))))) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___019744_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071725_)))))));
    __VdfgTmp_h58192683__0 = ((0x20U & ((0xcaU >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0)) 
                                        << 5U)) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019725_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019724_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xccccaaaaff00f0f0ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014374_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014373_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5970a25a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___035348_ = (1U & (IData)(
                                                         (0x55c0aa3faa3f55c0ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071758_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                              ? 
                                                                             (2U 
                                                                              >> (IData)(vlSelf->wasmetal_core__DOT___019737_))
                                                                              : 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___014357_)
                                                                               ? 
                                                                              (0xcaU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019668_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014353_))))
                                                                               : 
                                                                              (0xcaU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014354_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019669_)))))))))))))));
    vlSelf->wasmetal_core__DOT___035369_ = (1U & (0x3cc35aa5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xddf0f0f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___071720_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___071719_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019737_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h56cb633a__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0)))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071721_)))))));
    __VdfgTmp_h3874720c__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b12__05d) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019720_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014363_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xfcfaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___014359_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h51e83899__0)))))))))));
    vlSelf->wasmetal_core__DOT___035347_ = (1U & (0x69U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT___013631_)
                                                             ? 
                                                            (0xf0f0ccaaU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019733_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h42589940__0)))))
                                                             : 
                                                            (7U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___019734_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b2__05d 
        = (1U & (IData)((0xaaaacc0f555533f0ULL >> (
                                                   (0x20U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019734_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058071_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0xcaU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x555f444cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058068_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057975_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057976_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058067_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058037_)))))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___019733_)))))))))))));
    vlSelf->wasmetal_core__DOT___035343_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___013631_)
                                                   ? 
                                                  (0x35caca35U 
                                                   >> 
                                                   ((0x10U 
                                                     & ((0xdf2f20dU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                        << 4U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b11__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019715_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xfcfaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___014385_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd4b4ff41__0)))))))))))
                                                   : 
                                                  (0x96U 
                                                   >> 
                                                   ((4U 
                                                     & ((0xdf2f20dU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b11__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___019713_))))));
    wasmetal_core__DOT___013630_ = (1U & (4U >> ((2U 
                                                  & ((0x1000000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___058051_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058050_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & ((IData)(
                                                                         (0xa0c0f0f0f0f0f0fULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___058046_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0)) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c001b5f__0))))))) 
                                                                 << 2U)) 
                                                             | ((2U 
                                                                 & ((IData)(
                                                                            (0x7fff00007fff7fffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058045_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058044_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058043_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)))))))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0x7fffffffULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058041_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057926_)))))))))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff0000077770000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058040_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xff7f7fU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___057985_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057984_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057983_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057982_)))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019720_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019725_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019715_)))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128757___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035653_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035642_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035631_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035620_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    wasmetal_core__DOT___035598_ = ((IData)(vlSelf->wasmetal_core__DOT___035653_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b4__05d));
    wasmetal_core__DOT___128871___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b41__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128871___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127530___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023195_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023194_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023193_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023192_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023254_)))));
    vlSelf->wasmetal_core__DOT___023259_ = ((IData)(vlSelf->wasmetal_core__DOT___023195_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128805___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035971_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035913_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b20__05d));
    wasmetal_core__DOT___127497___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b9__05d) 
           & (IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128850___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h8c0ae79e__0)) 
           & (IData)(wasmetal_core__DOT___036346_));
    vlSelf->wasmetal_core__DOT___035373_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___071746_))))));
    vlSelf->wasmetal_core__DOT___035340_ = (1U & (0x5ca3a35cU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b8__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___071746_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                   ? 
                                                                  (2U 
                                                                   >> 
                                                                   (1U 
                                                                    & (IData)(
                                                                              (0xaaaaf0f0ff00ccccULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058035_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058034_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058033_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057980_))))))))))
                                                                   : 
                                                                  (0xfafcU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019706_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h51855551__0)))))))))))));
    vlSelf->wasmetal_core__DOT___035391_ = (1U & (IData)(
                                                         (0xff1000ef00efff10ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___071743_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h74456d25__0)))))));
    __VdfgTmp_ha1de3516__0 = (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                               << 5U) | (((IData)(wasmetal_core__DOT___013630_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013629_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___013628_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___013627_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(
                                                           (0xff000b00ff00ffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___057908_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057907_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057906_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((4U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0))))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((0x8000U 
                                                                              >> 
                                                                              ((8U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0)) 
                                                                                << 3U)) 
                                                                               | ((4U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf30cf57d__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9cb72e5a__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h04542857__0))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (IData)(
                                                                                (0x7fff00007fff7fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0))))))))))))))))))))))));
    if ((1U & (0xdf2f20dU >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))) {
        vlSelf->wasmetal_core__DOT___035345_ = (1U 
                                                & (IData)(
                                                          (0xfcc5500f033aaffULL 
                                                           >> (IData)(__VdfgTmp_h58192683__0))));
        vlSelf->wasmetal_core__DOT___035344_ = (1U 
                                                & (IData)(
                                                          (0xf335500f0ccaaffULL 
                                                           >> (IData)(__VdfgTmp_h3874720c__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b0__05d 
            = (1U & (IData)((0xffff000040000000ULL 
                             >> (IData)(__VdfgTmp_ha1de3516__0))));
    } else {
        vlSelf->wasmetal_core__DOT___035345_ = (1U 
                                                & (IData)(
                                                          (0xf033aaff0fcc5500ULL 
                                                           >> (IData)(__VdfgTmp_h58192683__0))));
        vlSelf->wasmetal_core__DOT___035344_ = (1U 
                                                & (IData)(
                                                          (0xf0ccaaff0f335500ULL 
                                                           >> (IData)(__VdfgTmp_h3874720c__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b0__05d 
            = (1U & (IData)((0xffffbfffffffULL >> (IData)(__VdfgTmp_ha1de3516__0))));
    }
    wasmetal_core__DOT___128743___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___035398_));
    wasmetal_core__DOT___128762___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035664_)
            ? (IData)(wasmetal_core__DOT___035598_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b5__05d));
    wasmetal_core__DOT___128871___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b42__05d) 
           & (IData)(wasmetal_core__DOT___128871___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006037_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127530___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h04d557bc__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf628d2c5__0)))));
    vlSelf->wasmetal_core__DOT___006010_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127530___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9bddaa79__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9bddaa79__0)))))));
    vlSelf->wasmetal_core__DOT___006035_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127530___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9c9f5aae__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9c9f5aae__0)))))));
    vlSelf->wasmetal_core__DOT___006036_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127530___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9be9fa04__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9be9fa04__0)))))));
    vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023196_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023259_));
    wasmetal_core__DOT___128805___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035972_)
            ? (IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b21__05d));
    wasmetal_core__DOT___127497___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h8d5d3612__0)) 
           & (IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128850___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h7594c868__0)) 
           & (IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128743___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128743___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128762___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035669_)
            ? (IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b6__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128871___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b43__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b42__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b41__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b40__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128871___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128871___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128871___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036498_)))));
    vlSelf->wasmetal_core__DOT___036503_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b43__05d) 
                                            & (IData)(wasmetal_core__DOT___128871___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023197_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128805___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035973_)
            ? (IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b22__05d));
    wasmetal_core__DOT____Vcellout___127497___O = (
                                                   ((8U 
                                                     & ((6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hff2cd213__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h8d5d3612__0)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b9__05d) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2a4257a8__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023017_)))));
    vlSelf->wasmetal_core__DOT___022990_ = ((6U >> (IData)(vlSelf->__VdfgTmp_hff2cd213__0)) 
                                            & (IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128850___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hb3fd333a__0)) 
           & (IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b0__05d) 
           & (0xdf2f20dU >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)));
    vlSelf->wasmetal_core__DOT____Vcellout___128743___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O)) 
                                               << 1U)) 
                                             | (IData)(vlSelf->wasmetal_core__DOT___035398_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128743___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___128743___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___035398_) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035486_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___128743___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128762___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035670_)
            ? (IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b7__05d));
    wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b44__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036503_));
    wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023198_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128805___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035974_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035973_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035972_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035971_)))) 
           ^ (((IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035913_)))));
    wasmetal_core__DOT___035918_ = ((IData)(vlSelf->wasmetal_core__DOT___035974_)
                                     ? (IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b23__05d));
    vlSelf->__VdfgTmp_h9b49e40f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127497___O) 
                                                         >> 2U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h95fb6f3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127497___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h8c2e6c21__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127497___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___018495_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016447_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127497___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___127498___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___022990_));
    vlSelf->wasmetal_core__DOT____Vcellout___128850___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h219534f4__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_hb3fd333a__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h7594c868__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8c0ae79e__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036346_)))));
    vlSelf->wasmetal_core__DOT___036325_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h219534f4__0)) 
                                            & (IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b1__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h834dc827__0 = (((IData)(vlSelf->wasmetal_core__DOT___035398_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128743___O)));
    vlSelf->wasmetal_core__DOT___128748___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035486_));
    vlSelf->wasmetal_core__DOT____Vcellout___128762___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035671_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035670_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035669_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035664_)))) 
           ^ (((IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035598_)))));
    vlSelf->wasmetal_core__DOT___035617_ = ((IData)(vlSelf->wasmetal_core__DOT___035671_)
                                             ? (IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b8__05d));
    wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b45__05d) 
           & (IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127531___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023199_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023198_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023197_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023196_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023259_)))));
    vlSelf->wasmetal_core__DOT___023263_ = ((IData)(vlSelf->wasmetal_core__DOT___023199_) 
                                            & (IData)(wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053601_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128805___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                         >> 3U)))));
    wasmetal_core__DOT___128806___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035975_)
            ? (IData)(wasmetal_core__DOT___035918_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b24__05d));
    vlSelf->wasmetal_core__DOT___018538_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                          ? 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8d5d3612__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h95fb6f3e__0))))
                                                                          : 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8d5d3612__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h95fb6f3e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f0cc55U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hdb61f435__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f0cc55U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hdb61f435__0))))))))))));
    vlSelf->wasmetal_core__DOT___059619_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2a4257a8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h8c2e6c21__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2a4257a8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h8c2e6c21__0))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xf0fccaa00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h5aa7dbd9__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0000ccaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h5aa7dbd9__0))))))))))));
    wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127498___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h692ab415__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036325_));
    wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128748___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035672_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035617_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b9__05d));
    wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b46__05d) 
           & (IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005913_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h85d5ffaf__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h85d5ffaf__0)))))));
    vlSelf->wasmetal_core__DOT___005847_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hbca1455c__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_haeb15d33__0)))));
    vlSelf->wasmetal_core__DOT___005779_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h85c84d1a__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h85c84d1a__0)))))));
    vlSelf->wasmetal_core__DOT___005778_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h850cecd0__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h850cecd0__0)))))));
    vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023200_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023263_));
    wasmetal_core__DOT___128806___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035976_)
            ? (IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b25__05d));
    wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
           & (IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h2f0f6f72__0)) 
           & (IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128728___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035369_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b1__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b0__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (1U & 
                                               (0xdf2f20dU 
                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))))));
    vlSelf->wasmetal_core__DOT___035315_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035369_)
                                                   ? (IData)(wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0))));
    wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035673_)
            ? (IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b10__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128872___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b47__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b46__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b45__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b44__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036503_)))));
    vlSelf->wasmetal_core__DOT___036507_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b47__05d) 
                                            & (IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023201_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128806___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035977_)
            ? (IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b26__05d));
    wasmetal_core__DOT____Vcellout___127498___O = (
                                                   ((8U 
                                                     & ((0xf10eU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h37243dd3__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((6U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127498___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022990_)))));
    vlSelf->wasmetal_core__DOT___022994_ = ((0xf10eU 
                                             >> (IData)(vlSelf->__VdfgTmp_h37243dd3__0)) 
                                            & (IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hf223abb4__0)) 
           & (IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035380_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035315_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128748___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128748___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035486_)))));
    vlSelf->wasmetal_core__DOT___035505_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035621_)
            ? (IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b11__05d));
    vlSelf->wasmetal_core__DOT___128873___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b48__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036507_));
    wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023203_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128806___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035978_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035977_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035976_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035975_)))) 
           ^ (((IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035918_)))));
    vlSelf->wasmetal_core__DOT___035922_ = ((IData)(vlSelf->wasmetal_core__DOT___035978_)
                                             ? (IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b27__05d));
    vlSelf->wasmetal_core__DOT___059797_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00aaaafc0cfc0cULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xf100U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h37243dd3__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127498___O) 
                                                                                >> 3U))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058456_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058455_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_)))))))))))))))))))))));
    vlSelf->__VdfgTmp_hc406f1dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127498___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h0017edb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127498___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_hc4afcee8__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(wasmetal_core__DOT____Vcellout___127498___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___127499___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hf599dae9__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___022994_));
    vlSelf->wasmetal_core__DOT____Vcellout___128851___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h77210e87__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_hf223abb4__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h2f0f6f72__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h692ab415__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036325_)))));
    vlSelf->wasmetal_core__DOT___036329_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h77210e87__0)) 
                                            & (IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035387_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0))));
    vlSelf->wasmetal_core__DOT___128749___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035505_));
    vlSelf->wasmetal_core__DOT____Vcellout___128763___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035622_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035621_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035673_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035672_)))) 
           ^ (((IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035617_)))));
    vlSelf->wasmetal_core__DOT___035567_ = ((IData)(vlSelf->wasmetal_core__DOT___035622_)
                                             ? (IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b12__05d));
    wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b49__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128873___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127532___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023204_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023203_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023201_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023200_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023263_)))));
    wasmetal_core__DOT___023268_ = ((IData)(vlSelf->wasmetal_core__DOT___023204_) 
                                    & (IData)(wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___042821_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128806___O) 
                                                               << 3U)) 
                                                           | (7U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128805___O) 
                                                                 >> 1U))))));
    wasmetal_core__DOT___128807___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035979_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035922_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b28__05d));
    vlSelf->wasmetal_core__DOT___059717_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hc406f1dc__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hc406f1dc__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058450_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058449_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059769_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h0017edb5__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h0017edb5__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058454_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O)) 
                                                                                | ((2U 
                                                                                & ((0x11000fU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hecea8d31__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059744_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                  ? 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc4afcee8__0))))
                                                                  : 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc4afcee8__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058452_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058451_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_)))))))))))))))))))))));
    wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127499___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_haf20b36b__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036329_));
    wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035388_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0))));
    wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128749___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035623_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035567_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b13__05d));
    wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b50__05d) 
           & (IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005914_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_he6ade5b0__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he6ade5b0__0)))))));
    vlSelf->wasmetal_core__DOT___005848_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1ea78a97__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h098b01ee__0)))));
    vlSelf->wasmetal_core__DOT___005776_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_he6a1153d__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he6a1153d__0)))))));
    vlSelf->wasmetal_core__DOT___005777_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_he5c4f457__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_he5c4f457__0)))))));
    wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023205_) 
           & (IData)(wasmetal_core__DOT___023268_));
    wasmetal_core__DOT___128807___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035980_)
            ? (IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b29__05d));
    wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
           & (IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h25476d0e__0)) 
           & (IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128734___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035389_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035388_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035387_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035380_)))) 
           ^ (((IData)(wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035315_)))));
    wasmetal_core__DOT___035336_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035389_)
                                           ? (IData)(wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0))));
    wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035624_)
            ? (IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b14__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128873___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b51__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b50__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b49__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b48__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128873___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036507_)))));
    wasmetal_core__DOT___036512_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b51__05d) 
                                    & (IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___048265_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006039_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006038_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005781_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005780_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005914_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006037_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006036_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006035_)))))))))));
    vlSelf->wasmetal_core__DOT___006121_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005848_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006010_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___023189_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127529___O) 
                                                                  >> 2U))))))));
    __VdfgTmp_hf524d067__0 = (((IData)(vlSelf->wasmetal_core__DOT___005779_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005778_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___005777_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005776_))));
    wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023206_) 
           & (IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128807___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035982_)
            ? (IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b30__05d));
    wasmetal_core__DOT____Vcellout___127499___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf599dae9__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127499___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022994_)))));
    wasmetal_core__DOT___022998_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
                                    & (IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h917221d1__0)) 
           & (IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h96193a8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                                >> 3U)))))));
    __VdfgTmp_hff06bcdd__0 = (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                               << 5U) | ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                   << 3U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                        >> 2U)))))));
    vlSelf->__VdfgTmp_he5c2d914__0 = (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                     << 4U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h91abfcdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035390_)
            ? (IData)(wasmetal_core__DOT___035336_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128749___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128749___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035505_)))));
    wasmetal_core__DOT___035455_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035625_)
            ? (IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b15__05d));
    vlSelf->wasmetal_core__DOT___060449_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128873___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1bc2f6b9__0))))))));
    wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b52__05d) 
           & (IData)(wasmetal_core__DOT___036512_));
    vlSelf->wasmetal_core__DOT___048158_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005783_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005782_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005781_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005780_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hf524d067__0))))))));
    vlSelf->wasmetal_core__DOT___006193_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006166_)) 
                                                  & ((~ 
                                                      (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127529___O) 
                                                        >> 1U) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                           ? (IData)(
                                                                     (0xf3f0f2e0f3faaaaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde33bda2__0)))))))
                                                           : 
                                                          (0x302U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hde33bda2__0))))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006036_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006035_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hf524d067__0))))))));
    wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023207_) 
           & (IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128807___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035983_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035982_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035980_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035979_)))) 
           ^ (((IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035922_)))));
    wasmetal_core__DOT___035927_ = ((IData)(vlSelf->wasmetal_core__DOT___035983_)
                                     ? (IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b31__05d));
    vlSelf->__VdfgTmp_h312e1166__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___059910_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00aaaafc0cfc0cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xfef00000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058307_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf5238d18__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                                                >> 3U))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f33aa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf552ae6e__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f000033aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf552ae6e__0))))))))))))));
    vlSelf->wasmetal_core__DOT___059849_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00aaaafc0cfc0cULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016441_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                                                >> 1U))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058461_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O) 
                                                                                >> 1U))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059882_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00aaaafc0cfc0cULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heb95d931__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                                                >> 2U))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058465_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O) 
                                                                                >> 2U))))))))))))))))))))));
    wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)) 
           & (IData)(wasmetal_core__DOT___022998_));
    vlSelf->wasmetal_core__DOT____Vcellout___128852___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_hafd7ea26__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_h917221d1__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h25476d0e__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_haf20b36b__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036329_)))));
    wasmetal_core__DOT___036333_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hafd7ea26__0)) 
                                    & (IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___014970_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                    ? (IData)(
                                                              (0xaaaaaaaa0f8b0088ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0)))
                                                    : (IData)(
                                                              (0xf0f0000aa2eaa22ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                    ? (IData)(
                                                              (0xf0f0000aa2eaa22ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0)))
                                                    : (IData)(
                                                              (0xaaaaaaaa0f8b0088ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0))))));
    wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035391_)
            ? (IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b6__05d));
    wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035455_));
    vlSelf->wasmetal_core__DOT____Vcellout___128764___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035626_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035625_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035624_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035623_)))) 
           ^ (((IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035567_)))));
    wasmetal_core__DOT___035571_ = ((IData)(vlSelf->wasmetal_core__DOT___035626_)
                                     ? (IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b16__05d));
    wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b53__05d) 
           & (IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127533___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023208_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023207_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023206_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023205_)))) 
           ^ (((IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023268_)))));
    wasmetal_core__DOT___023272_ = ((IData)(vlSelf->wasmetal_core__DOT___023208_) 
                                    & (IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128808___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035984_)
            ? (IData)(wasmetal_core__DOT___035927_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b32__05d));
    wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
           & (IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h513c757b__0)) 
           & (IData)(wasmetal_core__DOT___036333_));
    wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035339_)
            ? (IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b7__05d));
    wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O)) 
           & (IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035627_)
            ? (IData)(wasmetal_core__DOT___035571_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b17__05d));
    wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b54__05d) 
           & (IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006165_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127533___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006171_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb48e3438__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb48e3438__0))))));
    wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023209_) 
           & (IData)(wasmetal_core__DOT___023272_));
    wasmetal_core__DOT___128808___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035985_)
            ? (IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b33__05d));
    wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
           & (IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h310e5162__0)) 
           & (IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128735___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035340_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035339_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035391_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035390_)))) 
           ^ (((IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035336_)))));
    wasmetal_core__DOT___035284_ = ((IData)(vlSelf->wasmetal_core__DOT___035340_)
                                     ? (IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b8__05d));
    wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035628_)
            ? (IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b18__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128874___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b55__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b54__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b53__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b52__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036512_)))));
    wasmetal_core__DOT___036516_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023210_) 
           & (IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128808___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035986_)
            ? (IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b34__05d));
    wasmetal_core__DOT____Vcellout___127500___O = (
                                                   ((8U 
                                                     & ((0xf40bU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h86dfc376__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((6U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022998_)))));
    wasmetal_core__DOT___023003_ = ((0xf40bU >> (IData)(vlSelf->__VdfgTmp_h86dfc376__0)) 
                                    & (IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hd5a7b943__0)) 
           & (IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hb335ec2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h15de5b2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hbff92af3__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035341_)
                  ? (IData)(wasmetal_core__DOT___035284_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h9195d647__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128750___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035455_)))));
    wasmetal_core__DOT___035459_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035629_)
            ? (IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b19__05d));
    wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b56__05d) 
           & (IData)(wasmetal_core__DOT___036516_));
    wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023211_) 
           & (IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128808___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035987_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035986_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035985_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035984_)))) 
           ^ (((IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035927_)))));
    wasmetal_core__DOT___035931_ = ((IData)(vlSelf->wasmetal_core__DOT___035987_)
                                     ? (IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b35__05d));
    vlSelf->wasmetal_core__DOT___060022_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00aaaafc0cfc0cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xf400U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h86dfc376__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127500___O) 
                                                                                >> 3U))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f000ddU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h460f8c4e__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f000ddU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h460f8c4e__0))))))))))));
    __VdfgTmp_h4bfbe6f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127500___O) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    __VdfgTmp_h0c3747f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127500___O) 
                                                    >> 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    __VdfgTmp_h0968f04c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127500___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__ 
        = ((0xf40bU >> (IData)(vlSelf->__VdfgTmp_h6df53282__0)) 
           & (IData)(wasmetal_core__DOT___023003_));
    vlSelf->wasmetal_core__DOT____Vcellout___128853___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h4e8a0148__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_hd5a7b943__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h310e5162__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h513c757b__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036333_)))));
    wasmetal_core__DOT___036338_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h4e8a0148__0)) 
                                    & (IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035342_)
            ? (IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b10__05d));
    wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035459_));
    vlSelf->wasmetal_core__DOT____Vcellout___128765___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035630_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035629_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035628_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035627_)))) 
           ^ (((IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035571_)))));
    wasmetal_core__DOT___035575_ = ((IData)(vlSelf->wasmetal_core__DOT___035630_)
                                     ? (IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b20__05d));
    wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b57__05d) 
           & (IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127534___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023212_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023211_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023210_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023209_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023272_)))));
    wasmetal_core__DOT___023276_ = ((IData)(vlSelf->wasmetal_core__DOT___023212_) 
                                    & (IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053602_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128808___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128806___O) 
                                                         >> 3U)))));
    wasmetal_core__DOT___128809___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035988_)
            ? (IData)(wasmetal_core__DOT___035931_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b36__05d));
    vlSelf->wasmetal_core__DOT___018808_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h4bfbe6f9__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h4bfbe6f9__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058471_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059991_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0c3747f4__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0c3747f4__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdd0f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058474_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058473_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059963_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0968f04c__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0968f04c__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdd0f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058472_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016278_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006819_)))))))))))))))))))))))));
    wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
           & (IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128854___O = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d) 
                                                      & (IData)(wasmetal_core__DOT___036338_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___036338_)));
    wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035343_)
            ? (IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b11__05d));
    wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O)) 
           & (IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035632_)
            ? (IData)(wasmetal_core__DOT___035575_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b21__05d));
    wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b58__05d) 
           & (IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005975_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005989_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9937e7c0__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9937e7c0__0))))));
    vlSelf->wasmetal_core__DOT___006009_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006022_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_ha48aeb8e__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_ha48aeb8e__0))))));
    vlSelf->wasmetal_core__DOT___006079_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006099_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9936ac51__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9936ac51__0))))));
    vlSelf->wasmetal_core__DOT___006080_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006106_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h97a6ba37__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h97a6ba37__0))))));
    wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023214_) 
           & (IData)(wasmetal_core__DOT___023276_));
    wasmetal_core__DOT___128809___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035989_)
            ? (IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b37__05d));
    wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h20c89172__0)) 
           & (IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d 
        = (1U & (4U >> ((2U & (IData)(wasmetal_core__DOT____Vcellout___128854___O)) 
                        | (IData)(vlSelf->wasmetal_core__DOT___017533_))));
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry 
        = (1U & (0xb00U >> ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128854___O) 
                                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057694_))))));
    wasmetal_core__DOT____Vcellout___128736___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035344_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035343_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035342_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035341_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035284_)))));
    wasmetal_core__DOT___035288_ = ((IData)(vlSelf->wasmetal_core__DOT___035344_)
                                     ? (IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b12__05d));
    wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035633_)
            ? (IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b22__05d));
    wasmetal_core__DOT____Vcellout___128875___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b59__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b58__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b57__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b56__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036516_)))));
    wasmetal_core__DOT___036520_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b59__05d) 
                                    & (IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___006123_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005782_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005781_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006166_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006036_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005778_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005777_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006165_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006080_)))))))))));
    wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023215_) 
           & (IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128809___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035990_)
            ? (IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b38__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127501___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h20c89172__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
                                                << 1U)) 
                                         | (1U & (0xf40bU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h6df53282__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023003_)))));
    wasmetal_core__DOT___023007_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
                                    & (IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___036374_ = (1U & (6U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d))));
    wasmetal_core__DOT___036373_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                     << 1U)) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry))));
    vlSelf->__VdfgTmp_h493bd629__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128736___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_haaae3cf9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hbca0145a__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128736___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h532df62e__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035345_)
                  ? (IData)(wasmetal_core__DOT___035288_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128751___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035459_)))));
    wasmetal_core__DOT___035463_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035634_)
            ? (IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b23__05d));
    vlSelf->wasmetal_core__DOT___060552_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7cadd68e__0))))))));
    vlSelf->wasmetal_core__DOT___060566_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h49fa4f4c__0))))))));
    vlSelf->wasmetal_core__DOT___060584_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058512_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060598_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016491_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                  >> 3U))))))));
    wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b60__05d) 
           & (IData)(wasmetal_core__DOT___036520_));
    wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023216_) 
           & (IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128809___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035991_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035990_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035989_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035988_)))) 
           ^ (((IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035931_)))));
    wasmetal_core__DOT___035935_ = ((IData)(vlSelf->wasmetal_core__DOT___035991_)
                                     ? (IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b39__05d));
    __VdfgTmp_hffea5a13__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127501___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_he5a4e99b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127501___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b28__05d) 
           & (IData)(wasmetal_core__DOT___023007_));
    wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036373_)) 
           & (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry));
    wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035346_)
                  ? (IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0))));
    wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035463_));
    vlSelf->wasmetal_core__DOT____Vcellout___128766___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035635_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035634_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035633_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035632_)))) 
           ^ (((IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035575_)))));
    wasmetal_core__DOT___035580_ = ((IData)(vlSelf->wasmetal_core__DOT___035635_)
                                     ? (IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b24__05d));
    wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b61__05d) 
           & (IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127520___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023217_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023216_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023215_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023214_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023276_)))));
    vlSelf->wasmetal_core__DOT___023281_ = ((IData)(vlSelf->wasmetal_core__DOT___023217_) 
                                            & (IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053605_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128809___O) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128808___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___053599_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128809___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128808___O) 
                                                         >> 1U)))));
    wasmetal_core__DOT___128796___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035993_)
            ? (IData)(wasmetal_core__DOT___035935_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b40__05d));
    vlSelf->wasmetal_core__DOT___060072_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                          ? 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_hffea5a13__0))))
                                                                          : 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_hffea5a13__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f000ddU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h3056fe7c__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f000ddU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h3056fe7c__0))))))))))));
    wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
           & (IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036374_) ? (IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__)
            : (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d));
    wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035347_)
                  ? (IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0))));
    wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O)) 
           & (IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035636_)
            ? (IData)(wasmetal_core__DOT___035580_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128876___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b63__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b62__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b61__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b60__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b62__05d) 
                & (IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036520_)))));
    vlSelf->wasmetal_core__DOT___005845_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005868_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb869da0d__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb869da0d__0))))));
    vlSelf->wasmetal_core__DOT___005843_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005855_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_haba8fa43__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_haba8fa43__0))))));
    vlSelf->wasmetal_core__DOT___005706_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005770_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb86fa734__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb86fa734__0))))));
    vlSelf->wasmetal_core__DOT___005705_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___003806_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab9caa42__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab9caa42__0))))));
    vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023218_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023281_));
    wasmetal_core__DOT___128796___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035994_)
            ? (IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b41__05d));
    wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
           & (IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128737___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035348_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035347_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035346_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035345_)))) 
           ^ (((IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035288_)))));
    vlSelf->wasmetal_core__DOT___035292_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035348_)
                                                   ? (IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0))));
    wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035637_)
            ? (IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b26__05d));
    vlSelf->wasmetal_core__DOT___060614_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h307b9eba__0))))))));
    vlSelf->wasmetal_core__DOT___060640_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f000003355ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058515_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060624_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f000003355ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058514_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023219_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128796___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035995_)
            ? (IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b42__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127502___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b28__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023007_)))));
    vlSelf->wasmetal_core__DOT___023077_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
                                            & (IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128855___O 
        = (((0xcU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
            | (((IData)(wasmetal_core__DOT___036374_) 
                << 1U) | (IData)(wasmetal_core__DOT___036373_))) 
           ^ (((IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___036366_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_he1094429__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h4c1a1db9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h155aafca__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h6827e815__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035349_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035292_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h93626d60__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128752___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035463_)))));
    vlSelf->wasmetal_core__DOT___035468_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035638_)
            ? (IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b27__05d));
    vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023220_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128796___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035996_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035995_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035994_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035993_)))) 
           ^ (((IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035935_)))));
    wasmetal_core__DOT___035940_ = ((IData)(vlSelf->wasmetal_core__DOT___035996_)
                                     ? (IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b43__05d));
    __VdfgTmp_h01dc1976__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127502___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    __VdfgTmp_hb1f3bce1__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127502___O) 
                                                    >> 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___019013_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058337_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127502___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___127517___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b32__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___023077_));
    vlSelf->wasmetal_core__DOT___134162___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O))));
    vlSelf->wasmetal_core__DOT___128859___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O))));
    vlSelf->wasmetal_core__DOT___043027_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___043030_ = (1U & (0x40U 
                                                  >> 
                                                  ((6U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___128856___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___036366_));
    vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035350_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h767f4755__0))));
    vlSelf->wasmetal_core__DOT___128753___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035468_));
    vlSelf->wasmetal_core__DOT____Vcellout___128767___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035639_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035638_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035637_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035636_)))) 
           ^ (((IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035580_)))));
    vlSelf->wasmetal_core__DOT___035584_ = ((IData)(vlSelf->wasmetal_core__DOT___035639_)
                                             ? (IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b28__05d));
    wasmetal_core__DOT____Vcellout___127521___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023221_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023220_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023219_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023218_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023281_)))));
    wasmetal_core__DOT___023285_ = ((IData)(vlSelf->wasmetal_core__DOT___023221_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128797___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035997_)
            ? (IData)(wasmetal_core__DOT___035940_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b44__05d));
    vlSelf->wasmetal_core__DOT___060180_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f335500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                                 ? 
                                                                                (0xc0c5U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h01dc1976__0))))
                                                                                 : 
                                                                                (0xc0c5U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h01dc1976__0))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h78bec42d__0))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h78bec42d__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___060204_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_hb1f3bce1__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_hb1f3bce1__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xbb0f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058493_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128869___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4af9777a__0)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060234_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f335500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                                 ? 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019014_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___019013_))))
                                                                                 : 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___019013_))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060224_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h59bf4fdc__0))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h59bf4fdc__0)))))))))))))))));
    wasmetal_core__DOT___127517___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b33__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127517___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___134162___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                  >> 2U) | (IData)(vlSelf->wasmetal_core__DOT___134162___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___128856___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128856___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128738___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035351_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0))));
    wasmetal_core__DOT___128753___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128753___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128768___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035640_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035584_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b29__05d));
    vlSelf->wasmetal_core__DOT___005912_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127521___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___003805_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6e06acca__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6e06acca__0))))));
    vlSelf->wasmetal_core__DOT___005844_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127521___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___003811_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he245418c__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he245418c__0))))));
    vlSelf->wasmetal_core__DOT___005703_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127521___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___003808_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6f6c5c03__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6f6c5c03__0))))));
    vlSelf->wasmetal_core__DOT___005704_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127521___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___003807_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he137fc3d__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he137fc3d__0))))));
    wasmetal_core__DOT___127522___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023222_) 
           & (IData)(wasmetal_core__DOT___023285_));
    wasmetal_core__DOT___128797___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035998_)
            ? (IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b45__05d));
    wasmetal_core__DOT___127517___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b34__05d) 
           & (IData)(wasmetal_core__DOT___127517___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134162___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134162___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134162___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___036819_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                     >> 3U) 
                                                    | (IData)(wasmetal_core__DOT___134162___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___128856___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128856___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128738___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035352_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035351_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035350_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035349_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128738___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035292_)))));
    wasmetal_core__DOT___035297_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035352_)
                                           ? (IData)(wasmetal_core__DOT___128738___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_hff1a4828__0))));
    wasmetal_core__DOT___128753___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128753___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128768___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035641_)
            ? (IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b30__05d));
    vlSelf->wasmetal_core__DOT___006192_ = (1U & ((~ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127533___O) 
                                                     >> 1U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006215_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h584814f6__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h584814f6__0)))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006165_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006080_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006079_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005706_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005705_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005704_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005703_)))))))))));
    wasmetal_core__DOT___127522___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023223_) 
           & (IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128797___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035999_)
            ? (IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b46__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127517___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b35__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b34__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b33__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b32__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127517___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127517___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127517___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023077_)))));
    wasmetal_core__DOT___023081_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b35__05d) 
                                    & (IData)(wasmetal_core__DOT___127517___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128856___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
           ^ (((IData)(wasmetal_core__DOT___128856___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128856___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128856___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036366_)))));
    wasmetal_core__DOT___036370_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128856___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hddb36baf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128738___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h99b9ed45__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h5c210cc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128738___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hdd9a68de__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128739___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035353_)
                  ? (IData)(wasmetal_core__DOT___035297_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128753___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128753___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128753___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128753___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035468_)))));
    wasmetal_core__DOT___035472_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128753___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128768___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035643_)
            ? (IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b31__05d));
    wasmetal_core__DOT___127522___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023225_) 
           & (IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128797___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036000_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035999_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035998_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035997_)))) 
           ^ (((IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035940_)))));
    wasmetal_core__DOT___035944_ = ((IData)(vlSelf->wasmetal_core__DOT___036000_)
                                     ? (IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b47__05d));
    wasmetal_core__DOT___127518___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b36__05d) 
           & (IData)(wasmetal_core__DOT___023081_));
    vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036819_)));
    vlSelf->wasmetal_core__DOT____Vcellout___128859___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                       >> 1U)))))) 
           ^ (1U | ((((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                          >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___128859___DOT__CO__BRA__1__KET__)) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128859___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___058937_ = (1U & (1U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                             << 1U)) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                               >> 2U)))))));
    wasmetal_core__DOT___128857___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
           & (IData)(wasmetal_core__DOT___036370_));
    wasmetal_core__DOT___128739___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035354_)
            ? (IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b22__05d));
    wasmetal_core__DOT___128754___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035472_));
    vlSelf->wasmetal_core__DOT____Vcellout___128768___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035644_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035643_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035641_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035640_)))) 
           ^ (((IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035584_)))));
    wasmetal_core__DOT___035589_ = ((IData)(vlSelf->wasmetal_core__DOT___035644_)
                                     ? (IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b32__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127522___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023226_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023225_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023223_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023222_)))) 
           ^ (((IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023285_)))));
    wasmetal_core__DOT___023290_ = ((IData)(vlSelf->wasmetal_core__DOT___023226_) 
                                    & (IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___042824_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128797___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128796___O) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128809___O) 
                                                                    >> 3U)))))));
    wasmetal_core__DOT___128798___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036001_)
            ? (IData)(wasmetal_core__DOT___035944_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b48__05d));
    wasmetal_core__DOT___127518___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b37__05d) 
           & (IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                  >> 1U) | (IData)(vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___128857___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128739___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035355_)
            ? (IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b23__05d));
    wasmetal_core__DOT___128754___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O)) 
           & (IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128769___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035645_)
            ? (IData)(wasmetal_core__DOT___035589_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b33__05d));
    vlSelf->wasmetal_core__DOT___006397_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127522___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006400_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h201788e1__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h201788e1__0))))));
    vlSelf->wasmetal_core__DOT___006132_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127522___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___003810_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h21955c47__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h21955c47__0))))));
    vlSelf->wasmetal_core__DOT___006199_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127522___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___003809_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3cbf3996__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3cbf3996__0))))));
    wasmetal_core__DOT___127523___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023227_) 
           & (IData)(wasmetal_core__DOT___023290_));
    wasmetal_core__DOT___128798___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036002_)
            ? (IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b49__05d));
    wasmetal_core__DOT___127518___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b38__05d) 
           & (IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128857___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128739___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035356_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035355_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035354_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035353_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035297_)))));
    wasmetal_core__DOT___035301_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035356_)
                                           ? (IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0))));
    wasmetal_core__DOT___128754___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128769___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035646_)
            ? (IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b34__05d));
    wasmetal_core__DOT___127523___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023228_) 
           & (IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128798___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036004_)
            ? (IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b50__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127518___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b39__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b38__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b37__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b36__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023081_)))));
    wasmetal_core__DOT___023085_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b39__05d) 
                                    & (IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128857___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036370_)))));
    wasmetal_core__DOT___036360_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h207e55f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128739___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h328f8271__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hde3a7a63__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128739___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hdc99d11f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128740___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035357_)
                  ? (IData)(wasmetal_core__DOT___035301_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h7297059c__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128754___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035472_)))));
    wasmetal_core__DOT___035477_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128769___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035647_)
            ? (IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b35__05d));
    wasmetal_core__DOT___127523___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023229_) 
           & (IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128798___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036005_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036004_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036002_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036001_)))) 
           ^ (((IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035944_)))));
    wasmetal_core__DOT___035949_ = ((IData)(vlSelf->wasmetal_core__DOT___036005_)
                                     ? (IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b51__05d));
    vlSelf->wasmetal_core__DOT___019112_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff00bb00ff000f00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128885___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9e4b4f68__0))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f0335500000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058346_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127518___O) 
                                                                                >> 3U))))))))))))));
    wasmetal_core__DOT___127504___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b40__05d) 
           & (IData)(wasmetal_core__DOT___023085_));
    wasmetal_core__DOT___043028_ = (1U & (IData)((0x1fffULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128857___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                                     >> 3U))))))))));
    __VdfgTmp_hb9cb0b08__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                     >> 2U)) | (1U 
                                                & (IData)(wasmetal_core__DOT____Vcellout___128857___O)));
    wasmetal_core__DOT___128858___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___036292_)) 
           & (IData)(wasmetal_core__DOT___036360_));
    wasmetal_core__DOT___128740___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035358_)
                  ? (IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0))));
    wasmetal_core__DOT___128755___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035477_));
    vlSelf->wasmetal_core__DOT____Vcellout___128769___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035648_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035647_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035646_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035645_)))) 
           ^ (((IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035589_)))));
    wasmetal_core__DOT___035593_ = ((IData)(vlSelf->wasmetal_core__DOT___035648_)
                                     ? (IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b36__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127523___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023230_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023229_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023228_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023227_)))) 
           ^ (((IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023290_)))));
    wasmetal_core__DOT___023294_ = ((IData)(vlSelf->wasmetal_core__DOT___023230_) 
                                    & (IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053606_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128798___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128797___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___053607_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128798___O) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128797___O) 
                                                         >> 2U)))));
    wasmetal_core__DOT___128799___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036006_)
            ? (IData)(wasmetal_core__DOT___035949_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b52__05d));
    wasmetal_core__DOT___127504___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b41__05d) 
           & (IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___043031_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                       << 2U)) 
                                                   | ((0x1cU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_hb9cb0b08__0))))));
    wasmetal_core__DOT___128858___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___036292_)) 
           & (IData)(wasmetal_core__DOT___128858___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128740___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035359_)
            ? (IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b27__05d));
    wasmetal_core__DOT___128755___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O)) 
           & (IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128770___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035649_)
            ? (IData)(wasmetal_core__DOT___035593_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b37__05d));
    vlSelf->wasmetal_core__DOT___006008_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127523___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006015_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb514b790__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb514b790__0))))));
    vlSelf->wasmetal_core__DOT___006077_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127523___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006085_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h41acf677__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h41acf677__0))))));
    vlSelf->wasmetal_core__DOT___006078_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127523___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006092_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb6ef8d81__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb6ef8d81__0))))));
    wasmetal_core__DOT___127524___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023231_) 
           & (IData)(wasmetal_core__DOT___023294_));
    wasmetal_core__DOT___128799___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036007_)
            ? (IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b53__05d));
    wasmetal_core__DOT___127504___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b42__05d) 
           & (IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128858___O = (
                                                   (7U 
                                                    & (- (IData)(
                                                                 (1U 
                                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___036292_)))))) 
                                                   ^ 
                                                   ((((~ (IData)(vlSelf->wasmetal_core__DOT___036292_)) 
                                                      & (IData)(wasmetal_core__DOT___128858___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128858___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128858___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036360_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128740___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035360_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035359_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035358_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035357_)))) 
           ^ (((IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035301_)))));
    wasmetal_core__DOT___035306_ = ((IData)(vlSelf->wasmetal_core__DOT___035360_)
                                     ? (IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b28__05d));
    wasmetal_core__DOT___128755___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128770___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035650_)
            ? (IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b38__05d));
    vlSelf->wasmetal_core__DOT___006124_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005705_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005704_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006199_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006078_))))));
    vlSelf->wasmetal_core__DOT___048266_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005777_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005776_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006080_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006079_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005704_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005703_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006078_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006077_)))))))))));
    wasmetal_core__DOT___127524___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023232_) 
           & (IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128799___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036008_)
            ? (IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b54__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127504___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b43__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b42__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b41__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b40__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023085_)))));
    wasmetal_core__DOT___023090_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b43__05d) 
                                    & (IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___051536_ = (1U & (1U >> ((0x10U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128857___O) 
                                                     << 3U)) 
                                                 | ((8U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128858___O) 
                                                        << 2U)) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128857___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128858___O) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___128857___O) 
                                                                >> 3U))))))));
    vlSelf->__VdfgTmp_h13456aa5__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hbc521204__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h57d4c6cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hd7693faf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128741___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035361_)
                  ? (IData)(wasmetal_core__DOT___035306_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128755___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035477_)))));
    vlSelf->wasmetal_core__DOT___035481_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128770___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035651_)
            ? (IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b39__05d));
    wasmetal_core__DOT___127524___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023233_) 
           & (IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___035953_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036009_)
                                           ? (IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___036009_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128799___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036009_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036008_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036007_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036006_)))) 
           ^ (((IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035949_)))));
    wasmetal_core__DOT___127505___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b44__05d) 
           & (IData)(wasmetal_core__DOT___023090_));
    vlSelf->wasmetal_core__DOT___051539_ = (1U & (IData)(
                                                         (0xf0f0f0f0ffffff22ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128858___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051535_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(__VdfgTmp_hb9cb0b08__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(wasmetal_core__DOT___051536_)))))))));
    wasmetal_core__DOT___043032_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___051536_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128858___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___128741___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035362_)
                  ? (IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0))));
    vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035481_));
    vlSelf->wasmetal_core__DOT____Vcellout___128770___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035652_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035651_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035650_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035649_)))) 
           ^ (((IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035593_)))));
    vlSelf->wasmetal_core__DOT___035597_ = ((IData)(vlSelf->wasmetal_core__DOT___035652_)
                                             ? (IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b40__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127524___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023234_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023233_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023232_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023231_)))) 
           ^ (((IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023294_)))));
    vlSelf->wasmetal_core__DOT___023298_ = ((IData)(vlSelf->wasmetal_core__DOT___023234_) 
                                            & (IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___053557_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128799___O) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128798___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___127505___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b45__05d) 
           & (IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ecommon_totalUnderflow 
        = (1U & ((IData)(wasmetal_core__DOT___043032_)
                  ? ((IData)(wasmetal_core__DOT___043031_)
                      ? ((~ (IData)(vlSelf->wasmetal_core__DOT___043030_)) 
                         & (IData)(vlSelf->wasmetal_core__DOT___043027_))
                      : (IData)(wasmetal_core__DOT___043028_))
                  : ((IData)(wasmetal_core__DOT____Vcellout___128858___O) 
                     >> 2U)));
    wasmetal_core__DOT___128741___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035363_)
                  ? (IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0))));
    vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035654_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035597_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b41__05d));
    vlSelf->wasmetal_core__DOT___005846_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127524___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005875_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2a096466__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2a096466__0))))));
    vlSelf->wasmetal_core__DOT___005702_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127524___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005745_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2a29372f__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2a29372f__0))))));
    vlSelf->wasmetal_core__DOT___005701_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127524___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005738_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2bad41f9__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2bad41f9__0))))));
    vlSelf->wasmetal_core__DOT___127525___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023236_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023298_));
    vlSelf->wasmetal_core__DOT___042826_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053557_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(wasmetal_core__DOT___035953_))))));
    wasmetal_core__DOT___042814_ = (1U & (1U >> ((2U 
                                                  & ((~ (IData)(wasmetal_core__DOT___035953_)) 
                                                     << 1U)) 
                                                 | (IData)(wasmetal_core__DOT___053557_))));
    wasmetal_core__DOT___127505___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b46__05d) 
           & (IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___017780_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ecommon_totalUnderflow) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051535_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128741___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035364_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035363_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035362_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035361_)))) 
           ^ (((IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035306_)))));
    vlSelf->wasmetal_core__DOT___035310_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035364_)
                                                   ? (IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0))));
    vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
               >> 1U)) & (IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035655_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b42__05d));
    vlSelf->wasmetal_core__DOT___006392_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006397_)) 
                                                  & (IData)(
                                                            (0x3fafULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___005845_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005846_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127533___O) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h5b56c921__0)))))))));
    vlSelf->wasmetal_core__DOT___006407_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006397_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005913_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005846_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___023187_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127529___O))))))));
    vlSelf->wasmetal_core__DOT___048159_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005850_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005849_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005848_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005847_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005846_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005845_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005844_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005843_)))))))))));
    wasmetal_core__DOT___127525___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023237_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127525___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit 
        = ((IData)(vlSelf->wasmetal_core__DOT___042826_) 
           | (IData)(wasmetal_core__DOT___042814_));
    vlSelf->wasmetal_core__DOT____Vcellout___127505___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b47__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b46__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b45__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b44__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023090_)))));
    vlSelf->wasmetal_core__DOT___023094_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b47__05d) 
                                            & (IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___017785_ = (1U & (0x80888888U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128853___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017780_)))))));
    vlSelf->wasmetal_core__DOT___036825_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051539_))))));
    vlSelf->wasmetal_core__DOT___017480_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018504_))));
    vlSelf->wasmetal_core__DOT___017806_ = (1U & (0x700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051539_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(wasmetal_core__DOT____Vcellout___128857___O)))))));
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d 
        = (1U & (0xf8ffU >> (((IData)(vlSelf->wasmetal_core__DOT___051539_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                         >> 3U)))))));
    vlSelf->__VdfgTmp_hd215401d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h03fdecb9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h2549a40a__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hd6af8d62__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128742___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035365_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035310_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b33__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128756___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035481_)))));
    vlSelf->wasmetal_core__DOT___035485_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                >> 2U)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128758___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035656_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b43__05d));
    wasmetal_core__DOT____Vcellout___127525___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023239_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023238_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023237_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023236_)))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___023238_) 
                                                      & (IData)(wasmetal_core__DOT___127525___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127525___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127525___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023298_)))));
    vlSelf->wasmetal_core__DOT___020525_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048948_)))));
    vlSelf->wasmetal_core__DOT___019814_ = (1U & (IData)(
                                                         (0xf000f000ffff8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b53__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he775e720__0))))))));
    vlSelf->wasmetal_core__DOT___040107_ = (1U & (0x7520ff00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b55__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase)))))));
    __VdfgTmp_h77ea5fdf__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase));
    vlSelf->wasmetal_core__DOT___060410_ = (1U & (0xb00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xf0f0335500000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058354_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127505___O) 
                                                                                >> 3U))))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xc0aU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058505_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128872___O) 
                                                                            >> 3U))))))))))));
    vlSelf->wasmetal_core__DOT___060366_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058351_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127505___O))))))))));
    vlSelf->wasmetal_core__DOT___060381_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058352_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127505___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b48__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___023094_));
    wasmetal_core__DOT___017508_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128848___O)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017488_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013204_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128848___O) 
                                                           >> 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017522_ = (1U & (0x8888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128848___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    vlSelf->wasmetal_core__DOT___017537_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9110e1f3__0))))));
    vlSelf->wasmetal_core__DOT___017551_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3d32f603__0))))));
    vlSelf->wasmetal_core__DOT___017564_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9ce496ce__0))))));
    wasmetal_core__DOT___017594_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    vlSelf->wasmetal_core__DOT___017579_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8c0ae79e__0))))));
    vlSelf->wasmetal_core__DOT___017666_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7594c868__0))))));
    vlSelf->wasmetal_core__DOT___017679_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb3fd333a__0))))));
    wasmetal_core__DOT___017694_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    vlSelf->wasmetal_core__DOT___017704_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h692ab415__0))))));
    vlSelf->wasmetal_core__DOT___017613_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2f0f6f72__0))))));
    vlSelf->wasmetal_core__DOT___017626_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf223abb4__0))))));
    wasmetal_core__DOT___017655_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017719_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017716_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128852___O)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017643_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128852___O) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    vlSelf->wasmetal_core__DOT___017731_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h917221d1__0))))));
    wasmetal_core__DOT___017745_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128852___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017759_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017756_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128853___O) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017797_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017794_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128853___O)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    if (vlSelf->wasmetal_core__DOT___017485_) {
        if (vlSelf->wasmetal_core__DOT___017484_) {
            vlSelf->wasmetal_core__DOT___059057_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hd5a7b943__0))))));
            vlSelf->wasmetal_core__DOT___058947_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h60102cdd__0))))));
            vlSelf->wasmetal_core__DOT___058941_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (1U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___015777_)))))));
            vlSelf->wasmetal_core__DOT___058952_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h0bc68a5e__0))))));
            vlSelf->wasmetal_core__DOT___059006_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h77210e87__0))))));
            vlSelf->wasmetal_core__DOT___059036_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h25476d0e__0))))));
            vlSelf->wasmetal_core__DOT___059001_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_haf20b36b__0))))));
            vlSelf->wasmetal_core__DOT___059049_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h513c757b__0))))));
            vlSelf->wasmetal_core__DOT___059060_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h310e5162__0))))));
        } else {
            vlSelf->wasmetal_core__DOT___059057_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___017785_));
            vlSelf->wasmetal_core__DOT___058947_ = 
                (1U & (IData)(wasmetal_core__DOT___017508_));
            vlSelf->wasmetal_core__DOT___058941_ = 
                (1U & (IData)(wasmetal_core__DOT___017488_));
            vlSelf->wasmetal_core__DOT___058952_ = 
                (1U & (IData)(wasmetal_core__DOT___017522_));
            vlSelf->wasmetal_core__DOT___059006_ = 
                (1U & (IData)(wasmetal_core__DOT___017655_));
            vlSelf->wasmetal_core__DOT___059036_ = 
                (1U & (IData)(wasmetal_core__DOT___017719_));
            vlSelf->wasmetal_core__DOT___059001_ = 
                (1U & (IData)(wasmetal_core__DOT___017643_));
            vlSelf->wasmetal_core__DOT___059049_ = 
                (1U & (IData)(wasmetal_core__DOT___017759_));
            vlSelf->wasmetal_core__DOT___059060_ = 
                (1U & (IData)(wasmetal_core__DOT___017797_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___059057_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___017785_));
        vlSelf->wasmetal_core__DOT___058947_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017508_));
        vlSelf->wasmetal_core__DOT___058941_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017488_));
        vlSelf->wasmetal_core__DOT___058952_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017522_));
        vlSelf->wasmetal_core__DOT___059006_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017655_));
        vlSelf->wasmetal_core__DOT___059036_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017719_));
        vlSelf->wasmetal_core__DOT___059001_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017643_));
        vlSelf->wasmetal_core__DOT___059049_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017759_));
        vlSelf->wasmetal_core__DOT___059060_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017797_));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___134163___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036825_) 
                        << 2U) | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                             >> 1U)) 
                                         << 1U)) | 
                                  (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O)))))) 
           ^ ((8U & (((~ (IData)(vlSelf->wasmetal_core__DOT___036825_)) 
                      | (IData)(vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__1__KET__)) 
                     << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___036819_)))));
    wasmetal_core__DOT___059246_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017806_))));
    vlSelf->__VdfgTmp_hd43f4c44__0 = (((IData)(vlSelf->wasmetal_core__DOT___017806_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x7f0000U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___058937_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051539_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                                                                  << 1U) 
                                                                 | (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                                       >> 2U))))))))));
    wasmetal_core__DOT___128742___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035366_)
                  ? (IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hf30cf57d__0))));
    vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035485_));
    vlSelf->wasmetal_core__DOT____Vcellout___128758___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035657_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035656_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035655_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035654_)))) 
           ^ (((IData)(wasmetal_core__DOT___128758___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035597_)))));
    vlSelf->wasmetal_core__DOT___035602_ = ((IData)(vlSelf->wasmetal_core__DOT___035657_)
                                             ? (IData)(wasmetal_core__DOT___128758___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b44__05d));
    wasmetal_core__DOT___005911_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127525___O) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___005935_)
                                              ? (IData)(
                                                        (0x2aa00000202ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcdf58d3d__0)))
                                              : (IData)(
                                                        (0xfffffeaafffffefeULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcdf58d3d__0))))));
    vlSelf->wasmetal_core__DOT___005910_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127525___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005928_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hcf2773b3__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hcf2773b3__0))))));
    wasmetal_core__DOT___005700_ = (IData)((((IData)(wasmetal_core__DOT____Vcellout___127525___O) 
                                             >> 3U) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___005731_)
                                                ? (IData)(
                                                          (0x2aa00000202ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcf316312__0)))
                                                : (IData)(
                                                          (0xfffffeaafffffefeULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcf316312__0))))));
    vlSelf->wasmetal_core__DOT___040078_ = (1U & (IData)(
                                                         (0xffaa5500ffe0ffe0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b54__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071561_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h77ea5fdf__0))))))));
    __VdfgTmp_h25b244b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                               << 2U) | (IData)(__VdfgTmp_h77ea5fdf__0));
    vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b49__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___017591_) {
        if (vlSelf->wasmetal_core__DOT___017590_) {
            vlSelf->wasmetal_core__DOT___058984_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h46466860__0))))));
            vlSelf->wasmetal_core__DOT___059023_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h219534f4__0))))));
            vlSelf->wasmetal_core__DOT___059045_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hafd7ea26__0))))));
        } else {
            vlSelf->wasmetal_core__DOT___058984_ = 
                (1U & (IData)(wasmetal_core__DOT___017594_));
            vlSelf->wasmetal_core__DOT___059023_ = 
                (1U & (IData)(wasmetal_core__DOT___017694_));
            vlSelf->wasmetal_core__DOT___059045_ = 
                (1U & (IData)(wasmetal_core__DOT___017745_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___058984_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017594_));
        vlSelf->wasmetal_core__DOT___059023_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017694_));
        vlSelf->wasmetal_core__DOT___059045_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017745_));
    }
    vlSelf->wasmetal_core__DOT___060018_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059246_))));
    vlSelf->wasmetal_core__DOT___059248_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                       << 2U)) 
                                                   | (((IData)(wasmetal_core__DOT___059246_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___036825_)))));
    vlSelf->wasmetal_core__DOT___017495_ = (1U & (IData)(
                                                         (0xb000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)))))));
    wasmetal_core__DOT___128742___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035367_)
                  ? (IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h9cb72e5a__0))));
    vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035658_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035602_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b45__05d));
    __VdfgTmp_h102458ff__0 = (((IData)(wasmetal_core__DOT___005911_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127523___O) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___005982_)
                                                   ? (IData)(
                                                             (0x2aa00000202ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h41461f4e__0)))
                                                   : (IData)(
                                                             (0xfffffeaafffffefeULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h41461f4e__0)))))));
    __VdfgTmp_he3e5ec17__0 = (((IData)(vlSelf->wasmetal_core__DOT___005910_) 
                               << 1U) | (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127524___O) 
                                                >> 2U) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___005921_)
                                                   ? (IData)(
                                                             (0x2aa00000202ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h38639508__0)))
                                                   : (IData)(
                                                             (0xfffffeaafffffefeULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h38639508__0)))))));
    vlSelf->wasmetal_core__DOT___006125_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005850_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005849_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005701_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___005700_))))));
    vlSelf->__VdfgTmp_h2af4e7f7__0 = (((IData)(wasmetal_core__DOT___005700_) 
                                       << 1U) | (1U 
                                                 & (((IData)(wasmetal_core__DOT____Vcellout___127525___O) 
                                                     >> 1U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005716_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc8e63fc4__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc8e63fc4__0)))))));
    vlSelf->wasmetal_core__DOT___040072_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070574_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040064_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058083_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039409_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071476_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040085_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b4__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071481_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040041_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071485_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040042_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b6__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071489_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040083_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071495_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040043_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b9__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071498_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040044_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b10__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071501_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039760_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b11__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071504_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040045_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b12__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071507_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040046_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b13__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071510_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040109_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b14__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071513_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040048_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b16__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071518_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040049_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b17__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071520_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039741_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b18__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071523_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040075_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071525_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040051_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071527_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040052_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b21__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he775e720__0)) 
                                                          << 3U)) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039714_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b22__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071531_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040106_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071533_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039872_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b24__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071534_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040081_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b25__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071535_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039658_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b26__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071536_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040082_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b27__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071537_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040057_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b28__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071538_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040058_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b29__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071539_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039647_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b30__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071540_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040054_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071542_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040060_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071543_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040061_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071544_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039631_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071545_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040062_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071546_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040063_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071547_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039596_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071548_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039590_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071549_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040086_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b41__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071550_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040065_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071551_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039408_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071552_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040066_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071553_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040070_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071554_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040105_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071555_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040068_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071556_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040069_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b49__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071557_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039563_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b50__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071558_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040071_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b51__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071559_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040067_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071560_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->__VdfgTmp_hcfa19df1__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                       << 3U) | (IData)(__VdfgTmp_h25b244b0__0));
    vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b50__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___059344_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058947_))));
    vlSelf->wasmetal_core__DOT___059586_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058984_))));
    vlSelf->wasmetal_core__DOT___059683_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___059023_))));
    vlSelf->wasmetal_core__DOT___059611_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017579_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5bb2fc7d__0)))))));
    vlSelf->wasmetal_core__DOT___059636_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017666_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8d1d0ffb__0)))))));
    vlSelf->wasmetal_core__DOT___059708_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017704_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_haf11557d__0)))))));
    vlSelf->wasmetal_core__DOT___059735_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017613_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_heb003047__0)))))));
    vlSelf->wasmetal_core__DOT___059760_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017626_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h43b37fbe__0)))))));
    vlSelf->wasmetal_core__DOT___059876_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017731_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128852___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h69609ee5__0)))))));
    vlSelf->wasmetal_core__DOT___018304_ = (1U & (IData)(
                                                         (0xb00ff00ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017537_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1e507ca5__0)))))))))));
    vlSelf->wasmetal_core__DOT___018401_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017564_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h71876852__0)))))));
    vlSelf->wasmetal_core__DOT___059658_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017679_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6171bc25__0)))))));
    vlSelf->wasmetal_core__DOT___018344_ = (1U & (IData)(
                                                         (0xb00ff00ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017551_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6bcf76cf__0)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128742___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035368_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035367_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035366_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035365_)))) 
           ^ (((IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035310_)))));
    vlSelf->wasmetal_core__DOT___035314_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035368_)
                                                   ? (IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0))));
    vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
               >> 1U)) & (IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035659_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b46__05d));
    vlSelf->wasmetal_core__DOT___006408_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005914_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006037_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h102458ff__0)))));
    vlSelf->__VdfgTmp_h35bc9263__0 = (((IData)(vlSelf->wasmetal_core__DOT___005975_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005912_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h102458ff__0)));
    vlSelf->wasmetal_core__DOT___048160_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005916_)) 
                                                  & ((~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                           ? (IData)(
                                                                     (0xf3f0f2e0f3faaaaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf5f6fc6e__0)))))))
                                                           : 
                                                          (0x302U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf5f6fc6e__0))))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005914_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005913_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005912_) 
                                                                        << 3U) 
                                                                       | (((IData)(wasmetal_core__DOT___005911_) 
                                                                           << 2U) 
                                                                          | (IData)(__VdfgTmp_he3e5ec17__0))))))))));
    vlSelf->__VdfgTmp_hfdd5af20__0 = (((IData)(vlSelf->wasmetal_core__DOT___006132_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006008_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he3e5ec17__0)));
}
