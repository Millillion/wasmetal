#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__8(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__8\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___026143_;
    wasmetal_core__DOT___026143_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026239_;
    wasmetal_core__DOT___026239_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027654_;
    wasmetal_core__DOT___027654_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027719_;
    wasmetal_core__DOT___027719_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027880_;
    wasmetal_core__DOT___027880_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___028009_;
    wasmetal_core__DOT___028009_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029199_;
    wasmetal_core__DOT___029199_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029300_;
    wasmetal_core__DOT___029300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029360_;
    wasmetal_core__DOT___029360_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029662_;
    wasmetal_core__DOT___029662_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029722_;
    wasmetal_core__DOT___029722_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029831_;
    wasmetal_core__DOT___029831_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029891_;
    wasmetal_core__DOT___029891_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030000_;
    wasmetal_core__DOT___030000_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030362_;
    wasmetal_core__DOT___030362_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030574_;
    wasmetal_core__DOT___030574_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030725_;
    wasmetal_core__DOT___030725_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031108_;
    wasmetal_core__DOT___031108_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031112_;
    wasmetal_core__DOT___031112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031396_;
    wasmetal_core__DOT___031396_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031400_;
    wasmetal_core__DOT___031400_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031601_;
    wasmetal_core__DOT___031601_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031683_;
    wasmetal_core__DOT___031683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031883_;
    wasmetal_core__DOT___031883_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032082_;
    wasmetal_core__DOT___032082_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032172_;
    wasmetal_core__DOT___032172_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032419_;
    wasmetal_core__DOT___032419_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032423_;
    wasmetal_core__DOT___032423_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032619_;
    wasmetal_core__DOT___032619_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032776_;
    wasmetal_core__DOT___032776_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032809_;
    wasmetal_core__DOT___032809_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032810_;
    wasmetal_core__DOT___032810_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032811_;
    wasmetal_core__DOT___032811_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032812_;
    wasmetal_core__DOT___032812_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032940_;
    wasmetal_core__DOT___032940_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032973_;
    wasmetal_core__DOT___032973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032978_;
    wasmetal_core__DOT___032978_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033112_;
    wasmetal_core__DOT___033112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033206_;
    wasmetal_core__DOT___033206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033918_;
    wasmetal_core__DOT___033918_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033978_;
    wasmetal_core__DOT___033978_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034706_;
    wasmetal_core__DOT___034706_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034902_;
    wasmetal_core__DOT___034902_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035030_;
    wasmetal_core__DOT___035030_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053577_;
    wasmetal_core__DOT___053577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063146_;
    wasmetal_core__DOT___063146_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063152_;
    wasmetal_core__DOT___063152_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063158_;
    wasmetal_core__DOT___063158_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063164_;
    wasmetal_core__DOT___063164_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063170_;
    wasmetal_core__DOT___063170_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063176_;
    wasmetal_core__DOT___063176_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063182_;
    wasmetal_core__DOT___063182_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063188_;
    wasmetal_core__DOT___063188_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063458_;
    wasmetal_core__DOT___063458_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063490_;
    wasmetal_core__DOT___063490_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063498_;
    wasmetal_core__DOT___063498_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063506_;
    wasmetal_core__DOT___063506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063514_;
    wasmetal_core__DOT___063514_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063583_;
    wasmetal_core__DOT___063583_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063591_;
    wasmetal_core__DOT___063591_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063599_;
    wasmetal_core__DOT___063599_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063607_;
    wasmetal_core__DOT___063607_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064263_;
    wasmetal_core__DOT___064263_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070648_;
    wasmetal_core__DOT___070648_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128200___O;
    wasmetal_core__DOT____Vcellout___128200___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128201___O;
    wasmetal_core__DOT____Vcellout___128201___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128362___O;
    wasmetal_core__DOT____Vcellout___128362___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128363___O;
    wasmetal_core__DOT____Vcellout___128363___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128410___O;
    wasmetal_core__DOT____Vcellout___128410___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128430___O;
    wasmetal_core__DOT____Vcellout___128430___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128450___O;
    wasmetal_core__DOT____Vcellout___128450___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128451___O;
    wasmetal_core__DOT____Vcellout___128451___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellinp___128519___S;
    wasmetal_core__DOT____Vcellinp___128519___S = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellinp___128520___S;
    wasmetal_core__DOT____Vcellinp___128520___S = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128538___O;
    wasmetal_core__DOT____Vcellout___128538___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128539___O;
    wasmetal_core__DOT____Vcellout___128539___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128714___O;
    wasmetal_core__DOT____Vcellout___128714___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128715___O;
    wasmetal_core__DOT____Vcellout___128715___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127830___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127830___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127830___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127830___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127831___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127831___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127831___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127831___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127831___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127831___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127838___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127838___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127838___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127838___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127839___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127839___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127839___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127839___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127839___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127839___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127999___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127999___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127999___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127999___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127999___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127999___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128000___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128000___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128000___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128000___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128000___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128000___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128023___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128023___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128023___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128023___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128023___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128023___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128024___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128024___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128024___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128024___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128024___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128024___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128031___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128031___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128032___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128032___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128032___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128032___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128032___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128032___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128039___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128039___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128039___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128039___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128039___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128039___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128040___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128040___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128040___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128040___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128040___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128040___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128055___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128055___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128056___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128056___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128056___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128056___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128056___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128056___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128151___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128151___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128152___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128152___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128152___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128152___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128152___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128152___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128160___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128160___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128160___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128160___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128160___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128160___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128161___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128161___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128161___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128161___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128161___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128161___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128167___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128167___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128168___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128168___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128168___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128168___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128168___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128168___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128193___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128193___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128193___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128193___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128193___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128193___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128194___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128194___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128194___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128194___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128194___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128194___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128200___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128200___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128201___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128201___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128201___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128201___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128201___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128201___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128210___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128210___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128210___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128210___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128210___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128210___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128211___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128211___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128211___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128211___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128211___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128211___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128217___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128217___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128218___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128218___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128218___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128218___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128218___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128218___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128227___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128227___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128227___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128227___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128227___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128227___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128228___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128228___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128228___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128228___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128228___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128228___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128271___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128271___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128272___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128272___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128272___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128272___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128272___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128272___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128279___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128279___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128279___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128279___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128279___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128279___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128280___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128280___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128280___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128280___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128280___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128280___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128306___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128306___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128306___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128306___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128306___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128306___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128307___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128307___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128307___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128307___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128307___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128307___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128319___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128319___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128320___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128320___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128320___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128320___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128320___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128320___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128339___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128339___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128339___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128339___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128339___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128339___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128340___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128340___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128340___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128340___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128340___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128340___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128363___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128363___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128363___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128363___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128363___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128363___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128364___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128364___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128364___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128364___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128364___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128364___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128375___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128375___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128375___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128375___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128375___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128375___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128376___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128376___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128376___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128376___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128376___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128376___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128386___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128386___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128386___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128386___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128386___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128386___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128387___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128387___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128387___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128387___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128387___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128387___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128430___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128430___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128430___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128430___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128431___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128431___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128431___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128431___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128431___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128431___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128451___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128451___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128451___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128451___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128451___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128451___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128452___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128452___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128452___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128452___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128452___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128452___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128477___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128477___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128478___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128478___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128478___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128478___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128478___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128478___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128503___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128503___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128503___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128503___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128503___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128503___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128504___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128504___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128504___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128504___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128504___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128504___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128681___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128681___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128681___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128681___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128681___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128681___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128682___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128682___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128682___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128682___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128682___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128682___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128698___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128698___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128698___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128698___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128698___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128698___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128699___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128699___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128699___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128699___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128699___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128699___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128714___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128714___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128714___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128714___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128715___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128715___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128715___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128715___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128715___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128715___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134212___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134212___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134213___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134213___DOT__CO__BRA__2__KET__ = 0;
    CData/*2:0*/ __VdfgTmp_h98c6c754__0;
    __VdfgTmp_h98c6c754__0 = 0;
    // Body
    wasmetal_core__DOT___128430___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032202_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128430___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___070645_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070643_)))))))));
    vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032682_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037192_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h0dd4dc97__0))));
    wasmetal_core__DOT___128681___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034639_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034702_));
    wasmetal_core__DOT___128714___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035092_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128714___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d));
    wasmetal_core__DOT___128698___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034898_));
    wasmetal_core__DOT___127838___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026269_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127838___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b17__05d));
    wasmetal_core__DOT___127830___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026173_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127830___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d));
    vlSelf->wasmetal_core__DOT___054504_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054503_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xbU)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054506_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054505_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xcU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054508_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054507_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xdU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___063552_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063560_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063559_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063568_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063567_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063576_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063575_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___054502_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xaU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026365_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d));
    wasmetal_core__DOT___128477___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032807_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128502___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032969_)))));
    wasmetal_core__DOT___032973_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128306___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030849_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030784_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b8__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128338___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031167_)))));
    wasmetal_core__DOT___031108_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b11__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b11__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128362___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___031455_)))));
    wasmetal_core__DOT___031396_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128450___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___032483_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___032482_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032544_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032543_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032478_)))));
    wasmetal_core__DOT___032419_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032483_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032483_))));
    wasmetal_core__DOT___128386___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031807_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031742_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128580___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b16__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b19__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128398___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031879_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b19__05d) {
        wasmetal_core__DOT___031883_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
        wasmetal_core__DOT___033918_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
        wasmetal_core__DOT___032940_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
    } else {
        wasmetal_core__DOT___031883_ = vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___033918_ = vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___032940_ = vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031964_));
    vlSelf->wasmetal_core__DOT____Vcellout___128462___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032615_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b20__05d) {
        wasmetal_core__DOT___032619_ = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
        wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
        wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
        wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
    } else {
        wasmetal_core__DOT___032619_ = vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___031883_;
        wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___033918_;
        wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___032940_;
    }
    vlSelf->wasmetal_core__DOT___056534_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                               << 5U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_h0812d53d__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128181___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029608_)))));
    vlSelf->wasmetal_core__DOT___029612_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128284___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030683_)))));
    vlSelf->wasmetal_core__DOT___050459_ = (1U & (IData)(
                                                         (0xff00ffff07000707ULL 
                                                          >> 
                                                          (((IData)(vlSelf->reset) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050445_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048115_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050443_)))))))));
    vlSelf->wasmetal_core__DOT___051225_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051219_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0))))));
    vlSelf->wasmetal_core__DOT___053366_ = (1U & (IData)(
                                                         (0x40ff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052655_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053261_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053260_)))))))));
    vlSelf->wasmetal_core__DOT___052658_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052656_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052655_))));
    vlSelf->wasmetal_core__DOT___053088_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052660_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053087_))));
    vlSelf->wasmetal_core__DOT___052684_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052660_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050363_)))));
    vlSelf->wasmetal_core__DOT___052679_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth_ready) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052660_))));
    vlSelf->wasmetal_core__DOT___051205_ = (1U & (0xccca0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051201_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051200_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051199_)))))));
    vlSelf->wasmetal_core__DOT___051226_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051202_))));
    vlSelf->wasmetal_core__DOT___051239_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050441_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051204_))));
    vlSelf->wasmetal_core__DOT___050365_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050363_))));
    vlSelf->wasmetal_core__DOT___050380_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050364_))));
    vlSelf->wasmetal_core__DOT___071787_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid 
        = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048133_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048134_))));
    vlSelf->wasmetal_core__DOT___005670_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048134_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048949_))));
    vlSelf->__VdfgTmp_hf36d9f62__0 = (((IData)(vlSelf->wasmetal_core__DOT___048134_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048133_));
    wasmetal_core__DOT____Vcellout___128410___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032034_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032033_)))) 
                                                   ^ 
                                                   (1U 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__0__KET__) 
                                                             << 1U)))));
    vlSelf->wasmetal_core__DOT___032026_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036761_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h291433ac__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128348___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031332_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031331_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031361_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031360_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031327_)))));
    vlSelf->wasmetal_core__DOT___031300_ = ((IData)(vlSelf->wasmetal_core__DOT___031332_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128597___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033914_)))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))) {
        wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 3U));
        wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 3U));
        wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 3U));
    } else {
        wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128519___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128527___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128604___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128494___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032936_)))));
    vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 0x14U) & (IData)(vlSelf->wasmetal_core__DOT___027939_));
    vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x100000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x14U)
                  : (IData)(vlSelf->wasmetal_core__DOT___030474_)));
    wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027714_));
    wasmetal_core__DOT___128039___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___028004_));
    wasmetal_core__DOT___128160___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029295_));
    wasmetal_core__DOT___128193___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029657_));
    wasmetal_core__DOT___128210___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029826_));
    wasmetal_core__DOT___128375___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031596_));
    wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032077_));
    vlSelf->wasmetal_core__DOT___039847_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xeU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039846_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xfU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039845_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x10U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039844_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x11U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d)))))));
    wasmetal_core__DOT___128279___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030569_));
    vlSelf->wasmetal_core__DOT___039817_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039813_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039811_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039803_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d)))))))));
    wasmetal_core__DOT___128227___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029995_));
    wasmetal_core__DOT___128217___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029923_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d));
    wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032875_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    wasmetal_core__DOT___127999___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128956___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027649_));
    wasmetal_core__DOT___128200___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029754_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d));
    wasmetal_core__DOT___128167___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029391_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b18__05d));
    wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027810_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b18__05d));
    vlSelf->wasmetal_core__DOT___062805_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062816_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062827_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062838_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 0x14U) & (IData)(vlSelf->wasmetal_core__DOT___028165_));
    wasmetal_core__DOT___128151___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029230_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d));
    wasmetal_core__DOT___128023___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027875_));
    vlSelf->wasmetal_core__DOT___044764_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 0xcU)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                                        >> 1U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 0x12U)))))))));
    vlSelf->wasmetal_core__DOT___044776_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 0xfU)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 0x10U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 0x11U))))))))));
    vlSelf->wasmetal_core__DOT___044763_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 9U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 0xfU)))))))));
    vlSelf->wasmetal_core__DOT___044775_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 0xcU)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 0xdU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 0xeU))))))))));
    vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 0x14U)) & (IData)(vlSelf->wasmetal_core__DOT___030956_));
    wasmetal_core__DOT___128430___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032203_)
            ? (IData)(wasmetal_core__DOT___128430___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d));
    vlSelf->wasmetal_core__DOT___044808_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070645_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___044796_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070643_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032683_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    wasmetal_core__DOT___134212___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037193_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h148285ae__0))));
    wasmetal_core__DOT___128681___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034640_) 
           & (IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128714___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035093_)
            ? (IData)(wasmetal_core__DOT___128714___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d));
    wasmetal_core__DOT___128698___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d)) 
           & (IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127838___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026270_)
            ? (IData)(wasmetal_core__DOT___127838___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b18__05d));
    wasmetal_core__DOT___127830___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026174_)
            ? (IData)(wasmetal_core__DOT___127830___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128518___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128526___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128603___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026366_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b18__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128477___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032808_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032807_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032806_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032805_)))) 
           ^ (((IData)(wasmetal_core__DOT___128477___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032772_)))));
    wasmetal_core__DOT___032776_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032808_)
                                           ? (IData)(wasmetal_core__DOT___128477___DOT__CO__BRA__2__KET__)
                                           : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                              >> 3U)));
    wasmetal_core__DOT___032812_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b19__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___032811_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b18__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___032810_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b17__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___032809_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b16__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O)))));
    wasmetal_core__DOT___128503___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d)
            : (IData)(wasmetal_core__DOT___032973_));
    wasmetal_core__DOT___128306___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030850_)
            ? (IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b9__05d));
    wasmetal_core__DOT___128339___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b12__05d)
            : (IData)(wasmetal_core__DOT___031108_));
    wasmetal_core__DOT___128363___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d)
            : (IData)(wasmetal_core__DOT___031396_));
    wasmetal_core__DOT___063146_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128450___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063152_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128450___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063158_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128450___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063164_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128450___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___128451___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032484_)
                  ? (IData)(wasmetal_core__DOT___032419_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032484_))));
    wasmetal_core__DOT___128386___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031808_)
            ? (IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128589___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b20__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b19__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b18__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b17__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b20__05d)) 
           & (IData)(wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b9__05d) {
        vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
        vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___030656_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___030691_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___031937_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b21__05d) {
        wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
    } else {
        wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___032619_;
        wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b22__05d) {
        wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
    } else {
        wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030357_;
        wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___011156_ = (1U & (IData)(
                                                         (0xffff800000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056534_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                                                << 4U)) 
                                                                                | (0xfU 
                                                                                & ((0xcU 
                                                                                & ((~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                                                >> 1U))) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & (~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                                                >> 1U)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (3U 
                                                                             & (~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056530_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0812d53d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___063524_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___063532_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___063540_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___063548_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029612_));
    if (vlSelf->wasmetal_core__DOT__sp__05b12__05d) {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030656_;
        vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030691_;
        vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031937_;
    }
    vlSelf->wasmetal_core__DOT___053097_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053088_))));
    vlSelf->wasmetal_core__DOT___052863_ = (1U & (IData)(
                                                         (0xb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052861_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052684_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052860_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___045941_)))))))));
    vlSelf->wasmetal_core__DOT___051230_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051226_))));
    vlSelf->wasmetal_core__DOT___052657_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051226_))));
    vlSelf->wasmetal_core__DOT___053576_ = (1U & (IData)(
                                                         (0x40400000ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c1295c2__0))))))));
    vlSelf->wasmetal_core__DOT___000130_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->reset)))));
    vlSelf->wasmetal_core__DOT___053098_ = (1U & (0xfbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053094_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053093_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h44c20413__0))))));
    vlSelf->wasmetal_core__DOT___053621_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053434_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___051228_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___053359_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053263_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___053493_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050389_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)))))));
    vlSelf->wasmetal_core__DOT___053494_ = (1U & (0x2fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053091_))))));
    vlSelf->wasmetal_core__DOT___050382_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050380_))));
    vlSelf->wasmetal_core__DOT___020524_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid))));
    vlSelf->wasmetal_core__DOT___040092_ = (1U & (0xfb080808U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128793___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid))));
    vlSelf->wasmetal_core__DOT___014875_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015196_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058620_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058648_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058645_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058641_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058611_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015441_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___014689_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015140_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015025_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015166_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015102_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015078_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015109_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___014931_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___014714_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___019773_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048949_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))))));
    vlSelf->wasmetal_core__DOT___019023_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))))));
    vlSelf->wasmetal_core__DOT___006127_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))));
    vlSelf->wasmetal_core__DOT___063466_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128410___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063474_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128410___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063482_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128410___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063455_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128410___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032026_));
    vlSelf->wasmetal_core__DOT___036730_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036762_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6d2d9567__0))));
    vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031333_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031300_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    wasmetal_core__DOT____Vcellinp___128519___S = (
                                                   (8U 
                                                    & ((~ 
                                                        ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                         >> 1U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((~ 
                                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                               >> 3U)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                >> 2U))))));
    vlSelf->wasmetal_core__DOT___062784_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O))))))))));
    vlSelf->wasmetal_core__DOT___062795_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062806_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062817_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                             >> 3U))))))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))) {
        wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O));
        wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O));
        wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O));
    } else {
        wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 0x15U) & (IData)(vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x200000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x15U)
                  : (IData)(vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128039___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128160___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128193___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128210___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128375___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b21__05d)
            : (IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b21__05d)
            : (IData)(wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128279___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d)
            : (IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128227___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128217___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029924_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029923_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029922_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029921_)))) 
           ^ (((IData)(wasmetal_core__DOT___128217___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029887_)))));
    wasmetal_core__DOT___029891_ = ((IData)(vlSelf->wasmetal_core__DOT___029924_)
                                     ? (IData)(wasmetal_core__DOT___128217___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128486___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032876_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032875_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032874_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032873_)))) 
           ^ (((IData)(wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032840_)))));
    vlSelf->wasmetal_core__DOT___032844_ = ((IData)(vlSelf->wasmetal_core__DOT___032876_)
                                             ? (IData)(wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    wasmetal_core__DOT___127999___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128957___Q) 
           & (IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128200___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029755_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029754_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029753_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029752_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128200___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029718_)))));
    wasmetal_core__DOT___029722_ = ((IData)(vlSelf->wasmetal_core__DOT___029755_)
                                     ? (IData)(wasmetal_core__DOT___128200___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128167___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029392_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029391_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029390_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029389_)))) 
           ^ (((IData)(wasmetal_core__DOT___128167___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029356_)))));
    wasmetal_core__DOT___029360_ = ((IData)(vlSelf->wasmetal_core__DOT___029392_)
                                     ? (IData)(wasmetal_core__DOT___128167___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128014___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027811_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027810_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027809_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027808_)))) 
           ^ (((IData)(wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027775_)))));
    vlSelf->wasmetal_core__DOT___027779_ = ((IData)(vlSelf->wasmetal_core__DOT___027811_)
                                             ? (IData)(wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b19__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b23__05d) {
        wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___031888_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___033923_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___032945_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
    } else {
        wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___031888_ = wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033923_ = wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032945_ = wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 0x15U) & (IData)(vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128151___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029231_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029230_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029229_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029228_)))) 
           ^ (((IData)(wasmetal_core__DOT___128151___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029195_)))));
    wasmetal_core__DOT___029199_ = ((IData)(vlSelf->wasmetal_core__DOT___029231_)
                                     ? (IData)(wasmetal_core__DOT___128151___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d));
    wasmetal_core__DOT___128023___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 0x15U)) & (IData)(vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128430___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___032204_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___032203_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032202_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032201_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128430___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128430___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128430___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032168_)))));
    wasmetal_core__DOT___032172_ = ((IData)(vlSelf->wasmetal_core__DOT___032204_)
                                     ? (IData)(wasmetal_core__DOT___128430___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128470___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032684_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032683_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032682_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032681_)))) 
           ^ (((IData)(wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032648_)))));
    vlSelf->wasmetal_core__DOT___032652_ = ((IData)(vlSelf->wasmetal_core__DOT___032684_)
                                             ? (IData)(wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134212___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037194_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037193_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037192_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037191_)))) 
           ^ (((IData)(wasmetal_core__DOT___134212___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037159_)))));
    vlSelf->wasmetal_core__DOT___037163_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037194_)
                                                   ? (IData)(wasmetal_core__DOT___134212___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1274aae9__0))));
    wasmetal_core__DOT___128681___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034641_) 
           & (IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128714___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035094_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035093_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035092_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035091_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128714___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128714___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128714___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035026_)))));
    wasmetal_core__DOT___035030_ = ((IData)(vlSelf->wasmetal_core__DOT___035094_)
                                     ? (IData)(wasmetal_core__DOT___128714___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d));
    wasmetal_core__DOT___128698___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d)) 
           & (IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127838___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026271_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026270_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026269_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026268_)))) 
           ^ (((IData)(wasmetal_core__DOT___127838___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127838___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127838___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026235_)))));
    wasmetal_core__DOT___026239_ = ((IData)(vlSelf->wasmetal_core__DOT___026271_)
                                     ? (IData)(wasmetal_core__DOT___127838___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127830___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026175_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026174_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026173_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026172_)))) 
           ^ (((IData)(wasmetal_core__DOT___127830___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127830___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127830___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026139_)))));
    wasmetal_core__DOT___026143_ = ((IData)(vlSelf->wasmetal_core__DOT___026175_)
                                     ? (IData)(wasmetal_core__DOT___127830___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b3__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b2__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b1__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127846___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026367_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026366_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026365_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026364_)))) 
           ^ (((IData)(wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026331_)))));
    vlSelf->wasmetal_core__DOT___026335_ = ((IData)(vlSelf->wasmetal_core__DOT___026367_)
                                             ? (IData)(wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d));
    wasmetal_core__DOT___128478___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___032809_)
                  ? (IData)(wasmetal_core__DOT___032776_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O)));
    wasmetal_core__DOT___128503___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d)
            : (IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128306___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030788_)
            ? (IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b10__05d));
    wasmetal_core__DOT___128339___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b13__05d)
            : (IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128363___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d)
            : (IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063148_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063146_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063145_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128215___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128362___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063154_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063152_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063151_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128215___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128362___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063160_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063157_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128215___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___128362___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063166_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063164_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063163_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128215___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128362___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    wasmetal_core__DOT___128451___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032485_)
                  ? (IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032485_))));
    wasmetal_core__DOT___128386___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031746_)
            ? (IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d));
    wasmetal_core__DOT____Vcellout___128538___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b21__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b20__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b19__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b18__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b21__05d)) 
           & (IData)(wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128172___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
           ^ (((IData)(wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029502_)))));
    vlSelf->wasmetal_core__DOT___029506_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128292___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030718_)))));
    vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b13__05d) {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___053431_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051230_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053345_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048483_))))));
    vlSelf->wasmetal_core__DOT___053570_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xe0c0c0cU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052864_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                                   << 2U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h4b91004e__0))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052657_))));
    vlSelf->wasmetal_core__DOT___052688_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052657_))));
    vlSelf->wasmetal_core__DOT___039855_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053260_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053576_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))));
    wasmetal_core__DOT___053577_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___053576_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052658_))));
    vlSelf->wasmetal_core__DOT___053504_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053493_))));
    vlSelf->wasmetal_core__DOT___017494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide))));
    vlSelf->wasmetal_core__DOT___063467_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063466_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063465_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063475_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063474_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063473_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063483_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063482_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063481_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    wasmetal_core__DOT___063458_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (vlSelf->cmd_index 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0xf38f2779U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___009510_)))))))));
    vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036763_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036730_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h959d8796__0))));
    vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031334_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT___062785_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062784_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062783_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062796_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062795_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062794_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062807_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062806_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062805_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062818_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062817_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062816_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128519___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128519___S) 
           ^ (((IData)(wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128519___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033108_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))) {
        wasmetal_core__DOT___033112_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                              >> 1U));
        wasmetal_core__DOT___033206_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                              >> 1U));
        wasmetal_core__DOT___033978_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                              >> 1U));
    } else {
        wasmetal_core__DOT___033112_ = (1U & (IData)(wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__));
        wasmetal_core__DOT___033206_ = (1U & (IData)(wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__));
        wasmetal_core__DOT___033978_ = (1U & (IData)(wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128527___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128519___S) 
           ^ (((IData)(wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128527___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033202_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128604___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128519___S) 
           ^ (((IData)(wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128604___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033974_)))));
    wasmetal_core__DOT___128031___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 0x16U) & (IData)(vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128271___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x400000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x16U)
                  : (IData)(vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128039___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128160___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128193___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128210___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128375___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b22__05d)
            : (IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b22__05d)
            : (IData)(wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128279___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d)
            : (IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128227___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128218___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029926_)
            ? (IData)(wasmetal_core__DOT___029891_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d));
    vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032878_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032844_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    wasmetal_core__DOT___127999___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128958___Q) 
           & (IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063193_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128200___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063199_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128200___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063205_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128200___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063211_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128200___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    wasmetal_core__DOT___128201___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029757_)
            ? (IData)(wasmetal_core__DOT___029722_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d));
    wasmetal_core__DOT___128168___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029394_)
            ? (IData)(wasmetal_core__DOT___029360_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b20__05d));
    vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027813_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027779_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b20__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b24__05d) {
        wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___032624_ = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
    } else {
        wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___032624_ = wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031888_;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033923_;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032945_;
    }
    wasmetal_core__DOT___128055___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 0x16U) & (IData)(vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___044576_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___128152___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029233_)
            ? (IData)(wasmetal_core__DOT___029199_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d));
    wasmetal_core__DOT___128023___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128319___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 0x16U)) & (IData)(vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045542_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b18__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128430___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128430___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128430___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045541_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b15__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (IData)(wasmetal_core__DOT____Vcellout___128430___O))))))))));
    vlSelf->wasmetal_core__DOT___045554_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b17__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128430___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b18__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___128430___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b19__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128430___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045553_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b14__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b15__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b16__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(wasmetal_core__DOT____Vcellout___128430___O))))))))));
    wasmetal_core__DOT___128431___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032206_)
            ? (IData)(wasmetal_core__DOT___032172_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d));
    vlSelf->wasmetal_core__DOT___070649_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b18__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032686_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032652_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    wasmetal_core__DOT___070648_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070646_)))))))));
    vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037196_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037163_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h0817f177__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128681___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034642_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034641_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034640_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034639_)))) 
           ^ (((IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034702_)))));
    wasmetal_core__DOT___034706_ = ((IData)(vlSelf->wasmetal_core__DOT___034642_) 
                                    & (IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034646_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128714___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d)))));
    vlSelf->wasmetal_core__DOT___034645_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128714___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d)))));
    vlSelf->wasmetal_core__DOT___034644_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128714___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d)))));
    vlSelf->wasmetal_core__DOT___034643_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128714___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d)))));
    wasmetal_core__DOT___128715___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035096_)
            ? (IData)(wasmetal_core__DOT___035030_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128698___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034898_)))));
    wasmetal_core__DOT___034902_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d)) 
                                    & (IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127839___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026273_)
            ? (IData)(wasmetal_core__DOT___026239_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b20__05d));
    vlSelf->wasmetal_core__DOT___044596_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___127831___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026177_)
            ? (IData)(wasmetal_core__DOT___026143_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d));
    vlSelf->wasmetal_core__DOT___054509_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054511_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054513_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054515_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    wasmetal_core__DOT___063583_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063591_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063599_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063607_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___044380_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026369_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026335_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d));
    wasmetal_core__DOT___128478___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___032810_)
                  ? (IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                     >> 1U)));
    wasmetal_core__DOT___128503___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d)
            : (IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128306___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030789_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030788_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030850_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030849_)))) 
           ^ (((IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030784_)))));
    wasmetal_core__DOT___030725_ = ((IData)(vlSelf->wasmetal_core__DOT___030789_)
                                     ? (IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b11__05d));
    wasmetal_core__DOT___128339___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b14__05d)
            : (IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128363___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d)
            : (IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128451___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032486_)
                  ? (IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032486_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128386___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031747_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031746_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031808_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031807_)))) 
           ^ (((IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031742_)))));
    wasmetal_core__DOT___031683_ = ((IData)(vlSelf->wasmetal_core__DOT___031747_)
                                     ? (IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128572___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b22__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b21__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b20__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b19__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b22__05d)) 
           & (IData)(wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128404___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031964_)))));
    vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029506_));
    vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b14__05d) {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___019775_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053577_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053475_))));
    vlSelf->wasmetal_core__DOT___039856_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___053577_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039854_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___053577_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039857_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___053577_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___063462_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063458_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063457_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036764_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hb0a19382__0))));
    vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031335_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    vlSelf->wasmetal_core__DOT___062793_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x10U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062785_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O))))))));
    vlSelf->wasmetal_core__DOT___062804_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x11U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062796_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062815_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x12U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062807_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062826_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x13U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062818_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                  >> 3U))))))));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))) {
        wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 2U));
        wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 2U));
        wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 2U));
    } else {
        wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___033112_));
        wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___033206_));
        wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___033978_));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128031___O 
        = (0xfU & ((vlSelf->insn_z >> 0x14U) ^ (((IData)(wasmetal_core__DOT___128031___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___027939_))))));
    vlSelf->wasmetal_core__DOT___027944_ = ((vlSelf->insn_z 
                                             >> 0x17U) 
                                            & (IData)(wasmetal_core__DOT___128031___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128271___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0x17U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0x16U)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 0x15U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128271___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030474_)))));
    vlSelf->wasmetal_core__DOT___030479_ = (1U & ((0x800000U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 0x17U)
                                                   : (IData)(wasmetal_core__DOT___128271___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128007___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128423___DI) 
           ^ (((IData)(wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027714_)))));
    wasmetal_core__DOT___027719_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128039___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128431___DI) 
           ^ (((IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028004_)))));
    wasmetal_core__DOT___028009_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128160___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029295_)))));
    wasmetal_core__DOT___029300_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128193___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029657_)))));
    wasmetal_core__DOT___029662_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128210___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029826_)))));
    wasmetal_core__DOT___029831_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128375___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031596_)))));
    wasmetal_core__DOT___031601_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b23__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b23__05d)
                                     : (IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128423___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032077_)))));
    wasmetal_core__DOT___032082_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b23__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b23__05d)
                                     : (IData)(wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128279___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030569_)))));
    wasmetal_core__DOT___030574_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d)
                                     : (IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128227___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029995_)))));
    wasmetal_core__DOT___030000_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128218___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029927_)
            ? (IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d));
    vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032879_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127999___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128959___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128958___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128957___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128956___Q)))) 
           ^ (((IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027649_)))));
    wasmetal_core__DOT___027654_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128959___Q) 
                                    & (IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128201___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029758_)
            ? (IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d));
    wasmetal_core__DOT___128168___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029395_)
            ? (IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b21__05d));
    vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027814_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128260___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030357_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b25__05d) {
        wasmetal_core__DOT___030362_ = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
    } else {
        wasmetal_core__DOT___030362_ = wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032624_;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128055___O 
        = (0xfU & ((vlSelf->insn_x >> 0x14U) ^ (((IData)(wasmetal_core__DOT___128055___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028165_))))));
    vlSelf->wasmetal_core__DOT___028170_ = ((vlSelf->insn_x 
                                             >> 0x17U) 
                                            & (IData)(wasmetal_core__DOT___128055___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128152___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029234_)
            ? (IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128023___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___DI) 
           ^ (((IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027875_)))));
    wasmetal_core__DOT___027880_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128319___O 
        = (((8U & ((~ (vlSelf->function_params >> 0x17U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0x16U)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->function_params 
                                                      >> 0x15U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 0x14U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128319___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030956_)))));
    vlSelf->wasmetal_core__DOT___030961_ = ((~ (vlSelf->function_params 
                                                >> 0x17U)) 
                                            & (IData)(wasmetal_core__DOT___128319___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128431___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032207_)
            ? (IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___070651_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070649_)))))))));
    vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032687_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___044809_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070648_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___044797_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070648_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070646_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037197_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h092cd911__0))));
    wasmetal_core__DOT___128682___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034643_) 
           & (IData)(wasmetal_core__DOT___034706_));
    wasmetal_core__DOT___128715___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035097_)
            ? (IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d));
    wasmetal_core__DOT___128699___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d)) 
           & (IData)(wasmetal_core__DOT___034902_));
    wasmetal_core__DOT___127839___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026274_)
            ? (IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b21__05d));
    wasmetal_core__DOT___127831___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026178_)
            ? (IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d));
    vlSelf->wasmetal_core__DOT___054510_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054509_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xeU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054512_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054511_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xfU)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054514_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054513_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x10U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054516_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054515_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x11U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___063584_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063583_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063592_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063591_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063600_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063599_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063608_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026370_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b21__05d));
    wasmetal_core__DOT___128478___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___032811_)
                  ? (IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128503___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032973_)))));
    wasmetal_core__DOT___032978_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d)
                                     : (IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128307___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030790_)
            ? (IData)(wasmetal_core__DOT___030725_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b12__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128339___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031108_)))));
    wasmetal_core__DOT___031112_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b15__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b15__05d)
                                     : (IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128363___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___031396_)))));
    wasmetal_core__DOT___031400_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d)
                                     : (IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128451___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___032487_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___032486_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032485_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032484_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___032419_)))));
    wasmetal_core__DOT___032423_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032487_)
                                           ? (IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032487_))));
    wasmetal_core__DOT___128387___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031748_)
            ? (IData)(wasmetal_core__DOT___031683_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128581___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b23__05d)) 
           & (IData)(wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128399___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031883_)))));
    vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128463___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032619_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128182___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029612_)))));
    vlSelf->wasmetal_core__DOT___029585_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128285___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030656_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b15__05d) {
        vlSelf->wasmetal_core__DOT___030660_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___030695_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___031941_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030660_ = vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030695_ = wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031941_ = wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128411___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032026_)))));
    vlSelf->wasmetal_core__DOT___032030_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032030_));
    vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036765_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hfd696a08__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128349___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031336_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031335_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031334_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031333_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031300_)))));
    vlSelf->wasmetal_core__DOT___031304_ = ((IData)(vlSelf->wasmetal_core__DOT___031336_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128598___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033918_)))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))) {
        wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 3U));
        wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 3U));
        wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 3U));
    } else {
        wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128495___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032940_)))));
    wasmetal_core__DOT___128032___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 0x18U) & (IData)(vlSelf->wasmetal_core__DOT___027944_));
    wasmetal_core__DOT___128272___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x1000000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x18U)
                  : (IData)(vlSelf->wasmetal_core__DOT___030479_)));
    wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b24__05d) 
           & (IData)(wasmetal_core__DOT___027719_));
    wasmetal_core__DOT___128040___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d) 
           & (IData)(wasmetal_core__DOT___028009_));
    wasmetal_core__DOT___128161___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d) 
           & (IData)(wasmetal_core__DOT___029300_));
    wasmetal_core__DOT___128194___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b24__05d) 
           & (IData)(wasmetal_core__DOT___029662_));
    wasmetal_core__DOT___128211___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d) 
           & (IData)(wasmetal_core__DOT___029831_));
    wasmetal_core__DOT___128376___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b24__05d)
            : (IData)(wasmetal_core__DOT___031601_));
    wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b24__05d)
            : (IData)(wasmetal_core__DOT___032082_));
    vlSelf->wasmetal_core__DOT___039829_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x12U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039838_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x13U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039824_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x14U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039842_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x15U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d)))))));
    wasmetal_core__DOT___128280___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)
            : (IData)(wasmetal_core__DOT___030574_));
    vlSelf->wasmetal_core__DOT___039810_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039809_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039812_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039808_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d)))))))));
    wasmetal_core__DOT___128228___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d) 
           & (IData)(wasmetal_core__DOT___030000_));
    wasmetal_core__DOT___128218___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029928_)
            ? (IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d));
    wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032880_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    wasmetal_core__DOT___128000___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128960___Q) 
           & (IData)(wasmetal_core__DOT___027654_));
    wasmetal_core__DOT___128201___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029759_)
            ? (IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d));
    wasmetal_core__DOT___128168___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029396_)
            ? (IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b22__05d));
    wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027815_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b22__05d));
    vlSelf->wasmetal_core__DOT___062849_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062860_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062871_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062882_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    if (vlSelf->wasmetal_core__DOT__sp__05b26__05d) {
        wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
    } else {
        wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___030362_;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128056___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 0x18U) & (IData)(vlSelf->wasmetal_core__DOT___028170_));
    wasmetal_core__DOT___128152___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029235_)
            ? (IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d));
    wasmetal_core__DOT___128024___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d) 
           & (IData)(wasmetal_core__DOT___027880_));
    vlSelf->wasmetal_core__DOT___044765_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 0xfU)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 0x15U)))))))));
    vlSelf->wasmetal_core__DOT___044777_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 0x12U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 0x14U))))))))));
    wasmetal_core__DOT___128320___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 0x18U)) & (IData)(vlSelf->wasmetal_core__DOT___030961_));
    wasmetal_core__DOT___128431___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032208_)
            ? (IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d));
    vlSelf->wasmetal_core__DOT___044810_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070651_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___044798_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070651_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070649_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                                             >> 1U))))))))));
    wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032688_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    wasmetal_core__DOT___134213___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037198_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hbc3091a9__0))));
    wasmetal_core__DOT___128682___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034644_) 
           & (IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128715___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035098_)
            ? (IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d));
    wasmetal_core__DOT___128699___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d)) 
           & (IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127839___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026275_)
            ? (IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b22__05d));
    wasmetal_core__DOT___127831___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026179_)
            ? (IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d));
    wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026371_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128478___O 
        = ((((IData)(wasmetal_core__DOT___032812_) 
             << 3U) | (((IData)(wasmetal_core__DOT___032811_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___032810_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___032809_)))) 
           ^ (((IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032776_)))));
    vlSelf->wasmetal_core__DOT___032780_ = (1U & ((IData)(wasmetal_core__DOT___032812_)
                                                   ? (IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___032817_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032816_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032815_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b21__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032814_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O)))));
    wasmetal_core__DOT___128504___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d)
            : (IData)(wasmetal_core__DOT___032978_));
    wasmetal_core__DOT___128307___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030791_)
            ? (IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b13__05d));
    wasmetal_core__DOT___128340___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b16__05d)
            : (IData)(wasmetal_core__DOT___031112_));
    wasmetal_core__DOT___128364___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d)
            : (IData)(wasmetal_core__DOT___031400_));
    wasmetal_core__DOT___063170_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128451___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063176_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128451___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063182_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128451___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063188_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128451___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___128452___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032488_)
                  ? (IData)(wasmetal_core__DOT___032423_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032488_))));
    wasmetal_core__DOT___128387___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031749_)
            ? (IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128590___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b24__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b23__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b22__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b21__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b24__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063556_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___063564_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___063572_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___063580_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029585_));
    if (vlSelf->wasmetal_core__DOT__sp__05b16__05d) {
        vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030660_;
        vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030695_;
    }
    wasmetal_core__DOT___063490_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063498_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063506_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063514_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT____Vcellout___134155___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036766_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036765_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036764_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036763_)))) 
           ^ (((IData)(wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036730_)))));
    vlSelf->wasmetal_core__DOT___036734_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036766_)
                                                   ? (IData)(wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9473bd37__0))));
    vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031337_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031304_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    wasmetal_core__DOT____Vcellinp___128520___S = (
                                                   (8U 
                                                    & ((~ 
                                                        ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                         >> 1U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((~ 
                                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                               >> 3U)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                >> 2U))))));
    vlSelf->wasmetal_core__DOT___062828_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O))))))))));
    vlSelf->wasmetal_core__DOT___062839_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062850_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062861_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                             >> 3U))))))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))) {
        wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O));
        wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O));
        wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O));
    } else {
        wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__));
    }
    wasmetal_core__DOT___128032___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 0x19U) & (IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128272___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x2000000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x19U)
                  : (IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128040___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128161___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128194___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128211___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128376___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b25__05d)
            : (IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b25__05d)
            : (IData)(wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128280___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d)
            : (IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128228___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128218___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029929_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029928_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029927_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029926_)))) 
           ^ (((IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029891_)))));
    vlSelf->wasmetal_core__DOT___029896_ = ((IData)(vlSelf->wasmetal_core__DOT___029929_)
                                             ? (IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128487___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032881_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032880_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032879_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032878_)))) 
           ^ (((IData)(wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032844_)))));
    vlSelf->wasmetal_core__DOT___032849_ = ((IData)(vlSelf->wasmetal_core__DOT___032881_)
                                             ? (IData)(wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    wasmetal_core__DOT___128000___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128961___Q) 
           & (IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128201___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029760_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029759_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029758_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029757_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___029722_)))));
    vlSelf->wasmetal_core__DOT___029727_ = ((IData)(vlSelf->wasmetal_core__DOT___029760_)
                                             ? (IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128168___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029397_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029396_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029395_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029394_)))) 
           ^ (((IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029360_)))));
    vlSelf->wasmetal_core__DOT___029365_ = ((IData)(vlSelf->wasmetal_core__DOT___029397_)
                                             ? (IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128015___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027816_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027815_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027814_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027813_)))) 
           ^ (((IData)(wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027779_)))));
    vlSelf->wasmetal_core__DOT___027784_ = ((IData)(vlSelf->wasmetal_core__DOT___027816_)
                                             ? (IData)(wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b23__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b27__05d) {
        wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
    } else {
        wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128056___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 0x19U) & (IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128152___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029236_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029235_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029234_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029233_)))) 
           ^ (((IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029199_)))));
    vlSelf->wasmetal_core__DOT___029204_ = ((IData)(vlSelf->wasmetal_core__DOT___029236_)
                                             ? (IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d));
    wasmetal_core__DOT___128024___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128320___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 0x19U)) & (IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128431___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032209_) 
             << 3U) | (IData)(vlSelf->__VdfgTmp_hcd6b7a1f__0)) 
           ^ (((IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032172_)))));
    vlSelf->wasmetal_core__DOT___032177_ = ((IData)(vlSelf->wasmetal_core__DOT___032209_)
                                             ? (IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128471___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032689_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032688_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032687_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032686_)))) 
           ^ (((IData)(wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032652_)))));
    vlSelf->wasmetal_core__DOT___032657_ = ((IData)(vlSelf->wasmetal_core__DOT___032689_)
                                             ? (IData)(wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134213___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037199_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037198_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037197_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037196_)))) 
           ^ (((IData)(wasmetal_core__DOT___134213___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037163_)))));
    vlSelf->wasmetal_core__DOT___037168_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037199_)
                                                   ? (IData)(wasmetal_core__DOT___134213___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5a255a66__0))));
    wasmetal_core__DOT___128682___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034645_) 
           & (IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128715___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035099_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035098_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035097_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035096_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035030_)))));
    vlSelf->wasmetal_core__DOT___035035_ = ((IData)(vlSelf->wasmetal_core__DOT___035099_)
                                             ? (IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d));
    wasmetal_core__DOT___128699___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d)) 
           & (IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127839___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026276_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026275_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026274_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026273_)))) 
           ^ (((IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026239_)))));
    vlSelf->wasmetal_core__DOT___026244_ = ((IData)(vlSelf->wasmetal_core__DOT___026276_)
                                             ? (IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127831___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026180_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026179_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026178_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026177_)))) 
           ^ (((IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026143_)))));
    vlSelf->wasmetal_core__DOT___026148_ = ((IData)(vlSelf->wasmetal_core__DOT___026180_)
                                             ? (IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127847___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026372_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026371_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026370_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026369_)))) 
           ^ (((IData)(wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026335_)))));
    vlSelf->wasmetal_core__DOT___026340_ = ((IData)(vlSelf->wasmetal_core__DOT___026372_)
                                             ? (IData)(wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d));
    vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032814_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032780_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O)));
    wasmetal_core__DOT___128504___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d)
            : (IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128307___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030792_)
            ? (IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b14__05d));
    wasmetal_core__DOT___128340___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b17__05d)
            : (IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128364___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d)
            : (IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063172_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063169_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128216___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128363___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063178_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063176_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063175_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128216___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128363___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063184_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063181_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128216___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___128363___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063190_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063188_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063187_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128216___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128363___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    wasmetal_core__DOT___128452___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032489_)
                  ? (IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032489_))));
    wasmetal_core__DOT___128387___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031750_)
            ? (IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d));
    wasmetal_core__DOT____Vcellout___128539___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b25__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b24__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b23__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b22__05d)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b25__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128173___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
           ^ (((IData)(wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029506_)))));
    vlSelf->wasmetal_core__DOT___029479_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128293___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030691_)))));
    vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063491_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063490_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063489_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063499_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063497_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063507_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063506_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063505_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063515_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063514_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063513_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036768_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036734_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h1872cc15__0))));
    vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031338_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___062829_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062828_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062827_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062840_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062839_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062838_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062851_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062850_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062849_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062862_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062861_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062860_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128520___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128520___S) 
           ^ (((IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033112_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))) {
        vlSelf->wasmetal_core__DOT___033116_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033210_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033982_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033116_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033210_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033982_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128528___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128520___S) 
           ^ (((IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033206_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128605___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128520___S) 
           ^ (((IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033978_)))));
    wasmetal_core__DOT___128032___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 0x1aU) & (IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128272___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x4000000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x1aU)
                  : (IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128040___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128161___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128194___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128211___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128376___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b26__05d)
            : (IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b26__05d)
            : (IData)(wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128280___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d)
            : (IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128228___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029930_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029896_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d));
    vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032882_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032849_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    wasmetal_core__DOT___128000___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128962___Q) 
           & (IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128201___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063223_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128201___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063229_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128201___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063235_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128201___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___128202___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029761_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029727_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d));
    vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029398_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029365_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b24__05d));
    vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027817_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027784_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b24__05d));
    wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d)
            : (IData)(wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128056___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 0x1aU) & (IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029237_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029204_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d));
    wasmetal_core__DOT___128024___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128320___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 0x1aU)) & (IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045543_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b21__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b22__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___045555_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b22__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b20__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b21__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032210_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032177_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___070652_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b21__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032690_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032657_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037200_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037168_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h590821b5__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128682___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034646_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034645_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034644_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034643_)))) 
           ^ (((IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034706_)))));
    vlSelf->wasmetal_core__DOT___034710_ = ((IData)(vlSelf->wasmetal_core__DOT___034646_) 
                                            & (IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034651_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128715___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d)))));
    vlSelf->wasmetal_core__DOT___034650_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128715___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d)))));
    vlSelf->wasmetal_core__DOT___034649_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128715___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d)))));
    vlSelf->wasmetal_core__DOT___034648_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128715___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d)))));
    vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035100_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035035_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128699___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034902_)))));
    vlSelf->wasmetal_core__DOT___034907_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d)) 
                                            & (IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026277_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026244_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b24__05d));
    vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026181_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026148_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d));
    vlSelf->wasmetal_core__DOT___054517_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054519_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054521_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054523_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___063615_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063623_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063631_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063639_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026373_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026340_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b24__05d));
    vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032815_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                     >> 1U)));
    wasmetal_core__DOT___128504___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d)
            : (IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128307___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030793_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030792_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030791_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030790_)))) 
           ^ (((IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030725_)))));
    vlSelf->wasmetal_core__DOT___030729_ = ((IData)(vlSelf->wasmetal_core__DOT___030793_)
                                             ? (IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b15__05d));
    wasmetal_core__DOT___128340___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b18__05d)
            : (IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128364___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d)
            : (IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128452___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032490_)
                  ? (IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032490_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128387___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031751_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031750_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031749_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031748_)))) 
           ^ (((IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031683_)))));
    vlSelf->wasmetal_core__DOT___031687_ = ((IData)(vlSelf->wasmetal_core__DOT___031751_)
                                             ? (IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d));
    __VdfgTmp_h98c6c754__0 = ((4U & (IData)(wasmetal_core__DOT____Vcellout___128538___O)) 
                              | ((2U & ((IData)(wasmetal_core__DOT____Vcellout___128538___O) 
                                        >> 2U)) | (1U 
                                                   & (IData)(wasmetal_core__DOT____Vcellout___128539___O))));
    wasmetal_core__DOT___064263_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O) 
                                                       << 4U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O)) 
                                                         | ((4U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___128538___O) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___128538___O)) 
                                                               | (1U 
                                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128573___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b26__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b25__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b24__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b23__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b26__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128405___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031937_)))));
    vlSelf->wasmetal_core__DOT___128174___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029479_));
    vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036769_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hed077be7__0))));
    vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031339_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    vlSelf->wasmetal_core__DOT___062837_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x14U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062829_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O))))))));
    vlSelf->wasmetal_core__DOT___062848_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x15U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062840_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062859_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x16U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062851_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062870_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x17U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062862_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                  >> 3U))))))));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))) {
        vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033116_));
        vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033210_));
        vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033982_));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128032___O 
        = (0xfU & ((vlSelf->insn_z >> 0x18U) ^ (((IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___027944_))))));
    vlSelf->wasmetal_core__DOT___027948_ = ((vlSelf->insn_z 
                                             >> 0x1bU) 
                                            & (IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128272___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0x1bU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0x1aU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 0x19U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030479_)))));
    vlSelf->wasmetal_core__DOT___030483_ = (1U & ((0x8000000U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 0x1bU)
                                                   : (IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128008___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b26__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_ha5b552f8__0))) 
           ^ (((IData)(wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027719_)))));
    vlSelf->wasmetal_core__DOT___027723_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128040___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h17166267__0))) 
           ^ (((IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___028009_)))));
    vlSelf->wasmetal_core__DOT___028013_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128161___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_he45fe6bb__0))) 
           ^ (((IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029300_)))));
    vlSelf->wasmetal_core__DOT___029304_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128194___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b26__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b25__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b24__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029662_)))));
    vlSelf->wasmetal_core__DOT___029666_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128211___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029831_)))));
    vlSelf->wasmetal_core__DOT___029835_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128376___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031601_)))));
    vlSelf->wasmetal_core__DOT___031605_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128424___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032082_)))));
    vlSelf->wasmetal_core__DOT___032086_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128280___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030574_)))));
    vlSelf->wasmetal_core__DOT___030578_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128228___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030000_)))));
    vlSelf->wasmetal_core__DOT___030004_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029931_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d));
    vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032883_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128000___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128963___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128962___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128961___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128960___Q)))) 
           ^ (((IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027654_)))));
    vlSelf->wasmetal_core__DOT___027658_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128963___Q) 
                                            & (IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128202___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029762_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128202___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d));
    vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029399_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b25__05d));
    vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027818_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128261___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030362_)))));
    vlSelf->wasmetal_core__DOT___030366_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)
                                             : (IData)(wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128056___O 
        = (0xfU & ((vlSelf->insn_x >> 0x18U) ^ (((IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028170_))))));
    vlSelf->wasmetal_core__DOT___028174_ = ((vlSelf->insn_x 
                                             >> 0x1bU) 
                                            & (IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029238_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128024___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hd225b533__0))) 
           ^ (((IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027880_)))));
    vlSelf->wasmetal_core__DOT___027884_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128320___O 
        = (((8U & ((~ (vlSelf->function_params >> 0x1bU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0x1aU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->function_params 
                                                      >> 0x19U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 0x18U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030961_)))));
    vlSelf->wasmetal_core__DOT___030965_ = ((~ (vlSelf->function_params 
                                                >> 0x1bU)) 
                                            & (IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032211_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d));
    vlSelf->wasmetal_core__DOT___070654_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070652_)))))))));
    vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032691_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037201_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h137eceb9__0))));
    vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034648_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034710_));
    vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035101_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b24__05d));
    vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034907_));
    vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026278_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b25__05d));
    vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026182_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d));
    vlSelf->wasmetal_core__DOT___054518_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054517_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x12U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054520_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054522_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054521_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x14U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054524_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054523_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x15U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___063616_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063615_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063624_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063623_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063632_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063631_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063640_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063639_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026374_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d));
    vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032816_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT___032982_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128504___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032978_)))));
    vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030794_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030729_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b16__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128340___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031112_)))));
    vlSelf->wasmetal_core__DOT___031116_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128364___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031400_)))));
    vlSelf->wasmetal_core__DOT___031404_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128452___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032491_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032490_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032489_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032488_)))) 
           ^ (((IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032423_)))));
    vlSelf->wasmetal_core__DOT___032427_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032491_)
                                                   ? (IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___032491_))));
    vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031752_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031687_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d));
    vlSelf->wasmetal_core__DOT___064267_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f7fffffffff00ffULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O) 
                                                                     << 5U)) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(wasmetal_core__DOT___064263_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((8U 
                                                                               >> 
                                                                               ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O)) 
                                                                                | (1U 
                                                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128538___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128538___O) 
                                                                                >> 1U)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O) 
                                                                                >> 3U)))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5ffffffffffffff3ULL 
                                                                   >> 
                                                                   ((0x38U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128539___O) 
                                                                        << 2U)) 
                                                                    | ((4U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((1U 
                                                                               >> (IData)(__VdfgTmp_h98c6c754__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (0x80U 
                                                                                >> (IData)(__VdfgTmp_h98c6c754__0)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5ffffffffffffff3ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128535___O) 
                                                                         << 2U)) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128536___O) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128535___O) 
                                                                               << 2U)) 
                                                                           | ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128536___O) 
                                                                                << 1U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h015c016b__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h261f62de__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128535___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 4U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 2U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128535___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h015c016b__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h261f62de__0)))))))))))))))))))))));
}
