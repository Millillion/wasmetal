#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__13(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__13\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___044119_;
    wasmetal_core__DOT___044119_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048299_;
    wasmetal_core__DOT___048299_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048572_;
    wasmetal_core__DOT___048572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049444_;
    wasmetal_core__DOT___049444_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049584_;
    wasmetal_core__DOT___049584_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049591_;
    wasmetal_core__DOT___049591_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049596_;
    wasmetal_core__DOT___049596_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049678_;
    wasmetal_core__DOT___049678_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049727_;
    wasmetal_core__DOT___049727_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___042515_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035130_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035131_)))));
    vlSelf->wasmetal_core__DOT___042514_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035125_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035126_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035127_)))));
    vlSelf->wasmetal_core__DOT___042513_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035122_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035123_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035124_)))));
    vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128938___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___042512_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035119_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035120_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035121_)))));
    vlSelf->wasmetal_core__DOT___042511_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035115_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035116_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035118_)))));
    vlSelf->wasmetal_core__DOT___042510_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035112_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035113_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035114_)))));
    vlSelf->wasmetal_core__DOT___053343_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044142_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044148_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___044149_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___044145_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x40000000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___044150_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044144_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128343___DI)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128334___DI)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128330___DI)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053337_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b24__05d)))))))) 
                                                                             << 2U)) 
                                                                         | ((2U 
                                                                             & ((IData)(
                                                                                (0x100000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hba5a1633__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h347304aa__0))))))) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___044131_)))))))))))));
    vlSelf->wasmetal_core__DOT___044147_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hba5a1633__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128343___DI))))));
    vlSelf->wasmetal_core__DOT___042509_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035109_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035110_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035111_)))));
    vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___029914_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d));
    wasmetal_core__DOT___049678_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048539_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0))))));
    wasmetal_core__DOT___049444_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048295_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048539_))));
    vlSelf->wasmetal_core__DOT___048542_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048539_))));
    vlSelf->wasmetal_core__DOT___049914_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048539_))));
    wasmetal_core__DOT___049727_ = (1U & (8U >> ((2U 
                                                  & ((8U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    wasmetal_core__DOT___049596_ = (1U & (8U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf7906078__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0))))));
    wasmetal_core__DOT___049591_ = (1U & (8U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf7906078__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0))))));
    wasmetal_core__DOT___049584_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048295_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    wasmetal_core__DOT___048572_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048295_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    wasmetal_core__DOT___048299_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048295_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___048511_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___049942_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___049424_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___049421_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___050082_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___049611_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___048567_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048545_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0))))));
    vlSelf->wasmetal_core__DOT___049543_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048570_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048545_))));
    vlSelf->wasmetal_core__DOT___049390_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048545_))));
    vlSelf->wasmetal_core__DOT___048546_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048545_))));
    vlSelf->wasmetal_core__DOT___048541_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___049347_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0))))));
    vlSelf->wasmetal_core__DOT___049345_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0))))));
    vlSelf->wasmetal_core__DOT___049550_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048570_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048575_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048570_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048571_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048570_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048510_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___049392_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___049003_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048962_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048298_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048536_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048293_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___048288_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b22__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b11__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b10__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b9__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b8__05d)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048290_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048289_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b29__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b28__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b27__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b26__05d))))))))))));
    vlSelf->wasmetal_core__DOT___000248_ = ((IData)(vlSelf->wasmetal_core__DOT___043961_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___043960_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___043959_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___043964_)) 
                                                     & (~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d))))));
    vlSelf->wasmetal_core__DOT___027825_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b31__05d) 
                                                    << 1U) 
                                                   | (vlSelf->function_params 
                                                      >> 0x1fU))));
    vlSelf->wasmetal_core__DOT___026381_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b31__05d) 
                                                    << 1U) 
                                                   | (vlSelf->insn_x 
                                                      >> 0x1fU))));
    vlSelf->wasmetal_core__DOT___027824_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b30__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1eU)))));
    vlSelf->wasmetal_core__DOT___026380_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b30__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1eU)))));
    vlSelf->wasmetal_core__DOT___027822_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b29__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1dU)))));
    vlSelf->wasmetal_core__DOT___026378_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1dU)))));
    vlSelf->wasmetal_core__DOT___027821_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1cU)))));
    vlSelf->wasmetal_core__DOT___026377_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1cU)))));
    vlSelf->wasmetal_core__DOT___027820_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1bU)))));
    vlSelf->wasmetal_core__DOT___026376_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1bU)))));
    vlSelf->wasmetal_core__DOT___027819_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1aU)))));
    vlSelf->wasmetal_core__DOT___026375_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1aU)))));
    vlSelf->wasmetal_core__DOT___027818_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x19U)))));
    vlSelf->wasmetal_core__DOT___026374_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x19U)))));
    vlSelf->wasmetal_core__DOT___027817_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___026373_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___027816_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x17U)))));
    vlSelf->wasmetal_core__DOT___026372_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x17U)))));
    vlSelf->wasmetal_core__DOT___027815_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x16U)))));
    vlSelf->wasmetal_core__DOT___026371_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x16U)))));
    vlSelf->wasmetal_core__DOT___027814_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b21__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x15U)))));
    vlSelf->wasmetal_core__DOT___026370_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b21__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x15U)))));
    vlSelf->wasmetal_core__DOT___027813_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x14U)))));
    vlSelf->wasmetal_core__DOT___026369_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x14U)))));
    vlSelf->wasmetal_core__DOT___027811_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b19__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x13U)))));
    vlSelf->wasmetal_core__DOT___026367_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x13U)))));
    vlSelf->wasmetal_core__DOT___027810_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b18__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x12U)))));
    vlSelf->wasmetal_core__DOT___026366_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b18__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x12U)))));
    vlSelf->wasmetal_core__DOT___027809_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x11U)))));
    vlSelf->wasmetal_core__DOT___026365_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x11U)))));
    vlSelf->wasmetal_core__DOT___027808_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b16__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x10U)))));
    vlSelf->wasmetal_core__DOT___026364_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x10U)))));
    vlSelf->wasmetal_core__DOT___027807_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xfU)))));
    vlSelf->wasmetal_core__DOT___026363_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xfU)))));
    vlSelf->wasmetal_core__DOT___027806_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xeU)))));
    vlSelf->wasmetal_core__DOT___026362_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xeU)))));
    vlSelf->wasmetal_core__DOT___027805_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b13__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xdU)))));
    vlSelf->wasmetal_core__DOT___026361_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xdU)))));
    vlSelf->wasmetal_core__DOT___027804_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b12__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xcU)))));
    vlSelf->wasmetal_core__DOT___026360_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b12__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xcU)))));
    vlSelf->wasmetal_core__DOT___027803_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xbU)))));
    vlSelf->wasmetal_core__DOT___026359_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xbU)))));
    vlSelf->wasmetal_core__DOT___027802_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xaU)))));
    vlSelf->wasmetal_core__DOT___026358_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xaU)))));
    vlSelf->wasmetal_core__DOT___027832_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 9U)))));
    vlSelf->wasmetal_core__DOT___026388_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 9U)))));
    vlSelf->wasmetal_core__DOT___027831_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 8U)))));
    vlSelf->wasmetal_core__DOT___026387_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 8U)))));
    vlSelf->wasmetal_core__DOT___027830_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 7U)))));
    vlSelf->wasmetal_core__DOT___026386_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 7U)))));
    vlSelf->wasmetal_core__DOT___027829_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 6U)))));
    vlSelf->wasmetal_core__DOT___026385_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 6U)))));
    vlSelf->wasmetal_core__DOT___027828_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 5U)))));
    vlSelf->wasmetal_core__DOT___026384_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 5U)))));
    vlSelf->wasmetal_core__DOT___027827_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 4U)))));
    vlSelf->wasmetal_core__DOT___026383_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 4U)))));
    vlSelf->wasmetal_core__DOT___027826_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___026382_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___027823_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___026379_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___027812_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___026368_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT__call_kind__05b2__05d 
        = vlSelf->wasmetal_core__DOT___019772_;
    vlSelf->wasmetal_core__DOT___027801_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & vlSelf->function_params))));
    vlSelf->wasmetal_core__DOT__call_kind__05b1__05d 
        = vlSelf->wasmetal_core__DOT___019771_;
    vlSelf->wasmetal_core__DOT___026357_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & vlSelf->insn_x))));
    vlSelf->wasmetal_core__DOT___032218_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b31__05d))));
    vlSelf->wasmetal_core__DOT___032217_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d))));
    vlSelf->wasmetal_core__DOT___045569_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b31__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___032215_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d))));
    vlSelf->wasmetal_core__DOT___032214_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d))));
    vlSelf->wasmetal_core__DOT___032213_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d))));
    vlSelf->wasmetal_core__DOT___044274_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___045578_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___032212_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d))));
    vlSelf->wasmetal_core__DOT___032211_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d))));
    vlSelf->__VdfgTmp_h17166267__0 = (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___032210_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d))));
    vlSelf->wasmetal_core__DOT___032209_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d))));
    vlSelf->wasmetal_core__DOT___032208_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d))));
    vlSelf->wasmetal_core__DOT___032207_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128431___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d))));
    vlSelf->wasmetal_core__DOT___045576_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___032206_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d))));
    vlSelf->wasmetal_core__DOT___032204_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d))));
    vlSelf->wasmetal_core__DOT___032203_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d))));
    vlSelf->wasmetal_core__DOT___045575_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b17__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b19__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___032202_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d))));
    vlSelf->wasmetal_core__DOT___032201_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d))));
    vlSelf->wasmetal_core__DOT___032200_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d))));
    vlSelf->wasmetal_core__DOT___044272_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___045574_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___032199_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d))));
    vlSelf->wasmetal_core__DOT___032198_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d))));
    vlSelf->__VdfgTmp_he965b193__0 = (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___032197_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d))));
    vlSelf->wasmetal_core__DOT___032196_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d))));
    vlSelf->wasmetal_core__DOT___032195_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d))));
    vlSelf->wasmetal_core__DOT___032225_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d))));
    vlSelf->wasmetal_core__DOT___070607_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___045572_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___032224_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d))));
    vlSelf->wasmetal_core__DOT___032223_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d))));
    vlSelf->wasmetal_core__DOT___032222_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d))));
    vlSelf->wasmetal_core__DOT___045571_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b7__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___032221_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d))));
    vlSelf->wasmetal_core__DOT___032220_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d))));
    vlSelf->wasmetal_core__DOT___032219_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d))));
    vlSelf->wasmetal_core__DOT___045570_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___032216_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d))));
    vlSelf->__VdfgTmp_hbf5bedf6__0 = (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___032194_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d))));
    vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128720___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035215_ = ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128188___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029672_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128274___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030584_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___065587_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065585_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128002___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027729_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128418___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032092_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___044200_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044214_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044213_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044212_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044211_) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___044203_))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044212_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044213_)))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044214_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128370___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031611_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___052939_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x9000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052936_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052935_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052934_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((9U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b1__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x9009000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___052926_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___052925_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b21__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b17__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128222___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___030010_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029393_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b1__05d));
    vlSelf->wasmetal_core__DOT___045941_ = ((IData)(vlSelf->wasmetal_core__DOT___045964_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045973_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045972_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045971_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045970_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045969_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045968_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045967_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045966_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045965_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045963_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045951_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045953_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045954_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045955_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045956_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045957_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045958_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045959_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045960_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045961_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045952_));
    vlSelf->wasmetal_core__DOT___052676_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052024_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052023_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052022_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b23__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___065579_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064086_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b17__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___065562_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064086_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065561_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b19__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b18__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___064087_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064086_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___065557_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h49b76e08__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064091_))));
    vlSelf->wasmetal_core__DOT___066366_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b3__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b2__05d)))));
    vlSelf->__VdfgTmp_h92a0f8b0__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h49b76e08__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064091_));
    vlSelf->wasmetal_core__DOT___065554_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064095_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065553_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128205___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029841_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128155___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029310_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029232_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d));
    vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026176_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d));
    vlSelf->__VdfgTmp_h078a1663__0 = ((2U & ((8U >> 
                                              (3U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                >> 2U))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_haf6246da__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                      | (1U & (8U >> 
                                               (3U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                   >> 2U)))));
    vlSelf->wasmetal_core__DOT___066351_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))));
    vlSelf->wasmetal_core__DOT___064200_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b3__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT__simd_integer__02erunning 
        = ((1U & (~ (IData)(vlSelf->reset))) && (1U 
                                                 & (0xeU 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hd461afd0__0)) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___052730_)))));
    if (vlSelf->wasmetal_core__DOT___019810_) {
        vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d = 0U;
    } else if ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_hd461afd0__0)))) {
        vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128814___O));
    }
    vlSelf->wasmetal_core__DOT___053330_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053312_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053311_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b79__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_y 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b78__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0xeU))))))))));
    vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__1__KET__ 
        = ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hff2c11ba__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b0__05d));
    vlSelf->wasmetal_core__DOT___053303_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___053301_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b26__05d))));
    vlSelf->wasmetal_core__DOT___053300_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b24__05d))));
    vlSelf->wasmetal_core__DOT___052991_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02etrap__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02etrap__05b0__05d))));
    vlSelf->wasmetal_core__DOT___063361_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__bulk_table))));
    vlSelf->wasmetal_core__DOT___063360_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__bulk_table))));
    vlSelf->wasmetal_core__DOT___063357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__bulk_table))));
    vlSelf->wasmetal_core__DOT___053293_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b25__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b23__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b22__05d))))))))))));
    vlSelf->wasmetal_core__DOT___053290_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b20__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b16__05d))))))))))));
    vlSelf->wasmetal_core__DOT___053299_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127994___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128939___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128938___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128937___Q) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128936___Q)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128936___Q) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027664_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128939___Q) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053296_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b4__05d))));
    wasmetal_core__DOT___044119_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044142_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044151_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044150_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044149_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044148_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044147_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044146_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044145_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044144_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044143_) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044131_))
                                                         : 
                                                        (~ (IData)(vlSelf->wasmetal_core__DOT___044144_)))
                                                        : 
                                                       (~ (IData)(vlSelf->wasmetal_core__DOT___044145_)))
                                                       : 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___044146_)))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___044147_)))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044148_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044149_)))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044150_)))
                                               : (~ (IData)(vlSelf->wasmetal_core__DOT___044151_)))
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___044142_))));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d 
        = ((IData)(vlSelf->wasmetal_core__DOT___042520_)
            ? ((IData)(vlSelf->wasmetal_core__DOT___042519_)
                ? ((IData)(vlSelf->wasmetal_core__DOT___042517_)
                    ? ((IData)(vlSelf->wasmetal_core__DOT___042516_)
                        ? ((IData)(vlSelf->wasmetal_core__DOT___042515_)
                            ? ((IData)(vlSelf->wasmetal_core__DOT___042514_)
                                ? ((IData)(vlSelf->wasmetal_core__DOT___042513_)
                                    ? ((IData)(vlSelf->wasmetal_core__DOT___042512_)
                                        ? ((IData)(vlSelf->wasmetal_core__DOT___042511_)
                                            ? ((IData)(vlSelf->wasmetal_core__DOT___042510_)
                                                ? ((IData)(vlSelf->wasmetal_core__DOT___042509_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042508_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___042528_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___042527_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___042526_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___042525_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___042524_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___042523_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___042522_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___042521_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___042518_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___042507_) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___042483_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___042494_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___042497_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___042498_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___042499_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___042500_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042501_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___042502_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___042503_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___042504_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___042484_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___042485_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___042486_))
                                            : (IData)(vlSelf->wasmetal_core__DOT___042487_))
                                        : (IData)(vlSelf->wasmetal_core__DOT___042488_))
                                    : (IData)(vlSelf->wasmetal_core__DOT___042489_))
                                : (IData)(vlSelf->wasmetal_core__DOT___042490_))
                            : (IData)(vlSelf->wasmetal_core__DOT___042491_))
                        : (IData)(vlSelf->wasmetal_core__DOT___042492_))
                    : (IData)(vlSelf->wasmetal_core__DOT___042493_))
                : (IData)(vlSelf->wasmetal_core__DOT___042495_))
            : (IData)(vlSelf->wasmetal_core__DOT___042496_));
    vlSelf->wasmetal_core__DOT___053297_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d))));
    vlSelf->wasmetal_core__DOT___029769_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b31__05d))));
    vlSelf->wasmetal_core__DOT___029768_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b30__05d))));
    vlSelf->wasmetal_core__DOT___029766_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b29__05d))));
    vlSelf->wasmetal_core__DOT___029765_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b28__05d))));
    vlSelf->wasmetal_core__DOT___029764_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b27__05d))));
    vlSelf->wasmetal_core__DOT___029763_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b26__05d))));
    vlSelf->wasmetal_core__DOT___029762_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b25__05d))));
    vlSelf->wasmetal_core__DOT___029761_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b24__05d))));
    vlSelf->wasmetal_core__DOT___029760_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b23__05d))));
    vlSelf->wasmetal_core__DOT___029759_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b22__05d))));
    vlSelf->wasmetal_core__DOT___029758_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b21__05d))));
    vlSelf->wasmetal_core__DOT___029757_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b20__05d))));
    vlSelf->wasmetal_core__DOT___029755_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b19__05d))));
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__heap_next__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d = 0U;
        vlSelf->wasmetal_core__DOT__state__05b0__05d = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___019808_) {
            vlSelf->wasmetal_core__DOT__divider__02edividend__05b61__05d 
                = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b60__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054571_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128646___O)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___034340_)))))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019774_) {
            vlSelf->wasmetal_core__DOT__heap_next__05b31__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__heap_next__05b30__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__heap_next__05b29__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__heap_next__05b28__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O));
            vlSelf->wasmetal_core__DOT__heap_next__05b27__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__heap_next__05b26__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__heap_next__05b25__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__heap_next__05b24__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O));
            vlSelf->wasmetal_core__DOT__heap_next__05b23__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127855___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__heap_next__05b22__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127855___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__heap_next__05b21__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127855___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__heap_next__05b20__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127855___O));
            vlSelf->wasmetal_core__DOT__heap_next__05b19__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__heap_next__05b18__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__heap_next__05b17__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__heap_next__05b16__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O));
            vlSelf->wasmetal_core__DOT__heap_next__05b15__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__heap_next__05b14__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__heap_next__05b13__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__heap_next__05b12__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O));
            vlSelf->wasmetal_core__DOT__heap_next__05b11__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__heap_next__05b10__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__heap_next__05b9__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__heap_next__05b8__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O));
            vlSelf->wasmetal_core__DOT__heap_next__05b7__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__heap_next__05b6__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__heap_next__05b5__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__heap_next__05b4__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O));
            vlSelf->wasmetal_core__DOT__heap_next__05b3__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__heap_next__05b2__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__heap_next__05b1__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__heap_next__05b0__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O));
        }
        if (vlSelf->wasmetal_core__DOT___019788_) {
            vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d 
                = vlSelf->wasmetal_core__DOT___053428_;
        }
        if (vlSelf->wasmetal_core__DOT___019799_) {
            vlSelf->wasmetal_core__DOT__state__05b0__05d 
                = (1U & (0x20003fffU >> (((IData)(vlSelf->wasmetal_core__DOT___063397_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d)))))));
        }
    }
    vlSelf->wasmetal_core__DOT___029754_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b18__05d))));
    vlSelf->wasmetal_core__DOT___029753_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b17__05d))));
    vlSelf->wasmetal_core__DOT___029752_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b16__05d))));
    vlSelf->wasmetal_core__DOT___029751_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b15__05d))));
    vlSelf->wasmetal_core__DOT___029750_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b14__05d))));
    vlSelf->wasmetal_core__DOT___029749_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b13__05d))));
    vlSelf->wasmetal_core__DOT___029748_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b12__05d))));
    vlSelf->wasmetal_core__DOT___029747_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b11__05d))));
    vlSelf->wasmetal_core__DOT___029746_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b10__05d))));
    vlSelf->wasmetal_core__DOT___029776_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b9__05d))));
    vlSelf->wasmetal_core__DOT___029775_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b8__05d))));
    vlSelf->wasmetal_core__DOT___029774_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b7__05d))));
    vlSelf->wasmetal_core__DOT___029773_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b6__05d))));
    vlSelf->wasmetal_core__DOT___029772_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b5__05d))));
    vlSelf->wasmetal_core__DOT___029771_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b4__05d))));
    vlSelf->wasmetal_core__DOT___029770_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b3__05d))));
    vlSelf->wasmetal_core__DOT___029767_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b2__05d))));
    vlSelf->wasmetal_core__DOT___029756_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b1__05d))));
    vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029925_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d));
    vlSelf->wasmetal_core__DOT___029745_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d))));
    vlSelf->wasmetal_core__DOT___050502_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048567_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___051254_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___050292_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___050037_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___050495_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049548_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049442_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049389_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___051215_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___048568_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049948_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___050440_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___050355_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049950_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___051213_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___051489_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049829_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049543_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049929_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050286_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050473_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051279_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___049544_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050297_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051242_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051209_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051140_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051131_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050396_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050330_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___049915_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051206_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051377_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___049824_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049390_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___051251_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050281_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050393_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___051259_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___051248_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___049391_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___051237_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___051070_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___049941_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___049943_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050377_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050324_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___051243_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___051190_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___049939_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___049728_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048546_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___050270_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___049862_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050072_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___051255_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050285_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050299_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___048692_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___048547_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___051134_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050465_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050372_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___049935_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___051233_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050367_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050327_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050503_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049727_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049681_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050290_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050070_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049593_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050133_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049443_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049349_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___051216_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___048543_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049946_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050439_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049423_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049951_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___051234_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050084_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050497_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049347_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049682_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050288_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___051275_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___049585_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___049547_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___049441_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___049348_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___051214_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___051194_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050368_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050436_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050356_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___049949_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___051211_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___051490_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050496_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049345_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049680_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050289_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050036_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051263_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___049546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050305_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___049346_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051212_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051195_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050555_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___049582_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050279_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051378_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050734_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050331_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051258_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049550_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049679_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050287_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051273_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051260_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___049551_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050298_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051241_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051208_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051196_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050556_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050333_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___049916_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050376_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050325_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___049828_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048575_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049930_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050284_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050087_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051262_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050090_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___048576_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050157_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___049395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051139_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051130_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050391_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050329_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050471_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051193_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051488_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___049826_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048571_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___050163_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___050283_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___050474_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051261_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051231_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___048574_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___050902_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051207_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051138_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051129_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___050390_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___049583_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051246_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051192_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051487_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___049827_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048510_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___051250_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___050282_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___050472_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051302_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051249_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___049058_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051238_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___048512_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051137_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___050378_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___050326_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051245_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___050910_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___049612_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___049773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049392_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___050328_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___049604_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___051257_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050294_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___049393_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050747_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___051198_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___051136_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050469_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050374_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050323_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___051244_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050437_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___049952_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___049774_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049003_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___050267_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050071_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___051123_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___051256_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050296_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050306_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___049004_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___051197_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___051135_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050468_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050375_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___049594_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050085_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___051133_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___049937_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___049730_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048962_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___050295_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___049605_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050903_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050909_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050280_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050304_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___048963_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___051540_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050562_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050466_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050370_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___051379_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050086_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050373_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___049940_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___049729_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048298_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___050293_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049597_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049592_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050156_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049445_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___051247_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___048301_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___048544_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___051132_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050088_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049425_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049922_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050369_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050345_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050470_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050786_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048536_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___050271_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049920_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___050563_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___050134_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049446_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049350_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___048682_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___048538_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049947_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___050089_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049426_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049919_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___051232_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___050083_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___050478_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___048537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___049928_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___048573_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___049422_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___049938_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___048300_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___063355_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_kind__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill))));
    vlSelf->wasmetal_core__DOT___032540_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b63__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b63__05d)))));
    vlSelf->wasmetal_core__DOT___032539_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b62__05d)))));
    vlSelf->wasmetal_core__DOT___032538_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b61__05d)))));
    vlSelf->wasmetal_core__DOT___032537_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b60__05d)))));
    vlSelf->wasmetal_core__DOT___032535_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b59__05d)))));
    vlSelf->wasmetal_core__DOT___032534_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b58__05d)))));
    vlSelf->wasmetal_core__DOT___032533_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b57__05d)))));
    vlSelf->wasmetal_core__DOT___032532_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b56__05d)))));
    vlSelf->wasmetal_core__DOT___032531_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b55__05d)))));
    vlSelf->wasmetal_core__DOT___032530_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b54__05d)))));
    vlSelf->wasmetal_core__DOT___032529_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b53__05d)))));
    vlSelf->wasmetal_core__DOT___032528_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b52__05d)))));
    vlSelf->wasmetal_core__DOT___032527_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b51__05d)))));
    vlSelf->wasmetal_core__DOT___032526_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b50__05d)))));
    vlSelf->wasmetal_core__DOT___032524_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b49__05d)))));
    vlSelf->wasmetal_core__DOT___032523_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b48__05d)))));
    vlSelf->wasmetal_core__DOT___032522_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b47__05d)))));
    vlSelf->wasmetal_core__DOT___032521_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b46__05d)))));
    vlSelf->wasmetal_core__DOT___032520_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___032519_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___032518_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b43__05d)))));
    vlSelf->wasmetal_core__DOT___032517_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b42__05d)))));
    vlSelf->wasmetal_core__DOT___032516_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___032515_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b40__05d)))));
    vlSelf->wasmetal_core__DOT___032513_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b39__05d)))));
    vlSelf->wasmetal_core__DOT___032512_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b38__05d)))));
    vlSelf->wasmetal_core__DOT___032511_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b37__05d)))));
    vlSelf->wasmetal_core__DOT___032510_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b36__05d)))));
    vlSelf->wasmetal_core__DOT___032509_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b35__05d)))));
    vlSelf->wasmetal_core__DOT___032508_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b34__05d)))));
    vlSelf->wasmetal_core__DOT___032507_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b33__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b33__05d)))));
    vlSelf->wasmetal_core__DOT___032506_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b32__05d)))));
    vlSelf->wasmetal_core__DOT___032505_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___032504_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___032502_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b29__05d)))));
    vlSelf->wasmetal_core__DOT___032501_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b28__05d)))));
    vlSelf->wasmetal_core__DOT___032500_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b27__05d)))));
    vlSelf->wasmetal_core__DOT___032499_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b26__05d)))));
    vlSelf->wasmetal_core__DOT___032498_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b25__05d)))));
    vlSelf->wasmetal_core__DOT___032497_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b24__05d)))));
    vlSelf->wasmetal_core__DOT___032496_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b23__05d)))));
    vlSelf->wasmetal_core__DOT___032495_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b22__05d)))));
    vlSelf->wasmetal_core__DOT___032494_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b21__05d)))));
    vlSelf->wasmetal_core__DOT___032493_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b20__05d)))));
    vlSelf->wasmetal_core__DOT___032491_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b19__05d)))));
    vlSelf->wasmetal_core__DOT___032490_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b18__05d)))));
    vlSelf->wasmetal_core__DOT___032489_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b17__05d)))));
    vlSelf->wasmetal_core__DOT___032488_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b16__05d)))));
    vlSelf->wasmetal_core__DOT___032487_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b15__05d)))));
    vlSelf->wasmetal_core__DOT___032486_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b14__05d)))));
    vlSelf->wasmetal_core__DOT___032485_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b13__05d)))));
    vlSelf->wasmetal_core__DOT___032484_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b12__05d)))));
    vlSelf->wasmetal_core__DOT___032483_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b11__05d)))));
    vlSelf->wasmetal_core__DOT___032482_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___032544_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b9__05d)))));
    vlSelf->wasmetal_core__DOT___032543_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b8__05d)))));
    vlSelf->wasmetal_core__DOT___032542_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b7__05d)))));
    vlSelf->wasmetal_core__DOT___032541_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b6__05d)))));
    vlSelf->wasmetal_core__DOT___032536_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b5__05d)))));
    vlSelf->wasmetal_core__DOT___032397_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___032386_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___032375_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b2__05d)))));
    vlSelf->__VdfgTmp_h9fa2de6d__0 = (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill));
    vlSelf->wasmetal_core__DOT___032364_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___032353_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b0__05d)))));
    vlSelf->wasmetal_core__DOT__gc_source__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039615_));
    vlSelf->__VdfgTmp_h5736dc67__0 = ((2U & (vlSelf->insn_x 
                                             >> 6U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT___032895_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d))));
    vlSelf->wasmetal_core__DOT___032703_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039619_));
    vlSelf->__VdfgTmp_h13987860__0 = ((2U & (vlSelf->insn_x 
                                             >> 5U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___032894_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d))));
    vlSelf->wasmetal_core__DOT___032702_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039604_));
    vlSelf->wasmetal_core__DOT___044706_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & vlSelf->function_params) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 2U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)))))))));
    vlSelf->__VdfgTmp_haa7ff968__0 = ((2U & (vlSelf->insn_x 
                                             >> 4U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___032893_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d))));
    vlSelf->wasmetal_core__DOT___032701_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039603_));
    vlSelf->__VdfgTmp_h85ffa972__0 = ((2U & (vlSelf->insn_x 
                                             >> 3U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___032892_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128283___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d))))));
    vlSelf->wasmetal_core__DOT___032700_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039599_));
    vlSelf->__VdfgTmp_h83e5aafb__0 = ((2U & (vlSelf->insn_x 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->wasmetal_core__DOT___032891_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d))));
    vlSelf->wasmetal_core__DOT___032699_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039628_));
    vlSelf->wasmetal_core__DOT___036619_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d))));
    vlSelf->wasmetal_core__DOT___032890_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d))));
    vlSelf->wasmetal_core__DOT___032698_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039630_));
    vlSelf->__VdfgTmp_hf9e7c209__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1dU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d));
    vlSelf->wasmetal_core__DOT___032889_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d))));
    vlSelf->wasmetal_core__DOT___032697_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039626_));
    vlSelf->__VdfgTmp_h586b57d5__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1cU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    vlSelf->wasmetal_core__DOT___032887_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d))));
    vlSelf->wasmetal_core__DOT___044704_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0x18U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x1aU)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x1cU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___032695_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039625_));
    vlSelf->__VdfgTmp_h364ba349__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1bU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    vlSelf->wasmetal_core__DOT___032886_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128289___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d))))));
    vlSelf->wasmetal_core__DOT___032694_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039624_));
    vlSelf->__VdfgTmp_hd2526c88__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1aU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    vlSelf->wasmetal_core__DOT___032885_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d))));
    vlSelf->wasmetal_core__DOT___032693_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039623_));
    vlSelf->__VdfgTmp_h93f91ca8__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x19U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    vlSelf->wasmetal_core__DOT___032884_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d))));
    vlSelf->wasmetal_core__DOT___044713_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0x15U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x17U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___032692_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d))));
    vlSelf->wasmetal_core__DOT___044627_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT__gc_source__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039622_));
    vlSelf->__VdfgTmp_h4835143f__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x18U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT___032883_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d))));
    vlSelf->wasmetal_core__DOT___032691_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039621_));
    vlSelf->__VdfgTmp_hf6334cf8__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x17U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___032882_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d))));
    vlSelf->__VdfgTmp_hd225b533__0 = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp___128288___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d))))));
    vlSelf->wasmetal_core__DOT___032690_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039618_));
    vlSelf->__VdfgTmp_h2b80e318__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x16U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    vlSelf->wasmetal_core__DOT___032881_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d))));
    vlSelf->wasmetal_core__DOT___032689_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039606_));
    vlSelf->__VdfgTmp_h17547017__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x15U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    vlSelf->wasmetal_core__DOT___032880_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d))));
    vlSelf->wasmetal_core__DOT___032688_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039617_));
    vlSelf->__VdfgTmp_hed077be7__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x14U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___032879_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d))));
    vlSelf->wasmetal_core__DOT___032687_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039611_));
    vlSelf->__VdfgTmp_h1872cc15__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x13U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    vlSelf->wasmetal_core__DOT___044711_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0xfU)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x11U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___032878_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128287___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d))))));
    vlSelf->wasmetal_core__DOT___032686_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128287___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039620_));
    vlSelf->__VdfgTmp_h9473bd37__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x12U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT___032876_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d))));
    vlSelf->wasmetal_core__DOT___032684_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039616_));
    vlSelf->__VdfgTmp_hfd696a08__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x11U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    vlSelf->wasmetal_core__DOT___032875_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d))));
    vlSelf->wasmetal_core__DOT___032683_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039607_));
    vlSelf->wasmetal_core__DOT___044710_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0xcU)) 
                                                           | ((0x18U 
                                                               & (vlSelf->function_params 
                                                                  >> 0xfU)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d))))))));
    vlSelf->__VdfgTmp_hb0a19382__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x10U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___032874_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d))));
    vlSelf->wasmetal_core__DOT___032682_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039608_));
    vlSelf->__VdfgTmp_h959d8796__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xfU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___032873_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128286___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d))))));
    vlSelf->wasmetal_core__DOT___032681_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039609_));
    vlSelf->__VdfgTmp_h6d2d9567__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xeU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT___032872_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d))));
    vlSelf->wasmetal_core__DOT___032680_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039610_));
    vlSelf->wasmetal_core__DOT___044709_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 9U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0xbU)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)))))))));
    vlSelf->__VdfgTmp_h291433ac__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xdU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    vlSelf->wasmetal_core__DOT___032871_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d))));
    vlSelf->wasmetal_core__DOT___032679_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d))));
    vlSelf->wasmetal_core__DOT___044625_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT__gc_source__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039605_));
    vlSelf->__VdfgTmp_h6265db41__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xbU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___032869_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d))));
    vlSelf->wasmetal_core__DOT___032677_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039602_));
    vlSelf->__VdfgTmp_h7b2f5a0d__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xaU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT___032868_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d))));
    vlSelf->wasmetal_core__DOT___032676_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039612_));
    vlSelf->__VdfgTmp_h86617c98__0 = ((2U & (vlSelf->insn_x 
                                             >> 9U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    vlSelf->wasmetal_core__DOT___032867_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d))));
    vlSelf->wasmetal_core__DOT___032675_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039613_));
    vlSelf->__VdfgTmp_h20c332a4__0 = ((2U & (vlSelf->insn_x 
                                             >> 8U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___032897_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d))));
    vlSelf->wasmetal_core__DOT___032705_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039614_));
    vlSelf->wasmetal_core__DOT___044707_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 5U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 7U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)))))))));
    vlSelf->__VdfgTmp_h1c8d20fd__0 = ((2U & (vlSelf->insn_x 
                                             >> 7U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___032896_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128284___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d))))));
    vlSelf->wasmetal_core__DOT___032704_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128284___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039627_));
    vlSelf->wasmetal_core__DOT___032866_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d))));
    vlSelf->wasmetal_core__DOT___032674_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d))));
    vlSelf->wasmetal_core__DOT__gc_source__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039600_));
    vlSelf->wasmetal_core__DOT___044705_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)))))))));
    vlSelf->__VdfgTmp_hcb9fc16c__0 = ((2U & (vlSelf->insn_x 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___032888_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d))));
    vlSelf->wasmetal_core__DOT___032696_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d))));
    vlSelf->wasmetal_core__DOT___044624_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT__gc_source__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039601_));
    vlSelf->__VdfgTmp_h8befad22__0 = ((2U & vlSelf->insn_x) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___032877_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_y) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d))));
    vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___032685_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->function_params) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d))));
    vlSelf->wasmetal_core__DOT____VdfgTmp_hc50f84f8__0 
        = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b1__05d) {
        vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b0__05d;
        wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b1__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b1__05d;
        wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b0__05d;
    }
    vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b3__05d) {
        vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
        vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b2__05d;
        vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b2__05d) {
        vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b2__05d;
        vlSelf->wasmetal_core__DOT___128593___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128490___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b2__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128593___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b2__05d;
        vlSelf->wasmetal_core__DOT___128490___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____VdfgTmp_h1702059a__0 
        = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d)) 
                  << 1U)) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->__VdfgTmp_hbb12d5bf__0 = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT__gc_source__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039598_));
    vlSelf->__VdfgTmp_hbd028268__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xcU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->__VdfgTmp_ha938949d__0 = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___032870_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128285___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d))))));
    vlSelf->wasmetal_core__DOT___032678_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d))));
    vlSelf->wasmetal_core__DOT___052014_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_file__02epending_write))));
    vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___027801_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b0__05d));
    vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026357_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d));
    vlSelf->wasmetal_core__DOT___045581_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032218_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032217_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032215_)))));
    vlSelf->wasmetal_core__DOT___045590_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032214_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032213_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032212_)))));
    vlSelf->wasmetal_core__DOT___045577_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b23__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b25__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h17166267__0))))))));
    vlSelf->wasmetal_core__DOT___045589_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032211_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032210_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032209_)))));
    vlSelf->wasmetal_core__DOT___044273_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128431___DI))))));
    vlSelf->__VdfgTmp_hcd6b7a1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___032208_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032207_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___032206_)));
    vlSelf->wasmetal_core__DOT___045587_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032204_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032203_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032202_)))));
    vlSelf->wasmetal_core__DOT___045586_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032201_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032200_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032199_)))));
    vlSelf->wasmetal_core__DOT___045573_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b11__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b13__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he965b193__0))))))));
    vlSelf->wasmetal_core__DOT___045585_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032198_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032197_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032196_)))));
    vlSelf->wasmetal_core__DOT___044271_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070607_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_he965b193__0)))))));
    vlSelf->wasmetal_core__DOT___044263_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he965b193__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070607_)))));
    vlSelf->__VdfgTmp_he13e3256__0 = (((IData)(vlSelf->wasmetal_core__DOT___032195_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032225_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___032224_)));
    vlSelf->wasmetal_core__DOT___045583_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032223_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032222_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032221_)))));
    vlSelf->wasmetal_core__DOT___045582_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032220_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032219_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032216_)))));
    vlSelf->wasmetal_core__DOT___045568_ = (1U & (0x2b22U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbf5bedf6__0)))));
    vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h58222fb0__0 = ((2U & ((9U >> (IData)(vlSelf->__VdfgTmp_hbf5bedf6__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___032194_));
    vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032194_) 
           | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128721___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___035215_));
    vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029672_));
    vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030584_));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b4__05d) {
        vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027729_;
        vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b4__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__0__KET__ = 0U;
        vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032092_;
    }
    vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031611_));
    vlSelf->wasmetal_core__DOT___052940_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052939_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_reference))));
    vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___030010_));
    vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029404_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b2__05d));
    vlSelf->wasmetal_core__DOT___065582_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065579_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xeff7ffffffffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b1__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b0__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h49b76e08__0)))))))))));
    vlSelf->wasmetal_core__DOT___065565_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b4__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065563_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065562_)))));
    vlSelf->wasmetal_core__DOT___064978_ = (1U & (0x80000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h49b76e08__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064088_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064087_)))))));
    vlSelf->wasmetal_core__DOT___065558_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064087_))));
    vlSelf->wasmetal_core__DOT___064093_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064088_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064087_))));
    vlSelf->wasmetal_core__DOT___066365_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065557_)))));
    vlSelf->wasmetal_core__DOT___067556_ = (1U & (0xbfffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064087_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066366_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___066367_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066366_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064087_))));
    vlSelf->wasmetal_core__DOT___064452_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0))));
    vlSelf->wasmetal_core__DOT___064992_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064095_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0))));
    vlSelf->wasmetal_core__DOT___064973_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0))));
    vlSelf->wasmetal_core__DOT___065556_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065554_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064087_))));
    vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029841_));
    vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029310_));
    vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029243_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d));
    vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026187_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d));
    vlSelf->wasmetal_core__DOT___066352_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b4__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035106_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d));
    vlSelf->wasmetal_core__DOT___052994_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052991_))));
    vlSelf->wasmetal_core__DOT___053294_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053293_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b7__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___053295_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053290_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b13__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___053304_ = (1U & (IData)(
                                                         (0x9000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053301_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053300_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053299_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x9009000000009009ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b12__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b8__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128940___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027664_));
    vlSelf->wasmetal_core__DOT___046933_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___044119_)))));
    vlSelf->__VdfgTmp_hf5e419f7__0 = (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                       << 1U) | (IData)(wasmetal_core__DOT___044119_));
    vlSelf->wasmetal_core__DOT___128688___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d))));
    vlSelf->wasmetal_core__DOT___053305_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053297_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053296_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029936_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d));
    vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___029745_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d));
    vlSelf->wasmetal_core__DOT___021222_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048537_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___019818_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___020203_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___021480_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049422_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___020842_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049938_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___020584_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___036785_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5736dc67__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h13987860__0))));
    vlSelf->wasmetal_core__DOT___036784_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h13987860__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_haa7ff968__0))));
    vlSelf->wasmetal_core__DOT___044718_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032701_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032703_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032702_)))));
    vlSelf->wasmetal_core__DOT___036783_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa7ff968__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h85ffa972__0))));
    vlSelf->wasmetal_core__DOT___036782_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h85ffa972__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h83e5aafb__0))));
    vlSelf->wasmetal_core__DOT___052868_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032700_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___032699_))));
    vlSelf->wasmetal_core__DOT___036780_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036619_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf9e7c209__0))));
    vlSelf->wasmetal_core__DOT___036779_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf9e7c209__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h586b57d5__0))));
    vlSelf->wasmetal_core__DOT___044716_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032695_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032698_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032697_)))));
    vlSelf->wasmetal_core__DOT___036777_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h586b57d5__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h364ba349__0))));
    vlSelf->wasmetal_core__DOT___036776_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h364ba349__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2526c88__0))));
    vlSelf->wasmetal_core__DOT___052867_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032694_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___032693_))));
    vlSelf->wasmetal_core__DOT___036775_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd2526c88__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h93f91ca8__0))));
    vlSelf->wasmetal_core__DOT___036774_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h93f91ca8__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4835143f__0))));
    vlSelf->wasmetal_core__DOT___036773_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4835143f__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf6334cf8__0))));
    vlSelf->wasmetal_core__DOT___044712_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0x12U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x14U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd225b533__0))))))));
    vlSelf->__VdfgTmp_h42a8fe82__0 = (((IData)(vlSelf->wasmetal_core__DOT___032691_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032690_));
    vlSelf->wasmetal_core__DOT___036772_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf6334cf8__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2b80e318__0))));
    vlSelf->wasmetal_core__DOT___036771_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2b80e318__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h17547017__0))));
    vlSelf->wasmetal_core__DOT___036770_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17547017__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hed077be7__0))));
    vlSelf->wasmetal_core__DOT___036769_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hed077be7__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1872cc15__0))));
    vlSelf->wasmetal_core__DOT___044723_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032686_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032688_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032687_)))));
    vlSelf->wasmetal_core__DOT___044626_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___DI))))));
    vlSelf->wasmetal_core__DOT___036768_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1872cc15__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9473bd37__0))));
    vlSelf->wasmetal_core__DOT___036766_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9473bd37__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfd696a08__0))));
    vlSelf->wasmetal_core__DOT___036765_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfd696a08__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb0a19382__0))));
    vlSelf->wasmetal_core__DOT___044722_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032682_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032684_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032683_)))));
    vlSelf->wasmetal_core__DOT___036764_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0a19382__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h959d8796__0))));
    vlSelf->wasmetal_core__DOT___036763_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h959d8796__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d2d9567__0))));
    vlSelf->wasmetal_core__DOT___036762_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6d2d9567__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h291433ac__0))));
    vlSelf->wasmetal_core__DOT___044721_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032679_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032680_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032681_)))));
    vlSelf->wasmetal_core__DOT___036759_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6265db41__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7b2f5a0d__0))));
    vlSelf->wasmetal_core__DOT___036758_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7b2f5a0d__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h86617c98__0))));
    vlSelf->wasmetal_core__DOT___036757_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h86617c98__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h20c332a4__0))));
    vlSelf->wasmetal_core__DOT___036787_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h20c332a4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1c8d20fd__0))));
    vlSelf->wasmetal_core__DOT___036786_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1c8d20fd__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5736dc67__0))));
    vlSelf->wasmetal_core__DOT___044719_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032704_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032675_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032705_)))));
    vlSelf->wasmetal_core__DOT___048272_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___DI))));
    vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032866_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032674_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___036781_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h83e5aafb__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcb9fc16c__0))));
    vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___036778_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcb9fc16c__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8befad22__0))));
    vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h74a82ee2__0 = (((IData)(vlSelf->wasmetal_core__DOT___032685_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032674_));
    vlSelf->wasmetal_core__DOT___044703_ = (1U & (0x7150U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->function_params 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (vlSelf->function_params 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0)))));
    vlSelf->wasmetal_core__DOT___135298___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044624_)
                  ? (~ (1U >> (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0)))
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___044624_))));
    vlSelf->__VdfgTmp_h58bd40ba__0 = (((IData)(wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___036761_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h291433ac__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd028268__0))));
    vlSelf->wasmetal_core__DOT___036760_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbd028268__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6265db41__0))));
    vlSelf->wasmetal_core__DOT___044708_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 6U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 8U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha938949d__0))))))));
    vlSelf->__VdfgTmp_haf0d31b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___032678_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032677_));
    vlSelf->wasmetal_core__DOT___052015_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052014_))));
}
