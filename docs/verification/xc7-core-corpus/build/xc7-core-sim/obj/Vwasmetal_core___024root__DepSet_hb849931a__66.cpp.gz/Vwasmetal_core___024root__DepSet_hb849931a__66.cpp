#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__28(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__28\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___008826_;
    wasmetal_core__DOT___008826_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008882_;
    wasmetal_core__DOT___008882_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008884_;
    wasmetal_core__DOT___008884_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008941_;
    wasmetal_core__DOT___008941_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008972_;
    wasmetal_core__DOT___008972_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008973_;
    wasmetal_core__DOT___008973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009020_;
    wasmetal_core__DOT___009020_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009024_;
    wasmetal_core__DOT___009024_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009025_;
    wasmetal_core__DOT___009025_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009026_;
    wasmetal_core__DOT___009026_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009132_;
    wasmetal_core__DOT___009132_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009133_;
    wasmetal_core__DOT___009133_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009134_;
    wasmetal_core__DOT___009134_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009140_;
    wasmetal_core__DOT___009140_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009141_;
    wasmetal_core__DOT___009141_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009150_;
    wasmetal_core__DOT___009150_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009151_;
    wasmetal_core__DOT___009151_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009152_;
    wasmetal_core__DOT___009152_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009168_;
    wasmetal_core__DOT___009168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009243_;
    wasmetal_core__DOT___009243_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009274_;
    wasmetal_core__DOT___009274_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009387_;
    wasmetal_core__DOT___009387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009414_;
    wasmetal_core__DOT___009414_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009447_;
    wasmetal_core__DOT___009447_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009699_;
    wasmetal_core__DOT___009699_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009886_;
    wasmetal_core__DOT___009886_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013207_;
    wasmetal_core__DOT___013207_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013208_;
    wasmetal_core__DOT___013208_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014355_;
    wasmetal_core__DOT___014355_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014375_;
    wasmetal_core__DOT___014375_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014381_;
    wasmetal_core__DOT___014381_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014382_;
    wasmetal_core__DOT___014382_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014383_;
    wasmetal_core__DOT___014383_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014440_;
    wasmetal_core__DOT___014440_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014447_;
    wasmetal_core__DOT___014447_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014454_;
    wasmetal_core__DOT___014454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019677_;
    wasmetal_core__DOT___019677_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019684_;
    wasmetal_core__DOT___019684_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051265_;
    wasmetal_core__DOT___051265_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056103_;
    wasmetal_core__DOT___056103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056268_;
    wasmetal_core__DOT___056268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057713_;
    wasmetal_core__DOT___057713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057915_;
    wasmetal_core__DOT___057915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057936_;
    wasmetal_core__DOT___057936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057950_;
    wasmetal_core__DOT___057950_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057970_;
    wasmetal_core__DOT___057970_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057977_;
    wasmetal_core__DOT___057977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057979_;
    wasmetal_core__DOT___057979_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058023_;
    wasmetal_core__DOT___058023_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058027_;
    wasmetal_core__DOT___058027_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058032_;
    wasmetal_core__DOT___058032_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058042_;
    wasmetal_core__DOT___058042_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058054_;
    wasmetal_core__DOT___058054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058055_;
    wasmetal_core__DOT___058055_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058056_;
    wasmetal_core__DOT___058056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058981_;
    wasmetal_core__DOT___058981_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h3c5f3431__0;
    __VdfgTmp_h3c5f3431__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha336bc52__0;
    __VdfgTmp_ha336bc52__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2b908e25__0;
    __VdfgTmp_h2b908e25__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2c715ba9__0;
    __VdfgTmp_h2c715ba9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h29905bdd__0;
    __VdfgTmp_h29905bdd__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8ed306e0__0;
    __VdfgTmp_h8ed306e0__0 = 0;
    CData/*1:0*/ __VdfgTmp_h44cf3d5c__0;
    __VdfgTmp_h44cf3d5c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h5c89e2df__0;
    __VdfgTmp_h5c89e2df__0 = 0;
    CData/*1:0*/ __VdfgTmp_hca62a78c__0;
    __VdfgTmp_hca62a78c__0 = 0;
    CData/*1:0*/ __VdfgTmp_hcb32e64d__0;
    __VdfgTmp_hcb32e64d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3ae7f513__0;
    __VdfgTmp_h3ae7f513__0 = 0;
    CData/*2:0*/ __VdfgTmp_h115316d8__0;
    __VdfgTmp_h115316d8__0 = 0;
    CData/*1:0*/ __VdfgTmp_h351522cb__0;
    __VdfgTmp_h351522cb__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd28f0b72__0;
    __VdfgTmp_hd28f0b72__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb4d0429b__0;
    __VdfgTmp_hb4d0429b__0 = 0;
    CData/*2:0*/ __VdfgTmp_hb9a1e459__0;
    __VdfgTmp_hb9a1e459__0 = 0;
    CData/*2:0*/ __VdfgTmp_ha28c8f63__0;
    __VdfgTmp_ha28c8f63__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0e20e5e3__0;
    __VdfgTmp_h0e20e5e3__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8170c8be__0;
    __VdfgTmp_h8170c8be__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9dc510af__0;
    __VdfgTmp_h9dc510af__0 = 0;
    CData/*1:0*/ __VdfgTmp_hba696de2__0;
    __VdfgTmp_hba696de2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8453cf34__0;
    __VdfgTmp_h8453cf34__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbb8e97f6__0;
    __VdfgTmp_hbb8e97f6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3fbd9b9f__0;
    __VdfgTmp_h3fbd9b9f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h98614ec5__0;
    __VdfgTmp_h98614ec5__0 = 0;
    CData/*3:0*/ __VdfgTmp_h63472758__0;
    __VdfgTmp_h63472758__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7a1a10ae__0;
    __VdfgTmp_h7a1a10ae__0 = 0;
    CData/*4:0*/ __VdfgTmp_hb2511b98__0;
    __VdfgTmp_hb2511b98__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf3511969__0;
    __VdfgTmp_hf3511969__0 = 0;
    CData/*1:0*/ __VdfgTmp_h78b7c78d__0;
    __VdfgTmp_h78b7c78d__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf87abe5d__0;
    __VdfgTmp_hf87abe5d__0 = 0;
    CData/*3:0*/ __VdfgTmp_h32a58059__0;
    __VdfgTmp_h32a58059__0 = 0;
    CData/*4:0*/ __VdfgTmp_h836204cc__0;
    __VdfgTmp_h836204cc__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___058025_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)))))))))));
    vlSelf->wasmetal_core__DOT___014446_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)))))))))));
    vlSelf->wasmetal_core__DOT___014354_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h04542857__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0)))))))))));
    vlSelf->wasmetal_core__DOT___014353_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)))))))))));
    vlSelf->wasmetal_core__DOT___014959_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048958_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048957_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048956_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048955_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___014456_)))))));
    vlSelf->wasmetal_core__DOT___057908_ = (1U & (IData)(
                                                         (0xb00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x53U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0x53U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057899_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h95d04b06__0))))))));
    vlSelf->wasmetal_core__DOT___057916_ = (1U & (0xf0f000bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057899_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h95d04b06__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b33__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057899_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___057926_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057918_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT___057939_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057938_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT___058019_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058018_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b23__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___058018_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___058010_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058000_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b22__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___058000_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___058031_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006117_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b12__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___058046_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he29625ac__0))))));
    vlSelf->wasmetal_core__DOT___057978_ = (1U & (IData)(
                                                         (0x5555333300ff000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7c001b5f__0))))))));
    vlSelf->wasmetal_core__DOT___057956_ = (1U & (IData)(
                                                         (0xf0f030300ff0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he29625ac__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b11__05d 
        = (1U & (0xfcfaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___057969_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057965_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b8__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057965_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d)))))));
    vlSelf->__VdfgTmp_ha1cc8027__0 = (((IData)(vlSelf->wasmetal_core__DOT___057968_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7dbcfedb__0));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b7__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057968_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___057963_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057959_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b6__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057959_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___057962_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057961_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b5__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057961_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___035659_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d))));
    vlSelf->wasmetal_core__DOT___035636_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d))));
    vlSelf->wasmetal_core__DOT___035630_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d))));
    vlSelf->wasmetal_core__DOT___035629_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d))));
    vlSelf->wasmetal_core__DOT___035628_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d))));
    vlSelf->wasmetal_core__DOT___035627_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d))));
    vlSelf->wasmetal_core__DOT___035626_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d))));
    vlSelf->wasmetal_core__DOT___035625_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d))));
    vlSelf->wasmetal_core__DOT___035624_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d))));
    vlSelf->wasmetal_core__DOT___035623_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d))));
    vlSelf->wasmetal_core__DOT___035673_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d))));
    vlSelf->wasmetal_core__DOT___035672_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d))));
    vlSelf->wasmetal_core__DOT___035653_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d))));
    vlSelf->wasmetal_core__DOT___035642_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d))));
    vlSelf->wasmetal_core__DOT___035631_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b54__05d 
        = (1U & (8U >> ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b53__05d 
        = (1U & (0xf888U >> ((8U & ((8U >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b52__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b51__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b50__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b49__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b48__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b47__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b45__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b44__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b43__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b42__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b41__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b40__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b39__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b38__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b37__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b36__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b35__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b34__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b32__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b31__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b30__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b29__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b28__05d 
        = (1U & (0xfffff888U >> (((IData)(vlSelf->wasmetal_core__DOT___057918_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d) 
                                             << 3U) 
                                            | ((4U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                   << 2U)) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b27__05d 
        = (1U & (0xfffff888U >> (((IData)(vlSelf->wasmetal_core__DOT___057938_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                             << 3U) 
                                            | ((4U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                   << 2U)) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b26__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b24__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b21__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b1__05d 
        = (1U & (0xf888U >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0))))))));
    vlSelf->wasmetal_core__DOT___009946_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009285_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___056219_ = (1U & (0xf3faU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009357_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf0aacc00U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha91317d0__0)))))))));
    vlSelf->wasmetal_core__DOT___009358_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf0aacc00U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha91317d0__0))))));
    vlSelf->wasmetal_core__DOT___055837_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009357_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha91317d0__0)))))));
    vlSelf->__VdfgTmp_h890a41f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___009284_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055614_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0))))))));
    vlSelf->wasmetal_core__DOT___062388_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009417_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0)))))))));
    vlSelf->wasmetal_core__DOT___061165_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h35ac7889__0))));
    vlSelf->wasmetal_core__DOT___009940_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e622f55__0)))));
    vlSelf->wasmetal_core__DOT___062362_ = (1U & (IData)(
                                                         (0xf0f33aa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009346_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9685faf4__0))))))));
    vlSelf->wasmetal_core__DOT___009348_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9685faf4__0)))));
    vlSelf->wasmetal_core__DOT___062381_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7856ed04__0)))));
    vlSelf->wasmetal_core__DOT___009083_ = (1U & (0xf0044U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7856ed04__0)))));
    vlSelf->wasmetal_core__DOT___009935_ = (1U & (IData)(
                                                         (0xf3faf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h45aa792f__0))))))));
    vlSelf->wasmetal_core__DOT___009757_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h45aa792f__0))));
    vlSelf->wasmetal_core__DOT___061031_ = (1U & (0xf0f0cc55U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009333_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_had646e7f__0))))));
    vlSelf->wasmetal_core__DOT___009335_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had646e7f__0)))));
    vlSelf->wasmetal_core__DOT___009962_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009259_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___062442_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009329_))));
    vlSelf->__VdfgTmp_h792a3800__0 = (((IData)(vlSelf->wasmetal_core__DOT___009330_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009329_));
    vlSelf->wasmetal_core__DOT___055464_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009245_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055451_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)))))))));
    vlSelf->wasmetal_core__DOT___062375_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009396_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)))))))));
    vlSelf->wasmetal_core__DOT___009398_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009397_)))));
    vlSelf->__VdfgTmp_h3b5a0ff3__0 = (((IData)(vlSelf->wasmetal_core__DOT___009232_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056079_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0))))))));
    vlSelf->wasmetal_core__DOT___009389_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009388_)))));
    vlSelf->wasmetal_core__DOT___060828_ = (1U & (0xf0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009386_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0))))))));
    vlSelf->__VdfgTmp_h32990406__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h38f150ef__0))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009988_));
    vlSelf->wasmetal_core__DOT___060752_ = (1U & (0xf055ccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055718_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1125b1e9__0))))));
    vlSelf->wasmetal_core__DOT___009308_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1125b1e9__0))));
    vlSelf->wasmetal_core__DOT___062453_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009374_))));
    vlSelf->__VdfgTmp_h41d1df16__0 = (((IData)(vlSelf->wasmetal_core__DOT___009375_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009374_));
    vlSelf->wasmetal_core__DOT___009225_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6b56eebb__0))));
    vlSelf->wasmetal_core__DOT___008975_ = (1U & (IData)(
                                                         (0xfff0ff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009930_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb294466b__0))))))));
    vlSelf->wasmetal_core__DOT___009363_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h748d3c0c__0))));
    vlSelf->wasmetal_core__DOT___062469_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h584d0366__0))))));
    vlSelf->wasmetal_core__DOT___009425_ = (1U & (0x200U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h584d0366__0))))))));
    vlSelf->wasmetal_core__DOT___062410_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7ca1d027__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056169_)))));
    vlSelf->__VdfgTmp_he74af19b__0 = ((2U & ((0xacU 
                                              >> (IData)(vlSelf->__VdfgTmp_h748d3c0c__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009984_));
    vlSelf->wasmetal_core__DOT___061316_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h584d0366__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009920_)))));
    vlSelf->wasmetal_core__DOT___009727_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xa3U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055689_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___056147_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009951_)))))));
    vlSelf->wasmetal_core__DOT___062437_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056221_))));
    vlSelf->__VdfgTmp_hb864fb42__0 = (((IData)(vlSelf->wasmetal_core__DOT___056221_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009997_));
    vlSelf->wasmetal_core__DOT___062404_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h16f25fe1__0))));
    vlSelf->wasmetal_core__DOT___009710_ = (1U & (0xf5fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h16f25fe1__0))))));
    vlSelf->wasmetal_core__DOT___060840_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3dedcb44__0))));
    vlSelf->wasmetal_core__DOT___056042_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055739_))));
    vlSelf->__VdfgTmp_h27200c45__0 = (((IData)(vlSelf->wasmetal_core__DOT___009317_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055739_));
    vlSelf->__VdfgTmp_ha3cb0627__0 = (((IData)(vlSelf->wasmetal_core__DOT___009276_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009275_));
    vlSelf->wasmetal_core__DOT___062332_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7c9afb82__0))));
    vlSelf->wasmetal_core__DOT___055491_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7c9afb82__0)))));
    vlSelf->wasmetal_core__DOT___007857_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007906_));
    vlSelf->wasmetal_core__DOT___055636_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h7737ac68__0))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007940_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007939_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_ha9e5b07a__0))))))))))));
    vlSelf->wasmetal_core__DOT___008549_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h7737ac68__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hb7c4f884__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h4d366d59__0)))))));
    if (vlSelf->wasmetal_core__DOT___007866_) {
        vlSelf->wasmetal_core__DOT___007856_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0)));
        vlSelf->wasmetal_core__DOT___055545_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hae7eba08__0)));
        vlSelf->wasmetal_core__DOT___051315_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha30079fd__0)));
        vlSelf->wasmetal_core__DOT___055744_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0)));
        vlSelf->wasmetal_core__DOT___055458_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008558_));
        vlSelf->wasmetal_core__DOT___055474_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0)));
        vlSelf->wasmetal_core__DOT___055549_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1f7329f__0)));
        vlSelf->wasmetal_core__DOT___055818_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0)));
        vlSelf->wasmetal_core__DOT___055630_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb1634503__0)));
        vlSelf->wasmetal_core__DOT___055845_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0)));
        vlSelf->wasmetal_core__DOT___051313_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)));
        vlSelf->wasmetal_core__DOT___055353_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)));
        vlSelf->wasmetal_core__DOT___055742_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055395_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055456_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0)));
        vlSelf->wasmetal_core__DOT___055898_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0)));
        vlSelf->wasmetal_core__DOT___055472_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0)));
        vlSelf->wasmetal_core__DOT___055547_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1390519c__0)));
        vlSelf->wasmetal_core__DOT___055925_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h158bc821__0)));
        vlSelf->wasmetal_core__DOT___055701_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0)));
        vlSelf->wasmetal_core__DOT___051934_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055358_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055945_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055391_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055885_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055454_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1d26d4c__0)));
        vlSelf->wasmetal_core__DOT___055470_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1d26d4c__0)));
        vlSelf->wasmetal_core__DOT___055804_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4af50ce9__0)));
        vlSelf->wasmetal_core__DOT___055530_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4af50ce9__0)));
        vlSelf->wasmetal_core__DOT___055576_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ba7f15b__0)));
        vlSelf->wasmetal_core__DOT___055626_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008255_));
        vlSelf->wasmetal_core__DOT___055844_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___055699_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___051932_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd65a75a__0)));
        vlSelf->wasmetal_core__DOT___055947_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)));
        vlSelf->wasmetal_core__DOT___055389_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)));
        vlSelf->wasmetal_core__DOT___055887_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___055452_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___009878_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0)));
        vlSelf->wasmetal_core__DOT___008856_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___009338_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___009353_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h042cd865__0)));
        vlSelf->wasmetal_core__DOT___009860_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0)));
        vlSelf->wasmetal_core__DOT___008930_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0)));
        vlSelf->wasmetal_core__DOT___009368_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0)));
        vlSelf->wasmetal_core__DOT___009381_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0)));
        vlSelf->wasmetal_core__DOT___009392_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7267e294__0)));
        vlSelf->wasmetal_core__DOT___009031_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0)));
        vlSelf->wasmetal_core__DOT___009067_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___008831_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___008859_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___009090_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___009352_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___008900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___009124_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___008929_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___009017_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h94861db4__0)))));
        vlSelf->wasmetal_core__DOT___008958_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he24fa3ba__0)));
        vlSelf->wasmetal_core__DOT___009367_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he24fa3ba__0)));
        vlSelf->wasmetal_core__DOT___009380_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0)));
        vlSelf->wasmetal_core__DOT___008990_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0)));
        vlSelf->wasmetal_core__DOT___009034_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4c1297e6__0)));
        vlSelf->wasmetal_core__DOT___009101_ = (1U 
                                                & (0x3331U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1ab3b1fe__0)));
        vlSelf->wasmetal_core__DOT___055575_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1ab3b1fe__0)));
        vlSelf->wasmetal_core__DOT___008861_ = (1U 
                                                & (0xa0cU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9bf7e2f7__0))));
    } else {
        vlSelf->wasmetal_core__DOT___007856_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3ba3f00e__0)));
        vlSelf->wasmetal_core__DOT___055545_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h83c5326a__0)));
        vlSelf->wasmetal_core__DOT___051315_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0)));
        vlSelf->wasmetal_core__DOT___055744_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0)));
        vlSelf->wasmetal_core__DOT___055458_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha30079fd__0)));
        vlSelf->wasmetal_core__DOT___055474_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0)));
        vlSelf->wasmetal_core__DOT___055549_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008558_));
        vlSelf->wasmetal_core__DOT___055818_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0)));
        vlSelf->wasmetal_core__DOT___055630_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1f7329f__0)));
        vlSelf->wasmetal_core__DOT___055845_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0)));
        vlSelf->wasmetal_core__DOT___051313_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb1634503__0)));
        vlSelf->wasmetal_core__DOT___055353_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb1634503__0)));
        vlSelf->wasmetal_core__DOT___055742_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0)));
        vlSelf->wasmetal_core__DOT___055395_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0)));
        vlSelf->wasmetal_core__DOT___055456_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)));
        vlSelf->wasmetal_core__DOT___055898_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055472_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055547_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0)));
        vlSelf->wasmetal_core__DOT___055925_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1390519c__0)));
        vlSelf->wasmetal_core__DOT___055701_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0)));
        vlSelf->wasmetal_core__DOT___051934_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h158bc821__0)));
        vlSelf->wasmetal_core__DOT___055358_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h158bc821__0)));
        vlSelf->wasmetal_core__DOT___055945_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0)));
        vlSelf->wasmetal_core__DOT___055391_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0)));
        vlSelf->wasmetal_core__DOT___055885_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055454_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055470_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055804_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055530_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055576_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1d26d4c__0)));
        vlSelf->wasmetal_core__DOT___055626_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4af50ce9__0)));
        vlSelf->wasmetal_core__DOT___055844_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ba7f15b__0)));
        vlSelf->wasmetal_core__DOT___055699_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ba7f15b__0)));
        vlSelf->wasmetal_core__DOT___051932_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008255_));
        vlSelf->wasmetal_core__DOT___055947_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___055389_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___055887_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd65a75a__0)));
        vlSelf->wasmetal_core__DOT___055452_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd65a75a__0)));
        vlSelf->wasmetal_core__DOT___009878_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)));
        vlSelf->wasmetal_core__DOT___008856_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___009338_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___009353_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0)));
        vlSelf->wasmetal_core__DOT___009860_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___008930_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___009368_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h042cd865__0)));
        vlSelf->wasmetal_core__DOT___009381_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0)));
        vlSelf->wasmetal_core__DOT___009392_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0)));
        vlSelf->wasmetal_core__DOT___009031_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0)));
        vlSelf->wasmetal_core__DOT___009067_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7267e294__0)));
        vlSelf->wasmetal_core__DOT___008831_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7267e294__0)));
        vlSelf->wasmetal_core__DOT___008859_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0)));
        vlSelf->wasmetal_core__DOT___009090_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0)));
        vlSelf->wasmetal_core__DOT___009352_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___008900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___009124_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___008929_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___009017_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he24fa3ba__0)));
        vlSelf->wasmetal_core__DOT___008958_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___009367_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___009380_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___008990_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___009034_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0)));
        vlSelf->wasmetal_core__DOT___009101_ = (1U 
                                                & (0xf050f03U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0dadf452__0)));
        vlSelf->wasmetal_core__DOT___055575_ = (1U 
                                                & (0xa000cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0dadf452__0)));
        vlSelf->wasmetal_core__DOT___008861_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4c1297e6__0)));
    }
    vlSelf->wasmetal_core__DOT___055355_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3ba3f00e__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_haff0ba2f__0)))))));
    vlSelf->wasmetal_core__DOT___007855_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_haff0ba2f__0))));
    vlSelf->wasmetal_core__DOT___009659_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc719aa4c__0)))))));
    vlSelf->wasmetal_core__DOT___055747_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc719aa4c__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0)))))));
    vlSelf->__VdfgTmp_hc3aac618__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0xaaaaccccf0f0ff00ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008027_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008026_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc20acf35__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hdb0e0153__0))
                                                     : 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h8c5bf8f0__0)))));
    vlSelf->wasmetal_core__DOT___056157_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h83c5326a__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h0d1d68d2__0)))))));
    vlSelf->wasmetal_core__DOT___008548_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h0d1d68d2__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h83c5326a__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0)))))));
    vlSelf->wasmetal_core__DOT___009870_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8c5bf8f0__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hee048ece__0)))))));
    vlSelf->wasmetal_core__DOT___008824_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hee048ece__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h8c5bf8f0__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0)))))));
    vlSelf->wasmetal_core__DOT___055546_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___008642_));
    vlSelf->wasmetal_core__DOT___009851_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hae7eba08__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hab3491b0__0)))))));
    vlSelf->wasmetal_core__DOT___008920_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hab3491b0__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hae7eba08__0)))))));
    vlSelf->wasmetal_core__DOT___008938_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdb0e0153__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc229347b__0)))))));
    vlSelf->wasmetal_core__DOT___051316_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0de86ccc__0))));
    vlSelf->__VdfgTmp_ha33784b5__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_ha30079fd__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0de86ccc__0)))));
    vlSelf->wasmetal_core__DOT___055745_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd3e9a659__0))));
    vlSelf->__VdfgTmp_h63940f3b__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hd3e9a659__0)))));
    vlSelf->__VdfgTmp_hddf47e90__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3429c82f__0)))));
    vlSelf->wasmetal_core__DOT___055475_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3429c82f__0))));
    vlSelf->wasmetal_core__DOT___055817_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hfb017b9d__0))));
    vlSelf->__VdfgTmp_h5e3623a6__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb1634503__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc1f7329f__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha22ec9f2__0)))));
    vlSelf->wasmetal_core__DOT___055631_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha22ec9f2__0))));
    vlSelf->wasmetal_core__DOT___055846_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hb46d48f1__0))));
    vlSelf->wasmetal_core__DOT___055704_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hb46d48f1__0))));
    vlSelf->wasmetal_core__DOT___051314_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7092c9cd__0))));
    vlSelf->wasmetal_core__DOT___055354_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7092c9cd__0))));
    vlSelf->wasmetal_core__DOT___055743_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefb478a1__0))));
    vlSelf->wasmetal_core__DOT___055396_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefb478a1__0))));
    vlSelf->__VdfgTmp_h33e7f237__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0x555533330f0f00ffULL 
                                                   >> (IData)(vlSelf->__VdfgTmp_h855995cd__0)))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0x503U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0))
                                                     : 
                                                    (0x503U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)))));
    vlSelf->wasmetal_core__DOT___055457_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h855995cd__0))));
    vlSelf->wasmetal_core__DOT___055897_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h114e86e1__0))));
    vlSelf->wasmetal_core__DOT___055473_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h114e86e1__0))));
    vlSelf->__VdfgTmp_hb6e33d53__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h1390519c__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h91c21bf0__0)))));
    vlSelf->wasmetal_core__DOT___055548_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h91c21bf0__0))));
    vlSelf->__VdfgTmp_h1eb86efd__0 = ((2U & ((1U >> 
                                              ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                 & (IData)(
                                                           (0xaaaaccccf0f0ff00ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_hfb017b9d__0)))) 
                                                << 1U) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                      ? 
                                                     (0xa0cU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0))
                                                      : 
                                                     (0xa0cU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0)))))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  & (IData)(
                                                            (0xaaaaccccf0f0ff00ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hed13b60d__0)))) 
                                                 << 1U) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                       ? 
                                                      (0xa0cU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0))
                                                       : 
                                                      (0xa0cU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0))))))));
    vlSelf->__VdfgTmp_h16df2209__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hed13b60d__0)))));
    vlSelf->wasmetal_core__DOT___055924_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0c7e8da3__0))));
    vlSelf->__VdfgTmp_hfa157860__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0xaaaaccccf0f0ff00ULL 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0c7e8da3__0)))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h158bc821__0))
                                                     : 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h1390519c__0)))));
    vlSelf->__VdfgTmp_h7e1fafed__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3418aecb__0)))));
    vlSelf->wasmetal_core__DOT___055702_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3418aecb__0))));
    vlSelf->wasmetal_core__DOT___051935_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h051dc5dd__0))));
    vlSelf->wasmetal_core__DOT___055357_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h051dc5dd__0))));
    vlSelf->wasmetal_core__DOT___055392_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf618fe17__0))));
    vlSelf->wasmetal_core__DOT___055884_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2ada8d2f__0))));
    vlSelf->wasmetal_core__DOT___055455_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2ada8d2f__0))));
    vlSelf->wasmetal_core__DOT___055899_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he5945a68__0))));
    vlSelf->wasmetal_core__DOT___055471_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he5945a68__0))));
    vlSelf->wasmetal_core__DOT___055803_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha8c0c19d__0))));
    vlSelf->wasmetal_core__DOT___055531_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha8c0c19d__0))));
    vlSelf->wasmetal_core__DOT___055843_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefdefca0__0))));
    vlSelf->wasmetal_core__DOT___055700_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefdefca0__0))));
    vlSelf->wasmetal_core__DOT___055390_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h91b07825__0))));
    vlSelf->wasmetal_core__DOT___055886_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he2ba4454__0))));
    vlSelf->wasmetal_core__DOT___055453_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he2ba4454__0))));
    vlSelf->wasmetal_core__DOT___009877_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc2ad9167__0))));
    vlSelf->__VdfgTmp_hb6a6380e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0xaaaaccccf0f0ff00ULL 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc2ad9167__0)))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0))
                                                     : 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)))));
    vlSelf->wasmetal_core__DOT___008857_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h70bc0e9e__0))));
    vlSelf->wasmetal_core__DOT___009339_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h70bc0e9e__0))));
    vlSelf->wasmetal_core__DOT___009354_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf74c6a47__0))));
    vlSelf->__VdfgTmp_h900f682d__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h042cd865__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf74c6a47__0)))));
    vlSelf->wasmetal_core__DOT___009861_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf4d4c7d0__0))));
    vlSelf->wasmetal_core__DOT___008931_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf4d4c7d0__0))));
    vlSelf->__VdfgTmp_h12f500a7__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h042cd865__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h70291c6e__0)))));
    vlSelf->wasmetal_core__DOT___009369_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h70291c6e__0))));
    vlSelf->wasmetal_core__DOT___009382_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h850327e3__0))));
    vlSelf->__VdfgTmp_hd77eff94__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h850327e3__0)))));
    vlSelf->wasmetal_core__DOT___009391_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h950f0cb0__0))));
    vlSelf->__VdfgTmp_h37c9f429__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7267e294__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h950f0cb0__0)))));
    vlSelf->wasmetal_core__DOT___009032_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd89c9b51__0))));
    vlSelf->wasmetal_core__DOT___009066_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hdd777bec__0))));
    vlSelf->wasmetal_core__DOT___008832_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hdd777bec__0))));
    vlSelf->wasmetal_core__DOT___008858_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h69785613__0))));
    vlSelf->wasmetal_core__DOT___009089_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h69785613__0))));
    vlSelf->wasmetal_core__DOT___009351_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2c35a4fb__0))));
    vlSelf->wasmetal_core__DOT___008899_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2c35a4fb__0))));
    vlSelf->wasmetal_core__DOT___009123_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf17c2029__0))));
    vlSelf->wasmetal_core__DOT___008928_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf17c2029__0))));
    vlSelf->wasmetal_core__DOT___009204_ = (1U & (0xc05U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008901_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xcaU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb307080d__0))))))));
    if (vlSelf->wasmetal_core__DOT___007854_) {
        vlSelf->wasmetal_core__DOT___009068_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007866_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h79214203__0))));
        vlSelf->wasmetal_core__DOT___008836_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                   | (0xdU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h79214203__0))));
        vlSelf->wasmetal_core__DOT___008959_ = (1U 
                                                & (IData)(
                                                          (0x555533330f0f00ffULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hee6f9dc2__0))));
        vlSelf->wasmetal_core__DOT___009366_ = (1U 
                                                & (IData)(
                                                          (0xaaaaccccf0f0ff00ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hee6f9dc2__0))));
    } else {
        if (vlSelf->wasmetal_core__DOT___007866_) {
            vlSelf->wasmetal_core__DOT___009068_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_h5629f5f8__0)));
            vlSelf->wasmetal_core__DOT___008836_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h5629f5f8__0)));
        } else {
            vlSelf->wasmetal_core__DOT___009068_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_h6405266c__0)));
            vlSelf->wasmetal_core__DOT___008836_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h6405266c__0)));
        }
        vlSelf->wasmetal_core__DOT___008959_ = 0U;
        vlSelf->wasmetal_core__DOT___009366_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___009218_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009480_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009478_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007846_)))));
    vlSelf->wasmetal_core__DOT___009379_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5618ebf3__0))));
    vlSelf->wasmetal_core__DOT___008991_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5618ebf3__0))));
    vlSelf->wasmetal_core__DOT___008932_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  (0xfff5fff3U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9bf7e2f7__0))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008935_))));
    vlSelf->wasmetal_core__DOT___006194_ = (1U & ((~ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127519___O) 
                                                     >> 1U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf9e966c8__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf9e966c8__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006232_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006039_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006038_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005783_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005782_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005781_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005780_)))))))))));
    vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023188_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128884___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b35__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b34__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b33__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b32__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036490_)))));
    vlSelf->wasmetal_core__DOT___036494_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b35__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_he6069ba9__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h69683dae__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h42022071__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__0__KET__ 
        = ((0xf10eU >> (IData)(vlSelf->__VdfgTmp_ha1b196f5__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023013_));
    vlSelf->wasmetal_core__DOT___059445_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff00aaaafc0cfc0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0x3500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058241_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058242_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O) 
                                                                                >> 3U))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                ? 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e80d283__0))))
                                                                : 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e80d283__0)))))))))));
    vlSelf->wasmetal_core__DOT___017482_ = (1U & ((0xeee0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017794_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017623_))))) 
                                                  & ((0xeee0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017676_))))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___013613_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013612_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013611_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xeee0U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015665_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017716_))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((0xeee0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017610_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017652_))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0xeee0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057694_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017756_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015658_))))))))))))))));
    vlSelf->wasmetal_core__DOT___058980_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057710_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057719_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057722_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015677_)))))))));
    vlSelf->wasmetal_core__DOT___013378_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057722_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6a49916d__0)))));
    wasmetal_core__DOT___058981_ = (1U & (0xeeeef0ffU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017576_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013519_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9ce496ce__0))))));
    vlSelf->wasmetal_core__DOT___017483_ = (1U & ((
                                                   (0xf70000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015630_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013319_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___013549_)))))) 
                                                   & (IData)(
                                                             (0x4000000000000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___013540_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013539_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013538_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & (((IData)(vlSelf->wasmetal_core__DOT___013549_)
                                                                              ? (IData)(
                                                                                (0xeee0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013548_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013547_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013546_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013545_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9b65f112__0)))))))
                                                                              : 
                                                                             (1U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013548_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___013547_)))) 
                                                                            << 2U)) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x8fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015629_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015622_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013335_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013503_)))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xf3f5f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017531_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he3b69f57__0))))))))))))) 
                                                  & ((0x8000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017385_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017339_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057727_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017427_))))) 
                                                     & (IData)(
                                                               (0xe000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___013524_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013523_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013522_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015645_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015646_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015878_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015812_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057732_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015654_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015635_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8523194f__0))))))))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013519_)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128848___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h0bc68a5e__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036315_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h60102cdd__0)) 
                                                << 1U)) 
                                         | (1U & (8U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h8fcc0329__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h8fcc0329__0))) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___036342_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h0bc68a5e__0)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___013208_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057703_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he3b69f57__0)))));
    wasmetal_core__DOT___013207_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057707_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9cde2904__0)))));
    wasmetal_core__DOT___057950_ = (1U & (IData)((0xff00aaaaccccf0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha3ec838c__0)))))));
    __VdfgTmp_h7a1a10ae__0 = ((4U & ((0x53U >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                     << 2U)) | (IData)(vlSelf->__VdfgTmp_hed9f0c33__0));
    wasmetal_core__DOT___058056_ = (1U & (IData)((0xf0f0aaaaff00ccccULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hff1952b3__0))))))));
    wasmetal_core__DOT___058042_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014360_))));
    vlSelf->__VdfgTmp_hb0772ee2__0 = (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013631_));
    vlSelf->wasmetal_core__DOT___058037_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014357_))));
    vlSelf->__VdfgTmp_hd09be45d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014358_));
    vlSelf->wasmetal_core__DOT___014372_ = (1U & (0xaaccf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057934_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)))))))));
    __VdfgTmp_hb2511b98__0 = (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___014453_) 
                                           << 2U) | 
                                          ((2U & ((0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04542857__0)) 
                                                  << 1U)) 
                                           | (1U & 
                                              (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0)))))));
    vlSelf->wasmetal_core__DOT___014371_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057935_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he122bc0f__0))))));
    vlSelf->wasmetal_core__DOT___014461_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057934_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057935_)))));
    vlSelf->wasmetal_core__DOT___014374_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014460_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdb52a936__0))))));
    wasmetal_core__DOT___014383_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014460_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he122bc0f__0))))));
    wasmetal_core__DOT___014447_ = (1U & (0xaaccf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057914_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0x53U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)))))))));
    __VdfgTmp_hba696de2__0 = (((IData)(vlSelf->wasmetal_core__DOT___057914_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057913_));
    wasmetal_core__DOT___014382_ = (1U & (0xaaccf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057929_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hdb52a936__0))))));
    wasmetal_core__DOT___019684_ = (1U & (0xf011U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___057913_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057912_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057911_))))));
    wasmetal_core__DOT___057915_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057912_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057911_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057910_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___057909_)))))));
    vlSelf->wasmetal_core__DOT___019683_ = (1U & (0x110fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057928_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057909_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057910_))))));
    __VdfgTmp_h9dc510af__0 = (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057928_));
    vlSelf->wasmetal_core__DOT___014373_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057930_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057929_)))));
    vlSelf->wasmetal_core__DOT___019676_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057931_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h91cdf6cd__0))))));
    __VdfgTmp_h98614ec5__0 = (((IData)(vlSelf->wasmetal_core__DOT___057930_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057931_));
    wasmetal_core__DOT___057936_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057933_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h91cdf6cd__0))))));
    __VdfgTmp_h8453cf34__0 = (((IData)(vlSelf->wasmetal_core__DOT___057933_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057932_));
    wasmetal_core__DOT___014381_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057932_))));
    vlSelf->wasmetal_core__DOT___071749_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014446_))));
    vlSelf->__VdfgTmp_h51e83899__0 = (((IData)(vlSelf->wasmetal_core__DOT___014354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014353_));
    vlSelf->wasmetal_core__DOT___005668_ = (1U & (IData)(
                                                         (0xdf2f20d00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))));
    wasmetal_core__DOT___014454_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057916_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0x53U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)))))))));
    vlSelf->wasmetal_core__DOT___019668_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057916_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014453_)))));
    vlSelf->wasmetal_core__DOT___035645_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b33__05d))));
    vlSelf->wasmetal_core__DOT___057927_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)))))))))));
    wasmetal_core__DOT___058054_ = (1U & (IData)((0xaaaaccccff00f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)))))))))));
    wasmetal_core__DOT___058027_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)))))))))));
    wasmetal_core__DOT___058032_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)))))))))));
    vlSelf->wasmetal_core__DOT___057940_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057939_)))))))));
    wasmetal_core__DOT___058023_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058019_)))))))));
    vlSelf->wasmetal_core__DOT___035634_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d))));
    vlSelf->wasmetal_core__DOT___058041_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x53U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7297059c__0))))))));
    wasmetal_core__DOT___058055_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058010_)))))))));
    vlSelf->wasmetal_core__DOT___058028_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0)))))))))));
    vlSelf->wasmetal_core__DOT___058033_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hff1952b3__0))))))));
    vlSelf->wasmetal_core__DOT___058024_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hff1952b3__0))))))));
    vlSelf->wasmetal_core__DOT___035633_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d))));
    vlSelf->wasmetal_core__DOT___035622_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d))));
    vlSelf->wasmetal_core__DOT___058059_ = (1U & (0xf0f000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058031_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057978_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___014455_)))))));
    vlSelf->wasmetal_core__DOT___057971_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057957_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057956_)))));
    vlSelf->wasmetal_core__DOT___058026_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057956_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hed9f0c33__0))))));
    vlSelf->wasmetal_core__DOT___035621_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d))));
    wasmetal_core__DOT___057979_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0x53U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h9195d647__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___057969_)))));
    vlSelf->wasmetal_core__DOT___035671_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d))));
    __VdfgTmp_h63472758__0 = (((IData)(vlSelf->wasmetal_core__DOT___057969_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_ha1cc8027__0));
    vlSelf->wasmetal_core__DOT___035670_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d))));
    wasmetal_core__DOT___057977_ = (1U & (0xf0f000bbU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057968_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057963_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7dbcfedb__0))))));
    vlSelf->wasmetal_core__DOT___035669_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d))));
    wasmetal_core__DOT___014440_ = (1U & (0x8000U >> 
                                          ((8U & ((0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((0x53U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0)) 
                                                << 2U)) 
                                              | ((2U 
                                                  & ((0x53U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057962_))))));
    vlSelf->wasmetal_core__DOT___058061_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057962_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha3ec838c__0)))))));
    wasmetal_core__DOT___057970_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___057963_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___057962_)))));
    vlSelf->wasmetal_core__DOT___035664_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d))));
    vlSelf->wasmetal_core__DOT___035667_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b53__05d))));
    vlSelf->wasmetal_core__DOT___035666_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b52__05d))));
    vlSelf->wasmetal_core__DOT___035665_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b51__05d))));
    vlSelf->wasmetal_core__DOT___035663_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d))));
    vlSelf->wasmetal_core__DOT___035662_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b49__05d))));
    vlSelf->wasmetal_core__DOT___035661_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b48__05d))));
    vlSelf->wasmetal_core__DOT___035660_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d))));
    vlSelf->wasmetal_core__DOT___035658_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d))));
    vlSelf->wasmetal_core__DOT___035657_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d))));
    vlSelf->wasmetal_core__DOT___035656_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d))));
    vlSelf->wasmetal_core__DOT___035655_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d))));
    vlSelf->wasmetal_core__DOT___035654_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b41__05d))));
    vlSelf->wasmetal_core__DOT___035652_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b40__05d))));
    vlSelf->wasmetal_core__DOT___035651_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b39__05d))));
    vlSelf->wasmetal_core__DOT___035650_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d))));
    vlSelf->wasmetal_core__DOT___035649_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b37__05d))));
    vlSelf->wasmetal_core__DOT___035648_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b36__05d))));
    vlSelf->wasmetal_core__DOT___035647_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b35__05d))));
    vlSelf->wasmetal_core__DOT___035646_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b34__05d))));
    vlSelf->wasmetal_core__DOT___035644_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b32__05d))));
    vlSelf->wasmetal_core__DOT___035643_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b31__05d))));
    vlSelf->wasmetal_core__DOT___035641_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b30__05d))));
    vlSelf->wasmetal_core__DOT___035640_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b29__05d))));
    vlSelf->wasmetal_core__DOT___035639_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d))));
    vlSelf->wasmetal_core__DOT___035638_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d))));
    vlSelf->wasmetal_core__DOT___035637_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d))));
    vlSelf->wasmetal_core__DOT___035635_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d))));
    vlSelf->wasmetal_core__DOT___035632_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d))));
    vlSelf->wasmetal_core__DOT___035620_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b1__05d))));
    vlSelf->wasmetal_core__DOT___009359_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009358_)))));
    vlSelf->wasmetal_core__DOT___062342_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h890a41f9__0))));
    vlSelf->wasmetal_core__DOT___010627_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h890a41f9__0)))));
    vlSelf->wasmetal_core__DOT___009349_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009348_)))));
    vlSelf->wasmetal_core__DOT___062422_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009757_))));
    vlSelf->wasmetal_core__DOT___055555_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009267_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009757_)))));
    vlSelf->wasmetal_core__DOT___009336_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009335_)))));
    vlSelf->wasmetal_core__DOT___062356_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h792a3800__0))));
    vlSelf->__VdfgTmp_heedd871e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h792a3800__0)));
    vlSelf->wasmetal_core__DOT___062327_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b5a0ff3__0))));
    vlSelf->wasmetal_core__DOT___056271_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b5a0ff3__0)))));
    vlSelf->wasmetal_core__DOT___062347_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h32990406__0))));
    vlSelf->wasmetal_core__DOT___056227_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h32990406__0)))));
    vlSelf->wasmetal_core__DOT___062432_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009308_))));
    vlSelf->wasmetal_core__DOT___008808_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009309_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___009308_))))));
    vlSelf->wasmetal_core__DOT___062369_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h41d1df16__0))));
    vlSelf->wasmetal_core__DOT___062413_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009225_))));
    vlSelf->wasmetal_core__DOT___009364_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009363_)))));
    vlSelf->wasmetal_core__DOT___062367_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he74af19b__0)))));
    vlSelf->wasmetal_core__DOT___013087_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he74af19b__0))))));
    vlSelf->wasmetal_core__DOT___062353_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb864fb42__0))));
    vlSelf->wasmetal_core__DOT___009868_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb864fb42__0))))));
    vlSelf->wasmetal_core__DOT___062350_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h27200c45__0))));
    vlSelf->__VdfgTmp_h5cf792c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h27200c45__0)));
    vlSelf->wasmetal_core__DOT___062337_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha3cb0627__0))));
    vlSelf->wasmetal_core__DOT___010626_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha3cb0627__0)))));
    vlSelf->wasmetal_core__DOT___009739_ = (1U & (IData)(
                                                         (0xf0f0ff0011111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0x555533330f0f00ffULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hae568380__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007941_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007940_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4bfa77b1__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc3aac618__0))))))));
    vlSelf->wasmetal_core__DOT___008547_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055459_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055458_))));
    vlSelf->wasmetal_core__DOT___008844_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055546_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055545_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055550_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055549_)))))));
    vlSelf->wasmetal_core__DOT___008971_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055354_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055353_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha33784b5__0))))));
    wasmetal_core__DOT___056268_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055745_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055744_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055743_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055742_)))))));
    vlSelf->wasmetal_core__DOT___009001_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055395_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h63940f3b__0))))));
    wasmetal_core__DOT___009024_ = (1U & (0xfff01111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055458_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055459_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h33e7f237__0))))));
    vlSelf->wasmetal_core__DOT___009047_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055898_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055897_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hddf47e90__0))))));
    vlSelf->wasmetal_core__DOT___055490_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf1111U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055475_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055474_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055473_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055472_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055481_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008824_)))))))));
    vlSelf->wasmetal_core__DOT___009698_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055549_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055550_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb6e33d53__0))))));
    vlSelf->wasmetal_core__DOT___009081_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055550_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055549_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055548_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055547_)))))));
    vlSelf->wasmetal_core__DOT___009094_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055818_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055817_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h16df2209__0))))));
    wasmetal_core__DOT___009150_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055945_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf618fe17__0)))) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055396_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055395_)))))));
    vlSelf->wasmetal_core__DOT___009107_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055925_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055924_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5e3623a6__0))))));
    vlSelf->wasmetal_core__DOT___010622_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf1111U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055631_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055630_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfa157860__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055636_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008920_)))))))));
    wasmetal_core__DOT___009132_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055846_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055845_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7e1fafed__0))))));
    vlSelf->wasmetal_core__DOT___008758_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055704_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                               ? 
                                                              (0xa0cU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0))
                                                               : 
                                                              (0xa0cU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055702_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055701_)))))));
    vlSelf->wasmetal_core__DOT___055717_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051314_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051313_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051935_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051934_)))))));
    vlSelf->wasmetal_core__DOT___009139_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055357_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055354_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055353_)))))));
    vlSelf->wasmetal_core__DOT___055748_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055743_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055742_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055392_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055391_)))))));
    wasmetal_core__DOT___008882_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___055577_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055576_))));
    vlSelf->wasmetal_core__DOT___009167_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055885_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055884_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h33e7f237__0))))));
    vlSelf->wasmetal_core__DOT___008917_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055627_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055626_))));
    vlSelf->wasmetal_core__DOT___009178_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055900_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055899_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055898_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055897_)))))));
    vlSelf->wasmetal_core__DOT___009197_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055548_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055547_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055531_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055530_)))))));
    wasmetal_core__DOT___008972_ = (1U & (0x1111fff0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051932_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055358_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055357_)))))));
    vlSelf->wasmetal_core__DOT___009002_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055392_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055391_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055390_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055389_)))))));
    wasmetal_core__DOT___009025_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055887_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055886_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055885_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055884_)))))));
    __VdfgTmp_hcb32e64d__0 = ((2U & ((0xf1111U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055453_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055452_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                              & (IData)(
                                                                        (0xaaaaccccf0f0ff00ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd89c9b51__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                   ? 
                                                                  (0xa0cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0))
                                                                   : 
                                                                  (0xa0cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0))))))))) 
                                     << 1U)) | (1U 
                                                & (0x110fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                ? 
                                                               (0xa0cU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4c1297e6__0))
                                                                : 
                                                               (0xa0cU 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0xa0c0000U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)))))))));
    vlSelf->wasmetal_core__DOT___009048_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009878_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009877_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055900_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055899_)))))));
    wasmetal_core__DOT___009699_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055804_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055803_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008856_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___008857_)))))));
    __VdfgTmp_h2c715ba9__0 = (((IData)(vlSelf->wasmetal_core__DOT___009339_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009338_));
    wasmetal_core__DOT___009274_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055577_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055576_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009354_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009353_)))))));
    vlSelf->wasmetal_core__DOT___009095_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055576_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055577_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h900f682d__0))))));
    vlSelf->wasmetal_core__DOT___009108_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055626_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055627_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009860_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009861_)))))));
    wasmetal_core__DOT___009133_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055844_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055843_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h12f500a7__0))))));
    vlSelf->wasmetal_core__DOT___008757_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055700_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055699_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009369_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009368_)))))));
    vlSelf->wasmetal_core__DOT___009307_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051932_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009382_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009381_)))))));
    wasmetal_core__DOT___009140_ = (1U & (0xfff01111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051932_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd77eff94__0))))));
    __VdfgTmp_ha336bc52__0 = (((IData)(vlSelf->wasmetal_core__DOT___009391_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009392_));
    wasmetal_core__DOT___009151_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055947_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h91b07825__0)))) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h37c9f429__0))))));
    wasmetal_core__DOT___009168_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009031_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009032_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055887_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055886_)))))));
    __VdfgTmp_h351522cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___009066_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009067_));
    __VdfgTmp_h8170c8be__0 = (((IData)(vlSelf->wasmetal_core__DOT___009067_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009066_));
    wasmetal_core__DOT___009886_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___009163_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009017_))))));
    __VdfgTmp_hca62a78c__0 = (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009016_));
    wasmetal_core__DOT___009020_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h37c9f429__0))))));
    __VdfgTmp_h3ae7f513__0 = (((IData)(vlSelf->wasmetal_core__DOT___008859_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008858_));
    __VdfgTmp_hd28f0b72__0 = (((IData)(vlSelf->wasmetal_core__DOT___009089_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009090_));
    __VdfgTmp_h29905bdd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009352_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009351_));
    __VdfgTmp_h0e20e5e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___008900_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008899_));
    vlSelf->__VdfgTmp_h9f78711b__0 = (((IData)(vlSelf->wasmetal_core__DOT___009123_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009124_));
    __VdfgTmp_h115316d8__0 = ((4U & ((IData)((0xf0f0f050f0f0f03ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___009124_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___009123_)));
    __VdfgTmp_h8ed306e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___008929_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008928_));
    wasmetal_core__DOT___009447_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((0xf5f30000U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009034_))))));
    wasmetal_core__DOT___009243_ = (1U & (0xeeeefff0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009034_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((0xf5f30000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009031_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009032_)))))));
    vlSelf->wasmetal_core__DOT___056124_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008901_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb307080d__0)))))))
                                                    : 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h7bd92bc0__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009465_))))));
    vlSelf->wasmetal_core__DOT___061181_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056124_))));
    vlSelf->__VdfgTmp_h2275929a__0 = (((IData)(vlSelf->wasmetal_core__DOT___056124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    wasmetal_core__DOT___009414_ = (1U & (IData)((0x1f1fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055575_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_ha295f108__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___009351_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___009352_)))))))));
    vlSelf->wasmetal_core__DOT___009180_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_ha296f98c__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009068_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008835_)))))))));
    vlSelf->wasmetal_core__DOT___056114_ = (1U & ((IData)(
                                                          (0xffff8000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd3ee6e40__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? (IData)(
                                                                (0x33ffaaff0fff0fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009449_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha296f98c__0)) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008836_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___008835_))))))))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009449_)))));
    __VdfgTmp_h2b908e25__0 = (((IData)(vlSelf->wasmetal_core__DOT___008836_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008831_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008832_)));
    wasmetal_core__DOT___009134_ = (1U & (IData)((0x1f1fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055932_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_he25b62bf__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008958_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___008959_)))))))));
    wasmetal_core__DOT___008941_ = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                               ? (0xfeffU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h08b4abe6__0))
                                               : (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h315e9115__0)))) 
                                          & (IData)(
                                                    (0x1111ffff000fffffULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008959_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008958_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h12f500a7__0)))))))));
    if (vlSelf->wasmetal_core__DOT___007847_) {
        if (vlSelf->wasmetal_core__DOT___007844_) {
            vlSelf->wasmetal_core__DOT___056133_ = 
                (1U & (0xcdU >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___009480_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___009478_))))));
            vlSelf->wasmetal_core__DOT___056048_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                             << 2U) 
                                            | (IData)(__VdfgTmp_hcb32e64d__0)))));
        } else {
            vlSelf->wasmetal_core__DOT___056133_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h7ca1d027__0))));
            vlSelf->wasmetal_core__DOT___056048_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009322_))));
        }
        if (vlSelf->wasmetal_core__DOT___007846_) {
            wasmetal_core__DOT___056103_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008991_))))));
            vlSelf->wasmetal_core__DOT___011267_ = 
                (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                  << 2U) | ((2U & (
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h63940f3b__0)) 
                                                   << 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___009659_)))));
            vlSelf->wasmetal_core__DOT___011286_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                  << 2U) | ((2U & (
                                                   (1U 
                                                    >> 
                                                    ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                       & (IData)(
                                                                 (0x555533330f0f00ffULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hae568380__0)))) 
                                                      << 1U) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                            ? 
                                                           (0x503U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hd4d63a34__0))
                                                            : 
                                                           (0x503U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h2567a16a__0)))))) 
                                                   << 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___009659_)))));
            vlSelf->wasmetal_core__DOT___056111_ = 
                (1U & (IData)(wasmetal_core__DOT___009447_));
        } else {
            wasmetal_core__DOT___056103_ = (1U & (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___009147_)));
            vlSelf->wasmetal_core__DOT___011267_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___009150_)));
            vlSelf->wasmetal_core__DOT___011286_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009001_)));
            vlSelf->wasmetal_core__DOT___056111_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009175_)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___056133_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009479_)))));
        wasmetal_core__DOT___056103_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009427_)));
        vlSelf->wasmetal_core__DOT___056048_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009323_)))));
        if (vlSelf->wasmetal_core__DOT___007846_) {
            vlSelf->wasmetal_core__DOT___011267_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___009151_)));
            vlSelf->wasmetal_core__DOT___011286_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___009002_)));
        } else {
            vlSelf->wasmetal_core__DOT___011267_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___009886_)));
            vlSelf->wasmetal_core__DOT___011286_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___009020_)));
        }
        vlSelf->wasmetal_core__DOT___056111_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009441_)));
    }
    if (vlSelf->wasmetal_core__DOT___007846_) {
        wasmetal_core__DOT___009387_ = (1U & (0x1111fff0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009392_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009391_)))))));
        wasmetal_core__DOT___009152_ = (1U & (0xfc55U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009163_)))))));
        wasmetal_core__DOT___008884_ = (1U & (0x1111000fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___008900_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008899_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h900f682d__0))))));
        vlSelf->wasmetal_core__DOT___009169_ = (1U 
                                                & (0xfc55U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xf5f30000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009034_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009174_)))))));
        wasmetal_core__DOT___009026_ = (1U & (0xeeeefff0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009034_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((0xf5f30000U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                            << 2U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009032_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009031_)))))));
        wasmetal_core__DOT___008826_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                               ? (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb6a6380e__0))
                                               : (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008831_)))));
    } else {
        wasmetal_core__DOT___009387_ = (1U & (2U >> 
                                              (1U & 
                                               (0x35U 
                                                >> (IData)(vlSelf->__VdfgTmp_hecc250a9__0)))));
        wasmetal_core__DOT___009152_ = (1U & (1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                << 1U) 
                                               | (1U 
                                                  & (0xcaU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0))))));
        wasmetal_core__DOT___008884_ = (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___008901_)));
        vlSelf->wasmetal_core__DOT___009169_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___009175_))));
        wasmetal_core__DOT___009026_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009035_)));
        wasmetal_core__DOT___008826_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                               ? (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___008836_))
                                               : (1U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___008835_))));
    }
    if (vlSelf->wasmetal_core__DOT___007847_) {
        vlSelf->wasmetal_core__DOT___056052_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___008826_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009329_)))))));
        vlSelf->wasmetal_core__DOT___055849_ = (1U 
                                                & (0xaaccf0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x1111000fU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055844_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055843_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h7e1fafed__0))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((1U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___055846_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___055845_))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___008938_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___056052_ = (1U 
                                                & (0x100U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009330_))))));
        vlSelf->wasmetal_core__DOT___055849_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___008941_)));
    }
    vlSelf->wasmetal_core__DOT___009424_ = (1U & (IData)(
                                                         (0x1f1fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055709_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x35U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he25b62bf__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009366_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009367_)))))))));
    __VdfgTmp_h44cf3d5c__0 = (((IData)(vlSelf->wasmetal_core__DOT___009367_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009366_));
    vlSelf->wasmetal_core__DOT___019284_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056133_))));
    vlSelf->wasmetal_core__DOT___056134_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056133_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    __VdfgTmp_hb9a1e459__0 = (((IData)(vlSelf->wasmetal_core__DOT___009218_) 
                               << 2U) | ((2U & ((0xf1111U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055702_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055701_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055700_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___055699_)))))) 
                                                << 1U)) 
                                         | (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008958_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008959_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h12f500a7__0))))))));
    __VdfgTmp_h3c5f3431__0 = ((2U & ((0xf1111U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051935_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051934_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051932_)))))) 
                                     << 1U)) | (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009382_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009381_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009379_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009380_))))))));
    __VdfgTmp_h5c89e2df__0 = (((IData)(vlSelf->wasmetal_core__DOT___009380_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009379_));
    if (vlSelf->wasmetal_core__DOT___007846_) {
        wasmetal_core__DOT___009141_ = (1U & (0xfc55U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009146_)))))));
        wasmetal_core__DOT___008973_ = (1U & (0x1111000fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hd77eff94__0))))));
    } else {
        wasmetal_core__DOT___009141_ = (1U & (1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___009147_))));
        wasmetal_core__DOT___008973_ = (1U & (2U >> 
                                              (1U & 
                                               (0xcaU 
                                                >> (IData)(vlSelf->__VdfgTmp_h6b0a05f6__0)))));
    }
    if (vlSelf->wasmetal_core__DOT___007844_) {
        vlSelf->wasmetal_core__DOT___010650_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0x1f1fff00ff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(
                                                                                (0xa0000000cULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                                                                << 4U)) 
                                                                              | ((8U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7d874977__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008928_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008929_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009417_)))))));
        vlSelf->wasmetal_core__DOT___056062_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                                   ? 
                                                                  (0xf1111U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009354_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009353_) 
                                                                           << 2U) 
                                                                          | (IData)(__VdfgTmp_h29905bdd__0)))))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008901_))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009346_)))))));
        vlSelf->wasmetal_core__DOT___009908_ = (1U 
                                                & (0x3aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___009026_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009923_)))))));
        vlSelf->wasmetal_core__DOT___010649_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___009414_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009412_)))))));
        vlSelf->wasmetal_core__DOT___010648_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0x1111f0f0ff00ff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009069_) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h2b908e25__0)))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009400_)))))));
        vlSelf->wasmetal_core__DOT___056247_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___008941_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009984_)))))));
        vlSelf->wasmetal_core__DOT___010651_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009424_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009422_)))))));
        vlSelf->wasmetal_core__DOT___056001_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h3c5f3431__0))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009224_)))));
        vlSelf->wasmetal_core__DOT___009911_ = (1U 
                                                & (0xc000aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___008973_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009930_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___010650_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009419_)))));
        vlSelf->wasmetal_core__DOT___056062_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009349_));
        vlSelf->wasmetal_core__DOT___009908_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009398_));
        vlSelf->wasmetal_core__DOT___010649_ = (1U 
                                                & (0x200U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8ad90c85__0))))))));
        vlSelf->wasmetal_core__DOT___010648_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009402_)))));
        vlSelf->wasmetal_core__DOT___056247_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009364_));
        vlSelf->wasmetal_core__DOT___010651_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009425_));
        vlSelf->wasmetal_core__DOT___056001_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009225_)))));
        vlSelf->wasmetal_core__DOT___009911_ = (1U 
                                                & (0x200U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb294466b__0))))))));
    }
    if (vlSelf->wasmetal_core__DOT___007846_) {
        if (vlSelf->wasmetal_core__DOT___007858_) {
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___009878_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009877_))));
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___008857_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008856_))));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h2c715ba9__0)));
        } else {
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h8170c8be__0)));
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h3ae7f513__0)));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(__VdfgTmp_hd28f0b72__0)));
        }
        vlSelf->wasmetal_core__DOT___009003_ = (1U 
                                                & (IData)(wasmetal_core__DOT___009020_));
        vlSelf->wasmetal_core__DOT___009853_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009861_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009860_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9f78711b__0))))));
        vlSelf->wasmetal_core__DOT___009109_ = (1U 
                                                & (0xfef0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | (IData)(__VdfgTmp_h115316d8__0)))));
        vlSelf->wasmetal_core__DOT___008921_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008931_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008930_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h8ed306e0__0))))));
        vlSelf->wasmetal_core__DOT___009376_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009382_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009381_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h5c89e2df__0))))));
    } else {
        if (vlSelf->wasmetal_core__DOT___007858_) {
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009068_)));
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___008861_)));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___008861_)));
        } else {
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___008835_)));
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___008860_)));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___008860_)));
        }
        vlSelf->wasmetal_core__DOT___009003_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0xcaU 
                                                       >> (IData)(vlSelf->__VdfgTmp_hecc250a9__0)))));
        vlSelf->wasmetal_core__DOT___009853_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008932_)));
        vlSelf->wasmetal_core__DOT___009109_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (0xcaU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h7d874977__0))))));
        vlSelf->wasmetal_core__DOT___008921_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008932_)));
        vlSelf->wasmetal_core__DOT___009376_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6b0a05f6__0)))));
    }
    __VdfgTmp_hb4d0429b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008932_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009471_));
    __VdfgTmp_ha28c8f63__0 = (((IData)(vlSelf->wasmetal_core__DOT___009459_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008860_)));
    wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023189_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___060270_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058496_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128884___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b36__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036494_));
    vlSelf->wasmetal_core__DOT___059355_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hba6f19f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h69683dae__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hba6f19f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h69683dae__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                ? 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h647a213f__0))))
                                                                : 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h647a213f__0)))))))))));
    vlSelf->wasmetal_core__DOT___059254_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                  ? 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_had1ad578__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h42022071__0))))
                                                                  : 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_had1ad578__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h42022071__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                   ? 
                                                                  (0xc0c5U 
                                                                   >> 
                                                                   ((8U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h632fa2db__0))))
                                                                   : 
                                                                  (0xc0c5U 
                                                                   >> 
                                                                   ((8U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h632fa2db__0))))))))))));
    vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hed92d4b0__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___017485_ = ((1U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___057726_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017601_))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___013381_) 
                                               & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013380_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013379_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xefef00efU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057719_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017610_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h219534f4__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xefef00efU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017598_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017576_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9ce496ce__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h310e5162__0)))))))))))));
    vlSelf->wasmetal_core__DOT___017591_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058982_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058981_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058980_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___017601_)) 
                                                                         & (IData)(
                                                                                (0xb0bbb0bb0000b0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017600_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017599_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017598_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015681_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xdU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___057726_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057711_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xefefef00efefefefULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3d32f603__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h9110e1f3__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036342_));
    wasmetal_core__DOT___057713_ = (1U & ((IData)((0xef0000ffffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___057697_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057696_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015781_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfacd537a__0))))))) 
                                          & (IData)(
                                                    (0xcc000000f5ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                                       << 5U) 
                                                      | (((IData)(wasmetal_core__DOT___013208_) 
                                                          << 4U) 
                                                         | (((IData)(wasmetal_core__DOT___013207_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013206_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013205_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___013204_))))))))));
    vlSelf->wasmetal_core__DOT___057985_ = (1U & (0xfefeff00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___057950_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)))))))));
    vlSelf->wasmetal_core__DOT___058030_ = (1U & (IData)(
                                                         (0xccccaaaaf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a1a10ae__0)))))));
    vlSelf->wasmetal_core__DOT___058035_ = (1U & (IData)(
                                                         (0xff00ccaaaaf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058031_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h7a1a10ae__0)))))));
    vlSelf->__VdfgTmp_ha0dc9087__0 = (((IData)(vlSelf->wasmetal_core__DOT___058057_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058056_));
    vlSelf->wasmetal_core__DOT___058045_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014358_))));
    vlSelf->wasmetal_core__DOT___058040_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058037_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xccccc0c0f000aa00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)) 
                                                                            << 3U)) 
                                                                        | ((4U 
                                                                            & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0))))))))))))));
    vlSelf->wasmetal_core__DOT___058068_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h56cb633a__0))))))));
    vlSelf->wasmetal_core__DOT___057906_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0))))));
    vlSelf->wasmetal_core__DOT___057907_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xa0c0f0f0f0f0f0fULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0)) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057787_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0)) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_ha1f1e621__0))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xe000000000000000ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((0x53U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0)) 
                                                                         << 5U)) 
                                                                     | ((0x10U 
                                                                         & ((0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0)) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((0x80U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heb875033__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h04659776__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014358_)))))))))))));
    vlSelf->wasmetal_core__DOT___019685_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hb2511b98__0)))));
    vlSelf->__VdfgTmp_h5970a25a__0 = (((IData)(vlSelf->wasmetal_core__DOT___014372_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014371_));
    vlSelf->__VdfgTmp_he15aac2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014374_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014371_));
    if (vlSelf->wasmetal_core__DOT___014357_) {
        vlSelf->wasmetal_core__DOT___019697_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014461_)));
        vlSelf->wasmetal_core__DOT___014448_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___014454_)));
    } else {
        vlSelf->wasmetal_core__DOT___019697_ = (1U 
                                                & (IData)(wasmetal_core__DOT___014383_));
        vlSelf->wasmetal_core__DOT___014448_ = (1U 
                                                & (0xf0f0aaccU 
                                                   >> (IData)(__VdfgTmp_hb2511b98__0)));
    }
    vlSelf->wasmetal_core__DOT___019669_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hba696de2__0))));
    vlSelf->__VdfgTmp_hd4b4ff41__0 = (((IData)(wasmetal_core__DOT___014383_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014382_));
    __VdfgTmp_h32a58059__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                           << 1U) | (IData)(wasmetal_core__DOT___019684_))));
    vlSelf->wasmetal_core__DOT___019688_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___014447_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___019684_)))));
    vlSelf->wasmetal_core__DOT___014356_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057915_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hba696de2__0))))));
    __VdfgTmp_h836204cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019683_) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___014447_)))));
    vlSelf->wasmetal_core__DOT___071762_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019683_))))));
    vlSelf->wasmetal_core__DOT___071742_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___014447_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___019684_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014446_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019683_)))))))));
    vlSelf->__VdfgTmp_h06185798__0 = (((IData)(wasmetal_core__DOT___019684_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019683_));
    vlSelf->wasmetal_core__DOT___019670_ = (1U & (0xf077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___057915_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h9dc510af__0)))));
    wasmetal_core__DOT___014355_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                            << 2U) 
                                           | (IData)(__VdfgTmp_h9dc510af__0))));
    __VdfgTmp_hbb8e97f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___014374_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014373_));
    __VdfgTmp_hf87abe5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014373_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019676_));
    vlSelf->wasmetal_core__DOT___019696_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___014382_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h98614ec5__0))))));
    vlSelf->wasmetal_core__DOT___014384_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057936_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h98614ec5__0))))));
    wasmetal_core__DOT___019677_ = (1U & (0x3500U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h8453cf34__0)))));
    wasmetal_core__DOT___014375_ = (1U & (0xf0f0ccaaU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019676_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h8453cf34__0))))));
    vlSelf->wasmetal_core__DOT___019758_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___014381_))))));
    __VdfgTmp_h3fbd9b9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                               << 1U) | (IData)(wasmetal_core__DOT___014381_));
    __VdfgTmp_h78b7c78d__0 = (((IData)(wasmetal_core__DOT___057936_) 
                               << 1U) | (IData)(wasmetal_core__DOT___014381_));
    wasmetal_core__DOT___051265_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005668_))));
    vlSelf->__VdfgTmp_h51855551__0 = (((IData)(vlSelf->wasmetal_core__DOT___014354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019668_));
    vlSelf->wasmetal_core__DOT___014359_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019668_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057927_))))));
    vlSelf->wasmetal_core__DOT___071751_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___014454_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058054_))))));
    vlSelf->wasmetal_core__DOT___019710_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014372_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058027_))))));
    vlSelf->wasmetal_core__DOT___019706_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057927_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058032_))))));
    vlSelf->wasmetal_core__DOT___014385_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014461_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057940_))))));
    vlSelf->wasmetal_core__DOT___019698_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057940_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058023_))))));
    vlSelf->wasmetal_core__DOT___058050_ = (1U & (0xfafcffffU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058042_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058041_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058043_)))))));
    __VdfgTmp_hf3511969__0 = (((IData)(wasmetal_core__DOT___058055_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058054_));
    vlSelf->__VdfgTmp_h17641de8__0 = (((IData)(vlSelf->wasmetal_core__DOT___058028_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058027_));
    vlSelf->__VdfgTmp_hb21fd03f__0 = (((IData)(vlSelf->wasmetal_core__DOT___058033_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058032_));
    vlSelf->__VdfgTmp_h3ea29050__0 = (((IData)(vlSelf->wasmetal_core__DOT___058024_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058023_));
    vlSelf->wasmetal_core__DOT___071750_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058059_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058057_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___058056_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___058055_)))))))));
    vlSelf->wasmetal_core__DOT___057980_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057978_)))));
    vlSelf->wasmetal_core__DOT___057972_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h63472758__0))))));
    vlSelf->__VdfgTmp_hfa4aa235__0 = ((2U & ((IData)(
                                                     (0xf4f400ff00000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                           << 4U) 
                                                          | (IData)(__VdfgTmp_h63472758__0))))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___057957_)))));
    vlSelf->wasmetal_core__DOT___058060_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057977_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___057979_)))));
    vlSelf->wasmetal_core__DOT___057981_ = (1U & (0xaaccf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057977_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057962_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)))))))));
    vlSelf->wasmetal_core__DOT___058051_ = (1U & ((1U 
                                                   & (0x53U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)))
                                                   ? (IData)(
                                                             (0xfeccaa00c0c00000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                   << 5U)) 
                                                               | ((0x10U 
                                                                   & ((8U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                                      << 4U)) 
                                                                  | (((IData)(wasmetal_core__DOT___014440_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xb00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057969_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9195d647__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057963_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha1cc8027__0))))))))))))))
                                                   : 
                                                  (0x80U 
                                                   >> 
                                                   ((4U 
                                                     & ((8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd09be45d__0)))));
    vlSelf->__VdfgTmp_h625062d0__0 = (((IData)(wasmetal_core__DOT___057970_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014456_));
    vlSelf->wasmetal_core__DOT___057975_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057970_))));
    vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035620_) 
           | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b1__05d));
    vlSelf->wasmetal_core__DOT___009866_ = (1U & (0xf3f5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_heedd871e__0))));
    vlSelf->wasmetal_core__DOT___011268_ = (1U & (0xf3f5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5cf792c3__0))));
    vlSelf->wasmetal_core__DOT___010624_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009739_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1eb86efd__0))))))));
    vlSelf->wasmetal_core__DOT___056269_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056268_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                               & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hae568380__0)))) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd4d63a34__0))
                                                                                 : 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2567a16a__0)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055747_)))))))));
    vlSelf->wasmetal_core__DOT___056160_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___009024_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                               & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7737ac68__0)))) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7c4f884__0))
                                                                                 : 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4d366d59__0)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056157_)))))))));
    vlSelf->wasmetal_core__DOT___009724_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___009132_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008938_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0))
                                                                                 : 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3068c687__0))) 
                                                                                << 1U)) 
                                                                              | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h85f1be24__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___008806_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055717_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007855_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___007856_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___051316_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051315_))))))))))));
    vlSelf->wasmetal_core__DOT___008813_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055748_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055747_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055745_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055744_))))))))))));
    vlSelf->wasmetal_core__DOT___009709_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                ? (IData)(
                                                          (0xff55ffccff0fff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009204_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((0x1111000fU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008899_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008900_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h900f682d__0))))) 
                                                                         << 2U)) 
                                                                     | (((IData)(wasmetal_core__DOT___008882_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (1U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h16df2209__0))))))))))
                                                : (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009204_))));
    vlSelf->__VdfgTmp_h9005ae64__0 = (((IData)(vlSelf->wasmetal_core__DOT___008917_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055925_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___055924_)))));
    vlSelf->__VdfgTmp_h51a98e86__0 = (((IData)(wasmetal_core__DOT___008972_) 
                                       << 1U) | (1U 
                                                 & (0x1111000fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd77eff94__0)))))));
    vlSelf->wasmetal_core__DOT___010058_ = (1U & (IData)(
                                                         (0xfef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x305U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009323_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009322_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x33550f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf1111U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055457_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055456_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055455_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055454_)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008548_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008547_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x305U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_hcb32e64d__0)))))))))))));
    vlSelf->__VdfgTmp_hc9a6e3e5__0 = (((IData)(wasmetal_core__DOT___009699_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009698_));
    vlSelf->__VdfgTmp_hc1f2eefb__0 = ((2U & ((0x11f0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008858_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___008859_))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___009699_));
    vlSelf->wasmetal_core__DOT___009080_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055531_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055530_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h2c715ba9__0))))));
    vlSelf->__VdfgTmp_h01bf79b3__0 = (((IData)(wasmetal_core__DOT___009133_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055932_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008959_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___008958_)))))));
    vlSelf->wasmetal_core__DOT___061317_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008758_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008757_))))));
    vlSelf->__VdfgTmp_hcfb95646__0 = (((IData)(wasmetal_core__DOT___009140_) 
                                       << 1U) | (1U 
                                                 & (0x11f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___008990_)))))));
    vlSelf->__VdfgTmp_hc115db5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___009002_) 
                                       << 1U) | (1U 
                                                 & (0x1111fff0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                            << 2U) 
                                                           | (IData)(__VdfgTmp_ha336bc52__0)))))));
    vlSelf->wasmetal_core__DOT___009316_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055390_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055389_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_ha336bc52__0))))));
    vlSelf->__VdfgTmp_hea7ff6d4__0 = (((IData)(wasmetal_core__DOT___009168_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009167_));
    vlSelf->__VdfgTmp_hde712649__0 = (((IData)(vlSelf->wasmetal_core__DOT___009048_) 
                                       << 1U) | (1U 
                                                 & (0x11f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009068_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h351522cb__0))))));
    vlSelf->__VdfgTmp_hc3f8840b__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009878_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009877_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h351522cb__0))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009178_));
    vlSelf->__VdfgTmp_h6b05f1fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___009068_) 
                                       << 2U) | (IData)(__VdfgTmp_h8170c8be__0));
    vlSelf->wasmetal_core__DOT___056249_ = (1U & ((IData)(
                                                          (0xf3faf0f0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h243a5897__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                                     & (IData)(
                                                               (0xccffaafff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xa3U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055738_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xcaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(wasmetal_core__DOT___009151_) 
                                                                              << 1U) 
                                                                             | (IData)(wasmetal_core__DOT___009886_)))))))))));
    vlSelf->wasmetal_core__DOT___060834_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060828_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___056268_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009002_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(wasmetal_core__DOT___009387_)))))))));
    vlSelf->__VdfgTmp_hb35f8ae6__0 = (((IData)(wasmetal_core__DOT___009387_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009386_));
    vlSelf->wasmetal_core__DOT___011169_ = (1U & ((IData)(
                                                          (0xff0fff88ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009434_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h3eec0328__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xff00ffafffcfffULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___009152_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 2U) 
                                                                          | (((IData)(wasmetal_core__DOT___009151_) 
                                                                              << 1U) 
                                                                             | (IData)(wasmetal_core__DOT___009150_)))))))))));
    vlSelf->wasmetal_core__DOT___009436_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0x1111f0f000ff00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & ((0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009163_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_hca62a78c__0))))))));
    vlSelf->__VdfgTmp_hde083b18__0 = ((2U & ((0xeU 
                                              >> (IData)(__VdfgTmp_hca62a78c__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009163_));
    vlSelf->__VdfgTmp_h2fbb9566__0 = (((IData)(vlSelf->wasmetal_core__DOT___009002_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009020_));
    vlSelf->__VdfgTmp_hc9ff0a4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h3ae7f513__0)));
    vlSelf->__VdfgTmp_h2a535782__0 = ((4U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008860_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h8b31618a__0))))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___009197_) 
                                          << 1U) | 
                                         (1U & (0xf1111U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009339_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009338_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hd28f0b72__0))))))));
    vlSelf->__VdfgTmp_hc69ce2b6__0 = (((IData)(wasmetal_core__DOT___009274_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055575_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h29905bdd__0))))));
    vlSelf->__VdfgTmp_hcd20ba92__0 = (((IData)(vlSelf->wasmetal_core__DOT___009095_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___009101_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h0e20e5e3__0))))));
    vlSelf->__VdfgTmp_hafe541cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009101_) 
                                       << 2U) | (IData)(__VdfgTmp_h0e20e5e3__0));
    vlSelf->__VdfgTmp_hf2dd18ce__0 = (((IData)(wasmetal_core__DOT___008884_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009979_));
    vlSelf->__VdfgTmp_h8f3860df__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  (0x3aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc3aac618__0)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (1U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h16df2209__0))))))
                                                   : 
                                                  (0xa3U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___008882_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___055818_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___055817_))))))))
                                               : (2U 
                                                  >> (IData)(wasmetal_core__DOT___008884_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_));
    vlSelf->__VdfgTmp_h39a6e1f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___009108_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    ((8U 
                                                      & ((IData)(
                                                                 (0xf0f0f050f0f0f03ULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                                         << 3U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9f78711b__0))))));
    vlSelf->__VdfgTmp_h9555d936__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009419_) 
                                                  << 2U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      & (IData)(
                                                                (0xfefef0f000ff00ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7d874977__0)) 
                                                                            << 3U)) 
                                                                        | (IData)(__VdfgTmp_h115316d8__0))))))) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (1U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___055921_)))))));
    vlSelf->__VdfgTmp_h6abc2452__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010650_));
    vlSelf->__VdfgTmp_h68679bcf__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055627_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055626_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008931_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___008930_)))))) 
                                             << 1U)) 
                                      | (1U & (0x1fU 
                                               >> (
                                                   (8U 
                                                    & ((IData)(
                                                               (0xa0000000cULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h8ed306e0__0))))));
    vlSelf->__VdfgTmp_ha87cf846__0 = (((IData)(wasmetal_core__DOT___009168_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009447_));
    vlSelf->__VdfgTmp_hb37ea0c9__0 = (((IData)(wasmetal_core__DOT___009026_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009396_));
    vlSelf->__VdfgTmp_he49a3989__0 = (((IData)(wasmetal_core__DOT___009026_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___009025_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___009024_)));
    vlSelf->__VdfgTmp_h5aef5382__0 = (((IData)(wasmetal_core__DOT___009243_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009025_));
    vlSelf->__VdfgTmp_h3b033656__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055455_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055454_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055453_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___055452_)))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___009243_));
    vlSelf->__VdfgTmp_h78ee927d__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2275929a__0))));
    vlSelf->wasmetal_core__DOT___061171_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061165_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xccaaf0f0U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___009274_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1eb86efd__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(wasmetal_core__DOT___009414_)))))))));
    vlSelf->wasmetal_core__DOT___069049_ = (1U & (IData)(
                                                         (0xaaff00f0bbbb3030ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012329_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012330_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056114_)))))))));
    vlSelf->wasmetal_core__DOT___061015_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056114_))));
    vlSelf->__VdfgTmp_hab523f16__0 = (((IData)(vlSelf->wasmetal_core__DOT___056114_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___060982_ = (1U & (IData)(
                                                         (0xf005500330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___008826_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h792a3800__0))))))));
    vlSelf->wasmetal_core__DOT___010069_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                ? (0x33550f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xf1111U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055473_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055472_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055471_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___055470_)))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008824_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (1U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055475_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___055474_)))))))))
                                                : (1U 
                                                   >> (IData)(wasmetal_core__DOT___008826_))));
    vlSelf->__VdfgTmp_haa33114f__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055471_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055470_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb6a6380e__0))))) 
                                             << 1U)) 
                                      | (1U & (0x11f0U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h2b908e25__0)))));
    vlSelf->__VdfgTmp_h05b3fc84__0 = (((IData)(vlSelf->wasmetal_core__DOT___009920_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009134_));
    vlSelf->wasmetal_core__DOT___013181_ = (1U & ((IData)(
                                                          (0xff0fff44ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009422_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h584d0366__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xaaffccfff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(wasmetal_core__DOT___009134_) 
                                                                           << 2U) 
                                                                          | (((IData)(wasmetal_core__DOT___009133_) 
                                                                              << 1U) 
                                                                             | (IData)(wasmetal_core__DOT___009132_)))))))))));
    vlSelf->__VdfgTmp_he19f1ef5__0 = ((2U & (((~ ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  (0x100U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h08b4abe6__0))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h315e9115__0)))) 
                                              & (IData)(
                                                        (0xfffff1111ffffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009369_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009368_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h44cf3d5c__0)))))))) 
                                             << 1U)) 
                                      | (1U & (0xf0f03355U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009478_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2fcb0063__0)))))));
    vlSelf->wasmetal_core__DOT___008756_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055709_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h44cf3d5c__0)))));
    vlSelf->__VdfgTmp_haa7da8bd__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056134_));
    vlSelf->wasmetal_core__DOT___061327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009219_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xcc55f0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_hb9a1e459__0))))))))));
    vlSelf->wasmetal_core__DOT___009711_ = ((IData)(vlSelf->wasmetal_core__DOT___009219_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0x33ffaaff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hb9a1e459__0))))))));
    vlSelf->wasmetal_core__DOT___010035_ = (1U & ((~ (IData)(
                                                             (0xf0f00003355ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009224_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h6b56eebb__0)))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? 
                                                     (0x3f3bU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                        << 3U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            & (IData)(
                                                                      (0xffff1111fff0fff0ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007857_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007856_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007855_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007853_))))))))) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xf1111U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051316_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___051315_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051314_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051313_)))))))))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h3c5f3431__0)))))));
    vlSelf->wasmetal_core__DOT___009306_ = (1U & (0x110fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h5c89e2df__0)))));
    vlSelf->wasmetal_core__DOT___060766_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_heabab031__0)) 
                                                             << 1U)) 
                                                         | (IData)(wasmetal_core__DOT___056103_))))));
    vlSelf->wasmetal_core__DOT___056104_ = (1U & (IData)(
                                                         (0xf000000088ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heabab031__0))))))));
    vlSelf->wasmetal_core__DOT___055938_ = (1U & ((IData)(
                                                          (0xfff0ff88ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009427_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf516e409__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xff00ffafffcfffULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___009141_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 2U) 
                                                                          | (((IData)(wasmetal_core__DOT___009140_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009139_)))))))))));
    vlSelf->__VdfgTmp_hb80b9598__0 = (((IData)(wasmetal_core__DOT___008973_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___008972_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___008971_)));
    vlSelf->__VdfgTmp_ha0fb8243__0 = (((IData)(vlSelf->wasmetal_core__DOT___009472_) 
                                       << 2U) | (IData)(__VdfgTmp_hb4d0429b__0));
    vlSelf->wasmetal_core__DOT___009211_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hb4d0429b__0)))));
    vlSelf->wasmetal_core__DOT___056168_ = (1U & ((IData)(
                                                          (0xffff8000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055534_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h4ad8a46a__0)))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? (IData)(
                                                                (0xccffaaff0fff0fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009762_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_ha28c8f63__0))))))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009762_)))));
    vlSelf->wasmetal_core__DOT___056121_ = (1U & (IData)(
                                                         (0xf00000088ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                          ? 
                                                                         (0x3355f0f0U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                               << 3U) 
                                                                              | (IData)(__VdfgTmp_ha28c8f63__0))))
                                                                          : 
                                                                         (2U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___009460_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h18926335__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127529___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023190_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023189_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023188_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023187_)))) 
           ^ (((IData)(wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023250_)))));
    vlSelf->wasmetal_core__DOT___023254_ = ((IData)(vlSelf->wasmetal_core__DOT___023190_) 
                                            & (IData)(wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b37__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h14d2ff5c__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h3d32f603__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___017590_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xefefef00efefefefULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h6a49916d__0)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013381_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___057713_)))));
    vlSelf->wasmetal_core__DOT___017484_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___057713_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057712_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057711_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057710_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015657_)))))))));
    vlSelf->wasmetal_core__DOT___071723_ = (1U & (0xccaafff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058030_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057950_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057971_)))))));
    vlSelf->wasmetal_core__DOT___019690_ = (1U & (0x32U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019685_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014446_)))));
    vlSelf->__VdfgTmp_h2a7b33bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___019669_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014353_));
    vlSelf->wasmetal_core__DOT___035375_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((1U 
                                                          & (0xdf2f20dU 
                                                             >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___014357_)
                                                           ? 
                                                          (0x50003000U 
                                                           >> (IData)(__VdfgTmp_h836204cc__0))
                                                           : 
                                                          (0x4000U 
                                                           >> (IData)(__VdfgTmp_h32a58059__0)))
                                                          : 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___014357_)
                                                           ? 
                                                          (0xafffcfffU 
                                                           >> (IData)(__VdfgTmp_h836204cc__0))
                                                           : 
                                                          (0xbfffU 
                                                           >> (IData)(__VdfgTmp_h32a58059__0))))))));
    vlSelf->wasmetal_core__DOT___035384_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04659776__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071762_))))));
    vlSelf->__VdfgTmp_h74456d25__0 = (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071742_)));
    vlSelf->wasmetal_core__DOT___035379_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x3500000000000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h06185798__0))))))))))));
    vlSelf->wasmetal_core__DOT___071753_ = (1U & (0xf0aaccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___014447_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h06185798__0))))));
    vlSelf->wasmetal_core__DOT___071758_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019670_))));
    vlSelf->wasmetal_core__DOT___071763_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___014355_)))));
    vlSelf->wasmetal_core__DOT___071735_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014358_)
                                                   ? 
                                                  (0xccaa0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014355_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h51e83899__0)))))
                                                   : 
                                                  (0xbU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___014356_)))));
    vlSelf->wasmetal_core__DOT___014363_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014356_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___014355_)))));
    vlSelf->__VdfgTmp_h42589940__0 = (((IData)(vlSelf->wasmetal_core__DOT___019697_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019696_));
    vlSelf->__VdfgTmp_h09be8eb6__0 = (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014358_)
                                                     ? 
                                                    (0xf0cc55ffU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___014383_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___014382_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___014381_))))))
                                                     : 
                                                    (0xbU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014384_))))));
    vlSelf->wasmetal_core__DOT___071760_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___019677_)))));
    if (vlSelf->wasmetal_core__DOT___014360_) {
        if (vlSelf->wasmetal_core__DOT___014358_) {
            vlSelf->wasmetal_core__DOT___071725_ = 
                (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_he15aac2f__0))));
            vlSelf->wasmetal_core__DOT___013628_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h5970a25a__0))));
            vlSelf->wasmetal_core__DOT___013629_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014385_)));
        } else {
            vlSelf->wasmetal_core__DOT___071725_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(__VdfgTmp_hf87abe5d__0))));
            vlSelf->wasmetal_core__DOT___013628_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(__VdfgTmp_hbb8e97f6__0))));
            vlSelf->wasmetal_core__DOT___013629_ = 
                (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___014385_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_hd4b4ff41__0)))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___071725_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014358_)) 
                                                   | (1U 
                                                      >> (IData)(wasmetal_core__DOT___019677_))));
        vlSelf->wasmetal_core__DOT___013628_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014358_)) 
                                                   | (2U 
                                                      >> (IData)(wasmetal_core__DOT___014375_))));
        vlSelf->wasmetal_core__DOT___013629_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___014358_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___014384_))
                                                    : 
                                                   (7U 
                                                    >> (IData)(__VdfgTmp_h3fbd9b9f__0))));
    }
    vlSelf->__VdfgTmp_hd8777223__0 = (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                       << 3U) | (((IData)(wasmetal_core__DOT___019677_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hf87abe5d__0)));
    vlSelf->wasmetal_core__DOT___019724_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___014375_))));
    vlSelf->__VdfgTmp_h929e6874__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___014375_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hbb8e97f6__0))));
    vlSelf->wasmetal_core__DOT___035385_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019758_))))));
    vlSelf->wasmetal_core__DOT___019713_ = (1U & (0xf880000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014384_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h3fbd9b9f__0))))));
    vlSelf->wasmetal_core__DOT___035372_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f33aa00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019696_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h78b7c78d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___019695_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h78b7c78d__0))));
    vlSelf->wasmetal_core__DOT___035703_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d)))));
    vlSelf->wasmetal_core__DOT___035702_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd339b1da__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d)))));
    vlSelf->wasmetal_core__DOT___035712_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058087_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d)))));
    vlSelf->wasmetal_core__DOT___035711_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h97610f75__0))));
    vlSelf->wasmetal_core__DOT___035710_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cb02621__0))));
    vlSelf->wasmetal_core__DOT___035709_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2af737a__0))));
    vlSelf->wasmetal_core__DOT___035683_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d)))));
    vlSelf->wasmetal_core__DOT___035682_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d)))));
    vlSelf->wasmetal_core__DOT___035681_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b55__05d)))));
    vlSelf->wasmetal_core__DOT___035680_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b54__05d)))));
    vlSelf->wasmetal_core__DOT___035679_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b53__05d)))));
    vlSelf->wasmetal_core__DOT___035676_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b52__05d)))));
    vlSelf->__VdfgTmp_h4eafc8bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___014448_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___014447_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014446_)));
    vlSelf->wasmetal_core__DOT___019751_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___014454_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___058056_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hf3511969__0))))))));
    vlSelf->wasmetal_core__DOT___058058_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hf3511969__0))));
}
