#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__35(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__35\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006634_;
    wasmetal_core__DOT___006634_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006636_;
    wasmetal_core__DOT___006636_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006743_;
    wasmetal_core__DOT___006743_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022514_;
    wasmetal_core__DOT___022514_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022660_;
    wasmetal_core__DOT___022660_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022730_;
    wasmetal_core__DOT___022730_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023457_;
    wasmetal_core__DOT___023457_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023578_;
    wasmetal_core__DOT___023578_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023680_;
    wasmetal_core__DOT___023680_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023744_;
    wasmetal_core__DOT___023744_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023745_;
    wasmetal_core__DOT___023745_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023746_;
    wasmetal_core__DOT___023746_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023747_;
    wasmetal_core__DOT___023747_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026608_;
    wasmetal_core__DOT___026608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026743_;
    wasmetal_core__DOT___026743_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026878_;
    wasmetal_core__DOT___026878_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027078_;
    wasmetal_core__DOT___027078_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027405_;
    wasmetal_core__DOT___027405_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___028718_;
    wasmetal_core__DOT___028718_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029026_;
    wasmetal_core__DOT___029026_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029061_;
    wasmetal_core__DOT___029061_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029062_;
    wasmetal_core__DOT___029062_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029063_;
    wasmetal_core__DOT___029063_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029064_;
    wasmetal_core__DOT___029064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029143_;
    wasmetal_core__DOT___029143_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031029_;
    wasmetal_core__DOT___031029_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033425_;
    wasmetal_core__DOT___033425_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034362_;
    wasmetal_core__DOT___034362_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050127_;
    wasmetal_core__DOT___050127_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050128_;
    wasmetal_core__DOT___050128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050146_;
    wasmetal_core__DOT___050146_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050148_;
    wasmetal_core__DOT___050148_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050151_;
    wasmetal_core__DOT___050151_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057758_;
    wasmetal_core__DOT___057758_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058877_;
    wasmetal_core__DOT___058877_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059083_;
    wasmetal_core__DOT___059083_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059094_;
    wasmetal_core__DOT___059094_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059095_;
    wasmetal_core__DOT___059095_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063168_;
    wasmetal_core__DOT___063168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063174_;
    wasmetal_core__DOT___063174_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063180_;
    wasmetal_core__DOT___063180_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063186_;
    wasmetal_core__DOT___063186_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063192_;
    wasmetal_core__DOT___063192_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063198_;
    wasmetal_core__DOT___063198_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063204_;
    wasmetal_core__DOT___063204_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063210_;
    wasmetal_core__DOT___063210_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063216_;
    wasmetal_core__DOT___063216_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063222_;
    wasmetal_core__DOT___063222_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063228_;
    wasmetal_core__DOT___063228_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063234_;
    wasmetal_core__DOT___063234_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127437___O;
    wasmetal_core__DOT____Vcellout___127437___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127482___O;
    wasmetal_core__DOT____Vcellout___127482___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127483___O;
    wasmetal_core__DOT____Vcellout___127483___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127611___O;
    wasmetal_core__DOT____Vcellout___127611___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127612___O;
    wasmetal_core__DOT____Vcellout___127612___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127870___O;
    wasmetal_core__DOT____Vcellout___127870___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127970___O;
    wasmetal_core__DOT____Vcellout___127970___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128062___O;
    wasmetal_core__DOT____Vcellout___128062___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128063___O;
    wasmetal_core__DOT____Vcellout___128063___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128107___O;
    wasmetal_core__DOT____Vcellout___128107___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128108___O;
    wasmetal_core__DOT____Vcellout___128108___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127439___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127439___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127439___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127439___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127439___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127439___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127467___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127467___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127467___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127467___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127594___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127594___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127594___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127594___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127594___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127594___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127921___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127921___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127922___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127922___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127922___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127922___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127922___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127922___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127923___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127923___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127923___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127923___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127923___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127923___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127939___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127939___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127939___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127939___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127939___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127939___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127940___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127940___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127940___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127940___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127972___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127972___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128063___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128063___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128071___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128071___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128072___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128072___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128072___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128072___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128072___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128072___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128073___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128073___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128073___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128073___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128073___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128073___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128081___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128081___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128081___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128081___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128082___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128082___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128090___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128090___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128090___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128090___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128090___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128090___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128091___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128091___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128091___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128091___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128099___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128099___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128099___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128099___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128099___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128099___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128100___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128100___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128108___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128108___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128108___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128108___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128108___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128108___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128109___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128109___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128109___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128109___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128116___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128116___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128116___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128116___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128116___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128116___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128117___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128117___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128117___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128117___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128126___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128126___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128126___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128126___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128126___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128126___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128127___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128127___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128134___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128134___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128134___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128134___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128134___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128134___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128135___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128135___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128135___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128135___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128145___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128145___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128145___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128145___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128145___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128145___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128146___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128146___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128146___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128146___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128236___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128236___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128236___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128236___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128236___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128236___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128250___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128250___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128250___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128250___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128250___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128250___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128328___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128328___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128328___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128328___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128328___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128328___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128329___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128329___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128329___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128329___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128439___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128439___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128439___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128439___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128552___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128552___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128552___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128552___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128652___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128652___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128652___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128652___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128652___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128652___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128653___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128653___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128653___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128653___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128653___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128653___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128667___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128667___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128667___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128667___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128667___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128667___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128668___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128668___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h7052d05f__0;
    __VdfgTmp_h7052d05f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h29c879e7__0;
    __VdfgTmp_h29c879e7__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___045290_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071418_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071417_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071416_))))))));
    vlSelf->wasmetal_core__DOT___045314_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071418_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071417_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071416_)))))))));
    wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026569_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026502_)
            : (IData)(vlSelf->wasmetal_core__DOT___001613_));
    vlSelf->wasmetal_core__DOT___070802_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054349_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070800_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)))))))))));
    vlSelf->wasmetal_core__DOT___070801_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070800_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054349_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d)))))))));
    wasmetal_core__DOT___127921___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026942_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    wasmetal_core__DOT___128071___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h0cc9f882__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT___039999_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039993_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___040012_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___040011_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b19__05d)))))))));
    vlSelf->__VdfgTmp_h3b6a361f__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->__VdfgTmp_h5840e4cc__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->__VdfgTmp_h0eee83f1__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->__VdfgTmp_hb291576a__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001612_));
    wasmetal_core__DOT___128667___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000432_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034518_));
    wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030098_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d));
    wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030226_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d));
    wasmetal_core__DOT___063168_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063174_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063180_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063186_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028292_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028258_)
            : (IData)(vlSelf->wasmetal_core__DOT___028227_));
    wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036976_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0)
                  : (0x96U >> (IData)(vlSelf->__VdfgTmp_h009676e6__0))));
    wasmetal_core__DOT____Vcellout___127970___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027466_)))));
    wasmetal_core__DOT___027405_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
                                     >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027340_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027274_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b16__05d));
    vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003808_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128145___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128480___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029139_));
    wasmetal_core__DOT___128328___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031058_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031025_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036845_)
            ? (IData)(vlSelf->wasmetal_core__DOT___036837_)
            : (IData)(vlSelf->wasmetal_core__DOT___036632_));
    vlSelf->wasmetal_core__DOT____Vcellout___128550___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033421_)))));
    wasmetal_core__DOT___033425_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013648_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127465___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023800_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d));
    vlSelf->__VdfgTmp_h79e73f20__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005982_));
    vlSelf->__VdfgTmp_ha15895e4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->__VdfgTmp_h8b95dc84__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_));
    vlSelf->__VdfgTmp_ha7391b06__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006092_));
    wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___023873_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d) {
        wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d;
        wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d;
    } else {
        wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024000_;
        wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___006622_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050131_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006635_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050130_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006015_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O))))))))));
    vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005738_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005889_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013771_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022813_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))));
    vlSelf->__VdfgTmp_h4b2bd90e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005982_));
    vlSelf->__VdfgTmp_hbed85956__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->__VdfgTmp_hedc0f726__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_));
    vlSelf->__VdfgTmp_he0f48724__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006092_));
    wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___022863_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d) {
        wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d;
        wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d;
    } else {
        wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022926_;
        wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128045___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028097_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028096_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028095_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028094_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028061_)))));
    vlSelf->wasmetal_core__DOT___028065_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028097_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0xfU)));
    vlSelf->wasmetal_core__DOT____Vcellout___128651___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000499_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000477_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___000465_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___000433_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034357_)))));
    wasmetal_core__DOT___034362_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000499_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128116___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028853_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028818_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    wasmetal_core__DOT___128081___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028474_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128081___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003416_));
    vlSelf->wasmetal_core__DOT___054100_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128098___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054104_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128098___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b17__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054108_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128098___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b18__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054112_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128098___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b19__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    wasmetal_core__DOT___128099___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028649_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028614_)
            : (IData)(vlSelf->wasmetal_core__DOT___003936_));
    vlSelf->wasmetal_core__DOT____Vcellout___128133___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029060_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029059_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029058_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029057_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029022_)))));
    wasmetal_core__DOT___029026_ = ((IData)(vlSelf->wasmetal_core__DOT___029060_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    wasmetal_core__DOT___029064_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000419_))));
    wasmetal_core__DOT___029063_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001646_))));
    wasmetal_core__DOT___029062_ = (1U & (6U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001624_))));
    wasmetal_core__DOT___029061_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001612_))));
    wasmetal_core__DOT___128126___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028961_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028926_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b20__05d));
    wasmetal_core__DOT___128439___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000464_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000464_)
            : (IData)(vlSelf->wasmetal_core__DOT___128439___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128107___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028751_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028750_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028749_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028748_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028714_)))));
    wasmetal_core__DOT___028718_ = ((IData)(vlSelf->wasmetal_core__DOT___028751_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026463_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b18__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127887___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026673_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026672_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026671_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026670_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026604_)))));
    wasmetal_core__DOT___026608_ = ((IData)(vlSelf->wasmetal_core__DOT___026673_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___045246_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070698_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054348_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___045222_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070699_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054352_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xcU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054348_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070698_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127938___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027143_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027142_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027141_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027140_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027074_)))));
    wasmetal_core__DOT___027078_ = ((IData)(vlSelf->wasmetal_core__DOT___027143_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d));
    wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026570_)
            ? (IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001625_));
    vlSelf->wasmetal_core__DOT___044974_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070801_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___044950_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070802_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054351_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xcU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054347_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070801_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127921___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026943_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026942_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026941_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026940_)))) 
           ^ (((IData)(wasmetal_core__DOT___127921___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026874_)))));
    wasmetal_core__DOT___026878_ = ((IData)(vlSelf->wasmetal_core__DOT___026943_)
                                     ? (IData)(wasmetal_core__DOT___127921___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT____Vcellout___127904___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h3e3e53ad__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h0cc9f882__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h63306680__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h560b7672__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128071___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026739_)))));
    wasmetal_core__DOT___026743_ = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h3e3e53ad__0)))
                                     ? (IData)(wasmetal_core__DOT___128071___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___030103_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b6a361f__0)))));
    vlSelf->wasmetal_core__DOT___030231_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b6a361f__0)))));
    vlSelf->wasmetal_core__DOT___030102_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5840e4cc__0)))));
    vlSelf->wasmetal_core__DOT___030230_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5840e4cc__0)))));
    vlSelf->wasmetal_core__DOT___030101_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0eee83f1__0)))));
    vlSelf->wasmetal_core__DOT___030229_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0eee83f1__0)))));
    vlSelf->wasmetal_core__DOT___030100_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb291576a__0)))));
    vlSelf->wasmetal_core__DOT___030228_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb291576a__0)))));
    wasmetal_core__DOT___128667___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000464_)) 
           & (IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128234___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030099_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030098_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030097_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030096_)))) 
           ^ (((IData)(wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030063_)))));
    vlSelf->wasmetal_core__DOT___030067_ = ((IData)(vlSelf->wasmetal_core__DOT___030099_)
                                             ? (IData)(wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128248___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030227_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030226_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030225_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030224_)))) 
           ^ (((IData)(wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030159_)))));
    vlSelf->wasmetal_core__DOT___030163_ = ((IData)(vlSelf->wasmetal_core__DOT___030227_)
                                             ? (IData)(wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d));
    vlSelf->wasmetal_core__DOT___063171_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063168_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063167_)))))));
    vlSelf->wasmetal_core__DOT___063177_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063174_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063173_)))))));
    vlSelf->wasmetal_core__DOT___063183_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063180_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063179_)))))));
    vlSelf->wasmetal_core__DOT___063189_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063186_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063185_)))))));
    vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028293_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028228_));
    wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036977_)
            ? (IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036651_));
    vlSelf->wasmetal_core__DOT___044885_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127970___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___127970___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127970___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___044884_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127970___O))))));
    wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
           & (IData)(wasmetal_core__DOT___027405_));
    wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027341_)
            ? (IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b17__05d));
    wasmetal_core__DOT____Vcellout___127437___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he473afc4__0))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022510_)))));
    wasmetal_core__DOT___022514_ = ((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128145___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128480___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128328___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031059_)
            ? (IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134165___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036846_) 
             << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036845_)) 
           ^ (((((IData)(vlSelf->wasmetal_core__DOT___036846_)
                  ? (IData)(wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT___036627_)) 
                << 2U) | ((IData)(wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___036837_)));
    vlSelf->wasmetal_core__DOT___012774_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff00aaaaf0f03333ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                              << 1U)) 
                                                                          | ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)) 
           & (IData)(wasmetal_core__DOT___033425_));
    wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013666_) 
           & (IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d) {
        wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d;
        wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d;
    } else {
        wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127592___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023801_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023800_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023796_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023785_)))) 
           ^ (((IData)(wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023711_)))));
    vlSelf->wasmetal_core__DOT___023738_ = ((IData)(vlSelf->wasmetal_core__DOT___023801_)
                                             ? (IData)(wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d));
    vlSelf->wasmetal_core__DOT___023743_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d))));
    vlSelf->wasmetal_core__DOT___058878_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d))));
    vlSelf->wasmetal_core__DOT___023742_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d))));
    vlSelf->wasmetal_core__DOT___058706_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0))))));
    vlSelf->wasmetal_core__DOT___023803_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d))));
    vlSelf->wasmetal_core__DOT___058870_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0))))))));
    vlSelf->wasmetal_core__DOT___058924_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0))))));
    vlSelf->wasmetal_core__DOT___058707_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___023802_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d))));
    vlSelf->wasmetal_core__DOT___006952_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT____Vcellout___127457___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005935_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005745_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022656_)))));
    wasmetal_core__DOT___022660_ = ((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127560___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005795_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005955_)))) 
           ^ (((IData)(wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023453_)))));
    wasmetal_core__DOT___023457_ = ((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                    & (IData)(wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127577___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013770_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h81ac2e72__0))) 
           ^ (((IData)(wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023574_)))));
    wasmetal_core__DOT___023578_ = ((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                    & (IData)(wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) {
        wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d;
        wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d;
    } else {
        wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127470___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022814_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022813_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022812_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022811_)))) 
           ^ (((IData)(wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022779_)))));
    vlSelf->wasmetal_core__DOT___022783_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022814_)
                                                   ? (IData)(wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))));
    vlSelf->wasmetal_core__DOT___022788_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0))))));
    vlSelf->wasmetal_core__DOT___059183_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))));
    vlSelf->wasmetal_core__DOT___059191_ = (1U & (1U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5774c299__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))))));
    vlSelf->wasmetal_core__DOT___022787_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))));
    vlSelf->wasmetal_core__DOT___059168_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))))));
    wasmetal_core__DOT___059083_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))))));
    vlSelf->wasmetal_core__DOT___022816_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))))));
    vlSelf->wasmetal_core__DOT___059169_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he0f48724__0))))));
    vlSelf->wasmetal_core__DOT___022815_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he0f48724__0))))));
    vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028098_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028065_)
                  : (vlSelf->insn_x >> 0x10U)));
    vlSelf->wasmetal_core__DOT___054562_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000433_)))));
    vlSelf->wasmetal_core__DOT___054563_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000465_)))));
    vlSelf->wasmetal_core__DOT___054564_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000477_)))));
    vlSelf->wasmetal_core__DOT___054565_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000499_)))));
    wasmetal_core__DOT___128652___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000521_)) 
           & (IData)(wasmetal_core__DOT___034362_));
    wasmetal_core__DOT___128116___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028854_)
            ? (IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    wasmetal_core__DOT___128081___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028475_)
            ? (IData)(wasmetal_core__DOT___128081___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003348_));
    wasmetal_core__DOT___128099___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028650_)
            ? (IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003416_));
    wasmetal_core__DOT___128134___DOT__CO__BRA__0__KET__ 
        = ((IData)(wasmetal_core__DOT___029061_) ? (IData)(wasmetal_core__DOT___029026_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    wasmetal_core__DOT___128126___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028962_)
            ? (IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b21__05d));
    wasmetal_core__DOT___128439___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000476_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000476_)
            : (IData)(wasmetal_core__DOT___128439___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045371_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b47__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___045383_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b49__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b48__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b47__05d)))))))));
    wasmetal_core__DOT___128108___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028753_)
            ? (IData)(wasmetal_core__DOT___028718_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT____Vcellout___127854___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026464_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026463_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026462_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026461_)))) 
           ^ (((IData)(wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026427_)))));
    vlSelf->wasmetal_core__DOT___026431_ = ((IData)(vlSelf->wasmetal_core__DOT___026464_)
                                             ? (IData)(wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b19__05d));
    vlSelf->wasmetal_core__DOT___071264_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071263_))));
    vlSelf->wasmetal_core__DOT___045337_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052142_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052446_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052450_)))))))));
    vlSelf->wasmetal_core__DOT___045349_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052142_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052446_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052450_)))))))));
    wasmetal_core__DOT___128090___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026675_)
            ? (IData)(wasmetal_core__DOT___026608_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___054360_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054362_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054358_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054364_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127939___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027145_)
            ? (IData)(wasmetal_core__DOT___027078_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d));
    wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026571_)
            ? (IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001647_));
    vlSelf->wasmetal_core__DOT___054359_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054361_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054357_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127922___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026945_)
            ? (IData)(wasmetal_core__DOT___026878_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___045923_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052400_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052529_)))))))));
    vlSelf->wasmetal_core__DOT___045935_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052529_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052400_)))))))));
    vlSelf->wasmetal_core__DOT___045405_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h73e9a4a1__0)))))));
    vlSelf->wasmetal_core__DOT___045417_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004018_)))))))));
    vlSelf->wasmetal_core__DOT___045087_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071019_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071018_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071017_))))))));
    vlSelf->wasmetal_core__DOT___045111_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071019_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071018_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071017_)))))))));
    vlSelf->wasmetal_core__DOT___045878_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___003862_))))))));
    vlSelf->wasmetal_core__DOT___045902_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003862_)))))))));
    vlSelf->wasmetal_core__DOT___045877_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004004_)))))))));
    vlSelf->wasmetal_core__DOT___045901_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004670_)))))))));
    wasmetal_core__DOT___128072___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hd86a0826__0)))
            ? (IData)(wasmetal_core__DOT___026743_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    wasmetal_core__DOT___128667___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000476_)) 
           & (IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030100_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030067_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d));
    wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030228_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030163_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d));
    vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028294_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028229_));
    wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036978_)
            ? (IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036652_));
    wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027342_)
            ? (IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b18__05d));
    vlSelf->__VdfgTmp_h6e06acca__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                                                >> 3U)))))));
    vlSelf->__VdfgTmp_he245418c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_he137fc3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___127437___O)))))));
    vlSelf->__VdfgTmp_hd90860df__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127437___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_));
    vlSelf->__VdfgTmp_h6f6c5c03__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hbedf9838__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003805_));
    wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003806_) 
           & (IData)(wasmetal_core__DOT___022514_));
    wasmetal_core__DOT___128145___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128480___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128328___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031060_)
            ? (IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d)) 
           & (IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127465___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013658_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h7d2fcfb3__0))) 
           ^ (((IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127465___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022722_)))));
    vlSelf->wasmetal_core__DOT___022726_ = ((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                            & (IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d) {
        wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d;
        vlSelf->wasmetal_core__DOT___023877_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d;
    } else {
        wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023877_ = wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023802_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023738_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d));
    vlSelf->wasmetal_core__DOT___022627_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006952_))));
    vlSelf->wasmetal_core__DOT___006631_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005921_))));
    wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005716_) 
           & (IData)(wasmetal_core__DOT___022660_));
    vlSelf->wasmetal_core__DOT___006683_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127560___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xceU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005653_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b33__05d))))
                                                      : 
                                                     (0xf0f0fef0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005653_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h312c1c6b__0))))))));
    vlSelf->__VdfgTmp_h90f032b2__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127560___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005788_));
    wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005711_) 
           & (IData)(wasmetal_core__DOT___023457_));
    vlSelf->wasmetal_core__DOT___057748_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013771_))));
    vlSelf->wasmetal_core__DOT___057747_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013798_))));
    wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013805_) 
           & (IData)(wasmetal_core__DOT___023578_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d) {
        wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d;
        vlSelf->wasmetal_core__DOT___022867_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d;
    } else {
        wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022867_ = wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___059089_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059083_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059082_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h916673f4__0)))))))))));
    vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022815_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022783_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_he0f48724__0))));
    vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028099_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0x11U)));
    wasmetal_core__DOT___128652___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000543_)) 
           & (IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128116___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028855_)
            ? (IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT____Vcellout___128081___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028476_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028475_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028474_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028473_)))) 
           ^ (((IData)(wasmetal_core__DOT___128081___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128081___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128081___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028438_)))));
    vlSelf->wasmetal_core__DOT___028443_ = ((IData)(vlSelf->wasmetal_core__DOT___028476_)
                                             ? (IData)(wasmetal_core__DOT___128081___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___005164_));
    wasmetal_core__DOT___128099___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028651_)
            ? (IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003348_));
    wasmetal_core__DOT___128134___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___029062_) ? (IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    wasmetal_core__DOT___128126___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028963_)
            ? (IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b22__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128439___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128439___S) 
           ^ (((IData)(wasmetal_core__DOT___128439___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128439___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128439___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032268_)))));
    vlSelf->wasmetal_core__DOT___032273_ = ((IData)(vlSelf->wasmetal_core__DOT___000498_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___000498_)
                                             : (IData)(wasmetal_core__DOT___128439___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128108___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028754_)
            ? (IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000464_));
    vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026466_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026431_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b20__05d));
    vlSelf->wasmetal_core__DOT___071266_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071264_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d)))))))));
    wasmetal_core__DOT___128090___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026676_)
            ? (IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000464_));
    vlSelf->wasmetal_core__DOT___070702_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054358_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xfU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___070707_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054364_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x11U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d)))))));
    wasmetal_core__DOT___127939___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027146_)
            ? (IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d));
    wasmetal_core__DOT____Vcellout___127870___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___026572_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___026571_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___026570_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026569_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026502_)))));
    vlSelf->wasmetal_core__DOT___026506_ = ((IData)(vlSelf->wasmetal_core__DOT___026572_)
                                             ? (IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000420_));
    vlSelf->wasmetal_core__DOT___070805_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xfU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___070810_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054363_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x11U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d)))))));
    wasmetal_core__DOT___127922___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026946_)
            ? (IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000464_));
    wasmetal_core__DOT___128072___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h9cad1664__0)))
            ? (IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000464_));
    vlSelf->wasmetal_core__DOT____Vcellout___128667___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128439___S) 
           ^ (((IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034518_)))));
    vlSelf->wasmetal_core__DOT___034523_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000498_)) 
                                            & (IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030101_)
            ? (IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d));
    wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030229_)
            ? (IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d));
    wasmetal_core__DOT____Vcellout___128062___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028295_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028294_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028293_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028292_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028258_)))));
    vlSelf->wasmetal_core__DOT___028262_ = ((IData)(vlSelf->wasmetal_core__DOT___028295_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028230_));
    vlSelf->wasmetal_core__DOT____Vcellout___134183___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036979_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036978_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036977_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036976_)))) 
           ^ (((IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___036972_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036979_)
                                                   ? (IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hab776b02__0))));
    wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127955___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027343_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027342_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027341_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027340_)))) 
           ^ (((IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027274_)))));
    vlSelf->wasmetal_core__DOT___027278_ = ((IData)(vlSelf->wasmetal_core__DOT___027343_)
                                             ? (IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b19__05d));
    vlSelf->wasmetal_core__DOT___023221_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___003807_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_he137fc3d__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_he137fc3d__0)))));
    vlSelf->wasmetal_core__DOT___023220_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd90860df__0))));
    vlSelf->wasmetal_core__DOT___023219_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___003808_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6f6c5c03__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6f6c5c03__0)))));
    vlSelf->wasmetal_core__DOT___023218_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbedf9838__0))));
    wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005855_) 
           & (IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128145___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128480___O) 
           ^ (((IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029139_)))));
    wasmetal_core__DOT___029143_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128480___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128328___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031061_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031060_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031059_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031058_)))) 
           ^ (((IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031025_)))));
    wasmetal_core__DOT___031029_ = ((IData)(vlSelf->wasmetal_core__DOT___031061_)
                                     ? (IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d)) 
           & (IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__));
    __VdfgTmp_h29c879e7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___013654_));
    vlSelf->__VdfgTmp_h6ae1a845__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013666_));
    vlSelf->__VdfgTmp_haeb5561e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013658_));
    vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013719_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022726_));
    vlSelf->wasmetal_core__DOT____Vcellout___127627___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024000_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d) {
        vlSelf->wasmetal_core__DOT___024004_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d;
        vlSelf->wasmetal_core__DOT___127612___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024004_ = wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127612___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023877_;
    }
    vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023803_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d));
    wasmetal_core__DOT____Vcellout___127611___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023873_)))));
    wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005928_) 
           & (IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___006706_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006683_)) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                                     << 2U)) 
                                                                 | ((8U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                                              >> 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006151_))))))))));
    wasmetal_core__DOT___006743_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h90f032b2__0))))))));
    wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006215_) 
           & (IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___057758_ = (1U & (IData)((0x8acfULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057755_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057747_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                                << 1U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___013770_)))))))));
    wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002635_) 
           & (IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127490___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022926_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d) {
        vlSelf->wasmetal_core__DOT___022930_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d;
        vlSelf->wasmetal_core__DOT___127483___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022930_ = wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127483___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022867_;
    }
    vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022816_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))));
    wasmetal_core__DOT____Vcellout___127482___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022863_)))));
    vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028100_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0x12U)));
    wasmetal_core__DOT___128652___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000565_)) 
           & (IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128116___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028856_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028855_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028854_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028853_)))) 
           ^ (((IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028818_)))));
    vlSelf->wasmetal_core__DOT___028822_ = ((IData)(vlSelf->wasmetal_core__DOT___028856_)
                                             ? (IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___028861_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000498_))));
    vlSelf->wasmetal_core__DOT___028860_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000476_))));
    vlSelf->wasmetal_core__DOT___028859_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000464_))));
    vlSelf->wasmetal_core__DOT___028858_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000432_))));
    vlSelf->wasmetal_core__DOT___128082___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028477_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028443_)
            : (IData)(vlSelf->wasmetal_core__DOT___005096_));
    vlSelf->wasmetal_core__DOT____Vcellout___128099___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028652_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028651_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028650_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028649_)))) 
           ^ (((IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028614_)))));
    vlSelf->wasmetal_core__DOT___028619_ = ((IData)(vlSelf->wasmetal_core__DOT___028652_)
                                             ? (IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___005164_));
    wasmetal_core__DOT___128134___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___029063_) ? (IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT____Vcellout___128126___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028964_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028963_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028962_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028961_)))) 
           ^ (((IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028926_)))));
    vlSelf->wasmetal_core__DOT___028931_ = ((IData)(vlSelf->wasmetal_core__DOT___028964_)
                                             ? (IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b23__05d));
    vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000520_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000520_)
            : (IData)(vlSelf->wasmetal_core__DOT___032273_));
    wasmetal_core__DOT___128108___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028755_)
            ? (IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026467_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b21__05d));
    vlSelf->wasmetal_core__DOT___045043_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071266_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071265_)))));
    vlSelf->wasmetal_core__DOT___045019_ = (1U & (IData)(
                                                         (0xff737340ff404040ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071263_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071266_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071265_)))))))));
    wasmetal_core__DOT___128090___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026677_)
            ? (IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->wasmetal_core__DOT___070704_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070702_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)))))))))));
    vlSelf->wasmetal_core__DOT___070703_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070702_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___070709_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054362_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070707_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)))))))))));
    vlSelf->wasmetal_core__DOT___070708_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070707_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054362_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d)))))))));
    wasmetal_core__DOT___127939___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027147_)
            ? (IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d));
    vlSelf->wasmetal_core__DOT___045496_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071361_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127870___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071360_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071359_))))))));
    vlSelf->wasmetal_core__DOT___045520_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071361_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071360_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071359_)))))))));
    vlSelf->wasmetal_core__DOT___045495_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071358_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071357_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071356_)))))))));
    vlSelf->wasmetal_core__DOT___045519_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071358_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071357_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071356_)))))))));
    vlSelf->wasmetal_core__DOT___045292_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071424_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127870___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071423_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071422_))))))));
    vlSelf->wasmetal_core__DOT___045316_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071424_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071423_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071422_)))))))));
    vlSelf->wasmetal_core__DOT___045291_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071421_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071420_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071419_)))))))));
    vlSelf->wasmetal_core__DOT___045315_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071421_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071420_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071419_)))))))));
    vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026574_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026506_)
            : (IData)(vlSelf->wasmetal_core__DOT___000433_));
    vlSelf->wasmetal_core__DOT___070807_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054355_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)))))))))));
    vlSelf->wasmetal_core__DOT___070806_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070805_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054355_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___070812_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)))))))))));
    vlSelf->wasmetal_core__DOT___070811_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070810_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054361_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d)))))))));
    wasmetal_core__DOT___127922___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026947_)
            ? (IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000476_));
    wasmetal_core__DOT___128072___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hf0334e7f__0)))
            ? (IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->wasmetal_core__DOT___040010_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___040009_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___040020_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___040021_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b23__05d)))))))));
    vlSelf->__VdfgTmp_hf9b1d8fe__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->__VdfgTmp_ha8b85945__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->__VdfgTmp_haa037958__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000464_));
    vlSelf->__VdfgTmp_h8bacc2de__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___128668___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000520_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034523_));
    wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030102_)
            ? (IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d));
    wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030230_)
            ? (IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d));
    wasmetal_core__DOT___063192_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128062___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063198_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128062___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063204_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128062___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063210_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128062___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028297_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028262_)
            : (IData)(vlSelf->wasmetal_core__DOT___028232_));
    vlSelf->wasmetal_core__DOT___064905_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134183___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___064472_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134183___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___064737_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134183___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036980_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036972_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h935fcb03__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127971___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
           ^ (((IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027405_)))));
    vlSelf->wasmetal_core__DOT___027409_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027345_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027278_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b20__05d));
    wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005770_) 
           & (IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128146___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128481___O) 
           & (IData)(wasmetal_core__DOT___029143_));
    wasmetal_core__DOT___128329___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031062_)
            ? (IData)(wasmetal_core__DOT___031029_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128551___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033425_)))));
    vlSelf->wasmetal_core__DOT___033429_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d)) 
                                            & (IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___013709_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h29c879e7__0))))))));
    vlSelf->wasmetal_core__DOT___013663_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h29c879e7__0))))))));
    vlSelf->wasmetal_core__DOT___013716_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6ae1a845__0))))))));
    vlSelf->wasmetal_core__DOT___013682_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6ae1a845__0)))));
    vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013701_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d) {
        vlSelf->wasmetal_core__DOT___127628___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d;
        wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127628___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024004_;
        wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127612___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023742_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d));
    vlSelf->__VdfgTmp_hff1f1b74__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127611___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_));
    vlSelf->__VdfgTmp_he6c218f0__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127611___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_));
    vlSelf->__VdfgTmp_h2bc5853c__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127611___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003810_));
    vlSelf->__VdfgTmp_hec73a4f8__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127611___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->wasmetal_core__DOT____Vcellout___127458___O 
        = ((IData)(vlSelf->__VdfgTmp_h68317e95__0) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                & (IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___022660_)))));
    vlSelf->wasmetal_core__DOT___050096_ = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                & (IData)(wasmetal_core__DOT___006743_))
                                             : (IData)(wasmetal_core__DOT___006743_));
    wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006144_) 
           & (IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___057761_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057759_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057758_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057757_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___014245_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002632_) 
           & (IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d) {
        vlSelf->wasmetal_core__DOT___127491___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d;
        wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127491___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022930_;
        wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127483___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022787_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))));
    vlSelf->__VdfgTmp_h5308e2ff__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127482___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_));
    vlSelf->__VdfgTmp_h360b04fb__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127482___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_));
    vlSelf->__VdfgTmp_h6a2fda60__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127482___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003810_));
    vlSelf->__VdfgTmp_h607e9020__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127482___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->wasmetal_core__DOT____Vcellout___128046___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028101_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028100_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028099_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028098_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028065_)))));
    vlSelf->wasmetal_core__DOT___028069_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028101_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0x13U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128652___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000592_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000565_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___000543_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___000521_)))))) 
           ^ (((IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034362_)))));
    vlSelf->wasmetal_core__DOT___034366_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000592_)) 
                                            & (IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128117___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028858_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028822_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___128082___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028478_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128082___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___005368_));
    vlSelf->wasmetal_core__DOT___054116_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128099___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b20__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054120_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128099___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054124_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128099___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054128_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128099___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b23__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___128100___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028653_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028619_)
            : (IData)(vlSelf->wasmetal_core__DOT___005096_));
    vlSelf->wasmetal_core__DOT____Vcellout___128134___O 
        = ((((IData)(wasmetal_core__DOT___029064_) 
             << 3U) | (((IData)(wasmetal_core__DOT___029063_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___029062_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___029061_)))) 
           ^ (((IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029026_)))));
    vlSelf->wasmetal_core__DOT___029030_ = ((IData)(wasmetal_core__DOT___029064_)
                                             ? (IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___029069_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000498_))));
    vlSelf->wasmetal_core__DOT___029068_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000476_))));
    vlSelf->wasmetal_core__DOT___029067_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000464_))));
    vlSelf->wasmetal_core__DOT___029066_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000432_))));
    vlSelf->wasmetal_core__DOT___128127___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028965_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028931_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b24__05d));
    vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000542_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000542_)
            : (IData)(vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128108___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028756_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028755_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028754_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028753_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___028718_)))));
    vlSelf->wasmetal_core__DOT___028723_ = ((IData)(vlSelf->wasmetal_core__DOT___028756_)
                                             ? (IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026468_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b22__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127888___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026678_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026677_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026676_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026675_)))) 
           ^ (((IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026608_)))));
    vlSelf->wasmetal_core__DOT___026613_ = ((IData)(vlSelf->wasmetal_core__DOT___026678_)
                                             ? (IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT___045247_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070703_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054354_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___045223_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070704_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054358_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xfU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054354_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070703_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU))))))))))))));
    vlSelf->wasmetal_core__DOT___045248_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070708_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054360_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___045224_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070709_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054364_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x11U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054360_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070708_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127939___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027148_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027147_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027146_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027145_)))) 
           ^ (((IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027078_)))));
    vlSelf->wasmetal_core__DOT___027083_ = ((IData)(vlSelf->wasmetal_core__DOT___027148_)
                                             ? (IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d));
    vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026575_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000465_));
    vlSelf->wasmetal_core__DOT___044975_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070806_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054353_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___044951_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070807_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xfU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054353_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070806_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU))))))))))))));
    vlSelf->wasmetal_core__DOT___044976_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070811_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054359_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___044952_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070812_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054363_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x11U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054359_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070811_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127922___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026948_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026947_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026946_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026945_)))) 
           ^ (((IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026878_)))));
    vlSelf->wasmetal_core__DOT___026883_ = ((IData)(vlSelf->wasmetal_core__DOT___026948_)
                                             ? (IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT____Vcellout___127905___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026813_) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_hf0334e7f__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h9cad1664__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hd86a0826__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026743_)))));
    vlSelf->wasmetal_core__DOT___026748_ = ((IData)(vlSelf->wasmetal_core__DOT___026813_)
                                             ? (IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT___030108_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf9b1d8fe__0)))));
    vlSelf->wasmetal_core__DOT___030236_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf9b1d8fe__0)))));
    vlSelf->wasmetal_core__DOT___030107_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha8b85945__0)))));
    vlSelf->wasmetal_core__DOT___030235_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha8b85945__0)))));
    vlSelf->wasmetal_core__DOT___030106_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haa037958__0)))));
    vlSelf->wasmetal_core__DOT___030234_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haa037958__0)))));
    vlSelf->wasmetal_core__DOT___030105_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8bacc2de__0)))));
    vlSelf->wasmetal_core__DOT___030233_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8bacc2de__0)))));
    vlSelf->wasmetal_core__DOT___128668___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000542_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128668___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128235___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030103_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030102_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030101_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030100_)))) 
           ^ (((IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030067_)))));
    vlSelf->wasmetal_core__DOT___030071_ = ((IData)(vlSelf->wasmetal_core__DOT___030103_)
                                             ? (IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128249___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030231_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030230_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030229_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030228_)))) 
           ^ (((IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030163_)))));
    vlSelf->wasmetal_core__DOT___030167_ = ((IData)(vlSelf->wasmetal_core__DOT___030231_)
                                             ? (IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d));
    vlSelf->wasmetal_core__DOT___063195_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063192_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063191_)))))));
    vlSelf->wasmetal_core__DOT___063201_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063198_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063197_)))))));
    vlSelf->wasmetal_core__DOT___063207_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063203_)))))));
    vlSelf->wasmetal_core__DOT___063213_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063210_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063209_)))))));
    vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028298_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028233_));
    vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036981_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h0bfb68a4__0))));
    vlSelf->wasmetal_core__DOT___044886_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027409_));
    vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027346_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127438___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005868_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003806_)))) 
           ^ (((IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___022514_)))));
    vlSelf->wasmetal_core__DOT___022519_ = ((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                            & (IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128146___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128481___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128146___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128329___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031063_)
            ? (IData)(wasmetal_core__DOT___128329___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    vlSelf->wasmetal_core__DOT___128552___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033429_));
    vlSelf->wasmetal_core__DOT___057742_ = ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___013705_) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___013709_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___013709_));
    vlSelf->wasmetal_core__DOT___057743_ = ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___013716_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___013716_));
    vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013722_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d) {
        wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d;
        wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d;
    } else {
        wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127628___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127593___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023743_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023742_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023803_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023802_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023738_)))));
    wasmetal_core__DOT___023680_ = ((IData)(vlSelf->wasmetal_core__DOT___023743_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d));
    wasmetal_core__DOT___023747_ = (1U & (6U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d))));
    wasmetal_core__DOT___058877_ = (1U & (8U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he6c218f0__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d))));
    vlSelf->wasmetal_core__DOT___058916_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058913_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he6c218f0__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0)))))))))));
    vlSelf->wasmetal_core__DOT___058730_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127627___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he6c218f0__0))))));
    wasmetal_core__DOT___023746_ = (1U & (6U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he6c218f0__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d))));
    vlSelf->wasmetal_core__DOT___058906_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2bc5853c__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d))))));
    vlSelf->wasmetal_core__DOT___058742_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127627___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2bc5853c__0))))));
    wasmetal_core__DOT___023745_ = (1U & (6U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2bc5853c__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d))));
    wasmetal_core__DOT___023744_ = (1U & (6U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d))));
    wasmetal_core__DOT___050151_ = (1U & (0xb0bbU >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005731_))))));
    wasmetal_core__DOT___050127_ = (1U & (4U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005716_))));
    wasmetal_core__DOT___050146_ = (1U & (0xdU >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___050128_ = (1U & (0xb0bbU >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005738_))))));
    wasmetal_core__DOT___006634_ = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O) 
                                              >> 3U)) 
                                          & (IData)(
                                                    (0xb0bbb0bb0000b0bbULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                       << 5U) 
                                                      | ((0x10U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                                             << 3U)) 
                                                         | ((8U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___003811_))))))))));
    __VdfgTmp_h7052d05f__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O)) 
                              | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    vlSelf->wasmetal_core__DOT____Vcellout___127561___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006171_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005711_)))) 
           ^ (((IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023457_)))));
    vlSelf->wasmetal_core__DOT___023462_ = ((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                            & (IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127578___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___002631_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0d220f7a__0))) 
           ^ (((IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023578_)))));
    vlSelf->wasmetal_core__DOT___023583_ = ((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                            & (IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d) {
        wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d;
        wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d;
    } else {
        wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127491___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127471___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022788_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022787_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022816_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022815_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022783_)))));
    vlSelf->wasmetal_core__DOT___022757_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022788_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0))));
    vlSelf->wasmetal_core__DOT___059171_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0))))));
    vlSelf->wasmetal_core__DOT___022792_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0))))));
    vlSelf->wasmetal_core__DOT___059140_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127490___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0))))));
    vlSelf->wasmetal_core__DOT___059172_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0))))));
    vlSelf->wasmetal_core__DOT___022791_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0))))));
    wasmetal_core__DOT___059095_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127490___O)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0))))));
    vlSelf->wasmetal_core__DOT___022790_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0))))));
    wasmetal_core__DOT___059094_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127490___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h607e9020__0))))));
    vlSelf->wasmetal_core__DOT___022789_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h607e9020__0))))));
    vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028103_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028069_)
                  : (vlSelf->insn_x >> 0x14U)));
    vlSelf->wasmetal_core__DOT___054566_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128652___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000521_)))));
    vlSelf->wasmetal_core__DOT___054567_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128652___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000543_)))));
    vlSelf->wasmetal_core__DOT___054568_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128652___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000565_)))));
    vlSelf->wasmetal_core__DOT___054569_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128652___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000592_)))));
    wasmetal_core__DOT___128653___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000614_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034366_));
    wasmetal_core__DOT___128117___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028859_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128117___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000464_));
    wasmetal_core__DOT___128082___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028479_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128082___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004960_));
    vlSelf->wasmetal_core__DOT___128100___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028654_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128100___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___005368_));
    vlSelf->wasmetal_core__DOT___128135___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029066_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029030_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___128127___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028966_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128127___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b25__05d));
    vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000564_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000564_)
            : (IData)(vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045373_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128108___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b53__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b55__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b54__05d)))))))));
    vlSelf->wasmetal_core__DOT___045385_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b55__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b54__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(wasmetal_core__DOT____Vcellout___128108___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___045372_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT___045384_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b52__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128107___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b51__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___128109___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028757_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028723_)
            : (IData)(vlSelf->wasmetal_core__DOT___000520_));
    vlSelf->wasmetal_core__DOT____Vcellout___127855___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026469_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026468_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026467_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026466_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026431_)))));
    vlSelf->wasmetal_core__DOT___026436_ = ((IData)(vlSelf->wasmetal_core__DOT___026469_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b23__05d));
    vlSelf->wasmetal_core__DOT___071273_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071272_))));
    vlSelf->wasmetal_core__DOT___071268_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071267_))));
    vlSelf->wasmetal_core__DOT___045339_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052140_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h23d702b8__0))))))));
    vlSelf->wasmetal_core__DOT___045351_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052140_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052449_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052448_)))))))));
    vlSelf->wasmetal_core__DOT___045338_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052447_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052139_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052445_)))))))));
    vlSelf->wasmetal_core__DOT___045350_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052139_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052447_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052445_)))))))));
    vlSelf->wasmetal_core__DOT___128091___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026679_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026613_)
            : (IData)(vlSelf->wasmetal_core__DOT___000520_));
    vlSelf->wasmetal_core__DOT___054366_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054372_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054368_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054370_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127940___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027149_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027083_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d));
    vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026576_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000477_));
    vlSelf->wasmetal_core__DOT___054365_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127922___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054371_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127922___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054367_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127922___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054369_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127922___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127923___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026949_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026883_)
            : (IData)(vlSelf->wasmetal_core__DOT___000520_));
    vlSelf->wasmetal_core__DOT___045925_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he4fb154e__0)))))));
    vlSelf->wasmetal_core__DOT___045937_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052528_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052527_)))))))));
    vlSelf->wasmetal_core__DOT___045924_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052555_)))))))));
    vlSelf->wasmetal_core__DOT___045936_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052555_)))))))));
    vlSelf->wasmetal_core__DOT___045407_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h92d5757b__0)))))));
    vlSelf->wasmetal_core__DOT___045406_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7b969d91__0)))))));
    vlSelf->wasmetal_core__DOT___045419_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003360_)))))))));
    vlSelf->wasmetal_core__DOT___045418_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003876_)))))))));
    vlSelf->wasmetal_core__DOT___045089_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071049_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071048_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071047_))))))));
    vlSelf->wasmetal_core__DOT___045113_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071049_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071048_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071047_)))))))));
    vlSelf->wasmetal_core__DOT___045088_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071034_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071033_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071032_)))))))));
    vlSelf->wasmetal_core__DOT___045112_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071034_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071033_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071032_)))))))));
    vlSelf->wasmetal_core__DOT___045879_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003936_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003416_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___003348_))))))));
    vlSelf->wasmetal_core__DOT___045903_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003416_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003348_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003936_)))))))));
    wasmetal_core__DOT___128073___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026814_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026748_)
            : (IData)(vlSelf->wasmetal_core__DOT___000520_));
    wasmetal_core__DOT___128668___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000564_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128668___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128236___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030105_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030071_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d));
    wasmetal_core__DOT___128250___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030233_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030167_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d));
    wasmetal_core__DOT___128063___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028299_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028234_));
    vlSelf->wasmetal_core__DOT____Vcellout___134184___O 
        = (((4U & ((8U >> (IData)(vlSelf->__VdfgTmp_h0bfb68a4__0)) 
                   << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___036981_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036980_))) 
           ^ ((((8U >> (IData)(vlSelf->__VdfgTmp_h0bfb68a4__0)) 
                & (IData)(vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036972_)))));
    vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027347_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b22__05d));
    vlSelf->__VdfgTmp_haba8fa43__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_hab9caa42__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O)))))));
    vlSelf->__VdfgTmp_hbec5a32d__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003806_));
    vlSelf->__VdfgTmp_hcdb7900c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005855_));
    vlSelf->__VdfgTmp_hb86fa734__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hb869da0d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O) 
                                                                >> 3U)))))));
    wasmetal_core__DOT___127439___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006106_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022519_));
    vlSelf->wasmetal_core__DOT____Vcellout___128146___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128481___O) 
           ^ ((0xfffffff8U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128481___O) 
                               << 1U) & ((IData)(wasmetal_core__DOT___128146___DOT__CO__BRA__1__KET__) 
                                         << 3U))) | 
              (((IData)(wasmetal_core__DOT___128146___DOT__CO__BRA__1__KET__) 
                << 2U) | (((IData)(wasmetal_core__DOT___128146___DOT__CO__BRA__0__KET__) 
                           << 1U) | (IData)(wasmetal_core__DOT___029143_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128329___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031066_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031065_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031063_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031062_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___031065_)
                 ? (IData)(wasmetal_core__DOT___128329___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128329___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128329___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031029_)))));
    wasmetal_core__DOT___128552___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128552___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013909_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057743_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057742_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127466___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013694_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hfe0efeb9__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022726_)))));
    wasmetal_core__DOT___022730_ = ((IData)(vlSelf->wasmetal_core__DOT___013694_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d) {
        wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d;
        vlSelf->wasmetal_core__DOT___023881_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d;
    } else {
        wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023881_ = wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___058883_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058878_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058877_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc26f8061__0))))))));
    wasmetal_core__DOT___127594___DOT__CO__BRA__0__KET__ 
        = ((IData)(wasmetal_core__DOT___023744_) ? (IData)(wasmetal_core__DOT___023680_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d));
    wasmetal_core__DOT___050148_ = (1U & (8U >> (((IData)(wasmetal_core__DOT___050128_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___050131_))));
    vlSelf->wasmetal_core__DOT___006643_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___050151_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___006634_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050130_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050145_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(__VdfgTmp_h7052d05f__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(wasmetal_core__DOT___050127_)))))))));
    wasmetal_core__DOT___006636_ = (1U & (0xb0bbU >> 
                                          ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h7052d05f__0)))));
    vlSelf->wasmetal_core__DOT___006672_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127561___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005711_))));
    vlSelf->__VdfgTmp_h276936c0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127561___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006144_));
    vlSelf->__VdfgTmp_hd5a5809b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127561___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006215_));
    vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005989_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023462_));
    vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002634_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023583_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d) {
        wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d;
        vlSelf->wasmetal_core__DOT___022871_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d;
    } else {
        wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022871_ = wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___059105_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059095_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059094_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127487___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127487___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7e209046__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0)))))))))));
    vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022789_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022757_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h607e9020__0))));
    vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028104_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0x15U)));
    wasmetal_core__DOT___128653___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000636_)) 
           & (IData)(wasmetal_core__DOT___128653___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128117___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028860_)
            ? (IData)(wasmetal_core__DOT___128117___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->wasmetal_core__DOT____Vcellout___128082___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028480_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028479_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028478_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028477_)))) 
           ^ (((IData)(wasmetal_core__DOT___128082___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128082___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128082___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028443_)))));
    vlSelf->wasmetal_core__DOT___028447_ = ((IData)(vlSelf->wasmetal_core__DOT___028480_)
                                             ? (IData)(wasmetal_core__DOT___128082___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___005028_));
    wasmetal_core__DOT___128100___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028655_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128100___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004960_));
    wasmetal_core__DOT___128135___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029067_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128135___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000464_));
    wasmetal_core__DOT___128127___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028967_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128127___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b26__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128440___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128440___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032273_)))));
    vlSelf->wasmetal_core__DOT___032277_ = ((IData)(vlSelf->wasmetal_core__DOT___000591_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___000591_)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128109___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028758_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128109___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000542_));
    vlSelf->__VdfgTmp_hcfac9f06__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127855___O) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               ((0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                                                    << 1U)) 
                                                | ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                                                             >> 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                                                               >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026470_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026436_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b24__05d));
    vlSelf->wasmetal_core__DOT___071274_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071273_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___071269_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071268_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d)))))))));
    wasmetal_core__DOT___128091___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026680_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128091___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000542_));
    vlSelf->wasmetal_core__DOT___070712_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054370_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x14U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b22__05d)))))));
    wasmetal_core__DOT___127940___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027150_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127940___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127871___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026577_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026576_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026575_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026574_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026506_)))));
    vlSelf->wasmetal_core__DOT___026511_ = ((IData)(vlSelf->wasmetal_core__DOT___026577_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000499_));
    vlSelf->wasmetal_core__DOT___070815_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054369_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x14U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b22__05d)))))));
    wasmetal_core__DOT___127923___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026950_)
            ? (IData)(wasmetal_core__DOT___127923___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000542_));
    wasmetal_core__DOT___128073___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026815_)
            ? (IData)(wasmetal_core__DOT___128073___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000542_));
    vlSelf->wasmetal_core__DOT____Vcellout___128668___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128440___S) 
           ^ (((IData)(wasmetal_core__DOT___128668___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128668___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128668___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034523_)))));
    vlSelf->wasmetal_core__DOT___034527_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000591_)) 
                                            & (IData)(wasmetal_core__DOT___128668___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128236___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030106_)
            ? (IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d));
    wasmetal_core__DOT___128250___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030234_)
            ? (IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d));
    wasmetal_core__DOT____Vcellout___128063___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028300_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028299_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028298_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028297_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128063___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028262_)))));
    vlSelf->wasmetal_core__DOT___028267_ = ((IData)(vlSelf->wasmetal_core__DOT___028300_)
                                             ? (IData)(wasmetal_core__DOT___128063___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028235_));
    vlSelf->wasmetal_core__DOT___065179_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134184___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___065051_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134184___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    wasmetal_core__DOT___127972___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127956___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027348_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027347_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027346_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027345_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027278_)))));
    vlSelf->wasmetal_core__DOT___027283_ = ((IData)(vlSelf->wasmetal_core__DOT___027348_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b23__05d));
    vlSelf->wasmetal_core__DOT___023217_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbec5a32d__0))));
    vlSelf->wasmetal_core__DOT___023216_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcdb7900c__0))));
    vlSelf->wasmetal_core__DOT___023215_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005770_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb86fa734__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb86fa734__0)))));
    vlSelf->wasmetal_core__DOT___023214_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005868_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb869da0d__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb869da0d__0)))));
    wasmetal_core__DOT___127439___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006022_) 
           & (IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128552___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d)) 
           & (IData)(wasmetal_core__DOT___128552___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___022697_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___057741_ = (1U & ((~ 
                                                   (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127462___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___002472_)))) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127462___O) 
                                                                     << 1U)) 
                                                                 | ((8U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_haeb5561e__0)))))))));
    vlSelf->wasmetal_core__DOT___013698_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013694_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h87a694d3__0))))))));
    vlSelf->__VdfgTmp_h8f0bea78__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013694_));
    wasmetal_core__DOT___127467___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013668_) 
           & (IData)(wasmetal_core__DOT___022730_));
    vlSelf->wasmetal_core__DOT____Vcellout___127628___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127628___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024004_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d) {
        vlSelf->wasmetal_core__DOT___024008_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d;
        vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024008_ = wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023881_;
    }
    wasmetal_core__DOT___127594___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___023745_) ? (IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d));
    wasmetal_core__DOT____Vcellout___127612___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127612___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023877_)))));
    vlSelf->wasmetal_core__DOT___006644_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___050148_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050147_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___050146_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h0d021fbc__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___022626_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___006623_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___006636_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___050128_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O)) 
                                                                 | (((IData)(wasmetal_core__DOT___050127_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006631_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___005745_))))))))))));
    vlSelf->wasmetal_core__DOT___050132_ = ((IData)(wasmetal_core__DOT___006636_) 
                                            & (IData)(
                                                      (0x1000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006635_) 
                                                         << 5U) 
                                                        | (((IData)(wasmetal_core__DOT___006634_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006633_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006632_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006631_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (4U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h0d021fbc__0)))))))))));
    vlSelf->wasmetal_core__DOT___006737_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127561___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd5a5809b__0)))));
    vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006099_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002633_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127491___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127491___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022930_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d) {
        vlSelf->wasmetal_core__DOT___022934_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d;
        vlSelf->wasmetal_core__DOT___127484___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022934_ = wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127484___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022871_;
    }
    vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022790_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0))));
    wasmetal_core__DOT____Vcellout___127483___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127483___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022867_)))));
    vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028105_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0x16U)));
    wasmetal_core__DOT___128653___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000658_)) 
           & (IData)(wasmetal_core__DOT___128653___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128117___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028861_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028860_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028859_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028858_)))) 
           ^ (((IData)(wasmetal_core__DOT___128117___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128117___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128117___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028822_)))));
    vlSelf->wasmetal_core__DOT___028827_ = ((IData)(vlSelf->wasmetal_core__DOT___028861_)
                                             ? (IData)(wasmetal_core__DOT___128117___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT___028865_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000591_))));
    vlSelf->wasmetal_core__DOT___028864_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000564_))));
    vlSelf->wasmetal_core__DOT___028863_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000542_))));
    vlSelf->wasmetal_core__DOT___028862_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000520_))));
    vlSelf->wasmetal_core__DOT___128083___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028481_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028447_)
            : (IData)(vlSelf->wasmetal_core__DOT___004892_));
    vlSelf->wasmetal_core__DOT____Vcellout___128100___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028656_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028655_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028654_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028653_)))) 
           ^ (((IData)(wasmetal_core__DOT___128100___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128100___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128100___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028619_)))));
    vlSelf->wasmetal_core__DOT___028623_ = ((IData)(vlSelf->wasmetal_core__DOT___028656_)
                                             ? (IData)(wasmetal_core__DOT___128100___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___005028_));
    wasmetal_core__DOT___128135___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029068_)
            ? (IData)(wasmetal_core__DOT___128135___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->wasmetal_core__DOT____Vcellout___128127___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028968_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028967_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028966_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028965_)))) 
           ^ (((IData)(wasmetal_core__DOT___128127___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128127___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128127___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028931_)))));
    vlSelf->wasmetal_core__DOT___028935_ = ((IData)(vlSelf->wasmetal_core__DOT___028968_)
                                             ? (IData)(wasmetal_core__DOT___128127___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b27__05d));
    vlSelf->wasmetal_core__DOT___128441___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000613_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000613_)
            : (IData)(vlSelf->wasmetal_core__DOT___032277_));
    wasmetal_core__DOT___128109___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028759_)
            ? (IData)(wasmetal_core__DOT___128109___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000564_));
    vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026471_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b25__05d));
    vlSelf->wasmetal_core__DOT___045045_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071274_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___045021_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071274_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054119_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054123_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071272_))))));
    vlSelf->wasmetal_core__DOT___045044_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071269_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___045020_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071269_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054107_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                   << 1U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054111_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071267_))))));
    wasmetal_core__DOT___128091___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026681_)
            ? (IData)(wasmetal_core__DOT___128091___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000564_));
    vlSelf->wasmetal_core__DOT___070714_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070712_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x13U)))))))))));
    vlSelf->wasmetal_core__DOT___070713_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070712_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054368_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x13U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d)))))))));
    wasmetal_core__DOT___127940___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027151_)
            ? (IData)(wasmetal_core__DOT___127940___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d));
    vlSelf->wasmetal_core__DOT___045497_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071364_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071363_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071362_))))))));
    vlSelf->wasmetal_core__DOT___045521_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071364_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071363_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071362_)))))))));
    vlSelf->wasmetal_core__DOT___045293_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071427_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071426_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071425_))))))));
    vlSelf->wasmetal_core__DOT___045317_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071427_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071426_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071425_)))))))));
    vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026578_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026511_)
            : (IData)(vlSelf->wasmetal_core__DOT___000521_));
    vlSelf->wasmetal_core__DOT___070817_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054367_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070815_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x13U)))))))))));
    vlSelf->wasmetal_core__DOT___070816_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070815_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054367_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x13U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d)))))))));
    wasmetal_core__DOT___127923___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026951_)
            ? (IData)(wasmetal_core__DOT___127923___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000564_));
    wasmetal_core__DOT___128073___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026816_)
            ? (IData)(wasmetal_core__DOT___128073___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000564_));
    vlSelf->wasmetal_core__DOT___040022_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128668___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___040023_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128668___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___040029_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128668___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___040028_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128668___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b27__05d)))))))));
    vlSelf->__VdfgTmp_h57bfdade__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128668___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000591_));
    vlSelf->__VdfgTmp_hefc70752__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128668___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000564_));
    vlSelf->__VdfgTmp_h0addf646__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128668___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000542_));
    vlSelf->__VdfgTmp_h4b276de4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128668___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000520_));
    vlSelf->wasmetal_core__DOT___128669___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000613_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034527_));
    wasmetal_core__DOT___128236___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030107_)
            ? (IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d));
    wasmetal_core__DOT___128250___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030235_)
            ? (IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d));
    wasmetal_core__DOT___063216_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128063___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063222_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128063___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063228_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128063___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063234_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128063___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028301_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028267_)
            : (IData)(vlSelf->wasmetal_core__DOT___028236_));
    vlSelf->wasmetal_core__DOT____Vcellout___127972___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
           ^ (((IData)(wasmetal_core__DOT___127972___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027409_)))));
    vlSelf->wasmetal_core__DOT___027413_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127972___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027349_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027283_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b24__05d));
    wasmetal_core__DOT___127439___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006099_) 
           & (IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128552___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128552___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128552___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128552___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033429_)))));
    vlSelf->wasmetal_core__DOT___033434_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)) 
                                            & (IData)(wasmetal_core__DOT___128552___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127467___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013670_) 
           & (IData)(wasmetal_core__DOT___127467___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d) {
        vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d;
        vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024008_;
        vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127594___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___023746_) ? (IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d));
    vlSelf->__VdfgTmp_h9141ccce__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127612___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003805_));
    vlSelf->__VdfgTmp_h3ada9ffa__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127612___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003808_));
    vlSelf->__VdfgTmp_hd665514e__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127612___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_));
    vlSelf->__VdfgTmp_hd093a298__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127612___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003807_));
    vlSelf->wasmetal_core__DOT___022625_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___022642_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006644_)))));
    vlSelf->wasmetal_core__DOT___006862_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006623_))));
    vlSelf->wasmetal_core__DOT___006930_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006952_))));
    vlSelf->wasmetal_core__DOT___006900_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->__VdfgTmp_h8420cdb8__0 = (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050132_));
    vlSelf->wasmetal_core__DOT___006640_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003808_)))));
    vlSelf->wasmetal_core__DOT___006836_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_)))));
    vlSelf->wasmetal_core__DOT___006639_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he473afc4__0))));
    vlSelf->wasmetal_core__DOT___006835_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_)))));
    vlSelf->wasmetal_core__DOT___006638_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_)))));
    vlSelf->wasmetal_core__DOT___006834_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003810_)))));
    vlSelf->wasmetal_core__DOT___006850_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hadeaba1a__0))));
    vlSelf->wasmetal_core__DOT___006858_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005982_)))));
    vlSelf->wasmetal_core__DOT___006872_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h28ae1e0e__0))));
    vlSelf->wasmetal_core__DOT___006855_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_)))));
    vlSelf->wasmetal_core__DOT___006869_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbc1c04e5__0))));
    vlSelf->wasmetal_core__DOT___006854_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_)))));
    vlSelf->wasmetal_core__DOT___006868_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005745_)))));
    vlSelf->wasmetal_core__DOT___006853_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbbe1bed2__0))));
    vlSelf->wasmetal_core__DOT___006867_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he7a338fa__0))));
    vlSelf->wasmetal_core__DOT___006852_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_)))));
    vlSelf->wasmetal_core__DOT___006866_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_)))));
    vlSelf->wasmetal_core__DOT___006908_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_)))));
    vlSelf->wasmetal_core__DOT___006882_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h76ba8332__0))));
    vlSelf->wasmetal_core__DOT___006907_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005731_))));
    vlSelf->wasmetal_core__DOT___022624_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050132_)))));
    vlSelf->wasmetal_core__DOT___022641_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005868_)))));
    vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006022_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002630_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127492___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___022934_));
    vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022791_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0))));
    vlSelf->__VdfgTmp_hc4a2ed9e__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127483___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003805_));
    vlSelf->__VdfgTmp_h686e5d09__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127483___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003808_));
    vlSelf->__VdfgTmp_h4dc2cdc8__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127483___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_));
    vlSelf->__VdfgTmp_h57318413__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127483___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003807_));
    vlSelf->wasmetal_core__DOT____Vcellout___128047___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028106_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028105_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028104_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028103_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028069_)))));
    vlSelf->wasmetal_core__DOT___028074_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028106_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0x17U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128653___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005617_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000658_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___000636_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___000614_)))))) 
           ^ (((IData)(wasmetal_core__DOT___128653___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128653___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128653___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034366_)))));
    vlSelf->wasmetal_core__DOT___034371_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___005617_)) 
                                            & (IData)(wasmetal_core__DOT___128653___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128118___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028862_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028827_)
            : (IData)(vlSelf->wasmetal_core__DOT___000520_));
    vlSelf->wasmetal_core__DOT___128083___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028482_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128083___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___005300_));
    vlSelf->wasmetal_core__DOT___054132_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128100___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b24__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054136_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128100___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b25__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054159_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054158_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128100___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b26__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054163_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128100___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___128101___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028657_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028623_)
            : (IData)(vlSelf->wasmetal_core__DOT___004892_));
    vlSelf->wasmetal_core__DOT____Vcellout___128135___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029069_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029068_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029067_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029066_)))) 
           ^ (((IData)(wasmetal_core__DOT___128135___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128135___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128135___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029030_)))));
    vlSelf->wasmetal_core__DOT___029035_ = ((IData)(vlSelf->wasmetal_core__DOT___029069_)
                                             ? (IData)(wasmetal_core__DOT___128135___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT___029073_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128127___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000591_))));
    vlSelf->wasmetal_core__DOT___029072_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128127___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000564_))));
    vlSelf->wasmetal_core__DOT___029071_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128127___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000542_))));
    vlSelf->wasmetal_core__DOT___029070_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128127___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000520_))));
    vlSelf->wasmetal_core__DOT___128128___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028969_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028935_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b28__05d));
    vlSelf->wasmetal_core__DOT___128441___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000635_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000635_)
            : (IData)(vlSelf->wasmetal_core__DOT___128441___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128109___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028760_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028759_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028758_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028757_)))) 
           ^ (((IData)(wasmetal_core__DOT___128109___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128109___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128109___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028723_)))));
    vlSelf->wasmetal_core__DOT___028727_ = ((IData)(vlSelf->wasmetal_core__DOT___028760_)
                                             ? (IData)(wasmetal_core__DOT___128109___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000591_));
    vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026472_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b26__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127889___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026682_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026681_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026680_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026679_)))) 
           ^ (((IData)(wasmetal_core__DOT___128091___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128091___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128091___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026613_)))));
    vlSelf->wasmetal_core__DOT___026617_ = ((IData)(vlSelf->wasmetal_core__DOT___026682_)
                                             ? (IData)(wasmetal_core__DOT___128091___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000591_));
    vlSelf->wasmetal_core__DOT___045249_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070713_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054366_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x12U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___045225_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070714_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054370_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b22__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x14U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054366_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070713_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x12U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127940___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027152_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027151_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027150_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027149_)))) 
           ^ (((IData)(wasmetal_core__DOT___127940___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127940___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127940___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027083_)))));
    vlSelf->wasmetal_core__DOT___027087_ = ((IData)(vlSelf->wasmetal_core__DOT___027152_)
                                             ? (IData)(wasmetal_core__DOT___127940___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d));
    vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026579_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000543_));
    vlSelf->wasmetal_core__DOT___044977_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070816_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054365_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x12U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___044953_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070817_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054369_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b22__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x14U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054365_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070816_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x12U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127923___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026952_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026951_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026950_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026949_)))) 
           ^ (((IData)(wasmetal_core__DOT___127923___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127923___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127923___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026883_)))));
    vlSelf->wasmetal_core__DOT___026887_ = ((IData)(vlSelf->wasmetal_core__DOT___026952_)
                                             ? (IData)(wasmetal_core__DOT___127923___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000591_));
    vlSelf->wasmetal_core__DOT____Vcellout___127906___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h2be29f89__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___026816_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026815_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026814_)))) 
           ^ (((IData)(wasmetal_core__DOT___128073___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128073___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128073___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026748_)))));
    vlSelf->wasmetal_core__DOT___026752_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2be29f89__0)))
                                             ? (IData)(wasmetal_core__DOT___128073___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000591_));
    vlSelf->wasmetal_core__DOT___030112_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h57bfdade__0)))));
    vlSelf->wasmetal_core__DOT___030240_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h57bfdade__0)))));
    vlSelf->wasmetal_core__DOT___030111_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hefc70752__0)))));
    vlSelf->wasmetal_core__DOT___030239_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hefc70752__0)))));
    vlSelf->wasmetal_core__DOT___030110_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0addf646__0)))));
    vlSelf->wasmetal_core__DOT___030238_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0addf646__0)))));
    vlSelf->wasmetal_core__DOT___030109_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4b276de4__0)))));
    vlSelf->wasmetal_core__DOT___030237_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4b276de4__0)))));
    vlSelf->wasmetal_core__DOT___128669___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000635_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128669___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128236___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030108_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030107_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030106_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030105_)))) 
           ^ (((IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030071_)))));
    vlSelf->wasmetal_core__DOT___030076_ = ((IData)(vlSelf->wasmetal_core__DOT___030108_)
                                             ? (IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128250___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030236_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030235_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030234_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030233_)))) 
           ^ (((IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030167_)))));
    vlSelf->wasmetal_core__DOT___030172_ = ((IData)(vlSelf->wasmetal_core__DOT___030236_)
                                             ? (IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d));
    vlSelf->wasmetal_core__DOT___063219_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063216_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063215_)))))));
    vlSelf->wasmetal_core__DOT___063225_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063222_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063221_)))))));
    vlSelf->wasmetal_core__DOT___063231_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063228_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063227_)))))));
    vlSelf->wasmetal_core__DOT___063237_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063233_)))))));
    vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028302_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028237_));
    vlSelf->wasmetal_core__DOT___044887_ = (1U & (IData)(
                                                         (0x8000400020001fULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d))))))));
    vlSelf->wasmetal_core__DOT___044863_ = (1U & (IData)(
                                                         (0xa220fbbafffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O) 
                                                                             >> 1U))))))))));
    vlSelf->__VdfgTmp_h7aa341ef__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___127973___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027413_));
    vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027350_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127439___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005989_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006106_)))) 
           ^ (((IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022519_)))));
    vlSelf->wasmetal_core__DOT___022523_ = ((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                            & (IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128553___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033434_));
    vlSelf->wasmetal_core__DOT____Vcellout___127467___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013672_) 
             << 2U) | (IData)(vlSelf->__VdfgTmp_hf8096cfd__0)) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                & (IData)(wasmetal_core__DOT___127467___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127467___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127467___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___022730_)))));
    vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127594___O 
        = ((((IData)(wasmetal_core__DOT___023747_) 
             << 3U) | (((IData)(wasmetal_core__DOT___023746_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___023745_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___023744_)))) 
           ^ (((IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023680_)))));
    vlSelf->wasmetal_core__DOT___023684_ = ((IData)(wasmetal_core__DOT___023747_)
                                             ? (IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d));
    vlSelf->wasmetal_core__DOT___058714_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127628___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0))))));
    vlSelf->wasmetal_core__DOT___023751_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d))));
    vlSelf->wasmetal_core__DOT___058917_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058914_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2bc5853c__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0)))))))))));
    vlSelf->wasmetal_core__DOT___058729_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127628___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0))))));
    vlSelf->wasmetal_core__DOT___023750_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d))));
    vlSelf->wasmetal_core__DOT___023749_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d))));
    vlSelf->wasmetal_core__DOT___058868_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058863_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd093a298__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___023748_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd093a298__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d))));
    vlSelf->wasmetal_core__DOT___022628_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006900_))));
    vlSelf->wasmetal_core__DOT___006896_ = ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006834_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006858_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006855_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006854_)))))))));
    vlSelf->wasmetal_core__DOT___006619_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006850_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006872_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006869_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006868_)))))))));
    vlSelf->wasmetal_core__DOT___006843_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006872_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006869_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006868_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006867_)))))))));
    vlSelf->wasmetal_core__DOT___006917_ = ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006855_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006854_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006853_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006852_)))))))));
    vlSelf->wasmetal_core__DOT___006870_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006868_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006866_))))));
    vlSelf->wasmetal_core__DOT___006914_ = ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006869_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006868_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006867_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006866_)))))))));
    vlSelf->wasmetal_core__DOT___006874_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006854_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006853_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006852_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006908_)))))))));
    vlSelf->wasmetal_core__DOT___006895_ = (1U & (IData)(
                                                         (0xaaf0ccffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006882_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006866_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006867_)))))))));
}
