#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__57(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__57\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___016528_;
    wasmetal_core__DOT___016528_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016529_;
    wasmetal_core__DOT___016529_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016541_;
    wasmetal_core__DOT___016541_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016747_;
    wasmetal_core__DOT___016747_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016748_;
    wasmetal_core__DOT___016748_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016893_;
    wasmetal_core__DOT___016893_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016904_;
    wasmetal_core__DOT___016904_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016935_;
    wasmetal_core__DOT___016935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016936_;
    wasmetal_core__DOT___016936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016937_;
    wasmetal_core__DOT___016937_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016938_;
    wasmetal_core__DOT___016938_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016941_;
    wasmetal_core__DOT___016941_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016944_;
    wasmetal_core__DOT___016944_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016957_;
    wasmetal_core__DOT___016957_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016961_;
    wasmetal_core__DOT___016961_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016963_;
    wasmetal_core__DOT___016963_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016968_;
    wasmetal_core__DOT___016968_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016975_;
    wasmetal_core__DOT___016975_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016993_;
    wasmetal_core__DOT___016993_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016994_;
    wasmetal_core__DOT___016994_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016996_;
    wasmetal_core__DOT___016996_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017001_;
    wasmetal_core__DOT___017001_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017007_;
    wasmetal_core__DOT___017007_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017012_;
    wasmetal_core__DOT___017012_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017021_;
    wasmetal_core__DOT___017021_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017023_;
    wasmetal_core__DOT___017023_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017032_;
    wasmetal_core__DOT___017032_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017034_;
    wasmetal_core__DOT___017034_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017045_;
    wasmetal_core__DOT___017045_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017056_;
    wasmetal_core__DOT___017056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017091_;
    wasmetal_core__DOT___017091_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017102_;
    wasmetal_core__DOT___017102_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017118_;
    wasmetal_core__DOT___017118_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017128_;
    wasmetal_core__DOT___017128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017129_;
    wasmetal_core__DOT___017129_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017131_;
    wasmetal_core__DOT___017131_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017146_;
    wasmetal_core__DOT___017146_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017167_;
    wasmetal_core__DOT___017167_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017461_;
    wasmetal_core__DOT___017461_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017962_;
    wasmetal_core__DOT___017962_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017964_;
    wasmetal_core__DOT___017964_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017970_;
    wasmetal_core__DOT___017970_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017993_;
    wasmetal_core__DOT___017993_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017996_;
    wasmetal_core__DOT___017996_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018026_;
    wasmetal_core__DOT___018026_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018027_;
    wasmetal_core__DOT___018027_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018041_;
    wasmetal_core__DOT___018041_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018042_;
    wasmetal_core__DOT___018042_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018043_;
    wasmetal_core__DOT___018043_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018051_;
    wasmetal_core__DOT___018051_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018052_;
    wasmetal_core__DOT___018052_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018064_;
    wasmetal_core__DOT___018064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018077_;
    wasmetal_core__DOT___018077_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018111_;
    wasmetal_core__DOT___018111_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018112_;
    wasmetal_core__DOT___018112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018156_;
    wasmetal_core__DOT___018156_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018206_;
    wasmetal_core__DOT___018206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018212_;
    wasmetal_core__DOT___018212_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018213_;
    wasmetal_core__DOT___018213_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018214_;
    wasmetal_core__DOT___018214_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018215_;
    wasmetal_core__DOT___018215_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018223_;
    wasmetal_core__DOT___018223_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018224_;
    wasmetal_core__DOT___018224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018225_;
    wasmetal_core__DOT___018225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018227_;
    wasmetal_core__DOT___018227_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018245_;
    wasmetal_core__DOT___018245_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018247_;
    wasmetal_core__DOT___018247_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018286_;
    wasmetal_core__DOT___018286_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018358_;
    wasmetal_core__DOT___018358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018359_;
    wasmetal_core__DOT___018359_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018360_;
    wasmetal_core__DOT___018360_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018361_;
    wasmetal_core__DOT___018361_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018362_;
    wasmetal_core__DOT___018362_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018363_;
    wasmetal_core__DOT___018363_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018366_;
    wasmetal_core__DOT___018366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018367_;
    wasmetal_core__DOT___018367_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018369_;
    wasmetal_core__DOT___018369_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018370_;
    wasmetal_core__DOT___018370_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018371_;
    wasmetal_core__DOT___018371_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018373_;
    wasmetal_core__DOT___018373_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018429_;
    wasmetal_core__DOT___018429_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018463_;
    wasmetal_core__DOT___018463_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018464_;
    wasmetal_core__DOT___018464_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018525_;
    wasmetal_core__DOT___018525_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018532_;
    wasmetal_core__DOT___018532_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018640_;
    wasmetal_core__DOT___018640_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018643_;
    wasmetal_core__DOT___018643_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018673_;
    wasmetal_core__DOT___018673_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018702_;
    wasmetal_core__DOT___018702_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018713_;
    wasmetal_core__DOT___018713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018714_;
    wasmetal_core__DOT___018714_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018718_;
    wasmetal_core__DOT___018718_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018764_;
    wasmetal_core__DOT___018764_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018795_;
    wasmetal_core__DOT___018795_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018796_;
    wasmetal_core__DOT___018796_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018893_;
    wasmetal_core__DOT___018893_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019193_;
    wasmetal_core__DOT___019193_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025149_;
    wasmetal_core__DOT___025149_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025154_;
    wasmetal_core__DOT___025154_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025158_;
    wasmetal_core__DOT___025158_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036049_;
    wasmetal_core__DOT___036049_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036271_;
    wasmetal_core__DOT___036271_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036276_;
    wasmetal_core__DOT___036276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036280_;
    wasmetal_core__DOT___036280_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036283_;
    wasmetal_core__DOT___036283_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036284_;
    wasmetal_core__DOT___036284_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036792_;
    wasmetal_core__DOT___036792_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043019_;
    wasmetal_core__DOT___043019_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043020_;
    wasmetal_core__DOT___043020_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043023_;
    wasmetal_core__DOT___043023_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043024_;
    wasmetal_core__DOT___043024_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049338_;
    wasmetal_core__DOT___049338_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049339_;
    wasmetal_core__DOT___049339_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058565_;
    wasmetal_core__DOT___058565_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058566_;
    wasmetal_core__DOT___058566_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058569_;
    wasmetal_core__DOT___058569_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058570_;
    wasmetal_core__DOT___058570_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058572_;
    wasmetal_core__DOT___058572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058573_;
    wasmetal_core__DOT___058573_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058576_;
    wasmetal_core__DOT___058576_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058577_;
    wasmetal_core__DOT___058577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058578_;
    wasmetal_core__DOT___058578_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058579_;
    wasmetal_core__DOT___058579_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058583_;
    wasmetal_core__DOT___058583_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058587_;
    wasmetal_core__DOT___058587_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058588_;
    wasmetal_core__DOT___058588_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058592_;
    wasmetal_core__DOT___058592_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058595_;
    wasmetal_core__DOT___058595_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058600_;
    wasmetal_core__DOT___058600_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058601_;
    wasmetal_core__DOT___058601_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058603_;
    wasmetal_core__DOT___058603_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058616_;
    wasmetal_core__DOT___058616_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058617_;
    wasmetal_core__DOT___058617_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058626_;
    wasmetal_core__DOT___058626_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058627_;
    wasmetal_core__DOT___058627_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058633_;
    wasmetal_core__DOT___058633_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058634_;
    wasmetal_core__DOT___058634_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058637_;
    wasmetal_core__DOT___058637_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058638_;
    wasmetal_core__DOT___058638_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058653_;
    wasmetal_core__DOT___058653_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058654_;
    wasmetal_core__DOT___058654_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058657_;
    wasmetal_core__DOT___058657_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058658_;
    wasmetal_core__DOT___058658_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058662_;
    wasmetal_core__DOT___058662_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058663_;
    wasmetal_core__DOT___058663_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059222_;
    wasmetal_core__DOT___059222_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059257_;
    wasmetal_core__DOT___059257_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059258_;
    wasmetal_core__DOT___059258_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059263_;
    wasmetal_core__DOT___059263_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059264_;
    wasmetal_core__DOT___059264_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059267_;
    wasmetal_core__DOT___059267_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059268_;
    wasmetal_core__DOT___059268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059269_;
    wasmetal_core__DOT___059269_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059270_;
    wasmetal_core__DOT___059270_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059271_;
    wasmetal_core__DOT___059271_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059273_;
    wasmetal_core__DOT___059273_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059275_;
    wasmetal_core__DOT___059275_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059276_;
    wasmetal_core__DOT___059276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059279_;
    wasmetal_core__DOT___059279_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059280_;
    wasmetal_core__DOT___059280_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059283_;
    wasmetal_core__DOT___059283_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059284_;
    wasmetal_core__DOT___059284_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059287_;
    wasmetal_core__DOT___059287_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059288_;
    wasmetal_core__DOT___059288_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059289_;
    wasmetal_core__DOT___059289_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059290_;
    wasmetal_core__DOT___059290_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059295_;
    wasmetal_core__DOT___059295_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059296_;
    wasmetal_core__DOT___059296_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059297_;
    wasmetal_core__DOT___059297_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059298_;
    wasmetal_core__DOT___059298_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059299_;
    wasmetal_core__DOT___059299_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059300_;
    wasmetal_core__DOT___059300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059301_;
    wasmetal_core__DOT___059301_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059302_;
    wasmetal_core__DOT___059302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059303_;
    wasmetal_core__DOT___059303_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059304_;
    wasmetal_core__DOT___059304_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059305_;
    wasmetal_core__DOT___059305_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059306_;
    wasmetal_core__DOT___059306_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059307_;
    wasmetal_core__DOT___059307_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059308_;
    wasmetal_core__DOT___059308_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059309_;
    wasmetal_core__DOT___059309_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059310_;
    wasmetal_core__DOT___059310_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059359_;
    wasmetal_core__DOT___059359_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059362_;
    wasmetal_core__DOT___059362_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059365_;
    wasmetal_core__DOT___059365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059366_;
    wasmetal_core__DOT___059366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059367_;
    wasmetal_core__DOT___059367_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059369_;
    wasmetal_core__DOT___059369_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059371_;
    wasmetal_core__DOT___059371_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059404_;
    wasmetal_core__DOT___059404_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059407_;
    wasmetal_core__DOT___059407_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059414_;
    wasmetal_core__DOT___059414_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059451_;
    wasmetal_core__DOT___059451_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059454_;
    wasmetal_core__DOT___059454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059455_;
    wasmetal_core__DOT___059455_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059456_;
    wasmetal_core__DOT___059456_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059457_;
    wasmetal_core__DOT___059457_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059458_;
    wasmetal_core__DOT___059458_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059459_;
    wasmetal_core__DOT___059459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059460_;
    wasmetal_core__DOT___059460_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059461_;
    wasmetal_core__DOT___059461_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059527_;
    wasmetal_core__DOT___059527_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059529_;
    wasmetal_core__DOT___059529_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059530_;
    wasmetal_core__DOT___059530_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059531_;
    wasmetal_core__DOT___059531_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059532_;
    wasmetal_core__DOT___059532_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059566_;
    wasmetal_core__DOT___059566_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059579_;
    wasmetal_core__DOT___059579_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059603_;
    wasmetal_core__DOT___059603_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059604_;
    wasmetal_core__DOT___059604_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060193_;
    wasmetal_core__DOT___060193_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060348_;
    wasmetal_core__DOT___060348_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060387_;
    wasmetal_core__DOT___060387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060459_;
    wasmetal_core__DOT___060459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060492_;
    wasmetal_core__DOT___060492_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060506_;
    wasmetal_core__DOT___060506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060520_;
    wasmetal_core__DOT___060520_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060534_;
    wasmetal_core__DOT___060534_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060536_;
    wasmetal_core__DOT___060536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060548_;
    wasmetal_core__DOT___060548_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060562_;
    wasmetal_core__DOT___060562_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060591_;
    wasmetal_core__DOT___060591_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060595_;
    wasmetal_core__DOT___060595_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060600_;
    wasmetal_core__DOT___060600_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060602_;
    wasmetal_core__DOT___060602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060620_;
    wasmetal_core__DOT___060620_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060628_;
    wasmetal_core__DOT___060628_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060637_;
    wasmetal_core__DOT___060637_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060642_;
    wasmetal_core__DOT___060642_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eround64__02ecommon_totalUnderflow;
    wasmetal_core__DOT__fpu__02earithmetic__02eround64__02ecommon_totalUnderflow = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eround64__02egenblk2__02eroundedSig__05b53__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eround64__02egenblk2__02eroundedSig__05b53__05d = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eround64__02egenblk2__02eroundedSig__05b54__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eround64__02egenblk2__02eroundedSig__05b54__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127762___O;
    wasmetal_core__DOT____Vcellout___127762___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128812___O;
    wasmetal_core__DOT____Vcellout___128812___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128831___O;
    wasmetal_core__DOT____Vcellout___128831___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128832___O;
    wasmetal_core__DOT____Vcellout___128832___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128843___O;
    wasmetal_core__DOT____Vcellout___128843___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128845___O;
    wasmetal_core__DOT____Vcellout___128845___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134161___O;
    wasmetal_core__DOT____Vcellout___134161___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128812___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128812___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128812___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128812___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128831___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128831___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128831___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128831___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128831___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128831___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128842___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128842___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128842___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128842___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128842___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128842___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128843___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128843___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128843___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128843___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128843___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128843___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128844___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128844___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128844___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128844___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128844___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128844___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128845___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128845___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134159___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134159___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134159___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134159___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134160___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134160___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134160___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134160___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134160___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134160___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_he878b3a8__0;
    __VdfgTmp_he878b3a8__0 = 0;
    CData/*3:0*/ __VdfgTmp_he904009c__0;
    __VdfgTmp_he904009c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4e5aac03__0;
    __VdfgTmp_h4e5aac03__0 = 0;
    CData/*3:0*/ __VdfgTmp_h0ef48b5f__0;
    __VdfgTmp_h0ef48b5f__0 = 0;
    CData/*3:0*/ __VdfgTmp_hc59fb841__0;
    __VdfgTmp_hc59fb841__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha18a5876__0;
    __VdfgTmp_ha18a5876__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc47a2f1f__0;
    __VdfgTmp_hc47a2f1f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6ec83bdc__0;
    __VdfgTmp_h6ec83bdc__0 = 0;
    CData/*3:0*/ __VdfgTmp_h00d59987__0;
    __VdfgTmp_h00d59987__0 = 0;
    CData/*1:0*/ __VdfgTmp_h166e2223__0;
    __VdfgTmp_h166e2223__0 = 0;
    CData/*5:0*/ __VdfgTmp_hf618fc36__0;
    __VdfgTmp_hf618fc36__0 = 0;
    CData/*4:0*/ __VdfgTmp_h75d85fc5__0;
    __VdfgTmp_h75d85fc5__0 = 0;
    CData/*5:0*/ __VdfgTmp_h4b0290b7__0;
    __VdfgTmp_h4b0290b7__0 = 0;
    CData/*2:0*/ __VdfgTmp_h0c9be8e1__0;
    __VdfgTmp_h0c9be8e1__0 = 0;
    CData/*1:0*/ __VdfgTmp_h601cb0b3__0;
    __VdfgTmp_h601cb0b3__0 = 0;
    CData/*2:0*/ __VdfgTmp_hce4bc968__0;
    __VdfgTmp_hce4bc968__0 = 0;
    CData/*2:0*/ __VdfgTmp_h3e19c29d__0;
    __VdfgTmp_h3e19c29d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h893f43f0__0;
    __VdfgTmp_h893f43f0__0 = 0;
    CData/*1:0*/ __VdfgTmp_h96788d86__0;
    __VdfgTmp_h96788d86__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd32c8afd__0;
    __VdfgTmp_hd32c8afd__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbbb73552__0;
    __VdfgTmp_hbbb73552__0 = 0;
    CData/*3:0*/ __VdfgTmp_hc303443c__0;
    __VdfgTmp_hc303443c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h61eefee9__0;
    __VdfgTmp_h61eefee9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9e4f981d__0;
    __VdfgTmp_h9e4f981d__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha5bd917e__0;
    __VdfgTmp_ha5bd917e__0 = 0;
    CData/*1:0*/ __VdfgTmp_h91143f30__0;
    __VdfgTmp_h91143f30__0 = 0;
    CData/*1:0*/ __VdfgTmp_h503e256d__0;
    __VdfgTmp_h503e256d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0260a162__0;
    __VdfgTmp_h0260a162__0 = 0;
    CData/*3:0*/ __VdfgTmp_h4919b5b1__0;
    __VdfgTmp_h4919b5b1__0 = 0;
    CData/*5:0*/ __VdfgTmp_h23858478__0;
    __VdfgTmp_h23858478__0 = 0;
    CData/*5:0*/ __VdfgTmp_haf2ded6f__0;
    __VdfgTmp_haf2ded6f__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb9c3a66a__0;
    __VdfgTmp_hb9c3a66a__0 = 0;
    CData/*1:0*/ __VdfgTmp_hceb98761__0;
    __VdfgTmp_hceb98761__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9ccc8db2__0;
    __VdfgTmp_h9ccc8db2__0 = 0;
    CData/*2:0*/ __VdfgTmp_h29ce91ec__0;
    __VdfgTmp_h29ce91ec__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8e246f46__0;
    __VdfgTmp_h8e246f46__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb715052c__0;
    __VdfgTmp_hb715052c__0 = 0;
    CData/*1:0*/ __VdfgTmp_hcdaab3df__0;
    __VdfgTmp_hcdaab3df__0 = 0;
    CData/*1:0*/ __VdfgTmp_haab05145__0;
    __VdfgTmp_haab05145__0 = 0;
    CData/*1:0*/ __VdfgTmp_h56c348e9__0;
    __VdfgTmp_h56c348e9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1bda1915__0;
    __VdfgTmp_h1bda1915__0 = 0;
    CData/*1:0*/ __VdfgTmp_h81ca6039__0;
    __VdfgTmp_h81ca6039__0 = 0;
    CData/*1:0*/ __VdfgTmp_h688967d3__0;
    __VdfgTmp_h688967d3__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbf2b62f5__0;
    __VdfgTmp_hbf2b62f5__0 = 0;
    CData/*2:0*/ __VdfgTmp_hdf63e4bf__0;
    __VdfgTmp_hdf63e4bf__0 = 0;
    CData/*2:0*/ __VdfgTmp_h0efadc80__0;
    __VdfgTmp_h0efadc80__0 = 0;
    CData/*2:0*/ __VdfgTmp_h4b6964fc__0;
    __VdfgTmp_h4b6964fc__0 = 0;
    CData/*2:0*/ __VdfgTmp_had793d18__0;
    __VdfgTmp_had793d18__0 = 0;
    CData/*1:0*/ __VdfgTmp_he14d8a41__0;
    __VdfgTmp_he14d8a41__0 = 0;
    CData/*1:0*/ __VdfgTmp_h34e522da__0;
    __VdfgTmp_h34e522da__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8aa93d8f__0;
    __VdfgTmp_h8aa93d8f__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc3bb2a19__0;
    __VdfgTmp_hc3bb2a19__0 = 0;
    CData/*3:0*/ __VdfgTmp_h7d28918f__0;
    __VdfgTmp_h7d28918f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h82ac78d0__0;
    __VdfgTmp_h82ac78d0__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb9827f61__0;
    __VdfgTmp_hb9827f61__0 = 0;
    CData/*2:0*/ __VdfgTmp_h336c6eb7__0;
    __VdfgTmp_h336c6eb7__0 = 0;
    CData/*1:0*/ __VdfgTmp_h228f6e73__0;
    __VdfgTmp_h228f6e73__0 = 0;
    CData/*2:0*/ __VdfgTmp_h410ade1c__0;
    __VdfgTmp_h410ade1c__0 = 0;
    CData/*2:0*/ __VdfgTmp_h1a2fc46e__0;
    __VdfgTmp_h1a2fc46e__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1118b815__0;
    __VdfgTmp_h1118b815__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbcaa6c53__0;
    __VdfgTmp_hbcaa6c53__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf67d9e80__0;
    __VdfgTmp_hf67d9e80__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5778fde6__0;
    __VdfgTmp_h5778fde6__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc22a8b6b__0;
    __VdfgTmp_hc22a8b6b__0 = 0;
    CData/*4:0*/ __VdfgTmp_h9aeb2493__0;
    __VdfgTmp_h9aeb2493__0 = 0;
    CData/*1:0*/ __VdfgTmp_haf319b6f__0;
    __VdfgTmp_haf319b6f__0 = 0;
    CData/*4:0*/ __VdfgTmp_hf9874a1f__0;
    __VdfgTmp_hf9874a1f__0 = 0;
    CData/*1:0*/ __VdfgTmp_he893b9f2__0;
    __VdfgTmp_he893b9f2__0 = 0;
    // Body
    __VdfgTmp_h166e2223__0 = ((2U & ((IData)((0xfef0f0f0ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h8c11f975__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfef0f0f000000000ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0)))));
    __VdfgTmp_h1bda1915__0 = ((2U & ((IData)((0xfef0f0f000000000ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h8c11f975__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfef0f0f0ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1fd1b68c__0)))));
    wasmetal_core__DOT___018051_ = (1U & (IData)((0xf00001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1fd1b68c__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h8c11f975__0))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfef0f0f0ULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xfef0f0f000000000ULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h27aa09ab__0))))))))))));
    __VdfgTmp_h0efadc80__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 2U) | ((2U & ((IData)(
                                                        (0xfef0f0f000000000ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h27aa09ab__0))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0xfef0f0f0ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))))));
    wasmetal_core__DOT___018640_ = (1U & (1U >> ((2U 
                                                  & ((IData)(
                                                             (0xfef0f0f0ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc333bcf7__0))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfef0f0f000000000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2c68bea6__0)))))));
    wasmetal_core__DOT___018369_ = (1U & (IData)((0xf111100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h27aa09ab__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h1fd1b68c__0))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfef0f0f0ULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he4b52d96__0))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xfef0f0f000000000ULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))))))))))));
    __VdfgTmp_hb9c3a66a__0 = ((2U & ((IData)((0xfff00000eeeeULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                      << 4U) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (0xfef0f0f0ULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h27aa09ab__0))) 
                                                            << 3U)) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xfef0f0f000000000ULL 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h1fd1b68c__0))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xfef0f0f000000000ULL 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xfef0f0f0ULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he4b52d96__0))))))))))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfff00000eeee0000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(
                                                                              (0xfef0f0f0ULL 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))) 
                                                                      << 3U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0))) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8c11f975__0)))))))))))));
    __VdfgTmp_h9ccc8db2__0 = ((2U & ((IData)((0xfef0f0f0ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h2c68bea6__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfef0f0f000000000ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfc3008ab__0)))));
    __VdfgTmp_hf618fc36__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                          << 4U) | 
                                         ((8U & ((IData)(
                                                         (0xfef0f0f0ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_he4b52d96__0))) 
                                                 << 3U)) 
                                          | ((4U & 
                                              ((IData)(
                                                       (0xfef0f0f000000000ULL 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))) 
                                               << 2U)) 
                                             | ((2U 
                                                 & ((IData)(
                                                            (0xfef0f0f000000000ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hfc3008ab__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (IData)(
                                                             (0xfef0f0f0ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2c68bea6__0)))))))));
    __VdfgTmp_h81ca6039__0 = ((2U & ((IData)((0xfef0f0f000000000ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_he4b52d96__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfef0f0f0ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfc3008ab__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127761___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                   ^ (((IData)(vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__2__KET__) 
                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___025145_))))));
    if (vlSelf->wasmetal_core__DOT___025172_) {
        wasmetal_core__DOT___025149_ = vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___025149_;
        wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___025154_ = wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___025154_;
        wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___025158_ = wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___025158_;
        wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__;
    } else {
        wasmetal_core__DOT___025149_ = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___025154_ = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___025158_ = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
    }
    wasmetal_core__DOT___016957_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015579_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128830___O))))))));
    wasmetal_core__DOT___016968_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015574_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128830___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___017001_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015559_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128830___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___017012_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015584_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128830___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128831___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h59ed23b8__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036249_));
    wasmetal_core__DOT___059579_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6e41553f__0))));
    wasmetal_core__DOT___018156_ = (1U & (IData)((0xfff4ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6799374a__0))))));
    wasmetal_core__DOT___018077_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___018075_)
                                           ? (IData)(
                                                     (0xfffffff4ffffff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018074_) 
                                                           << 4U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6799374a__0)))))
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT___018074_))));
    wasmetal_core__DOT___018373_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___059534_)))));
    __VdfgTmp_h75d85fc5__0 = (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___059069_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                           << 2U) | 
                                          ((2U & ((IData)(
                                                          (0xfdfULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018073_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h6e41553f__0))))))) 
                                                  << 1U)) 
                                           | (1U & (IData)(
                                                           (0x1fff00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_hb666b13b__0))))))));
    vlSelf->wasmetal_core__DOT___060164_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0fe0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060152_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((IData)(
                                                                                (0x2220a2aaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                           & (IData)(
                                                                                (0x3337f3ff0000ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555f444cULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060158_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006215_))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060156_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058930_)))))))))))));
    wasmetal_core__DOT___060193_ = (1U & (IData)((0xf0f7ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060190_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hbba2540d__0))))))));
    vlSelf->wasmetal_core__DOT___018339_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hac5f758c__0)))));
    vlSelf->wasmetal_core__DOT___059338_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058948_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058949_))))));
    vlSelf->wasmetal_core__DOT___059810_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5cb81b0a__0)))));
    vlSelf->wasmetal_core__DOT___059924_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4ab5d99d__0)))));
    vlSelf->wasmetal_core__DOT___059536_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6c11e1cc__0)))));
    vlSelf->wasmetal_core__DOT___018570_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hea1901c2__0)))));
    vlSelf->wasmetal_core__DOT___059389_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h74f09674__0)))));
    vlSelf->wasmetal_core__DOT___059431_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha3f8ca93__0)))));
    vlSelf->wasmetal_core__DOT___059862_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h64c7108d__0)))));
    vlSelf->wasmetal_core__DOT___059219_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xff4f4fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0)) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058153_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017498_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x10U 
                                                                            >> 
                                                                            ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058153_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x3a000000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017498_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h069b89c3__0)))))))))))));
    wasmetal_core__DOT___018429_ = (1U & (0xe000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hcb62e82f__0)))));
    vlSelf->wasmetal_core__DOT___059605_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7385dfc5__0)))));
    wasmetal_core__DOT___018532_ = (1U & (0xe000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hdb9ea8ba__0)))));
    wasmetal_core__DOT___018286_ = (1U & (IData)((0xfff0111100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hde0d3ce6__0))))));
    wasmetal_core__DOT___018052_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h4f345a43__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hafe91978__0))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h7afeeb38__0))))))));
    wasmetal_core__DOT___018225_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h9f5057e1__0))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hafdf98d6__0))))))));
    __VdfgTmp_hdf63e4bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hafdf98d6__0));
    wasmetal_core__DOT___018371_ = (1U & (IData)((0xf00001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h166e2223__0))))))));
    wasmetal_core__DOT___017461_ = (1U & (IData)((0x11110000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059013_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___059012_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h166e2223__0))))))));
    wasmetal_core__DOT___018223_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h1bda1915__0))))))));
    __VdfgTmp_h4b6964fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 2U) | (IData)(__VdfgTmp_h1bda1915__0));
    vlSelf->__VdfgTmp_heca3be9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018050_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018051_)));
    __VdfgTmp_hbf2b62f5__0 = (((IData)(wasmetal_core__DOT___018640_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018065_));
    vlSelf->wasmetal_core__DOT___018302_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018283_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> (IData)(__VdfgTmp_hf618fc36__0))))))));
    wasmetal_core__DOT___018224_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h27aa09ab__0))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h81ca6039__0))))))));
    __VdfgTmp_had793d18__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 2U) | (IData)(__VdfgTmp_h81ca6039__0));
    vlSelf->wasmetal_core__DOT___061884_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127761___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    vlSelf->wasmetal_core__DOT___061813_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127761___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    wasmetal_core__DOT___128831___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h7d39981d__0)) 
           & (IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___018718_ = (1U & (IData)((0xfdfULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018074_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018073_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___059579_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017538_)))))))));
    __VdfgTmp_hf67d9e80__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 2U) | ((2U & ((IData)(
                                                        (0xfef0f0f000000000ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc333bcf7__0))) 
                                                << 1U)) 
                                         | (IData)(wasmetal_core__DOT___018156_)));
    __VdfgTmp_hceb98761__0 = (((IData)(wasmetal_core__DOT___018156_) 
                               << 1U) | (1U & (IData)(
                                                      (0xfef0f0f000000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc333bcf7__0)))));
    wasmetal_core__DOT___018227_ = (1U & (IData)((0xfef0000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                          << 3U) 
                                                         | ((((~ (IData)(vlSelf->wasmetal_core__DOT___018065_)) 
                                                              & (IData)(wasmetal_core__DOT___018077_)) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfef0f0f000000000ULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h2c68bea6__0))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xfef0f0f0ULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc333bcf7__0))))))))))));
    wasmetal_core__DOT___018064_ = ((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                    & (IData)(wasmetal_core__DOT___018077_));
    vlSelf->wasmetal_core__DOT___059982_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___018373_)))));
    vlSelf->wasmetal_core__DOT___059965_ = (1U & (0xbfbf00bfU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059579_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___018373_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018055_)))))));
    vlSelf->wasmetal_core__DOT___059981_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059980_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___018373_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1ab499a5__0))))))));
    vlSelf->wasmetal_core__DOT___018287_ = (1U & (IData)(
                                                         (0xff10000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h75d85fc5__0)))));
    __VdfgTmp_h228f6e73__0 = ((2U & ((IData)((0xfff00000eeee0000ULL 
                                              >> (IData)(__VdfgTmp_hf618fc36__0))) 
                                     << 1U)) | (1U 
                                                & (0xff10U 
                                                   >> (IData)(__VdfgTmp_h75d85fc5__0))));
    vlSelf->wasmetal_core__DOT___018980_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___060193_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060188_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                            & (IData)(
                                                                                (0x3337f3ff0000ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x2220a2aaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___018301_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018285_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___018286_))));
    wasmetal_core__DOT___018245_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___018225_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018226_))));
    wasmetal_core__DOT___059604_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017460_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___017461_)))));
    vlSelf->wasmetal_core__DOT___018428_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xeU 
                                                                      >> (IData)(__VdfgTmp_hdf63e4bf__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h7afeeb38__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xe0U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h4e256671__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> (IData)(__VdfgTmp_h4b6964fc__0)))))))))));
    vlSelf->__VdfgTmp_h450b6bb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                       << 2U) | ((2U 
                                                  & ((0xe0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018053_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___018052_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_heca3be9d__0)))));
    vlSelf->__VdfgTmp_h5acde712__0 = (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___018223_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018224_)));
    vlSelf->__VdfgTmp_ha0bbf0cf__0 = ((2U & ((IData)(
                                                     (0xff00f0f011111111ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059488_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((1U 
                                                                     >> 
                                                                     ((2U 
                                                                       & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9f5057e1__0)))))) 
                                                                    << 2U)) 
                                                                | ((2U 
                                                                    & ((0xeU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h4e256671__0)) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (0xe0U 
                                                                         >> (IData)(__VdfgTmp_hdf63e4bf__0)))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf000f0000eeeeULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((0xe0U 
                                                                >> (IData)(__VdfgTmp_had793d18__0)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((0xe0U 
                                                                   >> (IData)(__VdfgTmp_h4b6964fc__0)) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((0xeU 
                                                                      >> (IData)(__VdfgTmp_h0efadc80__0)) 
                                                                     << 2U)) 
                                                                 | (IData)(__VdfgTmp_hbf2b62f5__0)))))))));
    wasmetal_core__DOT___016941_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0x3a00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd6a04253__0))))
                                               : (IData)(wasmetal_core__DOT___016957_))
                                           : (IData)(wasmetal_core__DOT___016957_)));
    vlSelf->__VdfgTmp_hd10ddd3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___016942_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016941_));
    wasmetal_core__DOT___016961_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he686eaae__0))))
                                               : (IData)(wasmetal_core__DOT___016968_))
                                           : (IData)(wasmetal_core__DOT___016968_)));
    vlSelf->__VdfgTmp_h1c77e7ba__0 = (((IData)(wasmetal_core__DOT___016941_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016961_));
    wasmetal_core__DOT___016994_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0x3a00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcec7f9ed__0))))
                                               : (IData)(wasmetal_core__DOT___017001_))
                                           : (IData)(wasmetal_core__DOT___017001_)));
    vlSelf->__VdfgTmp_hb9ae5421__0 = (((IData)(wasmetal_core__DOT___016961_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016994_));
    vlSelf->wasmetal_core__DOT___017005_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4e293e30__0))))
                                                    : (IData)(wasmetal_core__DOT___017012_))
                                                   : (IData)(wasmetal_core__DOT___017012_)));
    vlSelf->__VdfgTmp_hbf2def73__0 = (((IData)(wasmetal_core__DOT___016994_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017005_));
    wasmetal_core__DOT___128831___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_ha00e7863__0)) 
           & (IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___018568_ = (1U & (0x70000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___018718_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hbf2b62f5__0))))));
    vlSelf->wasmetal_core__DOT___018427_ = (1U & (IData)(
                                                         (0x11111111fffff000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___018718_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___018640_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(__VdfgTmp_had793d18__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xe0U 
                                                                             >> (IData)(__VdfgTmp_h0efadc80__0)))))))))));
    vlSelf->wasmetal_core__DOT___059781_ = (1U & ((8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017462_))) 
                                                  & (IData)(
                                                            (0xfff0fff000007777ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___018718_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & ((0xe0U 
                                                                         >> (IData)(__VdfgTmp_h0efadc80__0)) 
                                                                        << 3U)) 
                                                                    | ((4U 
                                                                        & ((0xeU 
                                                                            >> (IData)(__VdfgTmp_had793d18__0)) 
                                                                           << 2U)) 
                                                                       | (IData)(__VdfgTmp_hbf2b62f5__0)))))))));
    vlSelf->wasmetal_core__DOT___018613_ = (1U & (IData)(
                                                         (0xfff0444400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018283_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(__VdfgTmp_hf618fc36__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___059069_) 
                                                                               << 3U) 
                                                                              | (IData)(__VdfgTmp_hf67d9e80__0))))))))))));
    __VdfgTmp_h5778fde6__0 = ((4U & ((IData)((0xfff4ff00ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018159_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((0xeU 
                                                                >> (IData)(__VdfgTmp_hf67d9e80__0)) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (1U 
                                                                    >> (IData)(__VdfgTmp_h9ccc8db2__0)))))))))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (1U 
                                                      >> (IData)(__VdfgTmp_hb9c3a66a__0)))));
    wasmetal_core__DOT___018370_ = (1U & (IData)((0xf00001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2c68bea6__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hfc3008ab__0))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_hceb98761__0))))))));
    vlSelf->wasmetal_core__DOT___018148_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___018159_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___017463_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___018065_)
                                                    ? 
                                                   (0xe000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h9ccc8db2__0))))
                                                    : 
                                                   (0xe000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_hceb98761__0)))))));
    vlSelf->wasmetal_core__DOT___059895_ = (1U & (IData)(
                                                         (0xbf00bfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___018227_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___059046_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___059047_))))))))))));
    vlSelf->wasmetal_core__DOT___059897_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___018227_))));
    wasmetal_core__DOT___018247_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___018227_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017462_))));
    vlSelf->wasmetal_core__DOT___059628_ = (1U & (IData)(
                                                         (0xff110000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(__VdfgTmp_had793d18__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(wasmetal_core__DOT___018064_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___018640_)))))))));
    vlSelf->wasmetal_core__DOT___018054_ = ((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___018066_)
                                                ? (0xfff01111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(
                                                                   (0xfef0f0f000000000ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_he4b52d96__0))) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xfef0f0f0ULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hfc3008ab__0))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0x1fffULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hb666b13b__0))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0x1fff00000000ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___059053_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059051_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059052_))))))))))))))
                                                : (2U 
                                                   >> (IData)(wasmetal_core__DOT___018064_))));
    vlSelf->__VdfgTmp_h5c50a9b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___018064_));
    vlSelf->wasmetal_core__DOT___059930_ = (1U & (0xdfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059924_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018287_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017462_)))))));
    vlSelf->wasmetal_core__DOT___018303_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018287_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017462_))));
    vlSelf->__VdfgTmp_h14645516__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___017462_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___017463_)
                                                   ? 
                                                  (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___018286_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___018285_))))
                                                   : 
                                                  (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> (IData)(__VdfgTmp_hf618fc36__0))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___018283_)))))
                                               : (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018287_)))) 
                                             << 1U)) 
                                      | (1U & (0xe000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha61a6e02__0))))));
    vlSelf->wasmetal_core__DOT___059809_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h228f6e73__0)))));
    wasmetal_core__DOT___059603_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h228f6e73__0))));
    vlSelf->wasmetal_core__DOT___059218_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017463_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017462_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(
                                                                 (0xfff000001111ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                       << 4U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hde0d3ce6__0))))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x1111fff000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7343b3bd__0))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfd96674a__0))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x1fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058950_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058949_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058948_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058945_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058943_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058942_)))))))))))))))))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((0xff10U 
                                                          >> (IData)(__VdfgTmp_h75d85fc5__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0xfff00000eeee0000ULL 
                                                                   >> (IData)(__VdfgTmp_hf618fc36__0)))))))
                                                   : 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___017462_)) 
                                                   | (0xeU 
                                                      >> 
                                                      (((IData)(wasmetal_core__DOT___017461_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017460_))))));
    vlSelf->wasmetal_core__DOT___059244_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x440f0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___014712_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059235_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059233_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d)))))))))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059218_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h1a828198__0))))))));
    wasmetal_core__DOT____Vcellout___128831___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h71404310__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha00e7863__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7d39981d__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h59ed23b8__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036249_)))));
    vlSelf->wasmetal_core__DOT___036254_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h71404310__0)) 
                                            & (IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hdd3dcee5__0 = ((2U & ((0xe0U 
                                              >> (IData)(vlSelf->__VdfgTmp_h5acde712__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___018568_));
    __VdfgTmp_h336c6eb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___018428_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018427_)));
    vlSelf->wasmetal_core__DOT___059784_ = (1U & (IData)(
                                                         (0xfffff44400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059781_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059005_)))))))));
    vlSelf->__VdfgTmp_hf7efd051__0 = ((4U & ((0xe000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc369107b__0)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___059781_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018055_)));
    vlSelf->__VdfgTmp_h4db98f39__0 = ((4U & ((0xe000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h214cf44d__0)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___018613_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018055_)));
    vlSelf->wasmetal_core__DOT___059707_ = (1U & (IData)(
                                                         (0xfffff44400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018613_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059027_)))))))));
    vlSelf->wasmetal_core__DOT___018521_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xb00ff00ff00ffULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((0xb0U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___059658_) 
                                                                           << 3U) 
                                                                          | (IData)(__VdfgTmp_h5778fde6__0)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016504_)))));
    vlSelf->wasmetal_core__DOT___018536_ = (1U & (IData)(
                                                         (0xb00ff00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059660_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h5778fde6__0)))))));
    vlSelf->__VdfgTmp_h7d1ccc69__0 = (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___018532_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_h5778fde6__0))));
    vlSelf->wasmetal_core__DOT___018683_ = (1U & (IData)(
                                                         (0xf888800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___018369_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___018370_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059534_)))))))));
    __VdfgTmp_hc3bb2a19__0 = (((IData)(wasmetal_core__DOT___018370_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018369_));
    if (vlSelf->wasmetal_core__DOT___017462_) {
        if (vlSelf->wasmetal_core__DOT___017463_) {
            vlSelf->wasmetal_core__DOT___059432_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018226_) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___018225_)))));
            vlSelf->wasmetal_core__DOT___059390_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018147_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___018146_)))));
        } else {
            vlSelf->wasmetal_core__DOT___059432_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___018224_) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___018223_)))));
            vlSelf->wasmetal_core__DOT___059390_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                 << 2U) | (IData)(__VdfgTmp_hb9c3a66a__0))));
        }
        vlSelf->wasmetal_core__DOT___059339_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___018055_)) 
                                                   & (0xfff01111U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018053_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___018052_) 
                                                              << 2U) 
                                                             | (((IData)(wasmetal_core__DOT___018051_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___018050_))))))));
        vlSelf->wasmetal_core__DOT___059535_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___018055_)) 
                                                   & (0xf1111U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018372_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___018371_) 
                                                              << 2U) 
                                                             | (IData)(__VdfgTmp_hc3bb2a19__0)))))));
    } else {
        vlSelf->wasmetal_core__DOT___059432_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___018227_))));
        vlSelf->wasmetal_core__DOT___059390_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___018148_))));
        vlSelf->wasmetal_core__DOT___059339_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___018055_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___018054_))));
        vlSelf->wasmetal_core__DOT___059535_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___018055_)) 
                                                   & (2U 
                                                      >> (IData)(wasmetal_core__DOT___018373_))));
    }
    vlSelf->wasmetal_core__DOT___059869_ = (1U & (0xff40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059862_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018148_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018055_)))))));
    vlSelf->wasmetal_core__DOT___059868_ = (1U & (0x7f7f007fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059040_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018148_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1ab499a5__0))))));
    __VdfgTmp_h29ce91ec__0 = ((4U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT___018148_) 
                                              << 1U) 
                                             | (IData)(vlSelf->wasmetal_core__DOT___017462_))) 
                                     << 2U)) | ((2U 
                                                 & ((1U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___018146_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___018147_))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (1U 
                                                      >> (IData)(__VdfgTmp_hb9c3a66a__0)))));
    vlSelf->wasmetal_core__DOT___059437_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___059432_))));
    vlSelf->wasmetal_core__DOT___059899_ = (1U & (IData)(
                                                         (0xfffff44400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059044_)))))))));
    vlSelf->wasmetal_core__DOT___059434_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xb0U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___018247_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xeU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h5acde712__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___018245_)))))))));
    vlSelf->wasmetal_core__DOT___059436_ = (1U & ((7U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___058951_)))) 
                                                  & (IData)(
                                                            (0xff00ff0fffdfffULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___018247_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((0xeU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h5acde712__0)) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                        << 2U) 
                                                                       | (((IData)(wasmetal_core__DOT___018245_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017463_))))))))));
    __VdfgTmp_h1118b815__0 = ((2U & ((0x10U >> (IData)(vlSelf->__VdfgTmp_heca3be9d__0)) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___059628_));
    vlSelf->wasmetal_core__DOT___059343_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018054_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017462_))));
    __VdfgTmp_h9aeb2493__0 = (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___059830_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___018054_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___018055_)))));
    vlSelf->wasmetal_core__DOT___059948_ = (1U & (IData)(
                                                         (0xbfffbfffbfffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059944_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5c50a9b1__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018055_)))))))));
    vlSelf->wasmetal_core__DOT___018338_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5c50a9b1__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017462_)))));
    wasmetal_core__DOT___018643_ = (1U & (0xf800U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h5c50a9b1__0)))));
    vlSelf->wasmetal_core__DOT___059729_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017463_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___018066_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___018643_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((0xeU 
                                                             >> (IData)(__VdfgTmp_h0efadc80__0)) 
                                                            << 1U)) 
                                                        | (1U 
                                                           & (0xe0U 
                                                              >> (IData)(__VdfgTmp_h4b6964fc__0))))))
                                                    : 
                                                   (0xf010U 
                                                    >> 
                                                    ((8U 
                                                      & ((0xe0U 
                                                          >> (IData)(__VdfgTmp_had793d18__0)) 
                                                         << 3U)) 
                                                     | (((IData)(wasmetal_core__DOT___018643_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_hbf2b62f5__0)))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(wasmetal_core__DOT___018643_))));
    vlSelf->wasmetal_core__DOT___059473_ = (1U & ((0xbU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___058956_)))) 
                                                  & (IData)(
                                                            (0xff00ff0fffdfffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___018303_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018302_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018301_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017463_))))))))));
    vlSelf->wasmetal_core__DOT___059483_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h14645516__0))));
    vlSelf->__VdfgTmp_h52593617__0 = (((IData)(vlSelf->wasmetal_core__DOT___059809_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018055_));
    vlSelf->wasmetal_core__DOT___018442_ = (1U & (IData)(
                                                         (0xf0fef0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059605_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___059604_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___059603_)))))))));
    vlSelf->__VdfgTmp_h75b7aca4__0 = (((IData)(wasmetal_core__DOT___059603_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___059604_));
    wasmetal_core__DOT____Vcellout___127762___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___025149_))))));
    vlSelf->wasmetal_core__DOT___017028_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015454_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___128831___O))))))));
    vlSelf->wasmetal_core__DOT___017039_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015450_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128831___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017136_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015522_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128831___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___017151_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015451_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128831___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128832___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h34f07943__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036254_));
    vlSelf->wasmetal_core__DOT___018549_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0fef0f0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018570_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hdd3dcee5__0)))))))))));
    vlSelf->wasmetal_core__DOT___059687_ = (1U & (IData)(
                                                         (0xef0f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___059022_)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdd3dcee5__0))))))));
    vlSelf->wasmetal_core__DOT___018434_ = (1U & (IData)(
                                                         (0xe00ff00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059588_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h336c6eb7__0)))))));
    vlSelf->__VdfgTmp_hc008d36b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___018429_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_h336c6eb7__0))));
    vlSelf->wasmetal_core__DOT___059785_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7efd051__0))));
    vlSelf->wasmetal_core__DOT___059656_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016506_)) 
                                                  & (IData)(
                                                            (0xff00fff4ff00ff00ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h7d1ccc69__0)))));
    vlSelf->__VdfgTmp_ha2122f26__0 = ((4U & ((0xe000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hdf3a557f__0)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___018683_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018055_)));
    vlSelf->__VdfgTmp_hb1bc7919__0 = (((IData)(wasmetal_core__DOT___018373_) 
                                       << 2U) | ((2U 
                                                  & ((0xe0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___018371_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___018372_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xeU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_hc3bb2a19__0))))));
    vlSelf->wasmetal_core__DOT___059392_ = (1U & (IData)(
                                                         (0xf3f5f0f000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xb0U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h29ce91ec__0)))))));
    vlSelf->wasmetal_core__DOT___059395_ = ((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                            & ((1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)))
                                                ? (IData)(
                                                          (0xf3fff5fff0fff0ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___018176_) 
                                                                   << 3U) 
                                                                  | (IData)(__VdfgTmp_h29ce91ec__0))))))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___018176_))));
    vlSelf->wasmetal_core__DOT___018510_ = (1U & (IData)(
                                                         (0xfff01110fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h15aa6b6f__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_h1118b815__0))))))));
    vlSelf->wasmetal_core__DOT___018490_ = (1U & (IData)(
                                                         (0xef0f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___059014_)))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_h1118b815__0))))))));
    vlSelf->wasmetal_core__DOT___059348_ = (1U & (IData)(
                                                         (0xff1fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059346_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059343_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450b6bb7__0)))))));
    vlSelf->wasmetal_core__DOT___059833_ = (1U & (IData)(
                                                         (0xff404040ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h9aeb2493__0)))));
    vlSelf->wasmetal_core__DOT___059837_ = (1U & (IData)(
                                                         (0xff404040ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h9aeb2493__0)))));
    vlSelf->__VdfgTmp_hf2800fdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___018338_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha0bbf0cf__0));
    vlSelf->__VdfgTmp_h4740201c__0 = (((IData)(vlSelf->wasmetal_core__DOT___018443_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018442_));
    vlSelf->wasmetal_core__DOT___059620_ = (1U & (IData)(
                                                         (0x1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059614_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h75b7aca4__0))))))));
    vlSelf->wasmetal_core__DOT___062013_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127762___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    vlSelf->wasmetal_core__DOT___062072_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127762___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    vlSelf->wasmetal_core__DOT___061953_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127762___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    wasmetal_core__DOT____Vcellout___128832___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___036202_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (7U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h34f07943__0)))) 
                                                   ^ 
                                                   (((((IData)(vlSelf->wasmetal_core__DOT___036202_) 
                                                       & (IData)(vlSelf->wasmetal_core__DOT___128832___DOT__CO__BRA__0__KET__)) 
                                                      << 2U) 
                                                     | ((IData)(vlSelf->wasmetal_core__DOT___128832___DOT__CO__BRA__0__KET__) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___036254_)));
    vlSelf->wasmetal_core__DOT___059584_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016506_)) 
                                                  & (IData)(
                                                            (0xff00fff1ff00ff00ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hc008d36b__0)))));
    vlSelf->wasmetal_core__DOT___018411_ = (1U & (0xeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff000e00ff00ffULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc008d36b__0))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___018318_)))));
    vlSelf->wasmetal_core__DOT___018520_ = (1U & (IData)(
                                                         (0xf0f0f0f0f0f0f02ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059657_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059656_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xdddf5d55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059652_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013654_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018080_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006085_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019194_)))))))));
    vlSelf->wasmetal_core__DOT___059552_ = (1U & (IData)(
                                                         (0xee000f00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059550_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb1bc7919__0)))))));
    vlSelf->wasmetal_core__DOT___018381_ = ((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                            & (IData)(
                                                      (0xff11fff0ff00ff00ULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((0xb0U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                            << 5U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018401_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb1bc7919__0)))))));
    vlSelf->wasmetal_core__DOT___018481_ = (1U & (IData)(
                                                         (0xcf8aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059635_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xdddf5d55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059631_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018080_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006015_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018510_)))))))));
    vlSelf->wasmetal_core__DOT___059516_ = ((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                            & ((1U 
                                                & (0xb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)))
                                                ? (IData)(
                                                          (0xf3fff5fff0fff0ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___018344_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hf2800fdf__0))))))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___018344_))));
    vlSelf->__VdfgTmp_hc5312148__0 = ((4U & ((0xe000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h11c34da7__0)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___059729_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018055_)));
    vlSelf->wasmetal_core__DOT___059733_ = (1U & (IData)(
                                                         (0xfffff44400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059729_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058992_)))))))));
    wasmetal_core__DOT___017021_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h59ed23b8__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___017028_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___017028_)));
    vlSelf->__VdfgTmp_h9d72ac71__0 = (((IData)(vlSelf->wasmetal_core__DOT___017005_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017021_));
    wasmetal_core__DOT___017032_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7d39981d__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___017039_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___017039_)));
    vlSelf->__VdfgTmp_hc6f109bf__0 = (((IData)(wasmetal_core__DOT___017021_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017032_));
    wasmetal_core__DOT___017129_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha00e7863__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___017136_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___017136_)));
    vlSelf->__VdfgTmp_hf8652348__0 = (((IData)(wasmetal_core__DOT___017032_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017129_));
    vlSelf->wasmetal_core__DOT___017144_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h71404310__0))))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___017151_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___017151_)));
    vlSelf->__VdfgTmp_h5ad561b8__0 = (((IData)(wasmetal_core__DOT___017129_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017144_));
    wasmetal_core__DOT___017167_ = (1U & (0x8aaaaaaaU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015262_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128832___O))))))));
    vlSelf->wasmetal_core__DOT___017155_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                                    ? 
                                                   (2U 
                                                    >> 
                                                    (1U 
                                                     & (4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h34f07943__0))))
                                                    : (IData)(wasmetal_core__DOT___017167_))
                                                   : (IData)(wasmetal_core__DOT___017167_)));
    wasmetal_core__DOT__fpu__02earithmetic__02eround64__02egenblk2__02eroundedSig__05b54__05d 
        = (1U & (0xb00U >> ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128832___O) 
                                   << 1U)) | (((IData)(vlSelf->wasmetal_core__DOT___058217_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058218_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015266_))))));
    wasmetal_core__DOT__fpu__02earithmetic__02eround64__02egenblk2__02eroundedSig__05b53__05d 
        = (1U & (IData)((0x30303030aaff0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058217_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128832___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058218_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015266_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015263_)))))))));
    wasmetal_core__DOT___036284_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround64__02egenblk2__02eroundedSig__05b54__05d))));
    wasmetal_core__DOT___036283_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround64__02egenblk2__02eroundedSig__05b53__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___127763___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                   ^ (((IData)(wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__) 
                       << 3U) | (((IData)(wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(wasmetal_core__DOT___025154_))))));
    wasmetal_core__DOT___128842___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036283_)) 
           & (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround64__02egenblk2__02eroundedSig__05b53__05d));
    vlSelf->wasmetal_core__DOT___061715_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___019293_)
                                                   ? 
                                                  (0x32U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (0xf1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061448_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0x30f030f000055ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061446_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019211_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127763___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127761___O))))))))))))))))))
                                                   : 
                                                  (0xf0a0303U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((7U 
                                                                  >> 
                                                                  ((4U 
                                                                    & ((IData)(
                                                                               (0xf0f00000ccaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055364_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127757___O))))))))))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054747_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___019304_)))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xf0f00000ccaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055732_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127759___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___025168_))))))))))))))));
    wasmetal_core__DOT___128842___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036284_) ? (IData)(wasmetal_core__DOT___128842___DOT__CO__BRA__0__KET__)
            : (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround64__02egenblk2__02eroundedSig__05b54__05d));
    wasmetal_core__DOT___128842___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
           & (IData)(wasmetal_core__DOT___128842___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127764___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                   ^ ((((IData)(vlSelf->wasmetal_core__DOT___025172_)
                         ? (IData)(wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__)
                         : (IData)(vlSelf->wasmetal_core__DOT___025132_)) 
                       << 3U) | (((IData)(wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(wasmetal_core__DOT___025158_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128842___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036284_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___036283_)))) 
           ^ (((IData)(wasmetal_core__DOT___128842___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128842___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___128842___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___036276_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                    & (IData)(wasmetal_core__DOT___128842___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___062191_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff1100000f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019293_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061448_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x3300ff0f0faaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062187_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055712_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O) 
                                                                                >> 3U))))))))))))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x30f030f000055ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062185_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055997_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127764___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127762___O) 
                                                                                >> 3U))))))))))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019292_)))));
    wasmetal_core__DOT___134159___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O))));
    vlSelf->wasmetal_core__DOT___016542_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O))))))));
    wasmetal_core__DOT___128812___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O))));
    wasmetal_core__DOT___128843___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
           & (IData)(wasmetal_core__DOT___036276_));
    wasmetal_core__DOT___134159___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134159___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___128812___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___128812___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128843___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
           & (IData)(wasmetal_core__DOT___128843___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134159___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134159___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134159___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                          << 1U)))));
    wasmetal_core__DOT___036792_ = (IData)((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                             >> 3U) 
                                            | (IData)(wasmetal_core__DOT___134159___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___128843___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
           & (IData)(wasmetal_core__DOT___128843___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128843___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128825___S) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128843___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128843___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128843___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036276_)))));
    wasmetal_core__DOT___036280_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                    & (IData)(wasmetal_core__DOT___128843___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134160___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                 | (IData)(wasmetal_core__DOT___036792_)));
    wasmetal_core__DOT___036049_ = ((~ (IData)(wasmetal_core__DOT____Vcellout___128843___O)) 
                                    & (IData)(wasmetal_core__DOT___128812___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___059222_ = (1U & (1U >> ((6U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT____Vcellout___128812___O = (
                                                   ((8U 
                                                     & ((~ (IData)(wasmetal_core__DOT____Vcellout___128843___O)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                             >> 3U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                                >> 2U)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ 
                                                                ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                                 >> 1U)))))) 
                                                   ^ 
                                                   (1U 
                                                    | (((IData)(wasmetal_core__DOT___128812___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___128812___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (2U 
                                                             & ((~ 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                                  >> 1U)) 
                                                                << 1U))))));
    wasmetal_core__DOT___043019_ = (1U & (IData)((0x7ffffffffffffULL 
                                                  >> 
                                                  ((0x30U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                                                       << 2U)) 
                                                   | ((8U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                                                             << 1U)) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                               >> 2U))))))));
    wasmetal_core__DOT___043023_ = (1U & (IData)((0x1000000000000000ULL 
                                                  >> 
                                                  ((0x30U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                                                       << 2U)) 
                                                   | ((0xcU 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O)) 
                                                      | (3U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___128843___O)))))));
    wasmetal_core__DOT___128844___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___036071_)) 
           & (IData)(wasmetal_core__DOT___036280_));
    wasmetal_core__DOT___134160___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                  >> 1U) | (IData)(wasmetal_core__DOT___134160___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___016520_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((~ 
                                                               ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                                                                >> 1U)) 
                                                              ^ (IData)(wasmetal_core__DOT___036049_)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (((~ 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                                   >> 1U)) 
                                                                 ^ (IData)(vlSelf->wasmetal_core__DOT___023670_)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((~ 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                    >> 1U)) 
                                                                  ^ (IData)(vlSelf->wasmetal_core__DOT___036393_)))))))));
    vlSelf->wasmetal_core__DOT___016521_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128812___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127583___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128860___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___016534_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128812___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127583___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128860___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___016533_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128812___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127583___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128860___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___016532_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128812___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127583___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128860___O))))))));
    wasmetal_core__DOT___128844___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
           & (IData)(wasmetal_core__DOT___128844___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___134160___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134160___DOT__CO__BRA__1__KET__)));
    vlSelf->__VdfgTmp_hc0c493be__0 = (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016521_));
    wasmetal_core__DOT___128844___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
           & (IData)(wasmetal_core__DOT___128844___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134160___O 
        = (((8U & ((~ ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(wasmetal_core__DOT____Vcellout___128843___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134160___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134160___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___134160___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036792_)))));
    vlSelf->wasmetal_core__DOT___036796_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                                                     >> 3U) 
                                                    | (IData)(wasmetal_core__DOT___134160___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128844___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036072_)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                          << 1U) | 
                                         (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___036071_)))))) 
           ^ (((IData)(wasmetal_core__DOT___128844___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128844___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128844___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036280_)))));
    wasmetal_core__DOT___036271_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___036072_)) 
                                    & (IData)(wasmetal_core__DOT___128844___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___134161___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036796_)));
    wasmetal_core__DOT___128845___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___036073_)) 
           & (IData)(wasmetal_core__DOT___036271_));
    wasmetal_core__DOT____Vcellout___128845___O = (
                                                   (3U 
                                                    & (- (IData)(
                                                                 (1U 
                                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___036073_)))))) 
                                                   ^ 
                                                   (((((~ (IData)(vlSelf->wasmetal_core__DOT___036073_)) 
                                                       & (IData)(wasmetal_core__DOT___128845___DOT__CO__BRA__0__KET__)) 
                                                      << 2U) 
                                                     | ((IData)(wasmetal_core__DOT___128845___DOT__CO__BRA__0__KET__) 
                                                        << 1U)) 
                                                    | (IData)(wasmetal_core__DOT___036271_)));
    wasmetal_core__DOT___049338_ = (1U & (0xf8U >> 
                                          ((0xcU & 
                                            ((IData)(wasmetal_core__DOT____Vcellout___128845___O) 
                                             << 2U)) 
                                           | (3U & 
                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                               >> 2U)))));
    wasmetal_core__DOT___043020_ = (1U & (IData)((0xf0f0f0f0f0f0f0f7ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                       << 3U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                          << 1U)) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128845___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___128845___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                                     >> 1U))))))))));
    wasmetal_core__DOT___043024_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  ((0x30U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128845___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___128845___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                                  >> 2U)))))))));
    wasmetal_core__DOT___049339_ = (1U & (0x700U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___049338_))))));
    wasmetal_core__DOT__fpu__02earithmetic__02eround64__02ecommon_totalUnderflow 
        = (1U & ((IData)(wasmetal_core__DOT___043024_)
                  ? ((IData)(wasmetal_core__DOT___043023_)
                      ? ((~ (4U >> (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O)))) 
                         & (~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                               >> 1U))) : (IData)(wasmetal_core__DOT___043019_))
                  : (IData)(wasmetal_core__DOT___043020_)));
    vlSelf->wasmetal_core__DOT___036802_ = (1U & (IData)(
                                                         (0xefffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround64__02ecommon_totalUnderflow) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___049338_)))))))));
    vlSelf->wasmetal_core__DOT___017158_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround64__02ecommon_totalUnderflow))));
    vlSelf->wasmetal_core__DOT___016574_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround64__02ecommon_totalUnderflow) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017156_)))));
    vlSelf->wasmetal_core__DOT___134161___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036802_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___134161___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eencode64__02ein__05b62__05d 
        = (1U & (0x8fU >> (((IData)(wasmetal_core__DOT___049339_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___017158_)))));
    vlSelf->wasmetal_core__DOT___059224_ = (1U & (0x80ffU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049339_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017158_)))));
    vlSelf->wasmetal_core__DOT___016500_ = (1U & (IData)(
                                                         (0xff007000ffffffffULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___049339_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017158_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x100000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___059222_) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128843___O) 
                                                                                >> 2U))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___036802_)))))))));
    vlSelf->wasmetal_core__DOT___017160_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016536_)
                                                   ? (IData)(
                                                             (0xfff3fffafff0fff0ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___017158_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017157_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017144_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___017155_))))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___017157_))));
    vlSelf->__VdfgTmp_h0586459d__0 = ((4U & ((0x1f00U 
                                              >> (((IData)(wasmetal_core__DOT___049339_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017158_) 
                                                      << 2U) 
                                                     | (3U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O) 
                                                           >> 2U))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___036802_) 
                                          << 1U) | 
                                         (1U & (IData)(
                                                       (0xff0040404040ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                          << 5U) 
                                                         | ((0x10U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                                << 4U)) 
                                                            | ((8U 
                                                                & ((7U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___036996_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058557_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d)))))))))));
    vlSelf->wasmetal_core__DOT___060332_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h11dd3326__0)))));
    vlSelf->wasmetal_core__DOT___016537_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016586_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016572_))))));
    vlSelf->wasmetal_core__DOT___059363_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                  & (IData)(
                                                            (0xf3f5f0f0f0f0f0f0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016780_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h44d9a03d__0)))))))));
    vlSelf->wasmetal_core__DOT___016575_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h52207b53__0))))))));
    vlSelf->wasmetal_core__DOT___016641_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O) 
                                                                                >> 1U))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc5bb64fc__0))))))));
    vlSelf->wasmetal_core__DOT___016652_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ecbbe50__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he0d8c702__0))))))));
    vlSelf->wasmetal_core__DOT___016609_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xca000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7af47ace__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h27d7faf5__0))))))));
    vlSelf->wasmetal_core__DOT___058596_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                  & (IData)(
                                                            (0xf3f5f0f0f0f0f0f0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016836_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h5865698c__0)))))))));
    vlSelf->wasmetal_core__DOT___016629_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xca000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcf32a2f0__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h04ff9270__0))))))));
    vlSelf->wasmetal_core__DOT___016689_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x40U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___058571_)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1afd8c5__0))))))));
    vlSelf->wasmetal_core__DOT___058591_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(
                                                      (0xf3f5f0f0f0f0f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016801_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc66d6698__0))))))));
    vlSelf->wasmetal_core__DOT___016699_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5c254f34__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5f559dac__0))))))));
    vlSelf->wasmetal_core__DOT___058602_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(
                                                      (0xf3f5f0f0f0f0f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016848_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd7617577__0))))))));
    vlSelf->wasmetal_core__DOT___016656_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O) 
                                                                                >> 3U))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfa0a9622__0))))))));
    vlSelf->wasmetal_core__DOT___016677_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf8000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hd9e83ce6__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfccc26d7__0))))))));
    vlSelf->wasmetal_core__DOT___016734_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb3aa193a__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6fb1c908__0))))))));
    vlSelf->wasmetal_core__DOT___017999_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016798_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h83a58712__0))))))));
    vlSelf->wasmetal_core__DOT___018005_ = (1U & (IData)(
                                                         (0xcfffafffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016836_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5865698c__0))))))));
    vlSelf->wasmetal_core__DOT___016744_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h842e8acf__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h23178df2__0))))))));
    vlSelf->wasmetal_core__DOT___016781_ = (1U & (IData)(
                                                         (0xcfffafffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016780_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h44d9a03d__0))))))));
    vlSelf->wasmetal_core__DOT___016703_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058574_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017018_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdbda1ab6__0))))))));
    vlSelf->wasmetal_core__DOT___016723_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058575_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017018_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2d6cb346__0))))))));
    vlSelf->wasmetal_core__DOT___016757_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058584_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017018_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hefec7bb7__0))))))));
    vlSelf->wasmetal_core__DOT___016769_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8b17c158__0))))))));
    vlSelf->wasmetal_core__DOT___016825_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016824_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfbf01d74__0))))))));
    vlSelf->wasmetal_core__DOT___016814_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058590_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017018_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc9aeb4c0__0))))))));
    vlSelf->wasmetal_core__DOT___018011_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016933_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3bf6c465__0))))))));
    vlSelf->wasmetal_core__DOT___018012_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016915_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h98ad354c__0))))))));
    vlSelf->wasmetal_core__DOT___016860_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058597_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017018_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h72106b67__0))))))));
    vlSelf->wasmetal_core__DOT___016871_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058598_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017018_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcacd7e7e__0))))))));
    vlSelf->wasmetal_core__DOT___016882_ = (1U & (IData)(
                                                         (0xf3f5f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xca000000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc42a79ae__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1813ebc7__0))))))));
    wasmetal_core__DOT___018026_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017087_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hde08d0b2__0))))))));
    wasmetal_core__DOT___016893_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057924_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058605_)))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha74c2851__0))))))));
    wasmetal_core__DOT___018027_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017068_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_he029cbf7__0))))))));
    wasmetal_core__DOT___016904_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057886_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hfa9cb9e8__0))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h06719132__0))))))));
    wasmetal_core__DOT___016996_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016995_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb9ae5421__0))))))));
    wasmetal_core__DOT___017007_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017006_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hbf2def73__0))))))));
    wasmetal_core__DOT___017045_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xa0cU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057882_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058642_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd520545b__0))))))));
    wasmetal_core__DOT___017056_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xa0cU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057848_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058646_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h1c39cb98__0))))))));
    wasmetal_core__DOT___017091_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057839_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058656_)))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h398f740d__0))))))));
    wasmetal_core__DOT___017102_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___017018_)
                                                                  ? 
                                                                 (0xac00U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h54a2cb2f__0)))))
                                                                  : 
                                                                 (2U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___017113_)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h19c83299__0))))))));
    wasmetal_core__DOT___017118_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057872_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058660_)))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h776da2e2__0))))))));
    wasmetal_core__DOT___017128_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057866_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058661_)))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb1e20b97__0))))))));
    wasmetal_core__DOT___016993_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xa0cU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057821_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058632_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h11dd3326__0))))))));
    wasmetal_core__DOT___016975_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xa0cU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057863_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058631_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h0184ff22__0))))))));
    wasmetal_core__DOT___016944_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xa0cU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057816_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058622_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd10ddd3a__0))))))));
    wasmetal_core__DOT___016963_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058625_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___057794_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h1c77e7ba__0))))))));
    wasmetal_core__DOT___017023_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058639_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___057776_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9d72ac71__0))))))));
    wasmetal_core__DOT___017034_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057784_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h01fee3b7__0))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hc6f109bf__0))))))));
    wasmetal_core__DOT___017131_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___017018_)
                                                                  ? 
                                                                 (0xac00U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h192fc191__0)))))
                                                                  : 
                                                                 (2U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___017141_)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf8652348__0))))))));
    wasmetal_core__DOT___017146_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057797_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058664_)))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h5ad561b8__0))))))));
    wasmetal_core__DOT____Vcellout___134161___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eencode64__02ein__05b62__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___036802_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O))))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eencode64__02ein__05b62__05d)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT___134161___DOT__CO__BRA__1__KET__)
                                                       : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eencode64__02ein__05b62__05d)) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___134161___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___134161___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036796_)))));
    vlSelf->wasmetal_core__DOT___060576_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134160___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___060489_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134159___O))))));
    vlSelf->wasmetal_core__DOT___060503_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134159___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060517_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134159___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___060545_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134160___O))))));
    vlSelf->wasmetal_core__DOT___060559_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134160___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060531_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134159___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___060591_ = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134160___O) 
                                                          >> 3U))))));
    vlSelf->wasmetal_core__DOT___019177_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___036802_)))));
    wasmetal_core__DOT___018041_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___017160_));
    wasmetal_core__DOT___018360_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___017160_));
    wasmetal_core__DOT___018043_ = (1U & (IData)((0x3f005500000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0586459d__0)))))));
    wasmetal_core__DOT___018713_ = (1U & (IData)((0x3f55000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0586459d__0)))))));
    wasmetal_core__DOT___018361_ = (1U & (0x3f0055U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0586459d__0)))));
    wasmetal_core__DOT___017970_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016542_)
                                           ? ((~ (IData)(vlSelf->wasmetal_core__DOT___016587_)) 
                                              & (0x1fffU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6047dcd2__0)))))
                                           : (0x13U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016538_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016537_))))));
    vlSelf->__VdfgTmp_h80e75d17__0 = (((IData)(vlSelf->wasmetal_core__DOT___016537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016536_));
    wasmetal_core__DOT___016541_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016575_));
    wasmetal_core__DOT___059257_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016575_));
    wasmetal_core__DOT___059258_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016641_));
    wasmetal_core__DOT___016529_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016641_));
    wasmetal_core__DOT___016528_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016652_));
    vlSelf->wasmetal_core__DOT___059261_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___016652_));
    vlSelf->wasmetal_core__DOT___059262_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___016609_));
    wasmetal_core__DOT___058565_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016609_));
    vlSelf->wasmetal_core__DOT___059259_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___016629_));
    wasmetal_core__DOT___058566_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016629_));
    vlSelf->wasmetal_core__DOT___059260_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___016689_));
    wasmetal_core__DOT___058572_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016689_));
    wasmetal_core__DOT___058573_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016699_));
    wasmetal_core__DOT___059264_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016699_));
    wasmetal_core__DOT___059263_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016656_));
    wasmetal_core__DOT___058569_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016656_));
    wasmetal_core__DOT___058570_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016677_));
    __VdfgTmp_he14d8a41__0 = ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                & (IData)(vlSelf->wasmetal_core__DOT___016677_)) 
                               << 1U) | ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                         & (IData)(vlSelf->wasmetal_core__DOT___016734_)));
    wasmetal_core__DOT___058578_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016734_));
    wasmetal_core__DOT___059362_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___017999_));
    wasmetal_core__DOT___059275_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___017999_));
    __VdfgTmp_h34e522da__0 = ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                & (IData)(vlSelf->wasmetal_core__DOT___018005_)) 
                               << 1U) | (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                               & (IData)(
                                                         (0xcfffafffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016848_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd7617577__0))))))))));
    wasmetal_core__DOT___058579_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016744_));
    wasmetal_core__DOT___059268_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016744_));
    __VdfgTmp_h96788d86__0 = ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                & (IData)(vlSelf->wasmetal_core__DOT___016781_)) 
                               << 1U) | (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                               & (IData)(
                                                         (0xcfffafffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016801_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc66d6698__0))))))))));
    wasmetal_core__DOT___059267_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016703_));
    wasmetal_core__DOT___058576_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016703_));
    wasmetal_core__DOT___058577_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016723_));
    wasmetal_core__DOT___059270_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016723_));
    wasmetal_core__DOT___058588_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016757_));
    wasmetal_core__DOT___059269_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016757_));
    wasmetal_core__DOT___058587_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016769_));
    wasmetal_core__DOT___059276_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016769_));
    wasmetal_core__DOT___058595_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016825_));
    wasmetal_core__DOT___059280_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016825_));
    wasmetal_core__DOT___058592_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016814_));
    wasmetal_core__DOT___059279_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016814_));
    wasmetal_core__DOT___059366_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___018011_));
    wasmetal_core__DOT___059287_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___018011_));
    wasmetal_core__DOT___059367_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___018012_));
    wasmetal_core__DOT___059290_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___018012_));
    wasmetal_core__DOT___058603_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016860_));
    wasmetal_core__DOT___059284_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016860_));
    wasmetal_core__DOT___059283_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016871_));
    wasmetal_core__DOT___058600_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016871_));
    wasmetal_core__DOT___058601_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016882_));
    wasmetal_core__DOT___059298_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___018026_));
    __VdfgTmp_h8aa93d8f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                & (IData)(vlSelf->wasmetal_core__DOT___016882_)) 
                               << 1U) | ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                         & (IData)(wasmetal_core__DOT___016893_)));
    wasmetal_core__DOT___058617_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016893_));
    wasmetal_core__DOT___059371_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___018027_));
    wasmetal_core__DOT___059296_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___018027_));
    wasmetal_core__DOT___058616_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016904_));
    wasmetal_core__DOT___059288_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016904_));
    wasmetal_core__DOT___058637_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016996_));
    wasmetal_core__DOT___059303_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016996_));
    wasmetal_core__DOT___058638_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017007_));
    wasmetal_core__DOT___059309_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017007_));
    wasmetal_core__DOT___059289_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017045_));
    wasmetal_core__DOT___058654_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017045_));
    wasmetal_core__DOT___059297_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017056_));
    wasmetal_core__DOT___058653_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017056_));
    wasmetal_core__DOT___059295_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017091_));
    wasmetal_core__DOT___058658_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017091_));
    wasmetal_core__DOT___059301_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017102_));
    wasmetal_core__DOT___058657_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017102_));
    wasmetal_core__DOT___059302_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017118_));
    wasmetal_core__DOT___058662_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017118_));
    wasmetal_core__DOT___059300_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017128_));
    wasmetal_core__DOT___058663_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017128_));
    wasmetal_core__DOT___059305_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016993_));
    wasmetal_core__DOT___058634_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016993_));
    wasmetal_core__DOT___059299_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016975_));
    wasmetal_core__DOT___058633_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016975_));
    wasmetal_core__DOT___059306_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016944_));
    wasmetal_core__DOT___058626_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016944_));
    wasmetal_core__DOT___059304_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016963_));
    wasmetal_core__DOT___058627_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016963_));
    wasmetal_core__DOT___059310_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017023_));
    wasmetal_core__DOT___018358_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017023_));
    wasmetal_core__DOT___059308_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017034_));
    wasmetal_core__DOT___018359_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017034_));
    wasmetal_core__DOT___059307_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017131_));
    wasmetal_core__DOT___018362_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017131_));
    wasmetal_core__DOT___018042_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017146_));
    wasmetal_core__DOT___018363_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017146_));
    vlSelf->wasmetal_core__DOT___060607_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___134161___O))))));
    wasmetal_core__DOT___060620_ = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___134161___O) 
                                                          >> 1U))))));
    vlSelf->wasmetal_core__DOT___060631_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134161___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___060581_ = (1U & (0xeU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0fff1100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127590___O) 
                                                                                >> 2U))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___058931_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060576_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016506_)))));
    wasmetal_core__DOT___060492_ = (1U & (IData)((0xaaa0ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060489_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9333e746__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127589___O))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___005830_)))))))));
    wasmetal_core__DOT___060506_ = (1U & (IData)((0xaaa0ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060503_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127589___O) 
                                                                                >> 1U))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___005896_)))))))));
    wasmetal_core__DOT___060520_ = (1U & (IData)((0xaaa0ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060517_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127589___O) 
                                                                                >> 2U))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__)))))))));
    wasmetal_core__DOT___060548_ = (1U & (IData)((0x5550ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060545_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060543_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127590___O))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d)))))))));
    wasmetal_core__DOT___060562_ = (1U & (IData)((0x5550ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060559_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060557_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127590___O) 
                                                                                >> 1U))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d)))))))));
    wasmetal_core__DOT___060534_ = (1U & (IData)((0xaaa0ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060531_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127589___O) 
                                                                                >> 3U))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___005962_)))))))));
    wasmetal_core__DOT___060595_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___060591_))));
    vlSelf->wasmetal_core__DOT___017951_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4cc4790a__0))))));
    vlSelf->wasmetal_core__DOT___018511_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb1afd8c5__0))))));
    vlSelf->wasmetal_core__DOT___059649_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5f559dac__0))))));
    vlSelf->wasmetal_core__DOT___018585_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfccc26d7__0))))));
    vlSelf->wasmetal_core__DOT___018663_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h23178df2__0))))));
    vlSelf->wasmetal_core__DOT___018812_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h44d9a03d__0))))));
    vlSelf->wasmetal_core__DOT___018829_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc66d6698__0))))));
    vlSelf->wasmetal_core__DOT___018847_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc9aeb4c0__0))))));
    vlSelf->wasmetal_core__DOT___018867_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfbf01d74__0))))));
    vlSelf->wasmetal_core__DOT___018897_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd7617577__0))))));
    vlSelf->wasmetal_core__DOT___018193_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016537_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019177_))));
    vlSelf->wasmetal_core__DOT___018266_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h52207b53__0))))));
    vlSelf->wasmetal_core__DOT___018946_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1813ebc7__0))))));
    vlSelf->wasmetal_core__DOT___060162_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha74c2851__0))))));
    vlSelf->wasmetal_core__DOT___019000_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3bf6c465__0))))));
    vlSelf->wasmetal_core__DOT___018101_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6047dcd2__0)))));
    vlSelf->wasmetal_core__DOT___018390_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he0d8c702__0))))));
    vlSelf->wasmetal_core__DOT___018622_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6fb1c908__0))))));
    vlSelf->wasmetal_core__DOT___018695_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdbda1ab6__0))))));
    vlSelf->wasmetal_core__DOT___018757_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hefec7bb7__0))))));
    vlSelf->wasmetal_core__DOT___018776_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8b17c158__0))))));
    vlSelf->wasmetal_core__DOT___018789_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h83a58712__0))))));
    vlSelf->wasmetal_core__DOT___018878_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5865698c__0))))));
    vlSelf->wasmetal_core__DOT___018913_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h72106b67__0))))));
    vlSelf->wasmetal_core__DOT___018444_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h04ff9270__0))))));
    vlSelf->wasmetal_core__DOT___018424_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h27d7faf5__0))))));
    vlSelf->wasmetal_core__DOT___019070_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hde08d0b2__0))))));
    wasmetal_core__DOT___060387_ = (1U & (0x35000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbf2def73__0))))));
    vlSelf->wasmetal_core__DOT___016501_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xbbbbf0ffU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___058217_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                                         << 3U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058218_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h605612ae__0))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058563_)))))));
    vlSelf->wasmetal_core__DOT___018737_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2d6cb346__0))))));
    vlSelf->wasmetal_core__DOT___019026_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h98ad354c__0))))));
    vlSelf->wasmetal_core__DOT___060411_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc6f109bf__0))))));
    vlSelf->wasmetal_core__DOT___018325_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc5bb64fc__0))))));
    wasmetal_core__DOT___060348_ = (1U & (0x35000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd10ddd3a__0))))));
    vlSelf->wasmetal_core__DOT___018984_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h06719132__0))))));
    vlSelf->wasmetal_core__DOT___018216_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___018713_)))));
    __VdfgTmp_h0260a162__0 = (((IData)(wasmetal_core__DOT___018360_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018361_));
    wasmetal_core__DOT___018366_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___018361_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018360_))));
    vlSelf->wasmetal_core__DOT___016531_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016532_)
                                                   ? 
                                                  (0xeU 
                                                   >> 
                                                   ((2U 
                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                         & (IData)(
                                                                   (0xafffcfffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___016587_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016586_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016585_))))))))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xc0a0f0f0f0f0f0f0ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((IData)(
                                                                                (0xf0f0f000aaccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058562_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O))))))))) 
                                                                                << 2U)) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h4cc4790a__0))))))))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016542_)
                                                    ? 
                                                   (7U 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___016541_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016538_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h80e75d17__0))))
                                                    : 
                                                   (1U 
                                                    >> (IData)(wasmetal_core__DOT___016541_)))));
    vlSelf->__VdfgTmp_h48e9ec96__0 = (((IData)(wasmetal_core__DOT___016529_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016528_));
    wasmetal_core__DOT___059407_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059261_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___059262_)))));
    vlSelf->wasmetal_core__DOT___016530_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058566_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058565_))));
    __VdfgTmp_h0c9be8e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___059260_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___059259_)));
    wasmetal_core__DOT___059527_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058566_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058565_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058572_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058573_)))))))));
    vlSelf->__VdfgTmp_h2402eec7__0 = (((IData)(wasmetal_core__DOT___058573_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058572_));
    wasmetal_core__DOT___059404_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___059263_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___059264_)))));
    wasmetal_core__DOT___059273_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___059264_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___059263_)))));
    __VdfgTmp_ha5bd917e__0 = (((IData)(wasmetal_core__DOT___058569_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058570_));
    vlSelf->wasmetal_core__DOT___059494_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059263_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059264_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_he14d8a41__0))))))));
    __VdfgTmp_h3e19c29d__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 2U) | (IData)(__VdfgTmp_he14d8a41__0));
    vlSelf->__VdfgTmp_hca806a32__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 2U) | (IData)(__VdfgTmp_h34e522da__0));
    __VdfgTmp_h91143f30__0 = (((IData)(wasmetal_core__DOT___058578_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058579_));
    __VdfgTmp_hce4bc968__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___059268_) 
                                          << 1U) | (IData)(wasmetal_core__DOT___059267_)));
    __VdfgTmp_h9e4f981d__0 = (((IData)(wasmetal_core__DOT___058576_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058577_));
    vlSelf->wasmetal_core__DOT___059409_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___059269_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___059270_)))));
    __VdfgTmp_h601cb0b3__0 = (((IData)(wasmetal_core__DOT___059270_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059269_));
    __VdfgTmp_hc59fb841__0 = (((IData)(wasmetal_core__DOT___058588_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___058587_) 
                                          << 2U) | 
                                         ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(
                                                      (0xcfffafffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016798_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h83a58712__0)))))))) 
                                           << 1U) | 
                                          ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                           & (IData)(vlSelf->wasmetal_core__DOT___016781_)))));
    vlSelf->wasmetal_core__DOT___059491_ = (1U & (IData)(
                                                         (0xfff000001111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059276_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059275_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h96788d86__0))))))));
    wasmetal_core__DOT___017996_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___059276_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___059275_)))));
    vlSelf->wasmetal_core__DOT___059408_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___059275_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___059276_)))));
    wasmetal_core__DOT___059456_ = (1U & (IData)((0xfff0111100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058591_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058592_) 
                                                             << 2U) 
                                                            | ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                                                 & (IData)(
                                                                           (0xcfffafffULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016824_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfbf01d74__0)))))))) 
                                                                << 1U) 
                                                               | ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT___018005_))))))))));
    __VdfgTmp_ha18a5876__0 = (((IData)(wasmetal_core__DOT___058592_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058591_));
    vlSelf->wasmetal_core__DOT___059497_ = (1U & (IData)(
                                                         (0xfff0111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059279_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059280_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h34e522da__0))))))));
    wasmetal_core__DOT___017993_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___059280_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___059279_))));
    __VdfgTmp_h503e256d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058602_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058603_));
    vlSelf->__VdfgTmp_hb4648514__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___059284_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___059283_)));
    wasmetal_core__DOT___059457_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058603_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058602_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058600_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058601_)))))))));
    __VdfgTmp_h4e5aac03__0 = (((IData)(wasmetal_core__DOT___058601_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058600_));
    vlSelf->wasmetal_core__DOT___059498_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059283_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059284_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h8aa93d8f__0))))))));
    vlSelf->__VdfgTmp_h64bc71ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 2U) | (IData)(__VdfgTmp_h8aa93d8f__0));
    wasmetal_core__DOT___059531_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058601_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058600_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058617_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058616_)))))))));
    __VdfgTmp_h0ef48b5f__0 = (((IData)(wasmetal_core__DOT___058617_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___058616_) 
                                          << 2U) | 
                                         ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(
                                                      (0xcfffafffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016933_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3bf6c465__0)))))))) 
                                           << 1U) | 
                                          (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                 & (IData)(
                                                           (0xcfffafffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___016915_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h98ad354c__0))))))))))));
    vlSelf->__VdfgTmp_hcbc72a24__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___059288_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___059287_)));
    wasmetal_core__DOT___016935_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___058638_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___058637_))));
    __VdfgTmp_hd32c8afd__0 = (((IData)(wasmetal_core__DOT___059290_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059289_));
    wasmetal_core__DOT___059414_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___059289_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___059290_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___059298_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___059297_)))))));
    wasmetal_core__DOT___059369_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___059367_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___059366_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___058653_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___058654_)))))));
    wasmetal_core__DOT___059529_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059367_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___059366_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058654_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058653_)))))))));
    __VdfgTmp_h00d59987__0 = (((IData)(wasmetal_core__DOT___058654_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___058653_) 
                                          << 2U) | 
                                         ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(
                                                      (0xcfffafffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017087_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde08d0b2__0)))))))) 
                                           << 1U) | 
                                          (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                 & (IData)(
                                                           (0xcfffafffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017068_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_he029cbf7__0))))))))))));
    vlSelf->__VdfgTmp_h0ef15e16__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___059298_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___059297_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___059296_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___059295_))))));
    __VdfgTmp_h6ec83bdc__0 = (((IData)(wasmetal_core__DOT___058658_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058657_));
    wasmetal_core__DOT___018215_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059295_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___059296_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___059301_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___059302_)))))))));
    wasmetal_core__DOT___059460_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058657_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058658_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058662_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058663_)))))))));
    wasmetal_core__DOT___059566_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___059299_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___059300_))));
    vlSelf->__VdfgTmp_h7c31faf3__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___059302_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___059301_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___059300_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___059299_))))));
    wasmetal_core__DOT___016936_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___058634_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___058633_)))));
    __VdfgTmp_h23858478__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                          << 4U) | 
                                         (((IData)(wasmetal_core__DOT___058663_) 
                                           << 3U) | 
                                          (((IData)(wasmetal_core__DOT___058662_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___058633_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___058634_))))));
    wasmetal_core__DOT___018214_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059299_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___059300_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___059305_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___059306_)))))))));
    __VdfgTmp_h82ac78d0__0 = (((IData)(wasmetal_core__DOT___059304_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059303_));
    wasmetal_core__DOT___059461_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058634_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058633_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058626_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058627_)))))))));
    wasmetal_core__DOT___016937_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___058627_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___058626_)))));
    __VdfgTmp_h4919b5b1__0 = (((IData)(wasmetal_core__DOT___058626_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___058627_) 
                                          << 2U) | 
                                         ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(
                                                      (0xcfffafffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016995_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb9ae5421__0)))))))) 
                                           << 1U) | 
                                          (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                 & (IData)(
                                                           (0xcfffafffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017006_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hbf2def73__0))))))))))));
    __VdfgTmp_haab05145__0 = (((IData)(wasmetal_core__DOT___059309_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059310_));
    __VdfgTmp_hc47a2f1f__0 = (((IData)(wasmetal_core__DOT___018358_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018359_));
    __VdfgTmp_hb9827f61__0 = (((IData)(wasmetal_core__DOT___059308_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059307_));
    __VdfgTmp_he893b9f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 1U) | (1U & (1U >> 
                                               (((IData)(wasmetal_core__DOT___018041_) 
                                                 << 1U) 
                                                | (IData)(wasmetal_core__DOT___018042_)))));
    __VdfgTmp_hcdaab3df__0 = (((IData)(wasmetal_core__DOT___018042_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018041_));
    vlSelf->wasmetal_core__DOT___018130_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___018359_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___018358_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___018362_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___018363_)))))))));
    wasmetal_core__DOT___018367_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___018363_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018362_))));
    vlSelf->wasmetal_core__DOT___060611_ = (1U & (0xeU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0fff1100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127591___O))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___058931_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060607_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016506_)))));
    wasmetal_core__DOT___019193_ = (1U & (IData)((0xeee0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060621_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___060620_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___006238_)))))))));
    wasmetal_core__DOT___060637_ = (1U & (0xeU >> (
                                                   (4U 
                                                    & ((IData)(
                                                               (0xf0fcf0fa00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127591___O) 
                                                                                >> 2U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060631_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016506_)))));
    vlSelf->wasmetal_core__DOT___060494_ = (1U & (IData)(
                                                         (0xf1ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060493_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060492_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xbb0bU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060483_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005830_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeee00000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048718_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060508_ = (1U & (IData)(
                                                         (0xf1ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060507_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xbb0bU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060500_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005896_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeee00000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048725_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060522_ = (1U & (IData)(
                                                         (0xf1ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060521_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060520_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xbb0bU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060514_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeee00000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048726_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060550_ = (1U & (IData)(
                                                         (0xf1ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060549_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060548_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x7707U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060542_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xee0e0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048713_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060564_ = (1U & (IData)(
                                                         (0xf1ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060563_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060562_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x7707U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060556_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xee0e0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048711_)))))))))))))));
    wasmetal_core__DOT___060536_ = (1U & (IData)((0xf1ff00ff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060535_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___060534_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xbb0bU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060528_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___005962_)))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0xeee00000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___048727_)))))))))))))));
    wasmetal_core__DOT___060600_ = (1U & (IData)((0xff00ff00ff00e000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___060595_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060594_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xdf0fU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                            << 3U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060588_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h74741c3a__0))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0xf7f0000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___060573_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060587_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_he45ddc74__0))))))))))))));
    vlSelf->wasmetal_core__DOT___060478_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xfef00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060472_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058466_)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128873___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005711_))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x7f7f7f7fffff00ffULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((0xff4fffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058665_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018216_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hc0c493be__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019074_)))));
    wasmetal_core__DOT___060459_ = (1U & (0x4000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___018216_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___016500_))))));
    wasmetal_core__DOT___059458_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___018363_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___018362_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h0260a162__0))))))));
    vlSelf->wasmetal_core__DOT___018133_ = (1U & (0xe0000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h0260a162__0))))));
    wasmetal_core__DOT___058583_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h2402eec7__0))));
    wasmetal_core__DOT___059451_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058573_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058572_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_ha5bd917e__0))))))));
    wasmetal_core__DOT___059359_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h91143f30__0))));
    vlSelf->__VdfgTmp_h6136b552__0 = ((2U & ((0xeU 
                                              >> (IData)(__VdfgTmp_hce4bc968__0)) 
                                             << 1U)) 
                                      | (1U & (0xe0U 
                                               >> (IData)(__VdfgTmp_h3e19c29d__0))));
    vlSelf->wasmetal_core__DOT___059449_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058579_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___058578_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h9e4f981d__0))))))));
    vlSelf->wasmetal_core__DOT___059492_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059267_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059268_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h601cb0b3__0))))))));
    wasmetal_core__DOT___059271_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h601cb0b3__0))));
    vlSelf->wasmetal_core__DOT___059448_ = (1U & (IData)(
                                                         (0xfff000001111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_hc59fb841__0))))));
    vlSelf->wasmetal_core__DOT___016749_ = (1U & (IData)(
                                                         (0xfff0111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_hc59fb841__0))))));
    __VdfgTmp_hb715052c__0 = (((IData)(vlSelf->wasmetal_core__DOT___059409_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___059408_));
    vlSelf->__VdfgTmp_h123a61a4__0 = ((2U & ((IData)(
                                                     (0xf111100000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                           << 4U) 
                                                          | (((IData)(wasmetal_core__DOT___058577_) 
                                                              << 3U) 
                                                             | (((IData)(wasmetal_core__DOT___058576_) 
                                                                 << 2U) 
                                                                | (((IData)(wasmetal_core__DOT___058587_) 
                                                                    << 1U) 
                                                                   | (IData)(wasmetal_core__DOT___058588_)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf00001111ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059363_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___059362_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_ha18a5876__0)))))))));
    __VdfgTmp_h61eefee9__0 = ((2U & ((1U >> (IData)(__VdfgTmp_ha18a5876__0)) 
                                     << 1U)) | (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___058596_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___058595_)))));
    __VdfgTmp_h893f43f0__0 = ((2U & ((0xeU >> (IData)(__VdfgTmp_h96788d86__0)) 
                                     << 1U)) | (IData)(wasmetal_core__DOT___017993_));
    wasmetal_core__DOT___059530_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058596_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058595_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h503e256d__0))))))));
    wasmetal_core__DOT___059365_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h503e256d__0))));
    vlSelf->wasmetal_core__DOT___018203_ = (1U & (IData)(
                                                         (0xff00f0f011111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xeU 
                                                                      >> (IData)(__VdfgTmp_h96788d86__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(wasmetal_core__DOT___017993_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb4648514__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hca806a32__0)))))))))));
    vlSelf->wasmetal_core__DOT___018597_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059457_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059456_))));
    wasmetal_core__DOT___016747_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___058603_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058602_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h4e5aac03__0))))));
    vlSelf->wasmetal_core__DOT___018630_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___059497_))));
    wasmetal_core__DOT___059455_ = (1U & (IData)((0xfff0111100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (IData)(__VdfgTmp_h0ef48b5f__0))))));
    wasmetal_core__DOT___016748_ = (1U & (IData)((0xfff000001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (IData)(__VdfgTmp_h0ef48b5f__0))))));
    vlSelf->wasmetal_core__DOT___018865_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xeU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb4648514__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x10U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hca806a32__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xe0U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h64bc71ef__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hcbc72a24__0)))))))))));
    __VdfgTmp_h4b0290b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                          << 4U) | 
                                         ((8U & ((0xeU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h64bc71ef__0)) 
                                                 << 3U)) 
                                          | ((4U & 
                                              ((0xe0U 
                                                >> (IData)(vlSelf->__VdfgTmp_hb4648514__0)) 
                                               << 2U)) 
                                             | ((2U 
                                                 & ((0xe0U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hcbc72a24__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hd32c8afd__0)))))))));
    vlSelf->wasmetal_core__DOT___059496_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059287_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059288_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hd32c8afd__0))))))));
    wasmetal_core__DOT___018702_ = (1U & (IData)((0xff00ff001111f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059414_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(wasmetal_core__DOT___059302_) 
                                                                   << 1U) 
                                                                  | (IData)(wasmetal_core__DOT___059301_))) 
                                                                << 2U)) 
                                                            | (((IData)(wasmetal_core__DOT___059295_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___059296_)))))))));
    __VdfgTmp_h8e246f46__0 = ((4U & ((0xe0U >> (IData)(vlSelf->__VdfgTmp_h64bc71ef__0)) 
                                     << 2U)) | ((2U 
                                                 & ((0xeU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hcbc72a24__0)) 
                                                    << 1U)) 
                                                | (IData)(wasmetal_core__DOT___059414_)));
    wasmetal_core__DOT___018111_ = (1U & (IData)((0x1111f0f0ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059369_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(wasmetal_core__DOT___058616_) 
                                                                   << 1U) 
                                                                  | (IData)(wasmetal_core__DOT___058617_))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h4e5aac03__0))))))));
    wasmetal_core__DOT___059454_ = (1U & (IData)((0xfff000001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (IData)(__VdfgTmp_h00d59987__0))))));
    wasmetal_core__DOT___018464_ = (1U & (IData)((0xfff0111100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (IData)(__VdfgTmp_h00d59987__0))))));
    wasmetal_core__DOT___018463_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (IData)(__VdfgTmp_h6ec83bdc__0))));
    __VdfgTmp_haf2ded6f__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                          << 4U) | 
                                         (((IData)(wasmetal_core__DOT___059371_) 
                                           << 3U) | 
                                          ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                             & (IData)(wasmetal_core__DOT___018026_)) 
                                            << 2U) 
                                           | (IData)(__VdfgTmp_h6ec83bdc__0)))));
    __VdfgTmp_hbbb73552__0 = ((2U & ((IData)((0xfff00000eeeeULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h7c31faf3__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfff00000eeee0000ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0ef15e16__0)))));
    wasmetal_core__DOT___018796_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___018214_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___018215_)))));
    __VdfgTmp_h56c348e9__0 = (((IData)(wasmetal_core__DOT___018215_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018214_));
    vlSelf->__VdfgTmp_h6b4dc907__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___059306_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___059305_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h82ac78d0__0)))));
    vlSelf->wasmetal_core__DOT___018595_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059461_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059460_))));
    wasmetal_core__DOT___059532_ = (1U & (IData)((0xfff000001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (IData)(__VdfgTmp_h4919b5b1__0))))));
    vlSelf->wasmetal_core__DOT___018129_ = (1U & (IData)(
                                                         (0xfff0111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h4919b5b1__0))))));
    vlSelf->wasmetal_core__DOT___018701_ = (1U & (IData)(
                                                         (0xff00f0f011111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059566_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(wasmetal_core__DOT___059306_) 
                                                                           << 1U) 
                                                                          | (IData)(wasmetal_core__DOT___059305_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                              << 2U) 
                                                                             | (IData)(__VdfgTmp_haab05145__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xe0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_h82ac78d0__0))))))))))));
    wasmetal_core__DOT___018213_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059303_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___059304_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_haab05145__0))))))));
    wasmetal_core__DOT___059459_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058638_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058637_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_hc47a2f1f__0))))))));
    wasmetal_core__DOT___016938_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hc47a2f1f__0))));
    wasmetal_core__DOT___018714_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (IData)(__VdfgTmp_hb9827f61__0))));
    vlSelf->__VdfgTmp_hde0459ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___059310_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___059309_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hb9827f61__0)))));
    __VdfgTmp_h410ade1c__0 = (((IData)(wasmetal_core__DOT___018043_) 
                               << 2U) | (IData)(__VdfgTmp_he893b9f2__0));
    wasmetal_core__DOT___018212_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059307_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___059308_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_hcdaab3df__0))))))));
    __VdfgTmp_hc303443c__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___018043_) 
                                          << 2U) | (IData)(__VdfgTmp_hcdaab3df__0)));
    wasmetal_core__DOT___018673_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016533_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016532_)
                                               ? (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___018359_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___018358_)))
                                               : (IData)(wasmetal_core__DOT___018367_))
                                           : ((~ (IData)(vlSelf->wasmetal_core__DOT___016532_)) 
                                              | (IData)(wasmetal_core__DOT___018366_))));
    __VdfgTmp_he878b3a8__0 = (((IData)(wasmetal_core__DOT___018367_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018366_));
    wasmetal_core__DOT___060628_ = (1U & (IData)((0xf4ff00ff00000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060627_) 
                                                          << 3U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                              & (IData)(
                                                                        (0xf0fffbff00ff00ffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                              << 4U) 
                                                                             | (((IData)(wasmetal_core__DOT___019193_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xffffff4f00000f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060618_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048714_))))))))))))))) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0xdU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134187___O) 
                                                                               >> 1U))))))))))))));
    wasmetal_core__DOT___060642_ = (1U & (IData)((0xfe000000ffff0000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___060637_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0x44ff00f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060629_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018273_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017171_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___060588_))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x101010ffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060571_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 2U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___019197_) 
                                                                                & (IData)(
                                                                                (0xff00ffffff1fffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc204a2d8__0))))))) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058687_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___060541_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060536_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134185___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018964_)))))))));
    wasmetal_core__DOT___060602_ = (1U & (0xfdf0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___060601_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___060600_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xdU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134186___O) 
                                                                      >> 3U))))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___018382_)))))));
    __VdfgTmp_hf9874a1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                               << 4U) | (((IData)(wasmetal_core__DOT___060459_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                           << 2U) | 
                                          ((2U & ((4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017158_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___017144_)))))) 
                                                  << 1U)) 
                                           | (1U & 
                                              (1U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___017155_))))))));
    vlSelf->wasmetal_core__DOT___018782_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018133_))));
    vlSelf->__VdfgTmp_hef484883__0 = (((IData)(wasmetal_core__DOT___058583_) 
                                       << 3U) | ((4U 
                                                  & ((1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___058570_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___058569_)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((0x10U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___058579_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___058578_)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (1U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 2U) 
                                                           | (((IData)(wasmetal_core__DOT___058577_) 
                                                               << 1U) 
                                                              | (IData)(wasmetal_core__DOT___058576_))))))));
    vlSelf->wasmetal_core__DOT___018113_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___059359_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xe0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                << 2U) 
                                                               | (IData)(__VdfgTmp_ha5bd917e__0))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xeU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                   << 2U) 
                                                                  | (((IData)(wasmetal_core__DOT___058588_) 
                                                                      << 1U) 
                                                                     | (IData)(wasmetal_core__DOT___058587_)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xe0U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h9e4f981d__0))))))))));
    wasmetal_core__DOT___017964_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0xeU 
                                                              >> (IData)(__VdfgTmp_h3e19c29d__0)) 
                                                             << 3U)) 
                                                         | (((IData)(wasmetal_core__DOT___059273_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xe0U 
                                                                    >> (IData)(__VdfgTmp_hce4bc968__0)) 
                                                                   << 1U)) 
                                                               | (IData)(wasmetal_core__DOT___059271_)))))))));
    vlSelf->wasmetal_core__DOT___018388_ = (1U & (IData)(
                                                         (0xfff0111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059527_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___058570_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___058569_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h91143f30__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h123a61a4__0))))))));
    vlSelf->__VdfgTmp_h712e4a02__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h61eefee9__0)));
    wasmetal_core__DOT___017962_ = ((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                    & (IData)((0xff00ff33f5f5f0f0ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___017996_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hca806a32__0)) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h893f43f0__0))))))));
    vlSelf->wasmetal_core__DOT___018675_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059531_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059530_))));
    wasmetal_core__DOT___018112_ = (1U & (IData)((0xf0f0cccc00aa00ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059365_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059363_) 
                                                                   << 1U) 
                                                                  | (IData)(wasmetal_core__DOT___059362_))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h61eefee9__0))))))));
    vlSelf->__VdfgTmp_hd61370f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___059496_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h0ef15e16__0)))));
    vlSelf->__VdfgTmp_h2229ca65__0 = ((2U & ((IData)(
                                                     (0xeeeeeeeeff00f0f0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                           << 4U) 
                                                          | ((8U 
                                                              & ((0xeU 
                                                                  >> (IData)(__VdfgTmp_h96788d86__0)) 
                                                                 << 3U)) 
                                                             | (((IData)(wasmetal_core__DOT___017993_) 
                                                                 << 2U) 
                                                                | (IData)(__VdfgTmp_hb715052c__0))))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___018702_));
    vlSelf->wasmetal_core__DOT___018561_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h8e246f46__0)))));
    wasmetal_core__DOT___018206_ = (1U & (0xfc0055U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h8e246f46__0)))));
    vlSelf->__VdfgTmp_hd6c2c06b__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                           << 4U) 
                                                          | (((IData)(wasmetal_core__DOT___059451_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((IData)(
                                                                            (0xfff00000eeee0000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___016528_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___016529_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___058565_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___058566_)))))))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059449_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___059448_)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff00000eeeeULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___059457_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___059456_) 
                                                                  << 2U) 
                                                                 | (((IData)(wasmetal_core__DOT___059455_) 
                                                                     << 1U) 
                                                                    | (IData)(wasmetal_core__DOT___059454_))))))))));
    vlSelf->wasmetal_core__DOT___018596_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059454_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059455_))));
    __VdfgTmp_he904009c__0 = (((IData)(wasmetal_core__DOT___018463_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                          << 2U) | 
                                         ((2U & ((1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058663_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058662_))) 
                                                 << 1U)) 
                                          | (IData)(vlSelf->wasmetal_core__DOT___016532_))));
    vlSelf->wasmetal_core__DOT___018387_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059531_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059530_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___059529_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(__VdfgTmp_haf2ded6f__0))))))))))));
    __VdfgTmp_hbcaa6c53__0 = (((IData)(wasmetal_core__DOT___018111_) 
                               << 1U) | (1U & (1U >> 
                                               ((2U 
                                                 & ((IData)(
                                                            (0xfff00000eeeeULL 
                                                             >> (IData)(__VdfgTmp_h23858478__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> (IData)(__VdfgTmp_haf2ded6f__0))))))));
    vlSelf->wasmetal_core__DOT___018674_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xfff00000eeeeULL 
                                                                >> (IData)(__VdfgTmp_haf2ded6f__0))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___059529_))));
    vlSelf->__VdfgTmp_h49ede088__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(__VdfgTmp_haf2ded6f__0))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff00000eeeeULL 
                                                       >> (IData)(__VdfgTmp_h23858478__0)))));
    vlSelf->wasmetal_core__DOT___018489_ = (1U & (IData)(
                                                         (0xf0f0cccc00ff00aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeee0000ULL 
                                                                              >> (IData)(__VdfgTmp_h4b0290b7__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xf1111U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((0xeU 
                                                                                >> (IData)(__VdfgTmp_h3e19c29d__0)) 
                                                                                << 3U)) 
                                                                             | (((IData)(wasmetal_core__DOT___059273_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___059271_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xe0U 
                                                                                >> (IData)(__VdfgTmp_hce4bc968__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0c0f0c0000aaffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hca806a32__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___017996_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h893f43f0__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(__VdfgTmp_hbbb73552__0)))))))))));
    __VdfgTmp_haf319b6f__0 = (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                               << 1U) | (1U & (1U >> (IData)(__VdfgTmp_hbbb73552__0))));
    vlSelf->wasmetal_core__DOT___018560_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h56c348e9__0))));
    vlSelf->wasmetal_core__DOT___018629_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xfff00000eeeeULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6b4dc907__0))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfff00000eeee0000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7c31faf3__0)))))));
    __VdfgTmp_hc22a8b6b__0 = ((2U & ((IData)((0xfff00000eeee0000ULL 
                                              >> (IData)(__VdfgTmp_h23858478__0))) 
                                     << 1U)) | (IData)(wasmetal_core__DOT___059532_));
    vlSelf->wasmetal_core__DOT___018780_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___018130_)))));
    wasmetal_core__DOT___018525_ = (1U & (IData)((0xffbfbfbfbfULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018130_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___018366_)))))))));
    vlSelf->__VdfgTmp_h5395e72d__0 = (((IData)(wasmetal_core__DOT___018702_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018701_));
    __VdfgTmp_h688967d3__0 = (((IData)(wasmetal_core__DOT___059459_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059458_));
    __VdfgTmp_h7d28918f__0 = (((IData)(wasmetal_core__DOT___018714_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___018713_) 
                                          << 2U) | (IData)(__VdfgTmp_he893b9f2__0)));
    __VdfgTmp_h1a2fc46e__0 = (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                               << 2U) | ((2U & ((IData)(
                                                        (0xfff00000eeee0000ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6b4dc907__0))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_hde0459ca__0))))));
    wasmetal_core__DOT___018893_ = (1U & (0xf40000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h410ade1c__0)))));
    wasmetal_core__DOT___018764_ = (1U & (0xf4000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h410ade1c__0)))));
    wasmetal_core__DOT___018795_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___018212_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___018213_)))));
    vlSelf->wasmetal_core__DOT___018562_ = (1U & (0xfff08888U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___018213_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___018212_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___018713_)))))));
    vlSelf->wasmetal_core__DOT___059499_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_hc303443c__0))));
    vlSelf->wasmetal_core__DOT___060388_ = (1U & (IData)(
                                                         (0xefffffffULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___060387_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___018673_)))))))));
    vlSelf->__VdfgTmp_h64b8144d__0 = (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___018673_))));
    vlSelf->__VdfgTmp_h4cdeac4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___018673_));
    vlSelf->wasmetal_core__DOT___018389_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfff00000eeee0000ULL 
                                                                      >> (IData)(__VdfgTmp_h23858478__0))) 
                                                             << 2U)) 
                                                         | (((IData)(wasmetal_core__DOT___059532_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___018673_)))))));
    vlSelf->__VdfgTmp_ha954d544__0 = ((((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                        & (IData)((0xf000fffff4444ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                     << 5U) 
                                                    | (((IData)(wasmetal_core__DOT___016938_) 
                                                        << 4U) 
                                                       | (((IData)(wasmetal_core__DOT___016936_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___016937_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                 << 1U) 
                                                                | (IData)(wasmetal_core__DOT___016935_))))))))) 
                                       << 1U) | (1U 
                                                 & (0x3050000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                            << 2U) 
                                                           | (IData)(__VdfgTmp_he878b3a8__0)))))));
    vlSelf->wasmetal_core__DOT___016516_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_he878b3a8__0))))));
    vlSelf->wasmetal_core__DOT___039859_ = (1U & (IData)(
                                                         (0xfefefefe02fe0202ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___060628_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060620_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048949_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___060644_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060643_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___060642_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134187___O) 
                                                                           >> 2U))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018382_)))))));
    vlSelf->wasmetal_core__DOT___039858_ = (1U & (IData)(
                                                         (0xf00ffff2e222e22ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                               << 5U)) 
                                                           | (((IData)(wasmetal_core__DOT___060602_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___060591_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048949_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___060479_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hf9874a1f__0)))));
    vlSelf->wasmetal_core__DOT___060469_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hf9874a1f__0)))));
    vlSelf->wasmetal_core__DOT___060441_ = (1U & (IData)(
                                                         (0xbf00bfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018782_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h5ad561b8__0))))))))))));
    vlSelf->wasmetal_core__DOT___060447_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018782_))));
    if (vlSelf->wasmetal_core__DOT___016534_) {
        vlSelf->wasmetal_core__DOT___016519_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___016749_)) 
                                                   & (0xfcfaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h712e4a02__0))));
        vlSelf->wasmetal_core__DOT___018456_ = (1U 
                                                & (0x23U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___016748_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___016747_)))));
    } else {
        vlSelf->wasmetal_core__DOT___016519_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___016748_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___016747_)))));
        vlSelf->wasmetal_core__DOT___018456_ = (1U 
                                                & ((~ (IData)(wasmetal_core__DOT___018464_)) 
                                                   & (0xf0feU 
                                                      >> (IData)(__VdfgTmp_he904009c__0))));
    }
    vlSelf->wasmetal_core__DOT___017953_ = (1U & ((~ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                     & (IData)(
                                                               (0xfef000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hc303443c__0))))))
                                                     ? 
                                                    (1U 
                                                     >> (IData)(vlSelf->wasmetal_core__DOT___016520_))
                                                     : 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___016534_)
                                                      ? 
                                                     (0xe0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_hbbb73552__0))))
                                                      : 
                                                     (0xe0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xfff00000eeeeULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hde0459ca__0))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xfff00000eeee0000ULL 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h6b4dc907__0))))))))))) 
                                                  & (IData)(
                                                            (0xfffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                  << 4U) 
                                                                 | (((IData)(wasmetal_core__DOT___017964_) 
                                                                     << 3U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                         & (IData)(
                                                                                (0xff0f0f11111111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___017970_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___059258_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___059257_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059262_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059261_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(__VdfgTmp_h0c9be8e1__0))))))))))) 
                                                                        << 2U) 
                                                                       | (((IData)(wasmetal_core__DOT___017962_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(__VdfgTmp_h4b0290b7__0)))))))))))));
    vlSelf->__VdfgTmp_h38d1dc38__0 = (((IData)(wasmetal_core__DOT___018112_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___018111_));
    vlSelf->wasmetal_core__DOT___018633_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd61370f8__0))));
    vlSelf->wasmetal_core__DOT___018422_ = (1U & (IData)(
                                                         (0xf0f0cccc00ff00aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018865_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfff01111U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                           << 4U) 
                                                                          | (((IData)(wasmetal_core__DOT___059404_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0x10U 
                                                                                >> (IData)(__VdfgTmp_h0c9be8e1__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6136b552__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2229ca65__0))))))));
    vlSelf->wasmetal_core__DOT___018195_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016521_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___016534_)
                                                      ? 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h56c348e9__0)))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___018213_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___018212_)))))
                                                     : 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___018216_))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___016521_)
                                                      ? 
                                                     (0x1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xfff000001111ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                            << 4U) 
                                                                           | ((8U 
                                                                               & ((0xe0U 
                                                                                >> (IData)(__VdfgTmp_h3e19c29d__0)) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((0xeU 
                                                                                >> (IData)(__VdfgTmp_hce4bc968__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(__VdfgTmp_hb715052c__0))))))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xfff0111100000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                             << 4U) 
                                                                            | (((IData)(wasmetal_core__DOT___059407_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___059257_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___059258_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> (IData)(__VdfgTmp_h0c9be8e1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(wasmetal_core__DOT___059404_))))))))))))
                                                      : 
                                                     (0xfdfU 
                                                      >> 
                                                      (((IData)(wasmetal_core__DOT___018206_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018203_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___016534_))))))));
    vlSelf->wasmetal_core__DOT___018258_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd6c2c06b__0))));
    vlSelf->__VdfgTmp_hb7c93ea5__0 = (((IData)(vlSelf->wasmetal_core__DOT___018596_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018595_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> 
                                                       (((IData)(wasmetal_core__DOT___059458_) 
                                                         << 1U) 
                                                        | (IData)(wasmetal_core__DOT___059459_))))));
    vlSelf->__VdfgTmp_h5fa8e6eb__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___016533_)
                                               ? (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___016937_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___016936_))))
                                               : (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___016938_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___016935_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016532_)))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf0fe00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                         << 5U) 
                                                        | (((IData)(wasmetal_core__DOT___018464_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_he904009c__0)))))));
    vlSelf->__VdfgTmp_h787c74f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___018674_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016534_));
    vlSelf->wasmetal_core__DOT___018781_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h49ede088__0))));
    vlSelf->__VdfgTmp_h97bdc512__0 = (((IData)(vlSelf->wasmetal_core__DOT___018489_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016520_));
    vlSelf->wasmetal_core__DOT___018849_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x11f0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                           << 3U) 
                                                                          | (((IData)(wasmetal_core__DOT___018673_) 
                                                                              << 2U) 
                                                                             | (IData)(__VdfgTmp_hc22a8b6b__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018675_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018674_)))))))));
    vlSelf->wasmetal_core__DOT___018677_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hc22a8b6b__0))));
    vlSelf->wasmetal_core__DOT___060333_ = (1U & (IData)(
                                                         (0xefffefffefffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060332_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___018525_)))))))));
    if (vlSelf->wasmetal_core__DOT___016520_) {
        if (vlSelf->wasmetal_core__DOT___016521_) {
            vlSelf->wasmetal_core__DOT___018535_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018113_) 
                                             << 1U) 
                                            | (IData)(wasmetal_core__DOT___018112_)))));
            vlSelf->wasmetal_core__DOT___018791_ = 
                (1U & (0xf4U >> (((IData)(wasmetal_core__DOT___018206_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___018203_)))));
        } else {
            vlSelf->wasmetal_core__DOT___018535_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                  << 2U) | (IData)(__VdfgTmp_hbcaa6c53__0))));
            vlSelf->wasmetal_core__DOT___018791_ = 
                (1U & (1U >> (((IData)(wasmetal_core__DOT___018796_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018795_))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___018535_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___016521_)) 
                                                   | (2U 
                                                      >> (IData)(wasmetal_core__DOT___018525_))));
        vlSelf->wasmetal_core__DOT___018791_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___018216_))));
    }
    vlSelf->__VdfgTmp_h111e31ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018525_)));
    vlSelf->wasmetal_core__DOT___018915_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___018525_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hbcaa6c53__0))))))));
    vlSelf->wasmetal_core__DOT___018265_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059461_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059460_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h688967d3__0))))))));
    vlSelf->wasmetal_core__DOT___018599_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h688967d3__0)))));
    vlSelf->wasmetal_core__DOT___018864_ = (1U & (IData)(
                                                         (0xff110000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h7d28918f__0))))));
    vlSelf->wasmetal_core__DOT___018715_ = (1U & (IData)(
                                                         (0xff11f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h7d28918f__0))))));
    vlSelf->wasmetal_core__DOT___018899_ = ((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                            & (IData)(
                                                      (0xffff1111fff0fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(
                                                                       (0xfff00000eeee0000ULL 
                                                                        >> (IData)(__VdfgTmp_h4b0290b7__0))) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((0xe0U 
                                                                   >> (IData)(__VdfgTmp_h1a2fc46e__0)) 
                                                                  << 3U)) 
                                                              | (((IData)(wasmetal_core__DOT___018893_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_haf319b6f__0))))))));
    vlSelf->__VdfgTmp_he026c2ed__0 = ((2U & ((0xe0U 
                                              >> (IData)(__VdfgTmp_h1a2fc46e__0)) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___018893_));
    vlSelf->wasmetal_core__DOT___019185_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___018764_)))));
    vlSelf->wasmetal_core__DOT___018759_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016521_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016520_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(__VdfgTmp_h4b0290b7__0))) 
                                                         << 1U)) 
                                                     | (IData)(wasmetal_core__DOT___017962_)))
                                                    : 
                                                   (1U 
                                                    >> (IData)(wasmetal_core__DOT___018764_)))
                                                   : 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___016520_)) 
                                                   | (0xdU 
                                                      >> 
                                                      ((4U 
                                                        & ((0xeU 
                                                            >> (IData)(__VdfgTmp_h1a2fc46e__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((1U 
                                                               >> (IData)(__VdfgTmp_hbbb73552__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016534_)))))));
    vlSelf->__VdfgTmp_h0b565375__0 = ((8U & ((0xeU 
                                              >> (IData)(__VdfgTmp_h1a2fc46e__0)) 
                                             << 3U)) 
                                      | (((IData)(wasmetal_core__DOT___018764_) 
                                          << 2U) | (IData)(__VdfgTmp_haf319b6f__0)));
    vlSelf->__VdfgTmp_hb98c8577__0 = (((IData)(vlSelf->wasmetal_core__DOT___018216_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___018795_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018796_)));
    vlSelf->wasmetal_core__DOT___018937_ = (1U & (0xfcaa0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018561_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018560_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018562_)))))));
    vlSelf->wasmetal_core__DOT___018935_ = (1U & ((~ 
                                                   (0x35000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hcacd7e7e__0)))))) 
                                                  & (IData)(
                                                            (0xffff11ffffff0fffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018562_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018560_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___018561_))))))))));
    vlSelf->__VdfgTmp_hc40410bb__0 = (((IData)(wasmetal_core__DOT___060348_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018562_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))));
}
