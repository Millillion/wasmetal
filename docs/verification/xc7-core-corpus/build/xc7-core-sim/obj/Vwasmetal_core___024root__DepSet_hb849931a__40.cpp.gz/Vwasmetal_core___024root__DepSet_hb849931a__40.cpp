#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__12(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__12\n"); );
    // Init
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_17;
    VlWide<4>/*127:0*/ __Vtemp_49;
    // Body
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_kind__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source_unit__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source_kind__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source_kind__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_table = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source_unit__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b79__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b86__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b77__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b84__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b83__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b82__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__sp__05b13__05d = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___019792_) {
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b29__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050937_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b28__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050919_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b27__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            >> 0x18U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1bU)))))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b26__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            >> 0x17U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1aU)))))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b25__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050927_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b24__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            >> 0x15U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x18U)))))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b23__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050950_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b22__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050952_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b21__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            >> 0x12U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x15U)))))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b20__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            >> 0x11U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x14U)))))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b19__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050945_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b18__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            >> 0xfU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x12U)))))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b16__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050947_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b15__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            >> 0xcU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0xfU)))))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b14__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            >> 0xbU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0xeU)))))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b13__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050935_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b12__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050933_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b11__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050954_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b10__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            >> 7U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0xaU)))))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b9__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050957_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b8__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050959_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b7__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050764_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b6__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050766_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b5__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___049400_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b4__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___049402_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b3__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048526_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b2__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048524_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b1__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 1U)))))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b0__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048522_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_kind__05b0__05d 
                = vlSelf->wasmetal_core__DOT___046221_;
            vlSelf->wasmetal_core__DOT__bulk_source_unit__05b4__05d 
                = (1U & (4U >> ((2U & (vlSelf->insn_z 
                                       >> 6U)) | (1U 
                                                  & (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h2157de83__0))))));
            vlSelf->wasmetal_core__DOT__bulk_table 
                = vlSelf->wasmetal_core__DOT___053955_;
            vlSelf->wasmetal_core__DOT__bulk_source_unit__05b1__05d 
                = (1U & (4U >> (IData)(vlSelf->__VdfgTmp_heaa2bcd7__0)));
            vlSelf->wasmetal_core__DOT__bulk_fill = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___052648_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___070452_))));
        }
        if (vlSelf->wasmetal_core__DOT___019808_) {
            vlSelf->wasmetal_core__DOT__divider__02edividend__05b62__05d 
                = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b61__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054572_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128646___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___034341_)))))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019794_) {
            vlSelf->wasmetal_core__DOT__bulk_source_kind__05b0__05d 
                = (1U & (0xf4ffU >> ((8U & ((1U >> (IData)(vlSelf->__VdfgTmp_h2157de83__0)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__decoded_table))))));
            vlSelf->wasmetal_core__DOT__bulk_source_kind__05b2__05d 
                = (1U & (IData)((0xfffffeeefffff000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048513_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052643_)))))))));
        }
        if (vlSelf->wasmetal_core__DOT___052916_) {
            vlSelf->wasmetal_core__DOT__load_vector__05b57__05d 
                = vlSelf->wasmetal_core__DOT___001058_;
            vlSelf->wasmetal_core__DOT__load_vector__05b47__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b45__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b43__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b42__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b41__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b38__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b37__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b36__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b29__05d 
                = vlSelf->wasmetal_core__DOT___000635_;
            vlSelf->wasmetal_core__DOT__load_vector__05b27__05d 
                = vlSelf->wasmetal_core__DOT___000591_;
            vlSelf->wasmetal_core__DOT__load_vector__05b25__05d 
                = vlSelf->wasmetal_core__DOT___000542_;
            vlSelf->wasmetal_core__DOT__load_vector__05b24__05d 
                = vlSelf->wasmetal_core__DOT___000520_;
            vlSelf->wasmetal_core__DOT__load_vector__05b23__05d 
                = vlSelf->wasmetal_core__DOT___000498_;
            vlSelf->wasmetal_core__DOT__load_vector__05b21__05d 
                = vlSelf->wasmetal_core__DOT___000464_;
            vlSelf->wasmetal_core__DOT__load_vector__05b19__05d 
                = vlSelf->wasmetal_core__DOT___000419_;
            vlSelf->wasmetal_core__DOT__load_vector__05b16__05d 
                = vlSelf->wasmetal_core__DOT___001612_;
            vlSelf->wasmetal_core__DOT__load_vector__05b14__05d 
                = vlSelf->wasmetal_core__DOT___001568_;
            vlSelf->wasmetal_core__DOT__load_vector__05b7__05d 
                = vlSelf->wasmetal_core__DOT___001487_;
            vlSelf->wasmetal_core__DOT__load_vector__05b6__05d 
                = vlSelf->wasmetal_core__DOT___001475_;
            vlSelf->wasmetal_core__DOT__load_vector__05b1__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b5__05d 
                = vlSelf->wasmetal_core__DOT___001443_;
            vlSelf->wasmetal_core__DOT__load_vector__05b2__05d 
                = vlSelf->wasmetal_core__DOT___001874_;
        }
        if (vlSelf->wasmetal_core__DOT___019788_) {
            vlSelf->wasmetal_core__DOT__gc_reference__05b31__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b31__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b30__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b30__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b29__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b29__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b28__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b28__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b27__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b27__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b26__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b26__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b25__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b25__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b24__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b24__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b23__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b23__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b22__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b22__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b21__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b21__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b20__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b20__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b19__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b19__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b18__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b18__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b17__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b17__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b16__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b16__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b15__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b15__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b14__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b14__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b13__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b13__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b12__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b12__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b11__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b11__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b10__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b10__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b9__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b9__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b8__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b8__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b7__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b7__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b6__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b6__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b5__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b5__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b4__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b4__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b3__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b3__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b2__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b2__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b1__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b1__05d;
            vlSelf->wasmetal_core__DOT__gc_reference__05b0__05d 
                = vlSelf->wasmetal_core__DOT__heap_next__05b0__05d;
        }
        if (vlSelf->wasmetal_core__DOT___019793_) {
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b79__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b63__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b86__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b62__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b55__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b77__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004191_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b61__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b54__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b84__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b60__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b83__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b53__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b59__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b82__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b47__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b52__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b58__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b57__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b46__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b51__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b56__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b50__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b45__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b49__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b44__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b39__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b48__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b43__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b38__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b42__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b37__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b41__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b36__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b40__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b35__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b31__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b34__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b30__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b33__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b29__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b32__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b28__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b27__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b7__05d 
                = vlSelf->wasmetal_core__DOT___001488_;
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b23__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b26__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b6__05d 
                = vlSelf->wasmetal_core__DOT___001476_;
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b22__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b5__05d 
                = vlSelf->wasmetal_core__DOT___001444_;
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b25__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b4__05d 
                = vlSelf->wasmetal_core__DOT___001438_;
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b21__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b24__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b3__05d 
                = vlSelf->wasmetal_core__DOT___001887_;
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b20__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b2__05d 
                = vlSelf->wasmetal_core__DOT___001875_;
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b19__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b1__05d 
                = vlSelf->wasmetal_core__DOT___003269_;
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b0__05d 
                = vlSelf->wasmetal_core__DOT___003189_;
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b18__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b15__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b17__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b14__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b16__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b13__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b12__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b11__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b10__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b9__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b8__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
        }
        if (vlSelf->wasmetal_core__DOT___019784_) {
            vlSelf->wasmetal_core__DOT__sp__05b7__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062694_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128181___O) 
                                                                   >> 2U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062690_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b7__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128189___O) 
                                                                              >> 3U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128172___O) 
                                                                       >> 2U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                         >> 3U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b6__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062683_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128181___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062679_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b6__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128189___O) 
                                                                              >> 2U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128172___O) 
                                                                       >> 1U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                         >> 2U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b5__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062672_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128181___O)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062668_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b5__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128189___O) 
                                                                              >> 1U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128172___O)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                         >> 1U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b4__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062661_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128181___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062657_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b4__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128189___O))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128172___O) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b3__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062650_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128180___O) 
                                                                   >> 2U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062646_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b3__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128188___O) 
                                                                              >> 3U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128171___O) 
                                                                       >> 2U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                         >> 3U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b31__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062958_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128187___O) 
                                                                   >> 2U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062954_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b31__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128195___O) 
                                                                              >> 3U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128178___O) 
                                                                       >> 2U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                         >> 3U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b30__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062947_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128187___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062943_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b30__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128195___O) 
                                                                              >> 2U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128178___O) 
                                                                       >> 1U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                         >> 2U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b29__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062936_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128187___O)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062932_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b29__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128195___O) 
                                                                              >> 1U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128178___O)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                         >> 1U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b28__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062925_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128187___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062921_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b28__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128195___O))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128178___O) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b27__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062914_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128186___O) 
                                                                   >> 2U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062910_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b27__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128194___O) 
                                                                              >> 3U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128177___O) 
                                                                       >> 2U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                         >> 3U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b26__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062903_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128186___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062899_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b26__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128194___O) 
                                                                              >> 2U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128177___O) 
                                                                       >> 1U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                         >> 2U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b25__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062892_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128186___O)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062888_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b25__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128194___O) 
                                                                              >> 1U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128177___O)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                         >> 1U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b24__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062881_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128186___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062877_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b24__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128194___O))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128177___O) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b23__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062870_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128185___O) 
                                                                   >> 2U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062866_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b23__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128193___O) 
                                                                              >> 3U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128176___O) 
                                                                       >> 2U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                         >> 3U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b22__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062859_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128185___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062855_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b22__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128193___O) 
                                                                              >> 2U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128176___O) 
                                                                       >> 1U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                         >> 2U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b21__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062848_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128185___O)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062844_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b21__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128193___O) 
                                                                              >> 1U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128176___O)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                         >> 1U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b20__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062837_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128185___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062833_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b20__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128193___O))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128176___O) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b19__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062826_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128184___O) 
                                                                   >> 2U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062822_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b19__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128192___O) 
                                                                              >> 3U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128175___O) 
                                                                       >> 2U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                         >> 3U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b18__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062815_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128184___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062811_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b18__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128192___O) 
                                                                              >> 2U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128175___O) 
                                                                       >> 1U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                         >> 2U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b17__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062804_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128184___O)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062800_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b17__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128192___O) 
                                                                              >> 1U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128175___O)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                         >> 1U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b16__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062793_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128184___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062789_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b16__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128192___O))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128175___O) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b15__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062782_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128183___O) 
                                                                   >> 2U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062778_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b15__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128191___O) 
                                                                              >> 3U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128174___O) 
                                                                       >> 2U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                         >> 3U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b14__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062771_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128183___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062767_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b14__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128191___O) 
                                                                              >> 2U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128174___O) 
                                                                       >> 1U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                         >> 2U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b12__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062749_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128183___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062745_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b12__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128191___O))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128174___O) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b11__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062738_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128182___O) 
                                                                   >> 2U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062734_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b11__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128190___O) 
                                                                              >> 3U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128173___O) 
                                                                       >> 2U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                         >> 3U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b10__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062727_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128182___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062723_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b10__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128190___O) 
                                                                              >> 2U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128173___O) 
                                                                       >> 1U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                         >> 2U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b9__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062716_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128182___O)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062712_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b9__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128190___O) 
                                                                              >> 1U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128173___O)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                         >> 1U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b8__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062705_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128182___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062701_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b8__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128190___O))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128173___O) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b0__05d 
                = (1U & (IData)((0x55553333ff0fff0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062616_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)
                                                            ? 
                                                           (0x5333U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128180___O))))))
                                                            : 
                                                           (0x35ffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128163___O) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062612_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b0__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128188___O))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128171___O) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b2__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062639_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128180___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062635_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b2__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128188___O) 
                                                                              >> 2U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128171___O) 
                                                                       >> 1U)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                         >> 2U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b1__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062628_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128180___O)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062624_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b1__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128188___O) 
                                                                              >> 1U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128171___O)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                         >> 1U))))))))))))));
            vlSelf->wasmetal_core__DOT__sp__05b13__05d 
                = (1U & (IData)((0x555533330f0f00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062760_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128183___O)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf3f50000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___062756_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b13__05d) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128191___O) 
                                                                              >> 1U))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128174___O)) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                         >> 1U))))))))))))));
        }
    }
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039551_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039552_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039553_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039536_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039549_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039870_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039555_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039556_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039557_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039558_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039562_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039547_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039546_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039537_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039538_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039539_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039540_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039523_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040088_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039869_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039542_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039543_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039544_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039545_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039554_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039535_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039533_));
    vlSelf->mem_index = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129036___Q) 
                          << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129035___Q) 
                                        << 0x1eU) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129034___Q) 
                                         << 0x1dU) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129033___Q) 
                                            << 0x1cU) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129032___Q) 
                                               << 0x1bU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129031___Q) 
                                                  << 0x1aU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129030___Q) 
                                                     << 0x19U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129029___Q) 
                                                        << 0x18U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129028___Q) 
                                                           << 0x17U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129027___Q) 
                                                              << 0x16U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129026___Q) 
                                                                 << 0x15U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129025___Q) 
                                                                    << 0x14U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129024___Q) 
                                                                       << 0x13U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129023___Q) 
                                                                          << 0x12U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129022___Q) 
                                                                             << 0x11U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129021___Q) 
                                                                                << 0x10U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129020___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129019___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129018___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129017___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129016___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129015___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129014___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129013___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129012___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129011___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129010___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129009___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129008___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129007___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129006___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129005___Q))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039561_));
    vlSelf->mem_kind = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129004___Q) 
                         << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129003___Q) 
                                    << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129002___Q)));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__DIPADIP 
        = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b35__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b26__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b17__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b8__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b34__05d) 
            << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b33__05d) 
                          << 0x1eU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b32__05d) 
                                        << 0x1dU) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b31__05d) 
                                         << 0x1cU) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b30__05d) 
                                            << 0x1bU) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b29__05d) 
                                               << 0x1aU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b28__05d) 
                                                  << 0x19U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b27__05d) 
                                                     << 0x18U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b25__05d) 
                                                        << 0x17U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b24__05d) 
                                                           << 0x16U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b23__05d) 
                                                              << 0x15U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b22__05d) 
                                                                 << 0x14U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b21__05d) 
                                                                    << 0x13U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b20__05d) 
                                                                       << 0x12U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b19__05d) 
                                                                          << 0x11U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b18__05d) 
                                                                             << 0x10U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b16__05d) 
                                                                                << 0xfU) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b15__05d) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b14__05d) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b13__05d) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b12__05d) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b11__05d) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b10__05d) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b9__05d) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b7__05d) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b6__05d) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b5__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b0__05d))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___035143_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b63__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b62__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040104_));
    vlSelf->wasmetal_core__DOT___035084_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b63__05d))));
    vlSelf->__VdfgTmp_h8e3eac18__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b255__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b254__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b253__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b252__05d))));
    vlSelf->__VdfgTmp_hea78939d__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b251__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b250__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b249__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b248__05d))));
    vlSelf->__VdfgTmp_h89ddcfc9__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b247__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b246__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b245__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b244__05d))));
    vlSelf->__VdfgTmp_hff3ab0b7__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b243__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b242__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b241__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b240__05d))));
    vlSelf->__VdfgTmp_hfc797c55__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b239__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b238__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b237__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b236__05d))));
    vlSelf->__VdfgTmp_he25b67d8__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b235__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b234__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b233__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b232__05d))));
    vlSelf->__VdfgTmp_hc793c4ac__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b231__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b230__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b229__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b228__05d))));
    vlSelf->__VdfgTmp_h4bfa6f09__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b227__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b226__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b225__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b224__05d))));
    vlSelf->__VdfgTmp_he2a57136__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b223__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b222__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b221__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b220__05d))));
    vlSelf->__VdfgTmp_hc7f628da__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b219__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b218__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b217__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b216__05d))));
    vlSelf->__VdfgTmp_h139eafce__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b215__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b214__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b213__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b212__05d))));
    vlSelf->__VdfgTmp_h738a13de__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b211__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b210__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b209__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b208__05d))));
    vlSelf->__VdfgTmp_h63b8fe6d__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b207__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b206__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b205__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b204__05d))));
    vlSelf->__VdfgTmp_he052d4e7__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b203__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b202__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b201__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b200__05d))));
    vlSelf->__VdfgTmp_h4f9812e4__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b199__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b198__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b197__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b196__05d))));
    vlSelf->__VdfgTmp_h40ae3a4f__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b195__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b194__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b193__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b192__05d))));
    vlSelf->__VdfgTmp_h60282e5c__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b191__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b190__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b189__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b188__05d))));
    vlSelf->__VdfgTmp_h7de567cd__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b187__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b186__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b185__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b184__05d))));
    vlSelf->__VdfgTmp_h420e04a5__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b183__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b182__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b181__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b180__05d))));
    vlSelf->__VdfgTmp_hb256bb9f__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b179__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b178__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b177__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b176__05d))));
    vlSelf->__VdfgTmp_h964144cd__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b175__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b174__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b173__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b172__05d))));
    vlSelf->__VdfgTmp_h1aa87dc1__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b171__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b170__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b169__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b168__05d))));
    vlSelf->__VdfgTmp_hc4635290__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b167__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b166__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b165__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b164__05d))));
    vlSelf->__VdfgTmp_h73f4a931__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b163__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b162__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b161__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b160__05d))));
    vlSelf->__VdfgTmp_h6ce46baf__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b159__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b158__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b157__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b156__05d))));
    vlSelf->__VdfgTmp_h1387689e__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b155__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b154__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b153__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b152__05d))));
    vlSelf->__VdfgTmp_h7a6ef80c__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b151__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b150__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b149__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b148__05d))));
    vlSelf->__VdfgTmp_h473eb647__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b147__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b146__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b145__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b144__05d))));
    vlSelf->__VdfgTmp_h211ae39f__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b143__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b142__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b141__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b140__05d))));
    vlSelf->__VdfgTmp_h4f25bbf3__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b139__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b138__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b137__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b136__05d))));
    vlSelf->__VdfgTmp_h7bd28ecf__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b135__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b134__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b133__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b132__05d))));
    vlSelf->__VdfgTmp_h3eb04205__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b131__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b130__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b129__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b128__05d))));
    vlSelf->__VdfgTmp_hd7287eb7__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b127__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b126__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b125__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b124__05d))));
    vlSelf->__VdfgTmp_hd508e470__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b123__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b122__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b121__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b120__05d))));
    vlSelf->__VdfgTmp_h79496643__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b119__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b118__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b117__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b116__05d))));
    vlSelf->__VdfgTmp_h8dc4790b__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b115__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b114__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b113__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b112__05d))));
    vlSelf->__VdfgTmp_h6d54506a__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b111__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b110__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b109__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b108__05d))));
    vlSelf->__VdfgTmp_h1cca9b8e__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b107__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b106__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b105__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b104__05d))));
    vlSelf->__VdfgTmp_h2b062dd4__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b103__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b102__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b101__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b100__05d))));
    vlSelf->__VdfgTmp_h6e193d9b__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b99__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b98__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b97__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b96__05d))));
    vlSelf->__VdfgTmp_hbcd45513__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b95__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b94__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b93__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b92__05d))));
    vlSelf->__VdfgTmp_h36e63769__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b91__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b90__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b89__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b88__05d))));
    vlSelf->__VdfgTmp_hd8443bfe__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b87__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b86__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b85__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b84__05d))));
    vlSelf->__VdfgTmp_h295e0579__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b83__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b82__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b81__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b80__05d))));
    vlSelf->__VdfgTmp_h0f8ff227__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b79__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b78__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b77__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b76__05d))));
    vlSelf->__VdfgTmp_h5760b542__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b75__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b74__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b73__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b72__05d))));
    vlSelf->__VdfgTmp_h28f7b227__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b71__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b70__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b69__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b68__05d))));
    vlSelf->__VdfgTmp_hed4d342a__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b67__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b66__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b65__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b64__05d))));
    vlSelf->__VdfgTmp_hb1756308__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b63__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b62__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b61__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b60__05d))));
    vlSelf->__VdfgTmp_h7031c855__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b59__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b58__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b57__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b56__05d))));
    vlSelf->__VdfgTmp_hfa693494__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b55__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b54__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b53__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b52__05d))));
    vlSelf->__VdfgTmp_h8546e85d__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b51__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b50__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b49__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b48__05d))));
    vlSelf->__VdfgTmp_hf690becd__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b47__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b46__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b45__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b44__05d))));
    vlSelf->__VdfgTmp_h8c9e90c9__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b43__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b42__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b41__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b40__05d))));
    vlSelf->__VdfgTmp_h6a500089__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b39__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b38__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b37__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b36__05d))));
    vlSelf->__VdfgTmp_he6124d0b__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b35__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b34__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b33__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b32__05d))));
    vlSelf->__VdfgTmp_h6239803f__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b30__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b29__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b28__05d))));
    vlSelf->__VdfgTmp_h60760575__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b27__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b26__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b25__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b24__05d))));
    vlSelf->__VdfgTmp_h02a1ae9a__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b23__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b22__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b21__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b20__05d))));
    vlSelf->__VdfgTmp_h87f17c6b__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b19__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b18__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b17__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b16__05d))));
    vlSelf->__VdfgTmp_h3ca396d5__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b15__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b14__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b13__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b12__05d))));
    vlSelf->__VdfgTmp_h12f13bc4__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b11__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b10__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b9__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b8__05d))));
    vlSelf->__VdfgTmp_h980fd1a4__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b7__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b6__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b5__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b4__05d))));
    vlSelf->__VdfgTmp_hf05a0261__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b3__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b2__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b1__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b0__05d))));
    vlSelf->wasmetal_core__DOT___042496_ = (1U & (0xaeefaeaeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b62__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b63__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b62__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___035142_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039589_));
    vlSelf->wasmetal_core__DOT___035141_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b61__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039581_));
    vlSelf->wasmetal_core__DOT___035140_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b60__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039576_));
    vlSelf->wasmetal_core__DOT___042495_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b58__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b59__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b60__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b61__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___035138_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b58__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039593_));
    vlSelf->wasmetal_core__DOT___044142_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b62__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b61__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b59__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b58__05d)))))))));
    vlSelf->wasmetal_core__DOT___035137_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b57__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039594_));
    vlSelf->wasmetal_core__DOT___035136_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b56__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039595_));
    vlSelf->wasmetal_core__DOT___042493_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b55__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b56__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b57__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b58__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___035135_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b56__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b55__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039597_));
    vlSelf->wasmetal_core__DOT___035134_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b54__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039588_));
    vlSelf->wasmetal_core__DOT__fpu__02etrap__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040087_));
    vlSelf->mem_bytes = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129105___Q) 
                          << 4U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129104___Q) 
                                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129103___Q) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129102___Q) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129101___Q)))));
    vlSelf->wasmetal_core__DOT___035133_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b53__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039587_));
    vlSelf->wasmetal_core__DOT___042492_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b53__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b54__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b55__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b54__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___035132_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b52__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039586_));
    vlSelf->wasmetal_core__DOT____Vcellinp___128334___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b55__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b54__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b53__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b52__05d))));
    vlSelf->wasmetal_core__DOT___035131_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b51__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039577_));
    vlSelf->wasmetal_core__DOT___035130_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b50__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039578_));
    vlSelf->wasmetal_core__DOT___042491_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b52__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b51__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___035129_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b49__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039579_));
    vlSelf->wasmetal_core__DOT___035127_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b48__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039580_));
    vlSelf->wasmetal_core__DOT___035126_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b47__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039565_));
    vlSelf->wasmetal_core__DOT___042490_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b47__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b48__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b49__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b48__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___035125_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b46__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039575_));
    vlSelf->wasmetal_core__DOT___044150_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b49__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b47__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___035124_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b45__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039570_));
    vlSelf->wasmetal_core__DOT___035123_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b44__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039582_));
    vlSelf->wasmetal_core__DOT___042489_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b45__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b45__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___035122_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b43__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039583_));
    vlSelf->wasmetal_core__DOT___035121_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b42__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039584_));
    vlSelf->pc = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128967___Q) 
                   << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128966___Q) 
                                 << 0x1eU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128965___Q) 
                                               << 0x1dU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128964___Q) 
                                                  << 0x1cU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128963___Q) 
                                                     << 0x1bU) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128962___Q) 
                                                        << 0x1aU) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128961___Q) 
                                                           << 0x19U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128960___Q) 
                                                              << 0x18U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128959___Q) 
                                                                 << 0x17U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128958___Q) 
                                                                    << 0x16U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128957___Q) 
                                                                       << 0x15U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128956___Q) 
                                                                          << 0x14U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128955___Q) 
                                                                             << 0x13U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128954___Q) 
                                                                                << 0x12U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128953___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128952___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128951___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128950___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128949___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128948___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128947___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128946___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128945___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128944___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128943___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128942___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128941___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128940___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128939___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128938___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128937___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128936___Q))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128936___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128937___Q));
    vlSelf->wasmetal_core__DOT___035120_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b41__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039585_));
    vlSelf->wasmetal_core__DOT___042488_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b41__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b42__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b43__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b42__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___035119_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b40__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039591_));
    vlSelf->wasmetal_core__DOT___044149_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___035118_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b39__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039574_));
    vlSelf->wasmetal_core__DOT___035116_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b38__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039573_));
    vlSelf->wasmetal_core__DOT___042487_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b38__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b39__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b40__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b39__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___035115_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b37__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039566_));
    vlSelf->wasmetal_core__DOT___035114_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b36__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039567_));
    vlSelf->wasmetal_core__DOT___035113_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b35__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039568_));
    vlSelf->wasmetal_core__DOT___042486_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b35__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b36__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b37__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b36__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___035112_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b34__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039569_));
    vlSelf->trap = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128903___Q) 
                     << 7U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128902___Q) 
                                << 6U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128901___Q) 
                                           << 5U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128900___Q) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128899___Q) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128898___Q) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128897___Q) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128896___Q))))))));
    vlSelf->wasmetal_core__DOT___044148_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b38__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b37__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___035111_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b33__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039571_));
    vlSelf->mem_address = (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129100___Q)) 
                            << 0x3fU) | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129099___Q)) 
                                          << 0x3eU) 
                                         | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129098___Q)) 
                                             << 0x3dU) 
                                            | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129097___Q)) 
                                                << 0x3cU) 
                                               | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129096___Q)) 
                                                   << 0x3bU) 
                                                  | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129095___Q)) 
                                                      << 0x3aU) 
                                                     | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129094___Q)) 
                                                         << 0x39U) 
                                                        | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129093___Q)) 
                                                            << 0x38U) 
                                                           | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129092___Q)) 
                                                               << 0x37U) 
                                                              | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129091___Q)) 
                                                                  << 0x36U) 
                                                                 | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129090___Q)) 
                                                                     << 0x35U) 
                                                                    | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129089___Q)) 
                                                                        << 0x34U) 
                                                                       | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129088___Q)) 
                                                                           << 0x33U) 
                                                                          | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129087___Q)) 
                                                                              << 0x32U) 
                                                                             | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129086___Q)) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129085___Q)) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129084___Q)) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129083___Q)) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129082___Q)) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129081___Q)) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129080___Q)) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129079___Q)) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129078___Q)) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129077___Q)) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129076___Q)) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129075___Q)) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129074___Q)) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129073___Q)) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129072___Q)) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129071___Q)) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129070___Q)) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129069___Q)) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129068___Q) 
                                                                                << 0x1fU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129067___Q) 
                                                                                << 0x1eU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129066___Q) 
                                                                                << 0x1dU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129065___Q) 
                                                                                << 0x1cU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129064___Q) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129063___Q) 
                                                                                << 0x1aU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129062___Q) 
                                                                                << 0x19U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129061___Q) 
                                                                                << 0x18U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129060___Q) 
                                                                                << 0x17U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129059___Q) 
                                                                                << 0x16U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129058___Q) 
                                                                                << 0x15U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129057___Q) 
                                                                                << 0x14U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129056___Q) 
                                                                                << 0x13U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129055___Q) 
                                                                                << 0x12U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129054___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129053___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129052___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129051___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129050___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129049___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129048___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129047___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129046___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129045___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129044___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129043___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129042___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129041___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129040___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129039___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129038___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129037___Q))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___035110_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b32__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039564_));
    vlSelf->__VdfgTmp_hba5a1633__0 = (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b32__05d));
    vlSelf->wasmetal_core__DOT___042485_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b32__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b33__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b34__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b33__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___035109_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b31__05d))));
    vlSelf->wasmetal_core__DOT__gc_count__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039592_));
    vlSelf->wasmetal_core__DOT___029938_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d))));
    vlSelf->wasmetal_core__DOT___029937_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d))));
    vlSelf->wasmetal_core__DOT___029935_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d))));
    vlSelf->wasmetal_core__DOT___029934_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d))));
    vlSelf->wasmetal_core__DOT___029933_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d))));
    vlSelf->wasmetal_core__DOT___029932_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d))));
    vlSelf->wasmetal_core__DOT___029931_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d))));
    vlSelf->wasmetal_core__DOT___029930_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d))));
    vlSelf->wasmetal_core__DOT___029929_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d))));
    vlSelf->wasmetal_core__DOT___029928_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d))));
    vlSelf->wasmetal_core__DOT___029927_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d))));
    vlSelf->wasmetal_core__DOT___029926_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d))));
    vlSelf->wasmetal_core__DOT___029924_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d))));
    vlSelf->wasmetal_core__DOT___029923_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d))));
    vlSelf->wasmetal_core__DOT___029922_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d))));
    vlSelf->wasmetal_core__DOT___029921_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d))));
    vlSelf->wasmetal_core__DOT___029920_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d))));
    vlSelf->wasmetal_core__DOT___029919_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d))));
    vlSelf->wasmetal_core__DOT___029918_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d))));
    vlSelf->wasmetal_core__DOT___029917_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d))));
    vlSelf->wasmetal_core__DOT___029916_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d))));
    vlSelf->wasmetal_core__DOT___029915_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d))));
    vlSelf->wasmetal_core__DOT___029945_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d))));
    vlSelf->wasmetal_core__DOT___029944_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d))));
    vlSelf->wasmetal_core__DOT___029943_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d))));
    vlSelf->wasmetal_core__DOT___029942_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d))));
    vlSelf->wasmetal_core__DOT___029941_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d))));
    vlSelf->wasmetal_core__DOT___029940_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d))));
    vlSelf->wasmetal_core__DOT___029939_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d))));
    vlSelf->wasmetal_core__DOT___029936_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d))));
    vlSelf->wasmetal_core__DOT___029925_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d))));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b79__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039718_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b63__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039694_));
    vlSelf->wasmetal_core__DOT___029914_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d))));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b86__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039712_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b62__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039693_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b55__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039690_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b77__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039727_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b61__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039686_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b54__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039692_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b84__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039715_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b60__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039679_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b83__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039708_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b53__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039681_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b59__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039687_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b82__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039699_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b47__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039691_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b52__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039665_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b58__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039677_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b57__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039688_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b46__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039682_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b51__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039676_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b56__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039685_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b50__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040055_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b45__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039689_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b49__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039684_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b44__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039675_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b39__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039659_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b48__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039698_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b43__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039674_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b38__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039667_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b42__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039673_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b37__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039657_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b41__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039660_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b36__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039661_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b40__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039666_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b35__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039669_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039656_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b34__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039671_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040056_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b33__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039683_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039664_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b32__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039642_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039672_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039670_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039638_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039654_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039662_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039637_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039653_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039636_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039668_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039635_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039643_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039655_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039634_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039644_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039633_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039645_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039629_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039755_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039646_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040059_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039648_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039649_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039641_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039650_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039651_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039652_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039663_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039640_));
    __Vtemp_1[0U] = (IData)((((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129169___Q)) 
                              << 0x3fU) | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129168___Q)) 
                                            << 0x3eU) 
                                           | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129167___Q)) 
                                               << 0x3dU) 
                                              | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129166___Q)) 
                                                  << 0x3cU) 
                                                 | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129165___Q)) 
                                                     << 0x3bU) 
                                                    | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129164___Q)) 
                                                        << 0x3aU) 
                                                       | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129163___Q)) 
                                                           << 0x39U) 
                                                          | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129162___Q)) 
                                                              << 0x38U) 
                                                             | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129161___Q)) 
                                                                 << 0x37U) 
                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129160___Q)) 
                                                                    << 0x36U) 
                                                                   | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129159___Q)) 
                                                                       << 0x35U) 
                                                                      | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129158___Q)) 
                                                                          << 0x34U) 
                                                                         | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129157___Q)) 
                                                                             << 0x33U) 
                                                                            | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129156___Q)) 
                                                                                << 0x32U) 
                                                                               | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129155___Q)) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129154___Q)) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129153___Q)) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129152___Q)) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129151___Q)) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129150___Q)) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129149___Q)) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129148___Q)) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129147___Q)) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129146___Q)) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129145___Q)) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129144___Q)) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129143___Q)) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129142___Q)) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129141___Q)) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129140___Q)) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129139___Q)) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129138___Q)) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129137___Q) 
                                                                                << 0x1fU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129136___Q) 
                                                                                << 0x1eU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129135___Q) 
                                                                                << 0x1dU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129134___Q) 
                                                                                << 0x1cU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129133___Q) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129132___Q) 
                                                                                << 0x1aU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129131___Q) 
                                                                                << 0x19U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129130___Q) 
                                                                                << 0x18U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129129___Q) 
                                                                                << 0x17U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129128___Q) 
                                                                                << 0x16U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129127___Q) 
                                                                                << 0x15U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129126___Q) 
                                                                                << 0x14U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129125___Q) 
                                                                                << 0x13U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129124___Q) 
                                                                                << 0x12U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129123___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129122___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129121___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129120___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129119___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129118___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129117___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129116___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129115___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129114___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129113___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129112___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129111___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129110___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129109___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129108___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129107___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129106___Q)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    __Vtemp_1[1U] = (IData)(((((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129169___Q)) 
                               << 0x3fU) | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129168___Q)) 
                                             << 0x3eU) 
                                            | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129167___Q)) 
                                                << 0x3dU) 
                                               | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129166___Q)) 
                                                   << 0x3cU) 
                                                  | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129165___Q)) 
                                                      << 0x3bU) 
                                                     | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129164___Q)) 
                                                         << 0x3aU) 
                                                        | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129163___Q)) 
                                                            << 0x39U) 
                                                           | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129162___Q)) 
                                                               << 0x38U) 
                                                              | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129161___Q)) 
                                                                  << 0x37U) 
                                                                 | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129160___Q)) 
                                                                     << 0x36U) 
                                                                    | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129159___Q)) 
                                                                        << 0x35U) 
                                                                       | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129158___Q)) 
                                                                           << 0x34U) 
                                                                          | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129157___Q)) 
                                                                              << 0x33U) 
                                                                             | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129156___Q)) 
                                                                                << 0x32U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129155___Q)) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129154___Q)) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129153___Q)) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129152___Q)) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129151___Q)) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129150___Q)) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129149___Q)) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129148___Q)) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129147___Q)) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129146___Q)) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129145___Q)) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129144___Q)) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129143___Q)) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129142___Q)) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129141___Q)) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129140___Q)) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129139___Q)) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129138___Q)) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129137___Q) 
                                                                                << 0x1fU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129136___Q) 
                                                                                << 0x1eU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129135___Q) 
                                                                                << 0x1dU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129134___Q) 
                                                                                << 0x1cU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129133___Q) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129132___Q) 
                                                                                << 0x1aU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129131___Q) 
                                                                                << 0x19U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129130___Q) 
                                                                                << 0x18U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129129___Q) 
                                                                                << 0x17U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129128___Q) 
                                                                                << 0x16U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129127___Q) 
                                                                                << 0x15U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129126___Q) 
                                                                                << 0x14U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129125___Q) 
                                                                                << 0x13U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129124___Q) 
                                                                                << 0x12U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129123___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129122___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129121___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129120___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129119___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129118___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129117___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129116___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129115___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129114___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129113___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129112___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129111___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129110___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129109___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129108___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129107___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129106___Q)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) 
                             >> 0x20U));
    __Vtemp_17[2U] = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129186___Q) 
                       << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129185___Q) 
                                     << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129184___Q) 
                                                  << 0xeU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129183___Q) 
                                                     << 0xdU) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129182___Q) 
                                                        << 0xcU) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129181___Q) 
                                                           << 0xbU) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129180___Q) 
                                                              << 0xaU) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129179___Q) 
                                                                 << 9U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129178___Q) 
                                                                    << 8U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129177___Q) 
                                                                       << 7U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129176___Q) 
                                                                          << 6U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129175___Q) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129174___Q) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129173___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129172___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129171___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129170___Q)))))))))))))))));
    __Vtemp_49[3U] = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129218___Q) 
                       << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129217___Q) 
                                     << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129216___Q) 
                                                  << 0xeU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129215___Q) 
                                                     << 0xdU) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129214___Q) 
                                                        << 0xcU) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129213___Q) 
                                                           << 0xbU) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129212___Q) 
                                                              << 0xaU) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129211___Q) 
                                                                 << 9U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129210___Q) 
                                                                    << 8U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129209___Q) 
                                                                       << 7U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129208___Q) 
                                                                          << 6U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129207___Q) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129206___Q) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129205___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129204___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129203___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129202___Q)))))))))))))))));
    vlSelf->mem_wdata[0U] = __Vtemp_1[0U];
    vlSelf->mem_wdata[1U] = __Vtemp_1[1U];
    vlSelf->mem_wdata[2U] = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129201___Q) 
                              << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129200___Q) 
                                            << 0x1eU) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129199___Q) 
                                               << 0x1dU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129198___Q) 
                                                  << 0x1cU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129197___Q) 
                                                     << 0x1bU) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129196___Q) 
                                                        << 0x1aU) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129195___Q) 
                                                           << 0x19U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129194___Q) 
                                                              << 0x18U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129193___Q) 
                                                                 << 0x17U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129192___Q) 
                                                                    << 0x16U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129191___Q) 
                                                                       << 0x15U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129190___Q) 
                                                                          << 0x14U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129189___Q) 
                                                                             << 0x13U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129188___Q) 
                                                                                << 0x12U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129187___Q) 
                                                                                << 0x11U) 
                                                                                | __Vtemp_17[2U])))))))))))))));
    vlSelf->mem_wdata[3U] = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129233___Q) 
                              << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129232___Q) 
                                            << 0x1eU) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129231___Q) 
                                               << 0x1dU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129230___Q) 
                                                  << 0x1cU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129229___Q) 
                                                     << 0x1bU) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129228___Q) 
                                                        << 0x1aU) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129227___Q) 
                                                           << 0x19U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129226___Q) 
                                                              << 0x18U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129225___Q) 
                                                                 << 0x17U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129224___Q) 
                                                                    << 0x16U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129223___Q) 
                                                                       << 0x15U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129222___Q) 
                                                                          << 0x14U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129221___Q) 
                                                                             << 0x13U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129220___Q) 
                                                                                << 0x12U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129219___Q) 
                                                                                << 0x11U) 
                                                                                | __Vtemp_49[3U])))))))))))))));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039639_));
    vlSelf->wasmetal_core__DOT__gc_fill = ((1U & (~ (IData)(vlSelf->reset))) 
                                           && (IData)(vlSelf->wasmetal_core__DOT___039632_));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__DIBDI 
        = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b63__05d) 
            << 0x18U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b61__05d) 
                          << 0x17U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b60__05d) 
                                        << 0x16U) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b59__05d) 
                                         << 0x15U) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b58__05d) 
                                            << 0x14U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b57__05d) 
                                               << 0x13U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b56__05d) 
                                                  << 0x12U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b55__05d) 
                                                     << 0x11U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b54__05d) 
                                                        << 0x10U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b52__05d) 
                                                           << 0xfU) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b51__05d) 
                                                              << 0xeU) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b50__05d) 
                                                                 << 0xdU) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b49__05d) 
                                                                    << 0xcU) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b48__05d) 
                                                                       << 0xbU) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b47__05d) 
                                                                          << 0xaU) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b46__05d) 
                                                                             << 9U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b45__05d) 
                                                                                << 8U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b43__05d) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b42__05d) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b41__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b40__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b39__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b38__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b36__05d)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__DIPBDIP 
        = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b62__05d) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b53__05d) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b44__05d)));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__DIBDI 
        = (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b64__05d) 
            << 0x19U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b63__05d) 
                          << 0x18U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d) 
                                        << 0x17U) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d) 
                                         << 0x16U) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d) 
                                            << 0x15U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b58__05d) 
                                               << 0x14U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d) 
                                                  << 0x13U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d) 
                                                     << 0x12U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b55__05d) 
                                                        << 0x11U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b54__05d) 
                                                           << 0x10U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b52__05d) 
                                                              << 0xfU) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b51__05d) 
                                                                 << 0xeU) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d) 
                                                                    << 0xdU) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b49__05d) 
                                                                       << 0xcU) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d) 
                                                                          << 0xbU) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d) 
                                                                             << 0xaU) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d) 
                                                                                << 9U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___048295_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b6__05d))));
    vlSelf->__VdfgTmp_h5a8db87d__0 = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b6__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b7__05d));
    vlSelf->wasmetal_core__DOT___048539_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b4__05d))));
    vlSelf->__VdfgTmp_hf7906078__0 = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b4__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b5__05d));
    vlSelf->wasmetal_core__DOT___048570_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b2__05d))));
    vlSelf->__VdfgTmp_h46faf1d8__0 = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b2__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__ADDRBWRADDR 
        = (0x803fU | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b7__05d) 
                       << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b6__05d) 
                                    << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b5__05d) 
                                                 << 0xbU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b4__05d) 
                                                    << 0xaU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b3__05d) 
                                                       << 9U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b2__05d) 
                                                          << 8U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b1__05d) 
                                                             << 7U) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b0__05d) 
                                                               << 6U)))))))));
    vlSelf->wasmetal_core__DOT___048545_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b0__05d))));
    vlSelf->__VdfgTmp_hc3285b0a__0 = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b1__05d));
    vlSelf->wasmetal_core__DOT___048290_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b24__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___048288_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b18__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b17__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___048289_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b14__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b13__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b12__05d))))));
    vlSelf->wasmetal_core__DOT___043961_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___043960_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___043959_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b14__05d)))))))));
    vlSelf->__VdfgTmp_h17767d6e__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b0__05d));
    vlSelf->wasmetal_core__DOT___043964_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT__fp__05b31__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b31__05d;
    vlSelf->wasmetal_core__DOT__fp__05b30__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b30__05d;
    vlSelf->wasmetal_core__DOT__fp__05b29__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b29__05d;
    vlSelf->wasmetal_core__DOT__fp__05b28__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b28__05d;
    vlSelf->wasmetal_core__DOT__fp__05b27__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b27__05d;
    vlSelf->wasmetal_core__DOT__fp__05b26__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b26__05d;
    vlSelf->wasmetal_core__DOT__fp__05b25__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b25__05d;
    vlSelf->wasmetal_core__DOT__fp__05b24__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b24__05d;
    vlSelf->wasmetal_core__DOT__fp__05b23__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b23__05d;
    vlSelf->wasmetal_core__DOT__fp__05b22__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b22__05d;
    vlSelf->wasmetal_core__DOT__fp__05b21__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b21__05d;
    vlSelf->wasmetal_core__DOT__fp__05b20__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b20__05d;
    vlSelf->wasmetal_core__DOT__fp__05b19__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b19__05d;
    vlSelf->wasmetal_core__DOT__fp__05b18__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b18__05d;
    vlSelf->wasmetal_core__DOT__fp__05b17__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b17__05d;
    vlSelf->wasmetal_core__DOT__fp__05b16__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b16__05d;
    vlSelf->wasmetal_core__DOT__fp__05b15__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b15__05d;
    vlSelf->wasmetal_core__DOT__fp__05b14__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b14__05d;
    vlSelf->wasmetal_core__DOT__fp__05b13__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b13__05d;
    vlSelf->wasmetal_core__DOT__fp__05b12__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b12__05d;
    vlSelf->wasmetal_core__DOT__fp__05b11__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b11__05d;
    vlSelf->wasmetal_core__DOT__fp__05b10__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b10__05d;
    vlSelf->wasmetal_core__DOT__fp__05b9__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b9__05d;
    vlSelf->wasmetal_core__DOT__fp__05b8__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b8__05d;
    vlSelf->wasmetal_core__DOT__fp__05b7__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b7__05d;
    vlSelf->wasmetal_core__DOT__fp__05b6__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b6__05d;
    vlSelf->wasmetal_core__DOT__fp__05b5__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b5__05d;
    vlSelf->wasmetal_core__DOT__fp__05b4__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b4__05d;
    vlSelf->wasmetal_core__DOT__fp__05b3__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b3__05d;
    vlSelf->wasmetal_core__DOT__fp__05b2__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b2__05d;
    vlSelf->wasmetal_core__DOT__fp__05b1__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b1__05d;
    vlSelf->wasmetal_core__DOT__fp__05b0__05d = vlSelf->__Vdly__wasmetal_core__DOT__fp__05b0__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b31__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b31__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b30__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b30__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b29__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b29__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b28__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b28__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b27__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b27__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b26__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b26__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b25__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b25__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b24__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b24__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b23__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b23__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b22__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b22__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b21__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b21__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b20__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b20__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b19__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b19__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b18__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b18__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b17__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b17__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b16__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b16__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b15__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b15__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b14__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b14__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b13__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b13__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b12__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b12__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b11__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b11__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b10__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b10__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b9__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b9__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b8__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b8__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b7__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b7__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b6__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b6__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b5__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b5__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b4__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b4__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b3__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b3__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b2__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b2__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b1__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b1__05d;
    vlSelf->wasmetal_core__DOT__control_sp__05b0__05d 
        = vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b0__05d;
    vlSelf->wasmetal_core__DOT___071471_ = (1U & (IData)(
                                                         (0xfeffffff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02ebusy) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2f7c3620__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___053749_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_he3290929__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053742_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___044213_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha5b552f8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128423___DI))))));
    vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___065584_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065583_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b4__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__load_width__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___065585_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b3__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065583_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__load_width__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___044212_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052942_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128422___DI))))));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b2__05d) {
        vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b2__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__2__KET__ = 0U;
        vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___044211_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b9__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052944_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d)))));
    vlSelf->wasmetal_core__DOT___044203_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052944_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5a9aeb48__0))));
    vlSelf->wasmetal_core__DOT___052949_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044210_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128423___DI)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128422___DI)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052944_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x1000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___044209_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___044214_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052942_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha5b552f8__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5a9aeb48__0))))))))))))));
    vlSelf->wasmetal_core__DOT___052926_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052924_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b7__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___045596_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___045609_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045608_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045607_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045606_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045605_)
                                                       ? 
                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT___045604_)) 
                                                       & (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b1__05d))
                                                       : 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___045605_)))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___045606_)))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___045607_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___045608_)))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___045609_))));
    vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___052925_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052921_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b13__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b9__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___052935_ = (1U & (IData)(
                                                         (0x9000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052929_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052928_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x9009000000009009ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b12__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b10__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b8__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___052936_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052932_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052931_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045960_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he45fe6bb__0))))))));
    vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___029382_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b0__05d));
    vlSelf->wasmetal_core__DOT___045956_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h950b0747__0))))))));
    vlSelf->wasmetal_core__DOT___052011_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052010_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052009_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052008_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b99__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b98__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b97__05d)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b109__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b108__05d)))))))));
    vlSelf->wasmetal_core__DOT___052675_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052025_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b77__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b76__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b67__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b66__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b65__05d)))))))));
    vlSelf->wasmetal_core__DOT___052024_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b59__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b58__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b42__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb8b9c084__0))))))));
    vlSelf->wasmetal_core__DOT___052019_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052017_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052016_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b35__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6b18dcfd__0))))))));
    vlSelf->wasmetal_core__DOT___064086_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b31__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b29__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___065559_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h49b76e08__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h835050f4__0))))));
    vlSelf->wasmetal_core__DOT___064091_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064090_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064089_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___065563_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065552_))));
    vlSelf->wasmetal_core__DOT___065553_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065552_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b4__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b5__05d)))));
    vlSelf->wasmetal_core__DOT___052004_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052003_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___042508_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035105_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035107_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035108_)))));
    vlSelf->wasmetal_core__DOT___042528_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035102_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035103_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035104_)))));
    vlSelf->wasmetal_core__DOT___042527_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035099_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035100_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035101_)))));
    vlSelf->wasmetal_core__DOT___042526_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035096_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035097_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035098_)))));
    vlSelf->wasmetal_core__DOT___042525_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035093_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035094_)))));
    vlSelf->wasmetal_core__DOT___042524_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035089_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035090_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035091_)))));
    vlSelf->wasmetal_core__DOT___042523_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035086_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035087_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035088_)))));
    vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___042522_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035146_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035147_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035085_)))));
    vlSelf->wasmetal_core__DOT___042521_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035139_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035144_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035145_)))));
    vlSelf->wasmetal_core__DOT___042518_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035106_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035117_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035128_)))));
    vlSelf->wasmetal_core__DOT___042483_ = (1U & (0x2b22U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hff2c11ba__0)))));
    vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___029221_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d));
    vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026165_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d));
    vlSelf->wasmetal_core__DOT___044146_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053337_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b24__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h347304aa__0))))));
    vlSelf->wasmetal_core__DOT___044143_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044131_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128567___O 
        = ((1U | ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b2__05d)) 
                         << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b1__05d)) 
                                           << 2U)) 
                                    | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                             << 1U))))) 
           ^ (3U | (((IData)(vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0) 
                     << 3U) | (4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                     << 2U)))));
    vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b2__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___053312_ = (1U & (IData)(
                                                         (0x4100004100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053310_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b89__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b86__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x15U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b87__05d) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x17U)))))))))))));
    vlSelf->wasmetal_core__DOT___042507_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hff2c11ba__0))))));
    vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035084_) 
           | (IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b63__05d));
    vlSelf->wasmetal_core__DOT___042520_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035143_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035142_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b63__05d)))));
    vlSelf->wasmetal_core__DOT___042519_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035138_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035140_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035141_)))));
    vlSelf->wasmetal_core__DOT___042517_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035135_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035136_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035137_)))));
    vlSelf->wasmetal_core__DOT___042516_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035133_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035134_)))));
    vlSelf->wasmetal_core__DOT___044151_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128334___DI)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d)))));
}
