#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__18(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__18\n"); );
    // Init
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128059___O;
    wasmetal_core__DOT____Vcellout___128059___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134211___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134211___DOT__CO__BRA__2__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___001741_ = (1U & (IData)(
                                                         (0xff000f00ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h07469665__0)))))));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___048789_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002433_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002432_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002431_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002430_))))))));
        vlSelf->wasmetal_core__DOT___001798_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001950_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001949_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001948_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001947_))))))));
        vlSelf->wasmetal_core__DOT___002189_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002280_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h85a07a94__0))))));
        vlSelf->wasmetal_core__DOT___002187_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002198_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002197_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002196_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002195_))))))));
        vlSelf->wasmetal_core__DOT___048787_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002355_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002354_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002353_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002352_))))))));
        vlSelf->wasmetal_core__DOT___001799_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001995_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcbcea2b7__0))))));
        vlSelf->wasmetal_core__DOT___000141_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000155_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h91cc03bd__0))))));
        vlSelf->wasmetal_core__DOT___002030_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002152_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002151_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3fe5e3ea__0)))))));
        vlSelf->wasmetal_core__DOT___000144_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001743_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001742_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001741_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001740_))))))));
    } else {
        vlSelf->wasmetal_core__DOT___048789_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002434_))));
        vlSelf->wasmetal_core__DOT___001798_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001951_))));
        vlSelf->wasmetal_core__DOT___002189_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002281_))));
        vlSelf->wasmetal_core__DOT___002187_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002199_))));
        vlSelf->wasmetal_core__DOT___048787_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002356_))));
        vlSelf->wasmetal_core__DOT___001799_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001996_))));
        vlSelf->wasmetal_core__DOT___000141_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___000156_))));
        vlSelf->wasmetal_core__DOT___002030_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002153_))));
        vlSelf->wasmetal_core__DOT___000144_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001744_))));
    }
    vlSelf->wasmetal_core__DOT___064936_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcbcea2b7__0))));
    vlSelf->wasmetal_core__DOT___068423_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068027_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068422_)))));
    vlSelf->wasmetal_core__DOT___068399_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067970_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068398_)))));
    vlSelf->wasmetal_core__DOT___068290_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067817_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068289_)))));
    vlSelf->wasmetal_core__DOT___068344_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067904_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068343_)))));
    vlSelf->wasmetal_core__DOT___068152_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067732_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068151_)))));
    vlSelf->wasmetal_core__DOT___068076_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067594_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068075_)))));
    vlSelf->wasmetal_core__DOT___067971_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067449_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067970_)))));
    vlSelf->wasmetal_core__DOT___067818_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067302_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067817_)))));
    vlSelf->wasmetal_core__DOT___067733_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067147_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067732_)))));
    vlSelf->wasmetal_core__DOT___067595_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066964_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067594_)))));
    vlSelf->wasmetal_core__DOT___068237_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067756_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068236_)))));
    vlSelf->wasmetal_core__DOT___067450_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066845_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067449_)))));
    vlSelf->wasmetal_core__DOT___068101_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067666_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068100_)))));
    vlSelf->wasmetal_core__DOT___067303_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066640_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067302_)))));
    vlSelf->wasmetal_core__DOT___068028_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067498_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068027_)))));
    vlSelf->wasmetal_core__DOT___067905_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067332_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067904_)))));
    vlSelf->wasmetal_core__DOT___067148_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066518_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067147_)))));
    vlSelf->wasmetal_core__DOT___067757_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067188_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067756_)))));
    vlSelf->wasmetal_core__DOT___067667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067069_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067666_)))));
    vlSelf->wasmetal_core__DOT___066965_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066306_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066964_)))));
    vlSelf->wasmetal_core__DOT___067499_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066886_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067498_)))));
    vlSelf->wasmetal_core__DOT___066846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066118_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066845_)))));
    vlSelf->wasmetal_core__DOT___067333_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066762_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067332_)))));
    vlSelf->wasmetal_core__DOT___067189_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067188_)))));
    vlSelf->wasmetal_core__DOT___066641_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065927_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066640_)))));
    vlSelf->wasmetal_core__DOT___066519_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065795_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066518_)))));
    vlSelf->wasmetal_core__DOT___067070_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066392_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067069_)))));
    vlSelf->wasmetal_core__DOT___066887_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066262_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066886_)))));
    vlSelf->wasmetal_core__DOT___066763_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066072_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066762_)))));
    vlSelf->wasmetal_core__DOT___066596_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066595_)))));
    vlSelf->wasmetal_core__DOT___066307_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065597_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066306_)))));
    vlSelf->wasmetal_core__DOT___066393_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066392_)))));
    vlSelf->wasmetal_core__DOT___065407_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065406_))));
    vlSelf->wasmetal_core__DOT___066263_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065406_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066262_)))));
    vlSelf->wasmetal_core__DOT___064893_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064892_))));
    vlSelf->wasmetal_core__DOT___065892_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064892_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065891_)))));
    vlSelf->wasmetal_core__DOT___065178_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065177_))));
    vlSelf->wasmetal_core__DOT___066073_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065177_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066072_)))));
    vlSelf->wasmetal_core__DOT___064485_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064484_))));
    vlSelf->wasmetal_core__DOT___065694_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064484_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065693_)))));
    vlSelf->wasmetal_core__DOT___065294_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065293_))));
    vlSelf->wasmetal_core__DOT___066119_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065293_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066118_)))));
    vlSelf->wasmetal_core__DOT___065796_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064725_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065795_)))));
    vlSelf->wasmetal_core__DOT___064726_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064725_))));
    vlSelf->wasmetal_core__DOT___065073_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065072_))));
    vlSelf->wasmetal_core__DOT___065928_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065072_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065927_)))));
    vlSelf->wasmetal_core__DOT___065598_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063831_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065597_)))));
    vlSelf->wasmetal_core__DOT___063863_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063831_))));
    vlSelf->wasmetal_core__DOT___050600_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050585_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049023_))))));
    vlSelf->wasmetal_core__DOT___049775_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049454_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049447_))))));
    vlSelf->wasmetal_core__DOT___050060_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050053_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xacU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0)))))));
    vlSelf->wasmetal_core__DOT___053887_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053634_))));
    vlSelf->wasmetal_core__DOT___049045_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049044_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049043_))));
    vlSelf->__VdfgTmp_h3784db21__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___050526_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___050521_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                          << 1U)) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___050528_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050521_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___051403_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051402_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051401_))));
    vlSelf->wasmetal_core__DOT___051543_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049688_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))));
    vlSelf->wasmetal_core__DOT___049690_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049689_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049688_))));
    vlSelf->wasmetal_core__DOT___049731_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049285_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049252_))));
    vlSelf->wasmetal_core__DOT___049869_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049657_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___049659_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049658_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049657_))));
    vlSelf->wasmetal_core__DOT___052592_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052591_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052590_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h36cbed8c__0))))));
    vlSelf->wasmetal_core__DOT___051461_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051428_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051427_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051426_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051433_)))))));
    vlSelf->wasmetal_core__DOT___053111_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051918_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051904_))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xcaU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051906_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___051905_)))))));
    vlSelf->wasmetal_core__DOT___050899_ = (1U & (IData)(
                                                         (0xff00aaaaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049057_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h10726817__0)))));
    vlSelf->wasmetal_core__DOT___053386_ = (1U & (0xa300U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xf0f5533U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052600_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h92ec5796__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h40926396__0)))))))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0))))))))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048680_))))));
    vlSelf->wasmetal_core__DOT___052604_ = (1U & (IData)(
                                                         (0xaaccf000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052600_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h84446dc0__0)))))));
    vlSelf->wasmetal_core__DOT___067179_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((4U 
                                                               & ((0xcaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___050046_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050058_))) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050059_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___050053_)))))));
    vlSelf->wasmetal_core__DOT___050061_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050058_))));
    vlSelf->wasmetal_core__DOT___049372_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049363_))));
    vlSelf->wasmetal_core__DOT___049799_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049493_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049505_))));
    vlSelf->wasmetal_core__DOT___049507_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049505_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049504_))));
    vlSelf->wasmetal_core__DOT___049707_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049706_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049705_))));
    vlSelf->wasmetal_core__DOT___050695_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049700_))));
    vlSelf->wasmetal_core__DOT___049147_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049145_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049144_))));
    vlSelf->wasmetal_core__DOT___049751_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049145_))));
    vlSelf->wasmetal_core__DOT___049888_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049623_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049618_))));
    vlSelf->wasmetal_core__DOT___049625_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049624_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049623_))));
    vlSelf->wasmetal_core__DOT___049860_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049384_))));
    vlSelf->wasmetal_core__DOT___051922_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049765_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051907_)))));
    vlSelf->wasmetal_core__DOT___049753_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049750_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049749_))));
    vlSelf->wasmetal_core__DOT___049709_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049702_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049701_))));
    vlSelf->wasmetal_core__DOT___053108_ = (1U & (0x5cU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xf0faaccU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___049109_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf7ec4412__0))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049111_))));
    vlSelf->wasmetal_core__DOT___049114_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049112_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049111_))));
    vlSelf->wasmetal_core__DOT___051417_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051414_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051413_))));
    vlSelf->wasmetal_core__DOT___049288_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049269_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049268_))));
    vlSelf->wasmetal_core__DOT___051422_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049209_))))));
    vlSelf->wasmetal_core__DOT___051408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049326_))))));
    vlSelf->wasmetal_core__DOT___049496_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049487_))));
    vlSelf->wasmetal_core__DOT___051995_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050609_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050599_))));
    vlSelf->wasmetal_core__DOT___049463_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049461_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049460_))));
    vlSelf->wasmetal_core__DOT___053871_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053534_))));
    vlSelf->wasmetal_core__DOT___051432_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051429_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051428_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051427_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051426_)))))));
    vlSelf->wasmetal_core__DOT___051920_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051919_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051918_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h28b05b3d__0))))));
    vlSelf->wasmetal_core__DOT___050544_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050542_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h10726817__0)))));
    vlSelf->wasmetal_core__DOT___051992_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051989_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050730_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050689_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050688_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050675_)))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xff00aaaaccccf0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050788_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050674_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7f4141b2__0)))))))))))));
    vlSelf->wasmetal_core__DOT___050678_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050675_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050674_))));
    vlSelf->wasmetal_core__DOT___051466_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049857_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049364_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049363_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___049370_)))))));
    vlSelf->wasmetal_core__DOT___049859_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049858_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049857_))));
    vlSelf->wasmetal_core__DOT___049495_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049493_))));
    vlSelf->wasmetal_core__DOT___049800_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049494_))));
    vlSelf->wasmetal_core__DOT___049708_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049704_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049703_))));
    vlSelf->wasmetal_core__DOT___050696_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049703_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049706_))));
    vlSelf->wasmetal_core__DOT___049889_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049621_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049624_))));
    vlSelf->wasmetal_core__DOT___049626_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049622_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049621_))));
    vlSelf->wasmetal_core__DOT___049752_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049111_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049086_))));
    vlSelf->wasmetal_core__DOT___049113_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049086_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049085_))));
    vlSelf->wasmetal_core__DOT___049846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049845_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049844_))));
    vlSelf->wasmetal_core__DOT___051474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049844_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049044_))));
    vlSelf->__VdfgTmp_h2966b870__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___050598_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___050585_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___049023_)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___050601_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050598_))));
    vlSelf->wasmetal_core__DOT___052624_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050527_))));
    vlSelf->wasmetal_core__DOT___050529_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050526_))));
    vlSelf->wasmetal_core__DOT___051591_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051410_))));
    vlSelf->wasmetal_core__DOT___051412_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051410_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051402_))));
    vlSelf->wasmetal_core__DOT___049602_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049588_))));
    vlSelf->wasmetal_core__DOT___050712_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049588_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049689_))));
    vlSelf->wasmetal_core__DOT___049776_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049460_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049455_))));
    vlSelf->wasmetal_core__DOT___049462_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049454_))));
    vlSelf->wasmetal_core__DOT___049732_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049268_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049286_))));
    vlSelf->wasmetal_core__DOT___049287_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049285_))));
    vlSelf->wasmetal_core__DOT___049660_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049656_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049655_))));
    vlSelf->wasmetal_core__DOT___049870_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049655_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049658_))));
    vlSelf->wasmetal_core__DOT___051766_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049522_))))));
    vlSelf->wasmetal_core__DOT___051771_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049476_))))));
    vlSelf->wasmetal_core__DOT___051782_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049634_))))));
    vlSelf->wasmetal_core__DOT___051797_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049716_))))));
    vlSelf->wasmetal_core__DOT___053392_ = (1U & (IData)(
                                                         (0xaaccf000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053388_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he62a830e__0)))))));
    vlSelf->wasmetal_core__DOT___049627_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049620_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049619_))));
    vlSelf->wasmetal_core__DOT___050803_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049757_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))))))));
    vlSelf->wasmetal_core__DOT___050808_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049736_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049321_))))))))));
    vlSelf->wasmetal_core__DOT___050863_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> 
                                                            (1U 
                                                             & (0x35U 
                                                                >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049805_))));
    vlSelf->wasmetal_core__DOT___050815_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___049464_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049780_))));
    vlSelf->wasmetal_core__DOT___050822_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049630_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049893_))));
    vlSelf->wasmetal_core__DOT___050835_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049545_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049873_))));
    vlSelf->wasmetal_core__DOT___050872_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049714_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050701_))));
    vlSelf->wasmetal_core__DOT___050877_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049684_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050716_))));
    vlSelf->wasmetal_core__DOT___049210_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049209_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049208_))));
    vlSelf->wasmetal_core__DOT___049327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049325_))));
    vlSelf->wasmetal_core__DOT___049523_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049521_))));
    vlSelf->wasmetal_core__DOT___051865_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049521_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xccaaf000U 
                                                         >> 
                                                         ((4U 
                                                           & ((0xcaU 
                                                               >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((0xacU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xacU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))))))));
    vlSelf->wasmetal_core__DOT___049479_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049476_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049475_))));
    vlSelf->wasmetal_core__DOT___049635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049633_))));
    vlSelf->wasmetal_core__DOT___049668_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049665_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049664_))));
    vlSelf->wasmetal_core__DOT___049717_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049715_))));
    vlSelf->wasmetal_core__DOT___049692_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049685_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049603_))));
    vlSelf->wasmetal_core__DOT___049759_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049757_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049756_))));
    vlSelf->wasmetal_core__DOT___049738_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049736_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049735_))));
    vlSelf->wasmetal_core__DOT___049806_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049804_))));
    vlSelf->wasmetal_core__DOT___049781_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049779_))));
    vlSelf->wasmetal_core__DOT___050896_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050895_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0)))))));
    vlSelf->wasmetal_core__DOT___049894_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049893_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049892_))));
    vlSelf->wasmetal_core__DOT___049874_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049873_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049872_))));
    vlSelf->wasmetal_core__DOT___050702_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050701_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050700_))));
    vlSelf->wasmetal_core__DOT___065164_ = (1U & (IData)(
                                                         (0xf0f00005533ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051486_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051485_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051484_)))))));
    vlSelf->wasmetal_core__DOT___050717_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050715_))));
    vlSelf->wasmetal_core__DOT___049538_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h454dd727__0))));
    vlSelf->wasmetal_core__DOT___051843_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051467_))));
    vlSelf->wasmetal_core__DOT___053119_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h444aee6e__0))));
    vlSelf->wasmetal_core__DOT___049722_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049721_))));
    vlSelf->wasmetal_core__DOT___052633_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051691_))));
    vlSelf->wasmetal_core__DOT___051809_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051348_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___051690_)))))));
    vlSelf->wasmetal_core__DOT___051857_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051583_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___051689_)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___051752_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051058_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051751_)))));
    vlSelf->wasmetal_core__DOT___053518_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051720_))));
    vlSelf->wasmetal_core__DOT___051721_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049890_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051720_)))));
    vlSelf->wasmetal_core__DOT___051834_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051522_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___051719_)))))));
    vlSelf->wasmetal_core__DOT___051780_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051290_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051779_)))));
    vlSelf->wasmetal_core__DOT___051880_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051632_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((4U 
                                                                           >> 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                                            << 1U)) 
                                                                          << 1U))) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___052718_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051707_))));
    vlSelf->wasmetal_core__DOT___051708_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049801_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051707_)))));
    vlSelf->wasmetal_core__DOT___051817_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051368_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___051706_)))))));
    vlSelf->wasmetal_core__DOT___051764_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051115_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051763_)))));
    vlSelf->wasmetal_core__DOT___051866_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051615_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((1U 
                                                                      >> 
                                                                      (1U 
                                                                       & (0x53U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hb6137419__0)))) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___051889_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051652_))));
    vlSelf->wasmetal_core__DOT___051795_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051328_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___051651_)))))));
    vlSelf->wasmetal_core__DOT___051849_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051551_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___051650_)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___051742_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050697_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051741_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128283___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030679_)))));
    vlSelf->wasmetal_core__DOT___048132_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048130_))));
    vlSelf->wasmetal_core__DOT___047994_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x77707770777ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___042672_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042576_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___042642_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___042534_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___042652_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___042554_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047992_))));
    vlSelf->wasmetal_core__DOT___048125_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128723___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((0xff7f7fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134178___O) 
                                                                         << 2U)) 
                                                                     | ((4U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134191___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h08bc6edf__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128725___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017176_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128723___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xff7f7fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134178___O) 
                                                                         << 3U)) 
                                                                     | ((4U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134191___O) 
                                                                            << 2U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h08bc6edf__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128725___O))))))));
    vlSelf->wasmetal_core__DOT___017171_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xffff07770777ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O) 
                                                                                >> 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O) 
                                                                                >> 3U))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___017186_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xffff07770777ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O) 
                                                                                >> 2U))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017924_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x777U 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O))))))));
    vlSelf->wasmetal_core__DOT___017185_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((0x777U 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O) 
                                                                              >> 1U)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02ewide = (1U 
                                                & (0xff4f4fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x77770007U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h4702c863__0))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xfffdf3ffffffffffULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048210_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003033_)))))))))))))));
    vlSelf->wasmetal_core__DOT___053477_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053426_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050456_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x44444447U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___053422_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053421_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___052947_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___052990_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___047995_))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xfa673738U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h673d32f0__0))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053423_)))))));
    vlSelf->wasmetal_core__DOT___032034_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047995_))));
    vlSelf->wasmetal_core__DOT___032033_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047995_))));
    vlSelf->wasmetal_core__DOT___044906_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026480_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026447_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b4__05d));
    wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036757_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h86617c98__0))));
    wasmetal_core__DOT____Vcellout___128059___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028314_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028313_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028312_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028311_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028278_)))));
    vlSelf->wasmetal_core__DOT___028282_ = ((IData)(vlSelf->wasmetal_core__DOT___028314_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028249_));
    vlSelf->wasmetal_core__DOT___045478_ = (1U & (IData)(
                                                         (0xfaa0fcc0f000f000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071343_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6ddd7671__0))))))));
    vlSelf->wasmetal_core__DOT___045502_ = (1U & (IData)(
                                                         (0x606006660606600ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070950_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070951_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071343_)))))))));
    vlSelf->wasmetal_core__DOT___045274_ = (1U & (IData)(
                                                         (0xfaa0fcc0f000f000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071406_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6ddd7671__0))))))));
    vlSelf->wasmetal_core__DOT___045298_ = (1U & (IData)(
                                                         (0x606006660606600ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070950_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070951_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071406_)))))))));
    vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026588_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026529_)
            : (IData)(vlSelf->wasmetal_core__DOT___001438_));
    vlSelf->wasmetal_core__DOT___044993_ = ((IData)(vlSelf->wasmetal_core__DOT___045039_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045038_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045036_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045035_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045034_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045033_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045032_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045031_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045030_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045029_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045028_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045027_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045047_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045046_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045045_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045044_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045043_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045042_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045041_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045040_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045037_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045026_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045002_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045013_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045016_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045017_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045018_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045019_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045020_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045021_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045022_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045023_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045003_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045004_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045005_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045006_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045007_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045008_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045009_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045010_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045011_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045012_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045014_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045015_));
    vlSelf->wasmetal_core__DOT____Vcellout___128347___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031359_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031358_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031357_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031356_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031323_)))));
    vlSelf->wasmetal_core__DOT___031327_ = ((IData)(vlSelf->wasmetal_core__DOT___031359_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034318_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034485_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127944___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027366_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027355_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027344_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027333_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027301_ = ((IData)(vlSelf->wasmetal_core__DOT___027366_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b3__05d));
    vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 0x10U) & (IData)(vlSelf->wasmetal_core__DOT___027935_));
    vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x10000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x10U)
                  : (IData)(vlSelf->wasmetal_core__DOT___030470_)));
    vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032871_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027806_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b14__05d));
    vlSelf->wasmetal_core__DOT___065936_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066081_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066276_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066123_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 0x10U) & (IData)(vlSelf->wasmetal_core__DOT___028161_));
    vlSelf->wasmetal_core__DOT____Vcellout___128044___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028093_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028092_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028122_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028121_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028088_)))));
    vlSelf->wasmetal_core__DOT___028061_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028093_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0xbU)));
    vlSelf->wasmetal_core__DOT___044762_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 6U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128316___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                                        << 1U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 0xcU)))))))));
    vlSelf->wasmetal_core__DOT___044774_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 9U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 0xaU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128316___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 0xbU))))))))));
    vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 0x10U)) & (IData)(vlSelf->wasmetal_core__DOT___030952_));
    vlSelf->wasmetal_core__DOT___044807_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070642_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___044795_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070640_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O))))))))));
    vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032679_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    wasmetal_core__DOT___134211___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037189_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h558b9029__0))));
    vlSelf->wasmetal_core__DOT___063525_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063520_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))))))));
    vlSelf->wasmetal_core__DOT___063533_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063528_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063541_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063549_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063544_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128517___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128525___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128602___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128517___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128525___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128602___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128518___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128526___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128603___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128518___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128526___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128603___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026362_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d));
    vlSelf->wasmetal_core__DOT___063401_ = (1U & (0xeeeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053368_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053087_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053096_))))));
    vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128171___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O)) 
            | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___029502_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b7__05d) {
        vlSelf->wasmetal_core__DOT___030683_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
        vlSelf->wasmetal_core__DOT___030718_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030683_ = vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030718_ = wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___062068_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062058_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062057_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___062031_)))))))));
    vlSelf->wasmetal_core__DOT___061946_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061882_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019303_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055510_)))))))));
    vlSelf->wasmetal_core__DOT___062173_ = (1U & (0xfafc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062171_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062157_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061706_)))))));
    vlSelf->wasmetal_core__DOT___061518_ = (1U & (IData)(
                                                         (0xfefffefffeffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061513_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061512_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061511_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061510_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf56802d2__0))))))));
    vlSelf->wasmetal_core__DOT___062182_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062129_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055712_)))))))));
    vlSelf->wasmetal_core__DOT___019292_ = (1U & (0xf40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h058d1256__0))));
    vlSelf->wasmetal_core__DOT___057687_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xf4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048453_))));
    vlSelf->wasmetal_core__DOT___055734_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xf4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___034151_ = ((IData)(vlSelf->wasmetal_core__DOT___034181_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128623___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034181_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034180_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034179_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034178_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->__VdfgTmp_h25073b9c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h249314f5__0)));
    vlSelf->__VdfgTmp_hf1d7bcdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010754_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010753_));
    vlSelf->__VdfgTmp_h304fb1ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___010753_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010754_));
    vlSelf->__VdfgTmp_hb57f307c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010090_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010089_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007798_))));
    vlSelf->wasmetal_core__DOT___056196_ = (1U & (IData)(
                                                         (0xfff88888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010140_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010139_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007731_)))))))))))))))));
    vlSelf->__VdfgTmp_h0b52da3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___009780_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009781_));
    vlSelf->__VdfgTmp_h047929cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___009815_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009814_));
    vlSelf->__VdfgTmp_h9bd5098e__0 = (((IData)(vlSelf->wasmetal_core__DOT___009794_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009795_));
    vlSelf->__VdfgTmp_h831e3e64__0 = (((IData)(vlSelf->wasmetal_core__DOT___009792_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009791_));
    vlSelf->__VdfgTmp_h910334c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009791_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009792_)));
    vlSelf->__VdfgTmp_hcdc85607__0 = (((IData)(vlSelf->wasmetal_core__DOT___010214_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010213_));
    vlSelf->__VdfgTmp_h4965d650__0 = (((IData)(vlSelf->wasmetal_core__DOT___010240_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010239_));
    vlSelf->__VdfgTmp_hb5f0d294__0 = (((IData)(vlSelf->wasmetal_core__DOT___010239_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010240_));
    vlSelf->wasmetal_core__DOT___056187_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010319_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010320_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                              & (IData)(
                                                                        (0xf0f555500ff3333ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hba71a165__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                                   ? 
                                                                  (0x305U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___007731_)))))
                                                                   : 
                                                                  (0x305U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb9c84dcf__0))))))))));
    vlSelf->wasmetal_core__DOT___070514_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010319_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010320_)))));
    vlSelf->__VdfgTmp_h95b8e055__0 = (((IData)(vlSelf->wasmetal_core__DOT___010320_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010319_));
    vlSelf->__VdfgTmp_hd7e7c41d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010251_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010250_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010253_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010252_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010250_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___010251_)))))))));
    vlSelf->__VdfgTmp_hfd1fc688__0 = (((IData)(vlSelf->wasmetal_core__DOT___010349_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010348_));
    vlSelf->__VdfgTmp_h35b20f8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010279_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010278_));
    vlSelf->__VdfgTmp_h1f90c42a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010288_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010287_));
    vlSelf->__VdfgTmp_he6780703__0 = (((IData)(vlSelf->wasmetal_core__DOT___009650_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009649_));
    vlSelf->__VdfgTmp_h42c557be__0 = (((IData)(vlSelf->wasmetal_core__DOT___010309_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010308_));
    vlSelf->wasmetal_core__DOT___010553_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2fc9f8d__0))));
    vlSelf->wasmetal_core__DOT___010547_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2fc9f8d__0))));
    vlSelf->__VdfgTmp_hf8199cb0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h143507db__0));
    vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__ 
        = (1U & (IData)((0xccccaaaa000f000fULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfff00000eeee0000ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hbc09f2bb__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfff00000eeeeULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053790_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053789_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha85bab6c__0))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xf0f555500ff3333ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d6eeee4__0))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0f555500ff3333ULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd5b4e54d__0))))))))))));
    vlSelf->wasmetal_core__DOT___055276_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053789_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053790_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha85bab6c__0))))));
    vlSelf->__VdfgTmp_h479e0c47__0 = (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    if (vlSelf->wasmetal_core__DOT___007235_) {
        vlSelf->wasmetal_core__DOT___011003_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007663_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007662_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb4fb5a01__0))))));
        if (vlSelf->wasmetal_core__DOT___007234_) {
            vlSelf->wasmetal_core__DOT___010957_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h8d86a2a9__0)));
            vlSelf->wasmetal_core__DOT___010988_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h0761bbb4__0)));
            vlSelf->wasmetal_core__DOT___010982_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h66742b2d__0)));
            vlSelf->wasmetal_core__DOT___010193_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h939caa69__0)));
            vlSelf->wasmetal_core__DOT___009784_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h29ef1e90__0))));
            vlSelf->wasmetal_core__DOT___009796_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h7619e45d__0))));
            vlSelf->wasmetal_core__DOT___010231_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hd4d40399__0)));
            vlSelf->wasmetal_core__DOT___010977_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h7e54e6f3__0))));
            vlSelf->wasmetal_core__DOT___054855_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hf2283ef8__0)));
        } else {
            vlSelf->wasmetal_core__DOT___010957_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___007628_));
            vlSelf->wasmetal_core__DOT___010988_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007566_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007565_))));
            vlSelf->wasmetal_core__DOT___010982_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007545_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007544_))));
            vlSelf->wasmetal_core__DOT___010193_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007525_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007524_))));
            vlSelf->wasmetal_core__DOT___009784_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h2aa6a52e__0))));
            vlSelf->wasmetal_core__DOT___009796_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h009b2026__0))));
            vlSelf->wasmetal_core__DOT___010231_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hae0eb281__0)));
            vlSelf->wasmetal_core__DOT___010977_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h0fc2ac4f__0))));
            vlSelf->wasmetal_core__DOT___054855_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007641_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007640_))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___011003_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007664_))));
        vlSelf->wasmetal_core__DOT___010957_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007624_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007623_)))));
        vlSelf->wasmetal_core__DOT___010988_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007570_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007569_)))));
        vlSelf->wasmetal_core__DOT___010982_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007549_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007548_)))));
        vlSelf->wasmetal_core__DOT___010193_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007528_)))));
        vlSelf->wasmetal_core__DOT___009784_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007740_)))));
        vlSelf->wasmetal_core__DOT___009796_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007703_)))));
        vlSelf->wasmetal_core__DOT___010231_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007505_)))));
        vlSelf->wasmetal_core__DOT___010977_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007755_)))));
        vlSelf->wasmetal_core__DOT___054855_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007644_)))));
    }
    if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010298_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007431_)))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009818_))))));
        vlSelf->wasmetal_core__DOT___010966_ = (1U 
                                                & (0xf0f0f0feU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010964_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h047929cf__0))))));
        vlSelf->wasmetal_core__DOT___010166_ = (1U 
                                                & (0xf0f0f0feU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010165_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h047929cf__0))))));
        vlSelf->wasmetal_core__DOT___009807_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h047929cf__0))));
        vlSelf->wasmetal_core__DOT___010196_ = (1U 
                                                & (0xf0f0f0eU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010216_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcdc85607__0))))));
        vlSelf->wasmetal_core__DOT___056172_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___009784_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___008974_))
                                                    : 
                                                   (0xffff0001U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009782_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009781_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009780_) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xfff00000eeeeULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hcb043302__0)))))))))));
    } else {
        vlSelf->wasmetal_core__DOT___010298_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xf00eeU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007663_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___007662_)))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeee0000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007660_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007661_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h86442115__0))))))))))));
        vlSelf->wasmetal_core__DOT___010966_ = (1U 
                                                & (0xcccdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010964_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010164_))))));
        vlSelf->wasmetal_core__DOT___010166_ = (1U 
                                                & (0xcccdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010165_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010164_))))));
        vlSelf->wasmetal_core__DOT___009807_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0x10U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h5812bf47__0))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf0f0aaaaff00ccccULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007484_))))))))))))));
        vlSelf->wasmetal_core__DOT___010196_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010216_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010215_))))));
        vlSelf->wasmetal_core__DOT___056172_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___009784_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___008974_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009783_)))));
    }
    vlSelf->__VdfgTmp_hdea69a06__0 = ((2U & ((IData)(
                                                     (0xf0f0ccccff00aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___007433_)))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010594_));
    vlSelf->wasmetal_core__DOT___010361_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007589_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007590_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3856dbf8__0))))))));
    vlSelf->wasmetal_core__DOT___010151_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007590_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007589_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3856dbf8__0))))));
    vlSelf->__VdfgTmp_h0073f5c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he9e11b30__0));
    vlSelf->wasmetal_core__DOT___010869_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007623_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007624_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8d86a2a9__0))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                 & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                     ? (IData)((0xff0fff0fff55ff33ULL 
                                >> (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                     << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                << 4U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___007824_) 
                                                   << 3U) 
                                                  | ((4U 
                                                      & ((IData)(
                                                                 (0xf0f555500ff3333ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h447558a7__0))))))) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007628_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8d86a2a9__0))))))))))
                     : (2U >> (IData)(vlSelf->wasmetal_core__DOT___007824_)))));
    vlSelf->wasmetal_core__DOT___010336_ = (1U & (0x1111fff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010333_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010331_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010330_)))))));
    vlSelf->wasmetal_core__DOT___033416_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010331_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010330_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010332_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010333_)))))));
    vlSelf->wasmetal_core__DOT___009808_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xa0c0000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hb53fd6c1__0))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h973345c0__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007603_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007604_))))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h973345c0__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054852_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054851_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___054850_)))))));
    vlSelf->wasmetal_core__DOT___010141_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007603_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h37a4ed19__0))))));
    vlSelf->wasmetal_core__DOT___010322_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h37a4ed19__0))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007589_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007590_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff00000eeee0000ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h496bba40__0))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007587_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007588_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007585_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007586_)))))))))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054806_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054805_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h496bba40__0))))))))));
    vlSelf->wasmetal_core__DOT___056195_ = (1U & (IData)(
                                                         (0xfeeef000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054928_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010150_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x11110000fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8a3dc284__0))))))))))))));
    vlSelf->wasmetal_core__DOT___054929_ = (1U & (IData)(
                                                         (0xfff0fff0aaaaccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010358_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010359_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054928_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1111fff0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h8a3dc284__0))))))))))));
    vlSelf->wasmetal_core__DOT___010887_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007570_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0761bbb4__0))))))));
    vlSelf->wasmetal_core__DOT___011719_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010444_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d))))));
    vlSelf->__VdfgTmp_h6df87d4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010351_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010350_)));
    vlSelf->wasmetal_core__DOT___010881_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007548_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007549_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h66742b2d__0))))))));
    vlSelf->wasmetal_core__DOT___010715_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf37b3ae8__0))))))));
    vlSelf->__VdfgTmp_ha8fd39d5__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d));
    vlSelf->wasmetal_core__DOT___010374_ = (1U & (0x1111fff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010371_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010370_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010369_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010368_)))))));
    vlSelf->wasmetal_core__DOT___010045_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010369_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010368_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010370_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010371_)))))));
    vlSelf->__VdfgTmp_he96324c1__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d));
    vlSelf->__VdfgTmp_hedc6bc1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h3c2b613a__0)))));
    vlSelf->__VdfgTmp_h18547ac4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010540_));
    vlSelf->wasmetal_core__DOT___056182_ = (1U & (IData)(
                                                         (0xf00001111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h939caa69__0))))))));
    vlSelf->wasmetal_core__DOT___010893_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h939caa69__0))))))));
    vlSelf->wasmetal_core__DOT___010338_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054797_) 
                                                       << 3U) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                           & (IData)(
                                                                     (0xf0f0aaaaff00ccccULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7b1353df__0)))) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                                  ? 
                                                                 (0xc0aU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf8957689__0))
                                                                  : 
                                                                 (0xc0aU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3a577ede__0))) 
                                                                << 1U)) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               & (IData)(vlSelf->wasmetal_core__DOT___007250_))))))));
    vlSelf->__VdfgTmp_h627ddd53__0 = (((IData)(vlSelf->wasmetal_core__DOT___007740_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h29ef1e90__0));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d 
        = (1U & (IData)((0x5500cc000f0000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010558_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h79c46d44__0))))))));
    vlSelf->__VdfgTmp_he89f377b__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcb043302__0))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                ? (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc98b4d16__0))))
                                                : (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h161030dd__0)))))));
    vlSelf->__VdfgTmp_hf222e899__0 = (((IData)(vlSelf->wasmetal_core__DOT___009783_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeeeULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcb043302__0))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009782_)));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___011470_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010773_)));
        vlSelf->wasmetal_core__DOT___012124_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010559_)));
        vlSelf->wasmetal_core__DOT___012027_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d)));
        vlSelf->wasmetal_core__DOT___012123_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010568_)));
        vlSelf->wasmetal_core__DOT___012131_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011014_)));
        vlSelf->wasmetal_core__DOT___011868_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011011_)));
        vlSelf->wasmetal_core__DOT___012125_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010552_)));
        vlSelf->wasmetal_core__DOT___011390_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010741_)));
        vlSelf->wasmetal_core__DOT___011869_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011004_)));
        vlSelf->wasmetal_core__DOT___056376_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010868_)));
        vlSelf->wasmetal_core__DOT___056552_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d))));
        vlSelf->wasmetal_core__DOT___012178_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he2e0905c__0)))));
        vlSelf->wasmetal_core__DOT___056379_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010886_)));
        vlSelf->wasmetal_core__DOT___056380_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010880_)));
        vlSelf->wasmetal_core__DOT___011660_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d))));
        vlSelf->wasmetal_core__DOT___011858_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010892_)));
        vlSelf->wasmetal_core__DOT___013095_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010961_)));
    } else {
        vlSelf->wasmetal_core__DOT___011470_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1110fffU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & ((0xf011U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007677_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___007678_))))) 
                                                                 << 2U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h724ed7d2__0)))))));
        vlSelf->wasmetal_core__DOT___012124_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                    ? 
                                                   (0xfaf3U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h79c46d44__0))))
                                                    : 
                                                   (0xefU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___010558_))))));
        vlSelf->wasmetal_core__DOT___012027_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010386_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcab0eaad__0))))));
        vlSelf->wasmetal_core__DOT___012123_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010569_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hce8e9d12__0))))));
        vlSelf->wasmetal_core__DOT___012131_ = (1U 
                                                & (0xffffffe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h831e3e64__0))))));
        vlSelf->wasmetal_core__DOT___011868_ = (1U 
                                                & (0xffeeff0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010215_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcdc85607__0))))));
        vlSelf->wasmetal_core__DOT___012125_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010553_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h25073b9c__0))));
        vlSelf->wasmetal_core__DOT___011390_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf8199cb0__0))));
        vlSelf->wasmetal_core__DOT___011869_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                    ? 
                                                   (0xff35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hdea69a06__0))))
                                                    : 
                                                   (0xdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011003_)))));
        vlSelf->wasmetal_core__DOT___056376_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010869_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf6bbf4d1__0))))));
        vlSelf->wasmetal_core__DOT___056552_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010336_)));
        vlSelf->wasmetal_core__DOT___012178_ = (1U 
                                                & (0xa0cU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d))))));
        vlSelf->wasmetal_core__DOT___056379_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010887_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h25286e3d__0))))));
        vlSelf->wasmetal_core__DOT___056380_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010881_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h41c2ec0e__0))))));
        vlSelf->wasmetal_core__DOT___011660_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010374_)));
        vlSelf->wasmetal_core__DOT___011858_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010893_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hde094a0f__0))))));
        vlSelf->wasmetal_core__DOT___013095_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hf222e899__0)))));
    }
    vlSelf->__VdfgTmp_h1a6962a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009783_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009782_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hcb043302__0)))))));
    vlSelf->__VdfgTmp_h8d891945__0 = ((8U & ((0xff550f33U 
                                              >> (IData)(vlSelf->__VdfgTmp_h544074d8__0)) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                          << 2U) | 
                                         ((2U & ((IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h2cfd74cc__0))) 
                                                 << 1U)) 
                                          | (IData)(vlSelf->wasmetal_core__DOT___010110_))));
    if (vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) {
        vlSelf->wasmetal_core__DOT___012044_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010132_)));
        vlSelf->wasmetal_core__DOT___012294_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010091_)));
        vlSelf->wasmetal_core__DOT___012043_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010113_)));
    } else if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___012044_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010132_)));
        vlSelf->wasmetal_core__DOT___012294_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010091_)));
        vlSelf->wasmetal_core__DOT___012043_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010113_)));
    } else {
        vlSelf->wasmetal_core__DOT___012044_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010132_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h143507db__0))))));
        vlSelf->wasmetal_core__DOT___012294_ = (1U 
                                                & (IData)(
                                                          (0x7000000ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010091_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hb57f307c__0))))));
        vlSelf->wasmetal_core__DOT___012043_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010113_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h8d891945__0))))));
    }
    vlSelf->__VdfgTmp_h8e4b209e__0 = ((2U & ((IData)(
                                                     (0xfff00000eeeeULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2cfd74cc__0))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010269_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010272_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010271_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010269_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (IData)(
                                                                        (0xfff00000eeeeULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2cfd74cc__0))))))))))));
    vlSelf->wasmetal_core__DOT___009832_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010582_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007834_)))))))));
    vlSelf->__VdfgTmp_hc5fe5af8__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)(vlSelf->wasmetal_core__DOT___007834_)) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010582_));
    vlSelf->__VdfgTmp_h9e2ff648__0 = (((IData)(vlSelf->wasmetal_core__DOT___007703_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7619e45d__0));
    vlSelf->__VdfgTmp_hd544aedd__0 = (((IData)(vlSelf->wasmetal_core__DOT___010589_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010588_));
    vlSelf->__VdfgTmp_h20b0bc38__0 = (((IData)(vlSelf->wasmetal_core__DOT___010588_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010589_));
    vlSelf->__VdfgTmp_he4fe919e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010760_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                     << 2U) 
                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___007798_)) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010089_)))));
    vlSelf->__VdfgTmp_h00532677__0 = (((IData)(vlSelf->wasmetal_core__DOT___010290_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010289_));
    vlSelf->__VdfgTmp_h0549af28__0 = (((IData)(vlSelf->wasmetal_core__DOT___010290_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010289_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010287_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010288_))));
    vlSelf->wasmetal_core__DOT___012029_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010490_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011713_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h63abc8ec__0)))))))));
    vlSelf->wasmetal_core__DOT___009830_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011713_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011712_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf00001111ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007677_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007678_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd5802a9c__0))))))))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___011713_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h63abc8ec__0))))));
    vlSelf->__VdfgTmp_hb67d963d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010102_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h724ed7d2__0)));
    vlSelf->__VdfgTmp_h15c467ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___010215_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010213_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010214_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d 
        = (1U & (IData)((0x11110000000fULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h86da9f86__0))))));
    vlSelf->__VdfgTmp_hdc4dab2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010780_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xf00001111ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007661_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007660_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h86442115__0))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___009818_))));
    vlSelf->__VdfgTmp_hfc864313__0 = (((IData)(vlSelf->wasmetal_core__DOT___010386_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xf00001111ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007662_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007663_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hb4fb5a01__0))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010594_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010386_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcab0eaad__0))))));
    vlSelf->__VdfgTmp_hd25df3ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___011622_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(
                                                                (0xfff00000eeee0000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2966a39c__0))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_he26aa999__0)))))));
    vlSelf->__VdfgTmp_h4e8951c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___054157_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_he26aa999__0))) 
                                                     << 2U)) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                      & (IData)(
                                                                (0xf0f0aaaaff00ccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007431_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___007430_))))))))) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h2966a39c__0)))))));
    vlSelf->__VdfgTmp_h02606b30__0 = ((2U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hd163f969__0))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010229_));
    vlSelf->wasmetal_core__DOT___009842_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056201_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf00001111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007510_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007509_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae0eb281__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010229_)))))))));
    vlSelf->wasmetal_core__DOT___010172_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007505_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd4d40399__0))))));
    vlSelf->wasmetal_core__DOT___054743_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007505_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd4d40399__0))))))));
    vlSelf->__VdfgTmp_he68aaf0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007755_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7e54e6f3__0));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010569_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hce8e9d12__0))))));
    vlSelf->wasmetal_core__DOT___010875_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf2283ef8__0))))))));
    vlSelf->wasmetal_core__DOT___011520_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010308_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010309_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                              & (IData)(
                                                                        (0xf0f555500ff3333ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h22d02546__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf00001111ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf2283ef8__0))))))))))))));
    vlSelf->__VdfgTmp_hc9e45bda__0 = (((IData)(vlSelf->wasmetal_core__DOT___010472_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->__VdfgTmp_h9c14d25f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010529_));
    vlSelf->__VdfgTmp_h842b3020__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010311_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010310_))));
    vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030120_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d));
    vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030276_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d));
    vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036897_)) 
                 & (0x96U >> (IData)(vlSelf->__VdfgTmp_h79b76beb__0))));
    vlSelf->wasmetal_core__DOT___068795_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067971_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068398_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068792_)))))))));
    vlSelf->wasmetal_core__DOT___068702_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067818_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068289_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068699_)))))))));
    vlSelf->wasmetal_core__DOT___068604_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067733_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068151_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068601_)))))))));
    vlSelf->wasmetal_core__DOT___068850_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___068028_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068422_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068847_)))))))));
    vlSelf->wasmetal_core__DOT___068751_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067905_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068343_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068748_)))))))));
    vlSelf->wasmetal_core__DOT___068654_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067757_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068236_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068651_)))))))));
    vlSelf->wasmetal_core__DOT___068552_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067667_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068100_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068549_)))))))));
    vlSelf->wasmetal_core__DOT___067821_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066641_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067818_))))));
    vlSelf->wasmetal_core__DOT___067735_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066519_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067733_))))));
    vlSelf->wasmetal_core__DOT___068031_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066887_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___068028_))))));
    vlSelf->wasmetal_core__DOT___067759_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066596_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067757_))))));
    vlSelf->wasmetal_core__DOT___067669_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066393_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067667_))))));
    vlSelf->wasmetal_core__DOT___066888_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065407_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066887_)))));
    vlSelf->wasmetal_core__DOT___065427_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065407_))));
    vlSelf->wasmetal_core__DOT___067500_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066263_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067499_)))));
    vlSelf->wasmetal_core__DOT___066288_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066263_))));
    vlSelf->wasmetal_core__DOT___066597_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064893_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066596_)))));
    vlSelf->wasmetal_core__DOT___064913_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064893_))));
    vlSelf->wasmetal_core__DOT___065909_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065892_))));
    vlSelf->wasmetal_core__DOT___067190_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065892_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067189_)))));
    vlSelf->wasmetal_core__DOT___066764_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065178_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066763_)))));
    vlSelf->wasmetal_core__DOT___066088_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066073_))));
    vlSelf->wasmetal_core__DOT___067335_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066073_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067333_)))));
    vlSelf->wasmetal_core__DOT___066394_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064485_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066393_)))));
    vlSelf->wasmetal_core__DOT___064515_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064485_))));
    vlSelf->wasmetal_core__DOT___067071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065694_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067070_)))));
    vlSelf->wasmetal_core__DOT___065711_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065694_))));
    vlSelf->wasmetal_core__DOT___066847_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065294_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066846_)))));
    vlSelf->wasmetal_core__DOT___066141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066119_))));
    vlSelf->wasmetal_core__DOT___067468_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066119_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067450_)))));
    vlSelf->wasmetal_core__DOT___065813_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065796_))));
    vlSelf->wasmetal_core__DOT___067149_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065796_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067148_)))));
    vlSelf->wasmetal_core__DOT___066520_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064726_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066519_)))));
    vlSelf->wasmetal_core__DOT___064747_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064726_))));
    vlSelf->wasmetal_core__DOT___066642_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065073_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066641_)))));
    vlSelf->wasmetal_core__DOT___065083_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065073_))));
    vlSelf->wasmetal_core__DOT___065943_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065928_))));
    vlSelf->wasmetal_core__DOT___067305_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065928_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067303_)))));
    vlSelf->wasmetal_core__DOT___066966_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065598_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066965_)))));
    vlSelf->wasmetal_core__DOT___065623_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065598_))));
    vlSelf->wasmetal_core__DOT___066308_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063863_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066307_)))));
    vlSelf->wasmetal_core__DOT___050658_ = (1U & (0x3f203f3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b24__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049049_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049045_)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                   << 1U)))))))));
    vlSelf->wasmetal_core__DOT___053662_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051543_))));
    vlSelf->wasmetal_core__DOT___051321_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049690_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))));
    vlSelf->wasmetal_core__DOT___051295_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049659_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___053215_ = (1U & (IData)(
                                                         (0xf0f0aa3300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050830_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053212_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f0aaccU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd0aa9c81__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2cac88ff__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053210_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053209_)))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052592_))))))));
    vlSelf->wasmetal_core__DOT___065729_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050857_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x55330f0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051594_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051424_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051429_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051461_))))))));
    vlSelf->wasmetal_core__DOT___051804_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051354_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051461_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050855_))))))));
    vlSelf->wasmetal_core__DOT___066109_ = (1U & (0xa300U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xf0f5533U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053111_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((0xf0f0ccaaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___051919_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd0aa9c81__0)))))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (0xcaU 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h28b05b3d__0))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049243_))))));
    vlSelf->wasmetal_core__DOT___053115_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051586_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053111_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049241_))))))));
    vlSelf->wasmetal_core__DOT___050982_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050899_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had82d15e__0)))));
    vlSelf->wasmetal_core__DOT___050069_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050064_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050061_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050060_))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___049531_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___050048_)))))))))));
    vlSelf->wasmetal_core__DOT___053195_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050061_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050048_))));
    vlSelf->wasmetal_core__DOT___049387_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049371_))));
    vlSelf->wasmetal_core__DOT___050861_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049799_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049798_))));
    vlSelf->wasmetal_core__DOT___049508_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049507_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049506_))));
    vlSelf->wasmetal_core__DOT___051329_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049707_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049702_))));
    vlSelf->wasmetal_core__DOT___050870_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050695_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050694_))));
    vlSelf->wasmetal_core__DOT___049148_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049147_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049146_))));
    vlSelf->wasmetal_core__DOT___050801_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049751_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049750_))));
    vlSelf->wasmetal_core__DOT___050820_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049888_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049887_))));
    vlSelf->wasmetal_core__DOT___050997_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049625_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049620_))));
    vlSelf->wasmetal_core__DOT___053730_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049860_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049721_)))));
    vlSelf->wasmetal_core__DOT___051692_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049753_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051691_)))));
    vlSelf->wasmetal_core__DOT___009538_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049709_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051652_)))));
    vlSelf->wasmetal_core__DOT___051060_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049208_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049114_))));
    vlSelf->wasmetal_core__DOT___051419_ = (1U & (IData)(
                                                         (0xf0f00005533ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051417_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051416_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051415_)))))));
    vlSelf->wasmetal_core__DOT___051045_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049288_))));
    vlSelf->wasmetal_core__DOT___051438_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051423_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051422_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051421_)))))))));
    vlSelf->wasmetal_core__DOT___051420_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051409_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051408_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051407_)))))))));
    vlSelf->wasmetal_core__DOT___050065_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049521_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049496_))));
    vlSelf->wasmetal_core__DOT___051101_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049463_))));
    vlSelf->wasmetal_core__DOT___066797_ = (1U & (IData)(
                                                         (0x55330f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051432_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha128d41e__0)))))));
    vlSelf->wasmetal_core__DOT___051927_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051922_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0f0077U 
                                                                         >> 
                                                                         ((8U 
                                                                           & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049574_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050476_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050475_))))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051594_) 
                                                                              << 2U) 
                                                                             | ((IData)(vlSelf->wasmetal_core__DOT___051425_) 
                                                                                << 1U)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051920_))))))));
    vlSelf->wasmetal_core__DOT___055415_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049768_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051920_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051907_))))))));
    vlSelf->wasmetal_core__DOT___066633_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049901_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050543_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050544_))))))));
    vlSelf->wasmetal_core__DOT___050554_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050546_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049575_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049574_))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049578_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049577_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049576_)))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050544_))))))));
    vlSelf->wasmetal_core__DOT___065828_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050869_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x53U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050731_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050678_))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___050792_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7f4141b2__0)))))))))))));
    vlSelf->wasmetal_core__DOT___050733_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050678_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7f4141b2__0))))));
    vlSelf->wasmetal_core__DOT___049861_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049859_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049372_))));
    vlSelf->wasmetal_core__DOT___049509_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049496_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049495_))));
    vlSelf->wasmetal_core__DOT___051116_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049495_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049507_))));
    vlSelf->wasmetal_core__DOT___049802_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049800_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049799_))));
    vlSelf->wasmetal_core__DOT___050862_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049804_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049800_))));
    vlSelf->wasmetal_core__DOT___049710_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049708_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049707_))));
    vlSelf->wasmetal_core__DOT___050635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049715_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049708_))));
    vlSelf->wasmetal_core__DOT___052603_ = (1U & (0x55ccf0f0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 4U)) 
                                                   | ((4U 
                                                       & ((0x55ccf000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___051647_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___051646_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___049712_)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf0faaccU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___049704_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((0xacU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h97f76463__0)) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & (0xacU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050696_))))));
    vlSelf->wasmetal_core__DOT___050871_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050700_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050696_))));
    vlSelf->wasmetal_core__DOT___050698_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050696_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050695_))));
    vlSelf->wasmetal_core__DOT___049891_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049889_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049888_))));
    vlSelf->wasmetal_core__DOT___050821_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049889_))));
    vlSelf->wasmetal_core__DOT___050979_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049626_))));
    vlSelf->wasmetal_core__DOT___049628_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049626_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049625_))));
    vlSelf->wasmetal_core__DOT___049754_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049752_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049751_))));
    vlSelf->wasmetal_core__DOT___050802_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049756_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049752_))));
    vlSelf->wasmetal_core__DOT___053114_ = (1U & (IData)(
                                                         (0x5555ccccff00f0f0ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053108_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0xaaccf0f0U 
                                                                      >> 
                                                                      ((4U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (1U 
                                                                             & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049152_)))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((0xacU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (0xcaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0)))))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0x5555ccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049204_)))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049113_))))))));
    vlSelf->wasmetal_core__DOT___049149_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049113_))));
    vlSelf->wasmetal_core__DOT___051059_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049113_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049147_))));
    vlSelf->wasmetal_core__DOT___049847_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049045_))));
    vlSelf->wasmetal_core__DOT___053374_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((1U 
                                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049043_)) 
                                                                          << 1U))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051486_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051474_))))))));
    vlSelf->wasmetal_core__DOT___065163_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051474_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049043_))))));
    vlSelf->wasmetal_core__DOT___052000_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2966b870__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050634_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050610_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051995_))))))));
    vlSelf->wasmetal_core__DOT___050639_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050601_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050600_))));
    vlSelf->wasmetal_core__DOT___052629_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3784db21__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050516_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___049001_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052624_))))))));
    vlSelf->wasmetal_core__DOT___053219_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___050528_)) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050530_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050529_))))))));
    vlSelf->wasmetal_core__DOT___050532_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050529_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050528_))));
    vlSelf->wasmetal_core__DOT___051593_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051403_))));
    vlSelf->wasmetal_core__DOT___066105_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((1U 
                                                                           >> (IData)(vlSelf->wasmetal_core__DOT___051401_)) 
                                                                          << 1U))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051417_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051412_))))))));
    vlSelf->wasmetal_core__DOT___051418_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051412_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___051401_))))));
    vlSelf->wasmetal_core__DOT___049691_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049602_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049690_))));
    vlSelf->wasmetal_core__DOT___049686_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049603_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049602_))));
    vlSelf->wasmetal_core__DOT___050713_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050712_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049688_))))));
    vlSelf->wasmetal_core__DOT___050876_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050715_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050712_))));
    vlSelf->wasmetal_core__DOT___049777_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049776_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049775_))));
    vlSelf->wasmetal_core__DOT___050814_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049779_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049776_))));
    vlSelf->wasmetal_core__DOT___051100_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049462_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___049447_)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___049478_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049463_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049462_))));
    vlSelf->wasmetal_core__DOT___049733_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049732_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049731_))));
    vlSelf->wasmetal_core__DOT___050807_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049735_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049732_))));
    vlSelf->wasmetal_core__DOT___051044_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049287_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049252_))))));
    vlSelf->wasmetal_core__DOT___049290_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049288_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049287_))));
    vlSelf->wasmetal_core__DOT___050784_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049664_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049660_))));
    vlSelf->wasmetal_core__DOT___049667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049660_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049659_))));
    vlSelf->wasmetal_core__DOT___049871_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049870_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049869_))));
    vlSelf->wasmetal_core__DOT___050834_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049872_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049870_))));
    vlSelf->wasmetal_core__DOT___051633_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049627_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051632_)))));
    vlSelf->wasmetal_core__DOT___050805_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050803_))));
    vlSelf->wasmetal_core__DOT___050865_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050863_))));
    vlSelf->wasmetal_core__DOT___050817_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050815_))));
    vlSelf->wasmetal_core__DOT___050837_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050835_))));
    vlSelf->wasmetal_core__DOT___050874_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050872_))));
    vlSelf->wasmetal_core__DOT___049212_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049210_))));
    vlSelf->wasmetal_core__DOT___049329_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049327_))));
    vlSelf->wasmetal_core__DOT___051867_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051865_))));
    vlSelf->wasmetal_core__DOT___053193_ = (1U & (0xac00U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051865_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xaaccf0f0U 
                                                            >> 
                                                            ((4U 
                                                              & ((IData)(
                                                                         (0x5555cccc0f0fff00ULL 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049485_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfc74b95b__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049483_)))))) 
                                                                 << 2U)) 
                                                             | ((2U 
                                                                 & ((0xf0faaccU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___049491_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc8d2269b__0))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xaaaaccccf0f0ff00ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___049077_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___049082_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3b672e02__0))))))))))))));
    vlSelf->wasmetal_core__DOT___049637_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049635_))));
    vlSelf->wasmetal_core__DOT___009497_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xbfff0000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055066_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049668_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xff55ccf0U 
                                                               >> 
                                                               ((0x10U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                    << 4U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052624_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h3784db21__0))))))))));
    vlSelf->wasmetal_core__DOT___049719_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049717_))));
    vlSelf->wasmetal_core__DOT___049694_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049692_))));
    vlSelf->wasmetal_core__DOT___049761_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049759_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> 
                                                                (1U 
                                                                 & (8U 
                                                                    >> 
                                                                    (1U 
                                                                     & (8U 
                                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049152_)))))))))))));
    vlSelf->wasmetal_core__DOT___049740_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049738_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> 
                                                                (1U 
                                                                 & (8U 
                                                                    >> 
                                                                    (1U 
                                                                     & (8U 
                                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049321_)))))))))))));
    vlSelf->wasmetal_core__DOT___049809_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> 
                                                                   (1U 
                                                                    & (0x35U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049806_)))));
    vlSelf->wasmetal_core__DOT___049784_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___049464_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049781_)))));
    vlSelf->wasmetal_core__DOT___049896_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049630_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049894_)))));
    vlSelf->wasmetal_core__DOT___049877_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049545_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049874_)))));
    vlSelf->wasmetal_core__DOT___050705_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049714_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050702_)))));
    vlSelf->wasmetal_core__DOT___050720_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049684_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050717_)))));
    vlSelf->wasmetal_core__DOT___053836_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051834_))));
    vlSelf->wasmetal_core__DOT___053832_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051817_))));
    vlSelf->wasmetal_core__DOT___053848_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051866_))));
    vlSelf->wasmetal_core__DOT___053822_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051795_))));
    vlSelf->wasmetal_core__DOT___053840_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051849_))));
    vlSelf->wasmetal_core__DOT___053800_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051742_))));
    vlSelf->wasmetal_core__DOT___063492_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___063500_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___063508_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___063516_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029608_));
    vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030683_));
    vlSelf->wasmetal_core__DOT___058549_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048132_))));
    vlSelf->wasmetal_core__DOT___018306_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048132_))));
    vlSelf->wasmetal_core__DOT___018178_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048132_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048131_))));
    vlSelf->wasmetal_core__DOT___063439_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->__VdfgTmp_h2a482fa4__0 = (((IData)(vlSelf->wasmetal_core__DOT___047994_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048486_));
    vlSelf->wasmetal_core__DOT___048115_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047994_))));
    vlSelf->wasmetal_core__DOT___047996_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047994_))));
    vlSelf->wasmetal_core__DOT___048397_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047994_))));
    vlSelf->wasmetal_core__DOT___048128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048125_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017176_))));
    vlSelf->__VdfgTmp_h8bd952af__0 = (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017186_));
    vlSelf->__VdfgTmp_he1590a3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017185_));
    vlSelf->__VdfgTmp_h10c9b581__0 = (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017924_));
    vlSelf->wasmetal_core__DOT___019044_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018382_))));
    vlSelf->wasmetal_core__DOT___053481_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053477_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053476_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052994_)))))));
    vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032033_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026481_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134153___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036758_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036757_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036787_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036786_)))) 
           ^ (((IData)(wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036753_)))));
    vlSelf->wasmetal_core__DOT___036726_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036758_)
                                                   ? (IData)(wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7b2f5a0d__0))));
    vlSelf->wasmetal_core__DOT___063120_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128059___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063126_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128059___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063132_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128059___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063138_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128059___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028315_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028282_)
            : (IData)(vlSelf->wasmetal_core__DOT___028250_));
    vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026589_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001444_));
    vlSelf->wasmetal_core__DOT___052701_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044993_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052648_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___045061_)))));
    vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031360_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031327_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034319_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034486_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___027472_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b3__05d))));
    vlSelf->wasmetal_core__DOT___027471_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b2__05d))));
    vlSelf->wasmetal_core__DOT___027470_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b1__05d))));
    vlSelf->wasmetal_core__DOT___027469_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b0__05d))));
    vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027377_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027301_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b4__05d));
    vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 0x11U) & (IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x20000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x11U)
                  : (IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128485___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032872_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032871_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032870_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032869_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032836_)))));
    vlSelf->wasmetal_core__DOT___032840_ = ((IData)(vlSelf->wasmetal_core__DOT___032872_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128013___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027807_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027806_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027805_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027804_)))) 
           ^ (((IData)(wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027771_)))));
    vlSelf->wasmetal_core__DOT___027775_ = ((IData)(vlSelf->wasmetal_core__DOT___027807_)
                                             ? (IData)(wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b15__05d));
    vlSelf->wasmetal_core__DOT___065939_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065936_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xbU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066084_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066081_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xcU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066278_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066276_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xeU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066126_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066123_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xdU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 0x11U) & (IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028094_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028061_)
                  : (vlSelf->insn_x >> 0xcU)));
    vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 0x11U)) & (IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128469___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032680_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032679_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_haf0d31b4__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032644_)))));
    vlSelf->wasmetal_core__DOT___032648_ = ((IData)(vlSelf->wasmetal_core__DOT___032680_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134211___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037190_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037189_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037188_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037187_)))) 
           ^ (((IData)(wasmetal_core__DOT___134211___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037155_)))));
    vlSelf->wasmetal_core__DOT___037159_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037190_)
                                                   ? (IData)(wasmetal_core__DOT___134211___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h54e5e4c4__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127845___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026363_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026362_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026361_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026360_)))) 
           ^ (((IData)(wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026327_)))));
    vlSelf->wasmetal_core__DOT___026331_ = ((IData)(vlSelf->wasmetal_core__DOT___026363_)
                                             ? (IData)(wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128291___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030714_)))));
    vlSelf->wasmetal_core__DOT___061662_ = (1U & (IData)(
                                                         (0xc0fd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061518_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061517_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048458_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf56802d2__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061510_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha1796962__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048414_)))))))));
    vlSelf->wasmetal_core__DOT___039366_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019277_)))));
    vlSelf->wasmetal_core__DOT___011157_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011740_))));
    vlSelf->__VdfgTmp_h394cead1__0 = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                             << 3U)) 
                                      | (7U & (~ (7U 
                                                  & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                     >> 1U)))));
    vlSelf->__VdfgTmp_h46d848cb__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010077_));
    vlSelf->wasmetal_core__DOT___012929_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010378_))));
    vlSelf->wasmetal_core__DOT___056504_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O)))));
    vlSelf->wasmetal_core__DOT___056535_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___011976_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___009681_ = (1U & (0x347U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___056191_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb57f307c__0))))));
    vlSelf->__VdfgTmp_h882f8f15__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010164_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h047929cf__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d 
        = (1U & (0x1fU >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                            << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h910334c5__0)))));
    vlSelf->__VdfgTmp_ha8472195__0 = (((IData)(vlSelf->wasmetal_core__DOT___056187_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056425_));
    vlSelf->__VdfgTmp_hc2d8d129__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h95b8e055__0)));
    vlSelf->__VdfgTmp_h7edccd87__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd7e7c41d__0));
    vlSelf->__VdfgTmp_h14ad002b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfd1fc688__0));
    vlSelf->wasmetal_core__DOT___033390_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010351_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010350_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfd1fc688__0))))));
    vlSelf->__VdfgTmp_h9c968075__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h35b20f8b__0));
    vlSelf->__VdfgTmp_h7ffc48a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h42c557be__0)));
    vlSelf->wasmetal_core__DOT___010044_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010311_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010310_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h42c557be__0))))));
    vlSelf->wasmetal_core__DOT___012992_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010518_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010553_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h25073b9c__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010553_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h249314f5__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_hf8199cb0__0)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055276_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                     << 2U) 
                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                         & (IData)(
                                                                   (0xf0f0aaaaff00ccccULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hd5b4e54d__0)))) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeeeULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hbc09f2bb__0))))))))))));
    vlSelf->__VdfgTmp_h249647a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h470ae9e3__0));
    vlSelf->__VdfgTmp_h73f89ba5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_h2544c7bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011003_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hdea69a06__0)));
    vlSelf->wasmetal_core__DOT___056615_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___011513_)))
                                                         : 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                         & (0x1111000fU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010351_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010350_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010348_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___010349_)))))))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                          ? 
                                                         (1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___011508_))
                                                          : 
                                                         (0x1111000fU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010361_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeee0000ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010358_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010359_)))))))))));
    vlSelf->__VdfgTmp_hbd75f801__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010361_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff00000eeee0000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0))))));
    vlSelf->wasmetal_core__DOT___010022_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010361_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfff00000eeee0000ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_he9e11b30__0))))));
    vlSelf->__VdfgTmp_ha7c061ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___010151_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010150_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010869_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf6bbf4d1__0))))));
    vlSelf->__VdfgTmp_h034bd5a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___010957_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010956_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010955_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010957_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010955_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010956_)))))));
    if (vlSelf->wasmetal_core__DOT___010124_) {
        vlSelf->wasmetal_core__DOT___056637_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010472_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d))))));
        vlSelf->wasmetal_core__DOT___056635_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011719_));
    } else {
        vlSelf->wasmetal_core__DOT___056637_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d))))));
        vlSelf->wasmetal_core__DOT___056635_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d))))));
    }
    vlSelf->wasmetal_core__DOT___010717_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2f9ca2ed__0))))))));
    vlSelf->__VdfgTmp_hafd3f22a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d));
    vlSelf->__VdfgTmp_h0adc7ff6__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010528_));
    vlSelf->wasmetal_core__DOT___010299_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010336_)));
    vlSelf->wasmetal_core__DOT___055016_ = (1U & (IData)(
                                                         (0xf0fcc5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055014_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055013_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___033416_)))))))));
    vlSelf->wasmetal_core__DOT___056313_ = (1U & (0x3300faU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xbU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010092_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010462_)))))));
    vlSelf->wasmetal_core__DOT___012980_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010462_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d)))))))));
    vlSelf->__VdfgTmp_hfba46556__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010534_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d))));
    vlSelf->__VdfgTmp_h3820fb89__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011125_));
    vlSelf->wasmetal_core__DOT___010186_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010184_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d))))));
    vlSelf->__VdfgTmp_h53247725__0 = (((IData)(vlSelf->wasmetal_core__DOT___010141_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010140_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010139_))));
    vlSelf->__VdfgTmp_hb7b9c3d6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010322_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010321_))));
    vlSelf->wasmetal_core__DOT___070513_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010321_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010322_)))));
    vlSelf->wasmetal_core__DOT___033411_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010322_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010321_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h95b8e055__0))))));
    vlSelf->wasmetal_core__DOT___056634_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010462_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010457_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___056308_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d)))));
    vlSelf->wasmetal_core__DOT___012039_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010457_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d))))));
    vlSelf->__VdfgTmp_hcf7af3c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he2e0905c__0)))));
    vlSelf->__VdfgTmp_h929b802f__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010534_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010533_))))));
    vlSelf->wasmetal_core__DOT___012798_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xccccaaaaf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hadb47ff7__0))))))));
    vlSelf->__VdfgTmp_h52f935f8__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d));
    vlSelf->__VdfgTmp_hcf7ded40__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011124_));
    vlSelf->wasmetal_core__DOT___011973_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010189_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010887_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h25286e3d__0))))));
    vlSelf->__VdfgTmp_h1d2a78cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010988_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010987_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010986_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010988_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010986_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010987_)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010881_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h41c2ec0e__0))))));
    vlSelf->__VdfgTmp_haef445c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010982_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010981_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010980_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010982_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010980_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010981_)))))));
    vlSelf->wasmetal_core__DOT___057047_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010444_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha8fd39d5__0))))))));
    vlSelf->__VdfgTmp_hb37e0c87__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha8fd39d5__0)));
    vlSelf->wasmetal_core__DOT___010342_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010374_)));
    vlSelf->wasmetal_core__DOT___054846_ = (1U & (IData)(
                                                         (0xf0fcc5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054844_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010045_)))))))));
    vlSelf->wasmetal_core__DOT___012978_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010434_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he96324c1__0))))))));
    vlSelf->__VdfgTmp_hf1841993__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he96324c1__0)));
    vlSelf->wasmetal_core__DOT___056896_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xccccaaaaf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hedc6bc1e__0))));
    vlSelf->wasmetal_core__DOT___012183_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hedc6bc1e__0))));
    vlSelf->wasmetal_core__DOT___056718_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xaaaaccccff00fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h18547ac4__0))))))));
    vlSelf->wasmetal_core__DOT___056186_ = (1U & (IData)(
                                                         (0xdddd000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056183_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056182_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                      & (IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7b1353df__0)))) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007250_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007235_)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010893_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde094a0f__0))))));
    vlSelf->__VdfgTmp_hd610ba85__0 = (((IData)(vlSelf->wasmetal_core__DOT___010193_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010191_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010192_)));
    vlSelf->__VdfgTmp_h1b8b64b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010193_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010192_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010191_))));
    vlSelf->__VdfgTmp_h6a02124a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056427_));
    vlSelf->__VdfgTmp_hcba8f5cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___010341_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h45be7681__0 = (((IData)(vlSelf->wasmetal_core__DOT___010341_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010338_));
    vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___010338_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_hfa355bbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___011115_ = (1U & (0xff00ff1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009784_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0b52da3e__0))))));
    vlSelf->__VdfgTmp_hcc63a86c__0 = (((IData)(vlSelf->wasmetal_core__DOT___009784_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h0b52da3e__0));
    vlSelf->wasmetal_core__DOT___010756_ = (1U & (0xf0ee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h627ddd53__0)))));
    vlSelf->wasmetal_core__DOT___010241_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h627ddd53__0)))));
    vlSelf->__VdfgTmp_hddfbd8d3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_he13bfe6a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he89f377b__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010547_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he89f377b__0))))));
    vlSelf->wasmetal_core__DOT___010197_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010206_)) 
                                                  & (IData)(
                                                            (0xffffff11fffffff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1a6962a9__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (IData)(vlSelf->__VdfgTmp_h1a6962a9__0))));
    vlSelf->__VdfgTmp_h7fb5afda__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h8d891945__0));
    vlSelf->__VdfgTmp_hc43f9106__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8e4b209e__0));
    vlSelf->__VdfgTmp_hc09bd195__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc5fe5af8__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc5fe5af8__0))))));
    vlSelf->wasmetal_core__DOT___011122_ = (1U & (0xff00ff1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009796_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9bd5098e__0))))));
    vlSelf->wasmetal_core__DOT___056173_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009796_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008974_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                    ? (IData)(
                                                              (0xf0f0f0f0f0f0fffeULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___009795_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009794_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h831e3e64__0)))))))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___008974_))))));
    vlSelf->__VdfgTmp_hf939f2bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___009796_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9bd5098e__0));
    vlSelf->wasmetal_core__DOT___010122_ = (1U & (0xf0ee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9e2ff648__0)))));
    vlSelf->wasmetal_core__DOT___010281_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9e2ff648__0)))));
}
