#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__27(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__27\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006814_;
    wasmetal_core__DOT___006814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006815_;
    wasmetal_core__DOT___006815_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006817_;
    wasmetal_core__DOT___006817_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016172_;
    wasmetal_core__DOT___016172_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016227_;
    wasmetal_core__DOT___016227_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016229_;
    wasmetal_core__DOT___016229_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016247_;
    wasmetal_core__DOT___016247_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016261_;
    wasmetal_core__DOT___016261_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016262_;
    wasmetal_core__DOT___016262_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016273_;
    wasmetal_core__DOT___016273_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016274_;
    wasmetal_core__DOT___016274_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016281_;
    wasmetal_core__DOT___016281_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016311_;
    wasmetal_core__DOT___016311_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016312_;
    wasmetal_core__DOT___016312_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016314_;
    wasmetal_core__DOT___016314_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016358_;
    wasmetal_core__DOT___016358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016368_;
    wasmetal_core__DOT___016368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016385_;
    wasmetal_core__DOT___016385_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016471_;
    wasmetal_core__DOT___016471_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016488_;
    wasmetal_core__DOT___016488_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016489_;
    wasmetal_core__DOT___016489_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016490_;
    wasmetal_core__DOT___016490_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017915_;
    wasmetal_core__DOT___017915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017925_;
    wasmetal_core__DOT___017925_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018349_;
    wasmetal_core__DOT___018349_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027435_;
    wasmetal_core__DOT___027435_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030198_;
    wasmetal_core__DOT___030198_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033456_;
    wasmetal_core__DOT___033456_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043038_;
    wasmetal_core__DOT___043038_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043042_;
    wasmetal_core__DOT___043042_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043050_;
    wasmetal_core__DOT___043050_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043058_;
    wasmetal_core__DOT___043058_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043064_;
    wasmetal_core__DOT___043064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057774_;
    wasmetal_core__DOT___057774_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058429_;
    wasmetal_core__DOT___058429_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058431_;
    wasmetal_core__DOT___058431_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058442_;
    wasmetal_core__DOT___058442_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058446_;
    wasmetal_core__DOT___058446_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058476_;
    wasmetal_core__DOT___058476_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058481_;
    wasmetal_core__DOT___058481_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058482_;
    wasmetal_core__DOT___058482_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058495_;
    wasmetal_core__DOT___058495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058536_;
    wasmetal_core__DOT___058536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058537_;
    wasmetal_core__DOT___058537_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058544_;
    wasmetal_core__DOT___058544_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058713_;
    wasmetal_core__DOT___058713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058735_;
    wasmetal_core__DOT___058735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058844_;
    wasmetal_core__DOT___058844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059077_;
    wasmetal_core__DOT___059077_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059104_;
    wasmetal_core__DOT___059104_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059127_;
    wasmetal_core__DOT___059127_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059133_;
    wasmetal_core__DOT___059133_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059180_;
    wasmetal_core__DOT___059180_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059181_;
    wasmetal_core__DOT___059181_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059190_;
    wasmetal_core__DOT___059190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059194_;
    wasmetal_core__DOT___059194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059195_;
    wasmetal_core__DOT___059195_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059977_;
    wasmetal_core__DOT___059977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___072263_;
    wasmetal_core__DOT___072263_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127476___O;
    wasmetal_core__DOT____Vcellout___127476___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127977___O;
    wasmetal_core__DOT____Vcellout___127977___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127947___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127947___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127947___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127947___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128242___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128242___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128242___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128242___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128242___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128242___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__ = 0;
    CData/*3:0*/ __VdfgTmp_hb9735979__0;
    __VdfgTmp_hb9735979__0 = 0;
    CData/*1:0*/ __VdfgTmp_haf03c95c__0;
    __VdfgTmp_haf03c95c__0 = 0;
    CData/*2:0*/ __VdfgTmp_h27477f57__0;
    __VdfgTmp_h27477f57__0 = 0;
    CData/*1:0*/ __VdfgTmp_h88996eeb__0;
    __VdfgTmp_h88996eeb__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc9b9f3ff__0;
    __VdfgTmp_hc9b9f3ff__0 = 0;
    CData/*4:0*/ __VdfgTmp_h7386a859__0;
    __VdfgTmp_h7386a859__0 = 0;
    CData/*2:0*/ __VdfgTmp_h352b51f3__0;
    __VdfgTmp_h352b51f3__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3d212b86__0;
    __VdfgTmp_h3d212b86__0 = 0;
    CData/*4:0*/ __VdfgTmp_hcfc69af2__0;
    __VdfgTmp_hcfc69af2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h19f5d4dc__0;
    __VdfgTmp_h19f5d4dc__0 = 0;
    CData/*4:0*/ __VdfgTmp_hdfa5ed14__0;
    __VdfgTmp_hdfa5ed14__0 = 0;
    CData/*1:0*/ __VdfgTmp_h84de2564__0;
    __VdfgTmp_h84de2564__0 = 0;
    CData/*2:0*/ __VdfgTmp_h4c4dfcd4__0;
    __VdfgTmp_h4c4dfcd4__0 = 0;
    CData/*1:0*/ __VdfgTmp_hafce6df8__0;
    __VdfgTmp_hafce6df8__0 = 0;
    CData/*2:0*/ __VdfgTmp_ha692919d__0;
    __VdfgTmp_ha692919d__0 = 0;
    CData/*1:0*/ __VdfgTmp_he6980ace__0;
    __VdfgTmp_he6980ace__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2de7cdff__0;
    __VdfgTmp_h2de7cdff__0 = 0;
    CData/*3:0*/ __VdfgTmp_h4fc19847__0;
    __VdfgTmp_h4fc19847__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf9598b43__0;
    __VdfgTmp_hf9598b43__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbced8ce8__0;
    __VdfgTmp_hbced8ce8__0 = 0;
    CData/*3:0*/ __VdfgTmp_h1b5253bd__0;
    __VdfgTmp_h1b5253bd__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb7173042__0;
    __VdfgTmp_hb7173042__0 = 0;
    CData/*3:0*/ __VdfgTmp_hbbab100a__0;
    __VdfgTmp_hbbab100a__0 = 0;
    CData/*3:0*/ __VdfgTmp_h90b76d4b__0;
    __VdfgTmp_h90b76d4b__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8c714845__0;
    __VdfgTmp_h8c714845__0 = 0;
    CData/*1:0*/ __VdfgTmp_h5bac664e__0;
    __VdfgTmp_h5bac664e__0 = 0;
    CData/*2:0*/ __VdfgTmp_h84b4ffe6__0;
    __VdfgTmp_h84b4ffe6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4f0a13d1__0;
    __VdfgTmp_h4f0a13d1__0 = 0;
    CData/*5:0*/ __VdfgTmp_hadd1132f__0;
    __VdfgTmp_hadd1132f__0 = 0;
    CData/*5:0*/ __VdfgTmp_h7bed2ca0__0;
    __VdfgTmp_h7bed2ca0__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5fca0975__0;
    __VdfgTmp_h5fca0975__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbd290b9b__0;
    __VdfgTmp_hbd290b9b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9c980b03__0;
    __VdfgTmp_h9c980b03__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___046015_ = (1U & (0xefff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072278_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052659_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050452_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053071_)))))));
    wasmetal_core__DOT___072263_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052712_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052711_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052710_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052709_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___052708_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052707_)))))))));
    vlSelf->wasmetal_core__DOT___044848_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8c284b8e__0)))))))))));
    vlSelf->wasmetal_core__DOT___044872_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8c284b8e__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d))))))));
    vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027369_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b42__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128556___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033447_)))));
    vlSelf->wasmetal_core__DOT___033451_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030259_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030194_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127631___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024017_)))));
    vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023758_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127615___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023890_)))));
    vlSelf->wasmetal_core__DOT___023895_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d) {
        vlSelf->wasmetal_core__DOT___024022_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024022_ = vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023895_;
    }
    vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022478_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013705_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022803_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0))));
    vlSelf->__VdfgTmp_h7695852b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127486___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006215_));
    vlSelf->__VdfgTmp_h5f0989ee__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127486___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006144_));
    vlSelf->__VdfgTmp_hd540c232__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127486___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT___060214_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060213_))));
    vlSelf->wasmetal_core__DOT___057772_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057769_))));
    vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006204_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__0__KET__));
    __VdfgTmp_h3d212b86__0 = (((IData)(vlSelf->wasmetal_core__DOT___016190_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016219_));
    __VdfgTmp_h19f5d4dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___006889_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006888_));
    __VdfgTmp_haf03c95c__0 = (((IData)(vlSelf->wasmetal_core__DOT___016233_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016232_));
    __VdfgTmp_h88996eeb__0 = (((IData)(vlSelf->wasmetal_core__DOT___016257_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016255_));
    __VdfgTmp_h84de2564__0 = (((IData)(vlSelf->wasmetal_core__DOT___016188_) 
                               << 1U) | (1U & (IData)(
                                                      (0xf5f3f0f000000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h934029c5__0)))));
    __VdfgTmp_hc9b9f3ff__0 = ((2U & ((IData)((0xf5f3f0f0ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___006887_));
    vlSelf->wasmetal_core__DOT___017945_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048950_))));
    vlSelf->wasmetal_core__DOT___017816_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000132_))));
    vlSelf->wasmetal_core__DOT___014612_ = (1U & (0xf0eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005711_))))));
    wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___017896_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___043038_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017895_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x4fU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051268_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___024134_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___051266_)))))))));
    __VdfgTmp_h7bed2ca0__0 = (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                          << 4U) | 
                                         ((8U & ((0x4fU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                 << 3U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                              << 2U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___017895_) 
                                                 << 1U) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                      >> 2U)))))));
    wasmetal_core__DOT___058544_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017895_))));
    vlSelf->wasmetal_core__DOT___052585_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017896_))));
    vlSelf->wasmetal_core__DOT___051319_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x4fU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017895_)))));
    __VdfgTmp_hb9735979__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                     << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017896_))));
    vlSelf->wasmetal_core__DOT___058438_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051511_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051510_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006819_)))));
    vlSelf->wasmetal_core__DOT___058494_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0x4fU 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))))))));
    vlSelf->wasmetal_core__DOT___058492_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                     >> 3U) 
                                                    & (0x700000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h363b6dc6__0)))))));
    vlSelf->wasmetal_core__DOT___058468_ = ((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                            & (IData)(
                                                      (0xfff0fff0ffff4444ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016377_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016376_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016375_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___016255_)))))))));
    wasmetal_core__DOT___016281_ = (1U & ((~ (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                               >> 2U) 
                                              & (IData)(
                                                        (0xb000000000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                           << 5U) 
                                                          | ((0x10U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                                 << 4U)) 
                                                             | ((8U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h29bb7b8d__0))))))))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___006829_)
                                              ? (0xfcfaU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___016288_)))))
                                              : (0xfcfaU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___006942_))))))));
    vlSelf->wasmetal_core__DOT___016313_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006891_))));
    vlSelf->wasmetal_core__DOT___016301_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h363b6dc6__0)))));
    vlSelf->wasmetal_core__DOT___016242_ = (1U & (0xa0003U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8655efce__0))))));
    vlSelf->wasmetal_core__DOT___016222_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058425_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006818_)))));
    wasmetal_core__DOT___016311_ = (1U & (0x55fcU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0xf5f3f0f0ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006887_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006889_))))));
    wasmetal_core__DOT___016314_ = (1U & (IData)((0xaa00ff0f0f0c0cULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016256_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016257_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016258_)))))))));
    vlSelf->wasmetal_core__DOT___016220_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016288_)))))))));
    vlSelf->wasmetal_core__DOT___016302_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016232_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016233_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006890_)))))));
    vlSelf->wasmetal_core__DOT___016248_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016188_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xf5f3f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___016191_)))))));
    wasmetal_core__DOT___016229_ = (1U & (0x70000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 4U) 
                                              | ((8U 
                                                  & ((0x4fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                     << 3U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h96af251d__0))))));
    wasmetal_core__DOT___016262_ = (1U & (0xf0faaccU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058425_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016289_)))))));
    wasmetal_core__DOT___016261_ = (1U & (IData)((0xf0f0aaaaff00ccccULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h04c27d81__0))))))));
    vlSelf->wasmetal_core__DOT___016240_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006943_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006942_)))))))));
    wasmetal_core__DOT___016274_ = (1U & (IData)((0xf0faaaaff00ccccULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016290_)))))))));
    wasmetal_core__DOT___006815_ = (1U & (IData)((0x111111110000ff0fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016377_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016375_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016376_)))))))));
    vlSelf->wasmetal_core__DOT___016241_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006944_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006930_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006940_)))))))));
    vlSelf->wasmetal_core__DOT___016221_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h04c27d81__0)))));
    wasmetal_core__DOT___016273_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006829_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                               ? (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___006942_))
                                               : (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___006941_)))
                                           : ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                               ? (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___006943_))
                                               : (IData)(vlSelf->wasmetal_core__DOT___006947_))));
    wasmetal_core__DOT___016247_ = (1U & (0xf0f000eeU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058424_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016192_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006829_)))))));
    wasmetal_core__DOT___016227_ = (1U & (IData)((0xaaaacccc000f000fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016376_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016375_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h161c803b__0))))))));
    vlSelf->wasmetal_core__DOT___016171_ = (1U & (IData)(
                                                         (0xff00aa0c0c0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058424_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016256_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h161c803b__0))))))));
    vlSelf->wasmetal_core__DOT___005689_ = (1U & ((1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O))
                                                   ? 
                                                  (0x331030U 
                                                   >> 
                                                   ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))))))
                                                   : (IData)(
                                                             (0x3000f0002000a00ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                                         << 2U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h7b6ee7cc__0)))))))));
    vlSelf->wasmetal_core__DOT___019795_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___072263_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___072262_))));
    vlSelf->wasmetal_core__DOT___039447_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128330___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039417_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128330___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039418_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128330___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039419_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128330___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039436_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128337___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039429_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128337___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039428_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128337___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039427_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128337___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039426_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128338___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___040089_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128338___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039420_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128338___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039416_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128338___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039425_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128339___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039424_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128339___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039423_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128339___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039422_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128339___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039430_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128340___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039431_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128340___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039432_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128340___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039438_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128340___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___040091_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128341___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039440_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128341___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039442_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128341___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039437_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128341___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___040090_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128342___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039433_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128342___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039421_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128342___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039443_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128342___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039441_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128343___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039439_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128343___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039435_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128343___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039434_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128343___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___039534_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054038_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128378___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039476_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054042_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128378___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039487_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054046_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128378___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039865_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054050_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128378___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039489_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054054_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128385___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039491_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054058_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128385___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039483_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054062_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128385___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039864_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128385___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039478_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054070_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128386___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039475_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054074_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128386___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039500_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054078_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128386___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039490_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054082_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128386___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039488_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054086_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128387___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039482_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054090_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128387___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039479_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054094_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128387___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039486_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054098_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128387___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039480_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054102_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128388___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039485_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054106_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128388___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039481_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054110_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128388___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039492_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054114_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128388___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039493_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054118_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128389___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039494_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054122_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128389___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039514_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054126_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128389___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039504_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054130_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128389___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039503_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054134_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128390___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039502_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054138_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128390___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039501_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054161_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128390___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039866_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054165_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128390___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039495_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054169_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128391___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039484_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054173_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128391___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039499_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054177_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128391___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039498_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054181_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128391___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___039497_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054185_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128392___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___039505_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054190_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128392___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___039506_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054192_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128392___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___039507_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054194_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128393___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___039528_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054196_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128393___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d)))))))));
    vlSelf->wasmetal_core__DOT___039518_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054198_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128393___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___039517_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054200_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128393___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___039516_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054202_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128379___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___039515_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054204_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128379___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___039867_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054206_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128379___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___039508_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054208_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128379___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT___039496_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054210_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128380___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___039513_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054212_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128380___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___039512_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054214_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128380___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___039511_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054216_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128380___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___039510_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054218_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128381___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___039519_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054220_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128381___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___039520_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054222_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128381___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___039521_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054224_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128381___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT___039541_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054226_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128382___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___039532_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054228_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128382___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___039531_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054230_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128382___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d)))))))));
    vlSelf->wasmetal_core__DOT___039530_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054232_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128382___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d)))))))));
    vlSelf->wasmetal_core__DOT___039529_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054234_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128383___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___039868_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054236_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128383___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT___039522_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054238_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128383___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d)))))))));
    vlSelf->wasmetal_core__DOT___039509_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054240_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128383___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___039527_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054242_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128384___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___039526_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054244_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128384___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___039525_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054246_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128384___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d)))))))));
    vlSelf->wasmetal_core__DOT___039524_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054248_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128384___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b63__05d)))))))));
    vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127945___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027370_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027369_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027368_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027367_)))) 
           ^ (((IData)(wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027300_)))));
    vlSelf->wasmetal_core__DOT___027305_ = ((IData)(vlSelf->wasmetal_core__DOT___027370_)
                                             ? (IData)(wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b43__05d));
    vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033451_));
    vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030260_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d) {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024022_;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023759_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d));
    wasmetal_core__DOT___058844_ = (1U & (0xf8U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                     >> 2U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                                       >> 3U)))))));
    vlSelf->__VdfgTmp_hfcfdf45d__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005711_));
    vlSelf->__VdfgTmp_h43b7a5ac__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006215_));
    vlSelf->__VdfgTmp_hf7bb201a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006144_));
    vlSelf->__VdfgTmp_h2307c8f1__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT____Vcellout___127442___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022479_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022478_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022477_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022476_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022532_)))));
    vlSelf->wasmetal_core__DOT___022536_ = ((IData)(vlSelf->wasmetal_core__DOT___022479_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013692_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022804_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0))));
    vlSelf->wasmetal_core__DOT___022809_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7695852b__0))))));
    wasmetal_core__DOT___059127_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127494___O) 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7695852b__0))))));
    vlSelf->wasmetal_core__DOT___022807_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0))))));
    wasmetal_core__DOT___059104_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059089_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059088_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127494___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)))))))))));
    wasmetal_core__DOT___059195_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059191_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h7695852b__0)))))))))));
    vlSelf->wasmetal_core__DOT___022806_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd540c232__0))))));
    wasmetal_core__DOT___059180_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd540c232__0))))));
    wasmetal_core__DOT___059190_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd540c232__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))))));
    vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003810_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___006814_ = (1U & (IData)((0x11111111f0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_haf03c95c__0))))))));
    __VdfgTmp_h352b51f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                               << 2U) | (IData)(__VdfgTmp_h88996eeb__0));
    if (vlSelf->wasmetal_core__DOT___006891_) {
        vlSelf->wasmetal_core__DOT___016173_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016190_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xf5f3f0f000000000ULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016188_))))));
        vlSelf->wasmetal_core__DOT___006816_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006888_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006887_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf5f3f0f0ULL 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h934029c5__0)))))))));
        vlSelf->wasmetal_core__DOT___016249_ = (1U 
                                                & (0x450fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016256_))))));
    } else {
        vlSelf->wasmetal_core__DOT___016173_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016192_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016191_)))));
        vlSelf->wasmetal_core__DOT___006816_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006890_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006889_)))));
        vlSelf->wasmetal_core__DOT___016249_ = (1U 
                                                & (0x32ffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_h352b51f3__0))));
    }
    wasmetal_core__DOT___016172_ = (1U & (0x302fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h88996eeb__0)))));
    vlSelf->wasmetal_core__DOT___016277_ = (1U & (0xee0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016192_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h84de2564__0))))));
    vlSelf->wasmetal_core__DOT___016267_ = (1U & (0xee0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006890_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hc9b9f3ff__0))))));
    vlSelf->wasmetal_core__DOT___060224_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017945_))));
    vlSelf->wasmetal_core__DOT___040077_ = (1U & (IData)(
                                                         (0x2a2a2aeaeaeaea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060213_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___060218_ = (1U & (0x7d00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060213_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005669_))))));
    vlSelf->__VdfgTmp_h1b3b7d3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014613_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014610_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___134186___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___017895_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                        << 2U) | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                             >> 1U)) 
                                         << 1U)) | 
                                  (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036988_)))));
    vlSelf->wasmetal_core__DOT___036992_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___017895_)) 
                                                  | (IData)(wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___043042_ = (1U & ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O))
                                           ? ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O))
                                               ? (0x104U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x4fU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017895_)))))
                                               : (IData)(
                                                         (0xc000100c0003200ULL 
                                                          >> (IData)(__VdfgTmp_h7bed2ca0__0))))
                                           : ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O))
                                               ? (IData)(
                                                         (0xc000004c00000c8ULL 
                                                          >> (IData)(__VdfgTmp_h7bed2ca0__0)))
                                               : (IData)(
                                                         (0xc000400c000c800ULL 
                                                          >> (IData)(__VdfgTmp_h7bed2ca0__0))))));
    vlSelf->wasmetal_core__DOT___016496_ = (1U & (0x10000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 4U)) 
                                                   | (((IData)(wasmetal_core__DOT___058544_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058528_)))))));
    vlSelf->wasmetal_core__DOT___016474_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058544_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->wasmetal_core__DOT___017813_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002961_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051268_)))));
    vlSelf->__VdfgTmp_hff203b22__0 = (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057769_));
    vlSelf->wasmetal_core__DOT___058557_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___036996_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052585_))))));
    vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d 
        = (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051319_)))));
    vlSelf->wasmetal_core__DOT___051320_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016255_)))));
    wasmetal_core__DOT___057774_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___051319_))));
    vlSelf->wasmetal_core__DOT___005688_ = (1U & (IData)(
                                                         (0xdf5dcc00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                                  << 1U)) 
                                                              | (IData)(__VdfgTmp_hb9735979__0))))));
    vlSelf->wasmetal_core__DOT___005687_ = (1U & (IData)(
                                                         (0xdf5dcc00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                                  << 2U)) 
                                                              | (IData)(__VdfgTmp_hb9735979__0))))));
    vlSelf->wasmetal_core__DOT___058516_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058470_))));
    vlSelf->wasmetal_core__DOT___058515_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058492_))));
    vlSelf->__VdfgTmp_h4af9777a__0 = (((IData)(vlSelf->wasmetal_core__DOT___058492_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006821_));
    vlSelf->__VdfgTmp_h2327e099__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058468_));
    vlSelf->wasmetal_core__DOT___058451_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___016281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->__VdfgTmp_h8d40b9ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016313_));
    vlSelf->wasmetal_core__DOT___016357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016301_))));
    vlSelf->wasmetal_core__DOT___058441_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->wasmetal_core__DOT___058440_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016222_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006820_)))));
    vlSelf->wasmetal_core__DOT___058444_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___016262_))));
    vlSelf->wasmetal_core__DOT___016250_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006818_)
                                                ? (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016261_)))
                                                : (0xf0f5533U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___016262_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h3d212b86__0)))))));
    vlSelf->wasmetal_core__DOT___016336_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___016261_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h3d212b86__0))))));
    __VdfgTmp_hafce6df8__0 = (((IData)(wasmetal_core__DOT___016261_) 
                               << 1U) | (IData)(wasmetal_core__DOT___016262_));
    __VdfgTmp_h4c4dfcd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___016240_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                          << 1U) | 
                                         (1U & (0x5cU 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8655efce__0))))));
    vlSelf->wasmetal_core__DOT___058448_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___016274_))));
    __VdfgTmp_hbced8ce8__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 1U) | (IData)(wasmetal_core__DOT___006815_));
    __VdfgTmp_h7386a859__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___016241_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___016240_) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006888_)))));
    wasmetal_core__DOT___016312_ = (1U & (0xcdU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___016241_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___006888_)))));
    if (vlSelf->wasmetal_core__DOT___006818_) {
        vlSelf->wasmetal_core__DOT___016315_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h3d212b86__0))));
        vlSelf->wasmetal_core__DOT___016228_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___006889_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(__VdfgTmp_hc9b9f3ff__0))));
        vlSelf->wasmetal_core__DOT___016268_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016273_))));
        vlSelf->wasmetal_core__DOT___016300_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006820_)) 
                                                & (IData)(wasmetal_core__DOT___016312_));
    } else {
        vlSelf->wasmetal_core__DOT___016315_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016191_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h84de2564__0)))));
        vlSelf->wasmetal_core__DOT___016228_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___006890_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(__VdfgTmp_haf03c95c__0))));
        vlSelf->wasmetal_core__DOT___016268_ = (1U 
                                                & (0xf0f0aaccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___016274_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h19f5d4dc__0))))));
        vlSelf->wasmetal_core__DOT___016300_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006820_)) 
                                                & (IData)(wasmetal_core__DOT___016311_));
    }
    vlSelf->wasmetal_core__DOT___016348_ = (1U & (IData)(
                                                         (0xff00aaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016191_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h3d212b86__0))))))));
    vlSelf->__VdfgTmp_hb91597d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016220_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016219_)))));
    vlSelf->wasmetal_core__DOT___016342_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___016273_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h19f5d4dc__0))))));
    __VdfgTmp_he6980ace__0 = (((IData)(wasmetal_core__DOT___016273_) 
                               << 1U) | (IData)(wasmetal_core__DOT___016274_));
    __VdfgTmp_h8c714845__0 = (((IData)(wasmetal_core__DOT___016314_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___016247_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016313_)));
    vlSelf->__VdfgTmp_hf4bdf179__0 = (((IData)(wasmetal_core__DOT___016247_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006818_));
    vlSelf->__VdfgTmp_hce0a7704__0 = (((IData)(wasmetal_core__DOT___016314_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016247_));
    vlSelf->__VdfgTmp_h64b5570f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016247_));
    vlSelf->__VdfgTmp_h31cd2dad__0 = (((IData)(wasmetal_core__DOT___016227_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006818_));
    __VdfgTmp_hb7173042__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 1U) | (IData)(wasmetal_core__DOT___016227_));
    wasmetal_core__DOT____Vcellout___127977___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027431_)))));
    wasmetal_core__DOT___027435_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                     >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063308_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063310_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063312_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063314_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027371_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027305_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b44__05d));
    vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030261_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d) {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127597___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023760_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023759_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023758_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023757_)))) 
           ^ (((IData)(wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023693_)))));
    vlSelf->wasmetal_core__DOT___023697_ = ((IData)(vlSelf->wasmetal_core__DOT___023760_)
                                             ? (IData)(wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d));
    vlSelf->wasmetal_core__DOT___017451_ = (1U & (IData)(
                                                         (0xb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058845_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058844_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005921_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005955_)))))))));
    vlSelf->wasmetal_core__DOT___058899_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d))))));
    vlSelf->wasmetal_core__DOT___023765_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d))));
    vlSelf->wasmetal_core__DOT___058873_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d))));
    wasmetal_core__DOT___058713_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0))))));
    vlSelf->wasmetal_core__DOT___023764_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d))));
    vlSelf->wasmetal_core__DOT___058898_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0))))))));
    vlSelf->wasmetal_core__DOT___058752_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058742_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058741_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)))))))))));
    vlSelf->wasmetal_core__DOT___023762_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d))));
    vlSelf->wasmetal_core__DOT___058897_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0))))))));
    wasmetal_core__DOT___058735_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058730_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058729_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)))))))))));
    vlSelf->wasmetal_core__DOT___023761_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d))));
    vlSelf->__VdfgTmp_h85d5ffaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_h85c84d1a__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_h850cecd0__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O)));
    vlSelf->wasmetal_core__DOT___023199_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022476_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O))))));
    vlSelf->wasmetal_core__DOT___023197_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022478_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___023196_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022479_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            >> 3U))))));
    vlSelf->__VdfgTmp_h85009285__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                    >> 1U)));
    vlSelf->wasmetal_core__DOT___127428___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022480_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022536_));
    vlSelf->wasmetal_core__DOT____Vcellout___127582___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013712_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0db23397__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023596_)))));
    vlSelf->wasmetal_core__DOT___023600_ = ((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127475___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022805_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022804_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022803_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022802_)))) 
           ^ (((IData)(wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022770_)))));
    vlSelf->wasmetal_core__DOT___022774_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022805_)
                                                   ? (IData)(wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))));
    wasmetal_core__DOT___059133_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059127_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059126_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127494___O) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hd540c232__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0)))))))))));
    vlSelf->wasmetal_core__DOT___059163_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059105_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059104_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059103_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127487___O) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O) 
                                                                                >> 1U)) 
                                                                              | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))))))))))));
    wasmetal_core__DOT___059181_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059180_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059179_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0)))))))))));
    wasmetal_core__DOT___059194_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059190_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059189_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127565___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003809_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006400_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023475_)))));
    vlSelf->wasmetal_core__DOT___023479_ = ((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h94e3de73__0 = (((IData)(wasmetal_core__DOT___006815_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___006814_));
    vlSelf->wasmetal_core__DOT___058489_ = ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                            & (IData)(
                                                      (0xcdf0000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h352b51f3__0)))))));
    vlSelf->__VdfgTmp_h8cd41eba__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016172_));
    vlSelf->__VdfgTmp_h10570a51__0 = (((IData)(wasmetal_core__DOT___016172_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016171_));
    vlSelf->wasmetal_core__DOT___058469_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___006814_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006818_)))));
    vlSelf->wasmetal_core__DOT___134187___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036992_)));
    vlSelf->wasmetal_core__DOT___043035_ = ((IData)(wasmetal_core__DOT___043042_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___043041_)
                                                 ? 
                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___043040_)) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___043036_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043037_))
                                             : (IData)(wasmetal_core__DOT___043038_));
    vlSelf->wasmetal_core__DOT___059072_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043041_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043040_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___043042_)))));
    vlSelf->wasmetal_core__DOT___017834_ = (1U & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)
                                                      ? 
                                                     (0x355fcaaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                        << 4U) 
                                                       | ((8U 
                                                           & ((8U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017840_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017839_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___017838_))))))
                                                      : 
                                                     (9U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002473_))))));
    vlSelf->wasmetal_core__DOT___060165_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058557_))));
    vlSelf->wasmetal_core__DOT___018964_ = (1U & (0x80ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058557_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                           << 5U)) 
                                                                       | ((0x1cU 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                              << 1U)) 
                                                                          | ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O))))))) 
                                                             << 2U)) 
                                                         | (((IData)(wasmetal_core__DOT___058544_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___036996_)))))));
    vlSelf->wasmetal_core__DOT___057797_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017831_))));
    vlSelf->wasmetal_core__DOT___017141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017849_))));
    vlSelf->wasmetal_core__DOT___057784_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016258_))));
    vlSelf->wasmetal_core__DOT___057776_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017829_))));
    vlSelf->wasmetal_core__DOT___017017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017821_))));
    vlSelf->wasmetal_core__DOT___057811_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xefU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hedae78d9__0))))));
    vlSelf->wasmetal_core__DOT___057794_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017910_))));
    vlSelf->wasmetal_core__DOT___057816_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xefU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8599270c__0))))));
    vlSelf->wasmetal_core__DOT___057821_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017874_))));
    vlSelf->wasmetal_core__DOT___057863_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xefU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6ef172e0__0))))));
    vlSelf->wasmetal_core__DOT___057866_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017887_))));
    vlSelf->wasmetal_core__DOT___057872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017888_))));
    vlSelf->wasmetal_core__DOT___017113_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057877_))));
    vlSelf->wasmetal_core__DOT___057839_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057838_))));
    vlSelf->wasmetal_core__DOT___057854_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006947_))));
    vlSelf->wasmetal_core__DOT___057844_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006941_))));
    vlSelf->wasmetal_core__DOT___057848_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006943_))));
    vlSelf->wasmetal_core__DOT___057882_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006942_))));
    vlSelf->wasmetal_core__DOT___057892_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016288_))));
    vlSelf->wasmetal_core__DOT___057895_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016290_))));
    vlSelf->wasmetal_core__DOT___057886_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016289_))));
    vlSelf->wasmetal_core__DOT___057924_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057774_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b63__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058516_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b62__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058515_))));
    vlSelf->__VdfgTmp_h307b9eba__0 = (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2327e099__0)))))));
    vlSelf->wasmetal_core__DOT___058487_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2327e099__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006819_)))));
    vlSelf->wasmetal_core__DOT___058445_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->wasmetal_core__DOT___016392_ = (1U & (IData)(
                                                         (0xf5f0f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hafce6df8__0))))))));
    vlSelf->wasmetal_core__DOT___058455_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hafce6df8__0)))));
    vlSelf->wasmetal_core__DOT___016316_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hafce6df8__0)))));
    vlSelf->__VdfgTmp_hecea8d31__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h4c4dfcd4__0)));
    vlSelf->wasmetal_core__DOT___016299_ = (1U & (0x110f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h4c4dfcd4__0)))));
    vlSelf->wasmetal_core__DOT___058449_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->wasmetal_core__DOT___016331_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h7386a859__0)))));
    vlSelf->wasmetal_core__DOT___016354_ = ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006818_)
                                                ? (IData)(wasmetal_core__DOT___016312_)
                                                : (IData)(wasmetal_core__DOT___016311_)));
    vlSelf->wasmetal_core__DOT___016328_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb91597d0__0)))));
    vlSelf->wasmetal_core__DOT___058502_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (0x3333f0f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016342_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___006814_))))))
                                                : (0x40U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hbced8ce8__0)))));
    vlSelf->wasmetal_core__DOT___016325_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_he6980ace__0)))));
    vlSelf->__VdfgTmp_h0d217f15__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he6980ace__0)));
    vlSelf->wasmetal_core__DOT___058511_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0x33aa0f0000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h8c714845__0)))))));
    vlSelf->wasmetal_core__DOT___058475_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & (IData)(
                                                      (0x3300aa000f0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h8c714845__0)))))));
    vlSelf->__VdfgTmp_h6fab7a0a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hce0a7704__0));
    if (vlSelf->wasmetal_core__DOT___006820_) {
        vlSelf->wasmetal_core__DOT___016278_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___016281_)));
        vlSelf->wasmetal_core__DOT___058456_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016315_)))
                                                    : 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h8d40b9ee__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___016278_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006818_)
                                                    ? 
                                                   (0x32U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___016219_))))
                                                    : 
                                                   (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016191_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___016190_))))));
        vlSelf->wasmetal_core__DOT___058456_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                   & (0x53U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h6fab7a0a__0)))));
    }
    vlSelf->__VdfgTmp_h76f112be__0 = (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h64b5570f__0));
    vlSelf->wasmetal_core__DOT___058427_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                        ? 
                                                       (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___016242_))
                                                        : 
                                                       (0xf0fff11U 
                                                        >> (IData)(__VdfgTmp_h7386a859__0))))) 
                                                  & (IData)(
                                                            (0xfff0fff0ff00ffddULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___016229_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016228_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h31cd2dad__0)))))))));
    vlSelf->wasmetal_core__DOT___058463_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___016229_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016228_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hb7173042__0))))))));
    vlSelf->__VdfgTmp_h4bc72baa__0 = (((IData)(wasmetal_core__DOT___016229_) 
                                       << 2U) | (IData)(__VdfgTmp_hb7173042__0));
    vlSelf->__VdfgTmp_hdd3525a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___016302_) 
                                       << 2U) | (IData)(__VdfgTmp_hb7173042__0));
    __VdfgTmp_hbd290b9b__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                     << 1U)) | (1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d)))));
    vlSelf->__VdfgTmp_h06766dbc__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d)))));
    wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
           & (IData)(wasmetal_core__DOT___027435_));
    wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027372_)
            ? (IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b45__05d));
    vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128241___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030262_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030261_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030260_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030259_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030194_)))));
    wasmetal_core__DOT___030198_ = ((IData)(vlSelf->wasmetal_core__DOT___030262_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d) {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d;
        vlSelf->wasmetal_core__DOT___023899_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023899_ = vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___058724_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058714_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058713_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)))))))))));
    vlSelf->wasmetal_core__DOT___058751_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058736_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058735_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127628___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127627___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)))))))))));
    vlSelf->wasmetal_core__DOT___127598___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023761_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023697_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d));
    vlSelf->__VdfgTmp_haeb15d33__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h85009285__0)));
    vlSelf->__VdfgTmp_hbca1455c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h85009285__0)))));
    wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022481_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127428___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013826_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002034_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002030_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002028_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___013761_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002191_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002188_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002029_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002033_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127581___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___013756_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002028_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002027_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002031_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127581___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___127570___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013690_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023600_));
    vlSelf->wasmetal_core__DOT___127476___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022806_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022774_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hd540c232__0))));
    vlSelf->wasmetal_core__DOT___059164_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059135_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059134_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059133_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((8U 
                                                                               >> 
                                                                               ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O)) 
                                                                              | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0))))))))))))));
    vlSelf->wasmetal_core__DOT___059188_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059182_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059181_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h607e9020__0)))))))))));
    vlSelf->wasmetal_core__DOT___059199_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059195_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059194_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059193_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he0f48724__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h607e9020__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0)))))))))));
    vlSelf->wasmetal_core__DOT___050111_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005855_))))));
    vlSelf->wasmetal_core__DOT___050095_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003809_))))));
    vlSelf->wasmetal_core__DOT___127553___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005982_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023479_));
    __VdfgTmp_h84b4ffe6__0 = (((IData)(vlSelf->wasmetal_core__DOT___006816_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h94e3de73__0));
    __VdfgTmp_hcfc69af2__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_h94e3de73__0))));
    __VdfgTmp_ha692919d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h94e3de73__0));
    vlSelf->wasmetal_core__DOT___058514_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058489_))));
    vlSelf->wasmetal_core__DOT___058543_ = (1U & (IData)(
                                                         (0x7fffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058489_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058492_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2327e099__0))))))));
    wasmetal_core__DOT___058495_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016250_)) 
                                          & (IData)(
                                                    (0xff00ffeefff0fff0ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016249_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf4bdf179__0)))))))));
    __VdfgTmp_h5bac664e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016249_));
    vlSelf->wasmetal_core__DOT___058503_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (0x3333f0f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016348_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___016171_))))))
                                                : (0x40U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8cd41eba__0)))));
    __VdfgTmp_h2de7cdff__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h10570a51__0));
    __VdfgTmp_hbbab100a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h10570a51__0)));
    __VdfgTmp_h27477f57__0 = (((IData)(vlSelf->wasmetal_core__DOT___016173_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h10570a51__0));
    vlSelf->wasmetal_core__DOT___058488_ = (1U & (IData)(
                                                         (0xff33f0aa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016342_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058448_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058469_)))))))));
    vlSelf->wasmetal_core__DOT___058471_ = (1U & (IData)(
                                                         (0xffffcc55f0f0ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016268_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058468_)))))))));
    wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036996_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___134187___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___043064_ = (1U & (0x90U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017834_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017831_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017832_)))));
    wasmetal_core__DOT___043058_ = (1U & (IData)((0xff40ffff4040ff40ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057769_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070587_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017831_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017834_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017832_)))))))));
    __VdfgTmp_h5fca0975__0 = ((((IData)(vlSelf->wasmetal_core__DOT___017834_) 
                                & ((IData)(vlSelf->wasmetal_core__DOT___017833_) 
                                   & (IData)((0x9009000000009009ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___017832_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017831_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017830_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h103cd5d4__0))))))))) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017811_) 
                                          << 1U) | 
                                         ((IData)(vlSelf->wasmetal_core__DOT___017863_) 
                                          & ((IData)(
                                                     (0x9009000000000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___059072_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___059071_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057923_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h2b8ef9eb__0))))))) 
                                             & (IData)(
                                                       (0x8000000000000000ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___017861_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017860_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017859_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017858_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hb36cd122__0)))))))))));
    vlSelf->wasmetal_core__DOT___060582_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134186___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___018964_))))));
    vlSelf->wasmetal_core__DOT___016503_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018964_))));
    vlSelf->wasmetal_core__DOT___060166_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___036996_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b60__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h307b9eba__0))));
    vlSelf->wasmetal_core__DOT___058484_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058445_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf4bdf179__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016336_)))))))));
    vlSelf->wasmetal_core__DOT___016492_ = (1U & ((~ 
                                                   (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058494_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___006821_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                      ? 
                                                     (0x3bU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016392_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016315_))))
                                                      : 
                                                     (0xf0fafcfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016392_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hce0a7704__0))))))));
    wasmetal_core__DOT___058476_ = (1U & (0xf100U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___016316_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___016315_))))));
    wasmetal_core__DOT___016385_ = (1U & (IData)((0x11000f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hecea8d31__0)))));
    wasmetal_core__DOT___058482_ = (1U & (IData)((0xf3f300fa00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016331_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016242_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016228_)))))))));
    __VdfgTmp_hf9598b43__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___016331_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016228_)));
    vlSelf->wasmetal_core__DOT___058473_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016300_))));
    vlSelf->wasmetal_core__DOT___058490_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016281_)))
                                                   : 
                                                  (0xf0f000eeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016348_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___016171_))))))));
    vlSelf->wasmetal_core__DOT___058491_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058490_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058489_)))));
    vlSelf->wasmetal_core__DOT___058480_ = (1U & (IData)(
                                                         (0xf3f300fa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016328_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016222_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016173_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b44__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058502_))));
    vlSelf->wasmetal_core__DOT___058450_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016342_)))
                                                    : 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                                            << 1U) 
                                                           | (IData)(wasmetal_core__DOT___006814_))))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hbced8ce8__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b12__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058450_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058449_))))));
    vlSelf->wasmetal_core__DOT___058477_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016325_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006816_))))));
    wasmetal_core__DOT___016368_ = (1U & (0x5030000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h0d217f15__0))));
    wasmetal_core__DOT___006817_ = (1U & (0x5030000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h0d217f15__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b55__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058511_))));
    vlSelf->wasmetal_core__DOT___058505_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                ? (0x33a0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016315_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016313_)))))
                                                : (0x5300U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6fab7a0a__0)))));
    wasmetal_core__DOT___058429_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                              ? (0xff00fff1U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016250_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h76f112be__0))))
                                              : (0xcdU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016250_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016249_)))))));
    vlSelf->wasmetal_core__DOT___058466_ = (1U & (IData)(
                                                         (0xf1f100ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016249_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h76f112be__0)))))));
    vlSelf->__VdfgTmp_h99986d68__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058427_));
    vlSelf->__VdfgTmp_h1bc2f6b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058463_));
    vlSelf->wasmetal_core__DOT___058465_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0f0553300000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016242_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016241_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006888_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006891_)))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___016240_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058463_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006821_)))));
    wasmetal_core__DOT___016488_ = (1U & (0xf4000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4bc72baa__0)))));
    wasmetal_core__DOT___058481_ = (1U & (IData)((0xb00ff00ff00ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4bc72baa__0)))))));
    __VdfgTmp_h4fc19847__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_h4bc72baa__0));
    __VdfgTmp_h90b76d4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___016301_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_hdd3525a7__0));
    __VdfgTmp_h1b5253bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___016354_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_hdd3525a7__0));
    vlSelf->wasmetal_core__DOT___044849_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___127977___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(__VdfgTmp_hbd290b9b__0)))))))))));
    vlSelf->wasmetal_core__DOT___044873_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(__VdfgTmp_hbd290b9b__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d))))))));
    wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027373_)
            ? (IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b46__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128542___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011478_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033451_)))));
    wasmetal_core__DOT___033456_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___011478_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128242___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030263_)
            ? (IData)(wasmetal_core__DOT___030198_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127632___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024022_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) {
        vlSelf->wasmetal_core__DOT___024026_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024026_ = vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023899_;
    }
    wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023762_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127598___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127616___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023895_)))));
    wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022482_) 
           & (IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013654_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127570___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022807_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127476___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0))));
    vlSelf->wasmetal_core__DOT___059204_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059199_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059198_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x700000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059188_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059187_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___059186_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x7000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___059164_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059163_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059162_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x153f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059146_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059145_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127490___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127491___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0)))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051505_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051507_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059159_)))))))))))))));
    wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006085_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127553___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___058506_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h84b4ffe6__0)))))));
    vlSelf->wasmetal_core__DOT___058508_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0xf0f5330000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (IData)(__VdfgTmp_hcfc69af2__0)))));
    vlSelf->wasmetal_core__DOT___058497_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___016268_))
                                                : (0xf0f53300U 
                                                   >> (IData)(__VdfgTmp_hcfc69af2__0))));
    vlSelf->wasmetal_core__DOT___016486_ = (1U & (0x53000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_ha692919d__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b61__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058514_))));
    vlSelf->wasmetal_core__DOT___058496_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058495_))));
    vlSelf->wasmetal_core__DOT___016491_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h5bac664e__0)))));
    vlSelf->wasmetal_core__DOT___058485_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h5bac664e__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b45__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058503_))));
    vlSelf->wasmetal_core__DOT___058452_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016348_)))
                                                    : 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___016171_))))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h8cd41eba__0))))));
    vlSelf->wasmetal_core__DOT___058540_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058450_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058452_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058451_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058449_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b13__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058452_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058451_))))));
    vlSelf->wasmetal_core__DOT___016487_ = (1U & (0x53000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h2de7cdff__0)))));
    vlSelf->wasmetal_core__DOT___058472_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & (IData)(
                                                      (0xf0f500003300ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_hbbab100a__0))))));
    __VdfgTmp_hdfa5ed14__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 4U) | (IData)(__VdfgTmp_hbbab100a__0));
    vlSelf->wasmetal_core__DOT___058459_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h27477f57__0)))))));
    wasmetal_core__DOT___016489_ = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                              & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                  ? 
                                                 (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___016222_))
                                                  : 
                                                 (0xf0fff11U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb91597d0__0))))) 
                                          & (IData)(
                                                    (0xfff0fff0ffaaffccULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                             << 3U) 
                                                            | (IData)(__VdfgTmp_h27477f57__0))))))));
    vlSelf->__VdfgTmp_h32c10bb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___058488_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058487_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b20__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058471_))));
    vlSelf->wasmetal_core__DOT____Vcellout___134187___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d) 
             << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036996_) 
                        << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d)
                 ? (IData)(wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134187___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036992_)))));
    wasmetal_core__DOT___043050_ = ((IData)(wasmetal_core__DOT___043064_)
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___043063_)
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___043062_)
                                             ? ((1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb36cd122__0)))
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___043060_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___017861_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017860_)
                                                    ? 
                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043059_)) 
                                                    & (IData)(vlSelf->wasmetal_core__DOT___043051_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___043052_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___043053_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___043054_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043055_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___043056_))
                                         : (IData)(vlSelf->wasmetal_core__DOT___043057_))
                                     : (IData)(wasmetal_core__DOT___043058_));
    __VdfgTmp_hadd1132f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017815_) 
                               << 5U) | ((0x10U & (
                                                   (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                   << 4U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___017813_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h5fca0975__0))));
    vlSelf->__VdfgTmp_hb0235e8a__0 = (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016503_));
    vlSelf->wasmetal_core__DOT___018963_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019037_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019050_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057882_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019079_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057844_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019120_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057872_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___060393_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b31__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016492_))));
    vlSelf->wasmetal_core__DOT___060014_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058475_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058476_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b23__05d 
        = (1U & (0xe1U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(wasmetal_core__DOT___058476_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058475_)))));
    vlSelf->wasmetal_core__DOT___058434_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016300_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___016299_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016302_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h31cd2dad__0)))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___016301_)))));
    vlSelf->wasmetal_core__DOT___058499_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058434_))));
    vlSelf->__VdfgTmp_h45a50d9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___058434_)));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b29__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058491_))));
    wasmetal_core__DOT___016490_ = (1U & ((~ (IData)(wasmetal_core__DOT___006817_)) 
                                          & (IData)(
                                                    (0xfff0fff0ffaaffccULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                             << 3U) 
                                                            | (IData)(__VdfgTmp_h84b4ffe6__0))))))));
    vlSelf->wasmetal_core__DOT___051562_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                      ? 
                                                     (0xcdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___006817_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006816_))))
                                                      : 
                                                     (0xf0f0f5f3U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___006817_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h94e3de73__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b47__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058505_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b15__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058456_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058455_))))));
    vlSelf->wasmetal_core__DOT___058435_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___016316_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016316_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016315_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (0xacU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6fab7a0a__0))
                                                    : 
                                                   (7U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h8d40b9ee__0)))));
    vlSelf->__VdfgTmp_h9e4b4f68__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058435_));
    wasmetal_core__DOT___058446_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                               ? (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016336_)))
                                               : (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h76f112be__0))))
                                           : ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                              & (1U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___016249_))))));
    vlSelf->wasmetal_core__DOT___058447_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058446_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058445_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058438_)))));
    vlSelf->__VdfgTmp_h9aa3e645__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058429_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b51__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058466_)))));
    vlSelf->wasmetal_core__DOT___058467_ = (1U & (IData)(
                                                         (0x5505cc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058466_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016336_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058444_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b34__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h99986d68__0))));
    vlSelf->__VdfgTmp_ha5a16447__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h99986d68__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b50__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1bc2f6b9__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b18__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058465_))));
    vlSelf->wasmetal_core__DOT___058512_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___016488_))));
    vlSelf->__VdfgTmp_h696b299a__0 = (((IData)(wasmetal_core__DOT___058481_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058482_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b26__05d 
        = (1U & (0x1eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(wasmetal_core__DOT___058482_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058481_)))));
    vlSelf->wasmetal_core__DOT___058510_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0xf1f1ff0000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_h90b76d4b__0))))));
    vlSelf->wasmetal_core__DOT___058474_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & (IData)(
                                                      (0xf1f10000ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_h90b76d4b__0))))));
    vlSelf->wasmetal_core__DOT___058493_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (2U 
                                                   >> (IData)(wasmetal_core__DOT___016385_))
                                                : (IData)(
                                                          (0xffffff00fffffff1ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                             << 5U) 
                                                            | (((IData)(wasmetal_core__DOT___016385_) 
                                                                << 4U) 
                                                               | (IData)(__VdfgTmp_h1b5253bd__0)))))));
    wasmetal_core__DOT___016358_ = (1U & (0xff00fff1U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                               << 4U) 
                                              | (IData)(__VdfgTmp_h1b5253bd__0))));
    if (vlSelf->wasmetal_core__DOT___006819_) {
        vlSelf->wasmetal_core__DOT___058430_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___016268_))));
        vlSelf->wasmetal_core__DOT___058436_ = (1U 
                                                & (0x32U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016325_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006816_)))));
        vlSelf->wasmetal_core__DOT___058501_ = (1U 
                                                & (0xf0f000eeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016336_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h64b5570f__0))))));
        vlSelf->wasmetal_core__DOT___058439_ = (1U 
                                                & (0x32U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016328_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016173_)))));
        vlSelf->wasmetal_core__DOT___058457_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (0x32U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 2U) 
                                                     | (((IData)(wasmetal_core__DOT___016368_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___006816_))))
                                                    : 
                                                   (0xf0f0a0cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 3U) 
                                                        | (((IData)(wasmetal_core__DOT___016368_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h94e3de73__0)))))));
        vlSelf->wasmetal_core__DOT___058500_ = (1U 
                                                & (0x32U 
                                                   >> (IData)(__VdfgTmp_hf9598b43__0)));
        wasmetal_core__DOT___058442_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                              & (0xcdU 
                                                 >> (IData)(__VdfgTmp_hf9598b43__0))));
        wasmetal_core__DOT___058431_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___016278_)));
        vlSelf->wasmetal_core__DOT___058454_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                & (IData)(wasmetal_core__DOT___016358_));
    } else {
        vlSelf->wasmetal_core__DOT___058430_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                   & (0xf0f53300U 
                                                      >> (IData)(__VdfgTmp_hcfc69af2__0))));
        vlSelf->wasmetal_core__DOT___058436_ = (1U 
                                                & (0xacffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_ha692919d__0))));
        vlSelf->wasmetal_core__DOT___058501_ = (1U 
                                                & (0xbU 
                                                   >> (IData)(__VdfgTmp_h5bac664e__0)));
        vlSelf->wasmetal_core__DOT___058439_ = (1U 
                                                & (0xacffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_h2de7cdff__0))));
        vlSelf->wasmetal_core__DOT___058457_ = (1U 
                                                & (1U 
                                                   >> (IData)(wasmetal_core__DOT___016368_)));
        vlSelf->wasmetal_core__DOT___058500_ = (1U 
                                                & (0xbffU 
                                                   >> (IData)(__VdfgTmp_h4fc19847__0)));
        wasmetal_core__DOT___058442_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                              & (0xf400U 
                                                 >> (IData)(__VdfgTmp_h4fc19847__0))));
        wasmetal_core__DOT___058431_ = (1U & (0xf0accffU 
                                              >> (IData)(__VdfgTmp_hdfa5ed14__0)));
        vlSelf->wasmetal_core__DOT___058454_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___016357_));
    }
    wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127946___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027374_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027373_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027372_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027371_)))) 
           ^ (((IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027305_)))));
    vlSelf->wasmetal_core__DOT___027309_ = ((IData)(vlSelf->wasmetal_core__DOT___027374_)
                                             ? (IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b47__05d));
    vlSelf->wasmetal_core__DOT___011738_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff55550f0f3333ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d)) 
           & (IData)(wasmetal_core__DOT___033456_));
    wasmetal_core__DOT___128242___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030264_)
            ? (IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d) {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024026_;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023764_)
            ? (IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d));
    vlSelf->__VdfgTmp_he93f6ca8__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005955_));
    vlSelf->__VdfgTmp_h263b1cf5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005788_));
    vlSelf->__VdfgTmp_h7a46858f__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005889_));
    vlSelf->__VdfgTmp_h0afc15e4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005795_));
    vlSelf->wasmetal_core__DOT____Vcellout___127428___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022483_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022482_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022481_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022480_)))) 
           ^ (((IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127428___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022536_)))));
    vlSelf->wasmetal_core__DOT___022541_ = ((IData)(vlSelf->wasmetal_core__DOT___022483_) 
                                            & (IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013648_) 
           & (IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127476___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___022809_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___022807_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___022806_))) 
                                                   ^ 
                                                   ((8U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___022809_)
                                                          ? (IData)(wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__)
                                                          : 
                                                         (1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h7695852b__0))) 
                                                        << 3U)) 
                                                    | (((IData)(wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127476___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022774_)))));
    vlSelf->wasmetal_core__DOT___059548_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005745_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127470___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059585_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005875_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h916673f4__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127470___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___059834_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___003811_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127473___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059863_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___003808_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127473___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059950_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005855_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059511_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005921_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127470___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___018685_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006204_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127472___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___059896_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003805_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127473___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___060008_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O) 
                                                                                >> 3U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060038_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h36468d91__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060062_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060087_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O) 
                                                                                >> 2U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060107_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O) 
                                                                                >> 3U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    wasmetal_core__DOT___059977_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((1U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT___059635_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006015_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127471___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059657_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006085_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbed85956__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127471___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059923_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003806_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059610_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006092_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he0f48724__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127471___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059210_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005731_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127469___O)))))))))))));
    wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006015_) 
           & (IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hb5f365d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058506_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b52__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058508_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b36__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058497_))));
    vlSelf->wasmetal_core__DOT___058533_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058430_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058429_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b4__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058430_))));
    vlSelf->__VdfgTmp_h7cadd68e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016486_));
    vlSelf->wasmetal_core__DOT___058478_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058477_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016486_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006821_)))));
    vlSelf->wasmetal_core__DOT___058534_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058435_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058436_))))));
    vlSelf->__VdfgTmp_hcb1f4515__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058436_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b35__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058496_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b59__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016491_))));
    vlSelf->__VdfgTmp_h0a35847a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058501_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b27__05d 
        = (1U & (0x1eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058485_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058484_)))));
    vlSelf->__VdfgTmp_h49fa4f4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016487_));
    vlSelf->__VdfgTmp_h98e96722__0 = (((IData)(vlSelf->wasmetal_core__DOT___058439_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006821_));
    vlSelf->__VdfgTmp_h8bfce2cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058439_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b21__05d 
        = (1U & (0xf40bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058472_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016278_))))));
    vlSelf->wasmetal_core__DOT___058509_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0xf0f5330000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (IData)(__VdfgTmp_hdfa5ed14__0)))));
    vlSelf->wasmetal_core__DOT___058507_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058459_))));
    vlSelf->wasmetal_core__DOT___058461_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0f0553300000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016222_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016219_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006891_)))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___016220_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058459_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006821_)))));
    vlSelf->__VdfgTmp_ha19857b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016489_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b28__05d 
        = (1U & (0x1eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h32c10bb5__0))));
    vlSelf->wasmetal_core__DOT___060612_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134187___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___018964_))))));
    wasmetal_core__DOT___017915_ = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043035_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059072_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___043050_))))));
    vlSelf->wasmetal_core__DOT___018081_ = ((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                            & (IData)(
                                                      (0xffffff80ffff0000ULL 
                                                       >> (IData)(__VdfgTmp_hadd1132f__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b38__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058499_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b16__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058457_))));
    vlSelf->wasmetal_core__DOT___016482_ = ((IData)(vlSelf->wasmetal_core__DOT___016492_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___016491_)) 
                                               & (IData)(
                                                         (0x1000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___016490_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___016489_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___016488_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016487_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016486_))))))))));
    vlSelf->__VdfgTmp_h718e5977__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016490_));
    vlSelf->__VdfgTmp_h15403f4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051562_));
    vlSelf->__VdfgTmp_h459e7eca__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9e4b4f68__0));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b11__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058447_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b19__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058467_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b58__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058512_))));
    wasmetal_core__DOT___058536_ = (1U & (0xeU >> (
                                                   ((IData)(wasmetal_core__DOT___058476_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058475_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h696b299a__0)))));
    vlSelf->__VdfgTmp_h27b7e067__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058500_));
    vlSelf->wasmetal_core__DOT___058542_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058442_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058446_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058441_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058445_)))))));
    vlSelf->wasmetal_core__DOT___058443_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058442_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058441_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058438_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b54__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058510_))));
    wasmetal_core__DOT___058537_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058474_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___058472_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058473_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___016278_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b22__05d 
        = (1U & (0xf40bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058474_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058473_))))));
    vlSelf->wasmetal_core__DOT___058538_ = (1U & (0xf00011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058493_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058490_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058492_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058489_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b30__05d 
        = (1U & (0xf40bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058493_) 
                                         << 2U) | (IData)(vlSelf->__VdfgTmp_h4af9777a__0)))));
    vlSelf->wasmetal_core__DOT___058504_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (IData)(wasmetal_core__DOT___016358_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___016357_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127962___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
           ^ (((IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027435_)))));
    vlSelf->wasmetal_core__DOT___027440_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063316_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063318_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063320_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063322_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___127947___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027375_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027309_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b48__05d));
    wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)) 
           & (IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128242___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030266_)
            ? (IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d) {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127598___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023765_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023764_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023762_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023761_)))) 
           ^ (((IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127598___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023697_)))));
    vlSelf->wasmetal_core__DOT___023702_ = ((IData)(vlSelf->wasmetal_core__DOT___023765_)
                                             ? (IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d));
    vlSelf->wasmetal_core__DOT___058796_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127632___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he93f6ca8__0))))));
    vlSelf->wasmetal_core__DOT___023769_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he93f6ca8__0))));
    vlSelf->wasmetal_core__DOT___058807_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127632___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h263b1cf5__0))))));
    vlSelf->wasmetal_core__DOT___023768_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h263b1cf5__0))));
    vlSelf->wasmetal_core__DOT___023767_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7a46858f__0))));
    vlSelf->wasmetal_core__DOT___058866_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0afc15e4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d))));
    vlSelf->wasmetal_core__DOT___058789_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127632___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0afc15e4__0))))));
    vlSelf->wasmetal_core__DOT___023766_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0afc15e4__0))));
    vlSelf->__VdfgTmp_h9bddaa79__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                    >> 1U)));
    vlSelf->__VdfgTmp_h9c9f5aae__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_h9be9fa04__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O)));
    vlSelf->wasmetal_core__DOT___023195_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022480_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O))))));
    vlSelf->wasmetal_core__DOT___023194_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022481_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___023193_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022482_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            >> 2U))))));
    __VdfgTmp_h9c980b03__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                               >> 3U)));
    vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022484_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022541_));
    vlSelf->wasmetal_core__DOT____Vcellout___127570___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013666_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h41b1ef3d__0))) 
           ^ (((IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127570___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023600_)))));
    vlSelf->wasmetal_core__DOT___023605_ = ((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                                            & (IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___060134_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd540c232__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127476___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060158_ = (1U & (IData)(
                                                         (0xf0fcf0faULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127476___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___060190_ = (1U & (IData)(
                                                         (0xf0fcf0fa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7695852b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127476___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059979_ = (1U & (IData)(
                                                         (0xffff44f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051509_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059977_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005770_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127553___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006092_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005982_)))) 
           ^ (((IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127553___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023479_)))));
    vlSelf->wasmetal_core__DOT___023484_ = ((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                            & (IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b48__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hb5f365d2__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b56__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h7cadd68e__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b24__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058478_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b40__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hcb1f4515__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b8__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hcb1f4515__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b43__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0a35847a__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b57__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h49fa4f4c__0))));
    vlSelf->__VdfgTmp_h963234d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058480_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h49fa4f4c__0)))));
    vlSelf->wasmetal_core__DOT___058535_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058457_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058440_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h98e96722__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b41__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8bfce2cf__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b9__05d 
        = (1U & (0xf10eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058440_) 
                                         << 2U) | (IData)(vlSelf->__VdfgTmp_h8bfce2cf__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b53__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058509_))));
    vlSelf->wasmetal_core__DOT___016481_ = (1U & (0x80ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058497_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058427_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___058431_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___058495_)))))));
    vlSelf->wasmetal_core__DOT___058498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058431_))));
    vlSelf->wasmetal_core__DOT___058432_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058431_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b49__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058507_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b17__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058461_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b33__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_ha19857b4__0))));
    vlSelf->__VdfgTmp_hadae8e7b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha19857b4__0))));
    wasmetal_core__DOT___017925_ = (1U & ((1U & (4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___005711_))))
                                           ? (1U >> 
                                              (1U & 
                                               (8U 
                                                >> (IData)(vlSelf->__VdfgTmp_hff203b22__0))))
                                           : ((1U & 
                                               (0xf800U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043035_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___043050_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___059072_))))))
                                               ? (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017813_)))
                                               : (IData)(
                                                         (0x7f00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017813_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___017915_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h5fca0975__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b32__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h718e5977__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b42__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h27b7e067__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b10__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058443_))));
    vlSelf->wasmetal_core__DOT___016472_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058537_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058471_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058467_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058465_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058461_)))))))));
    vlSelf->wasmetal_core__DOT___016483_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058505_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058504_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058503_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058502_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b46__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058504_))));
    vlSelf->wasmetal_core__DOT___058541_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058454_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058456_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058455_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x11000fU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hecea8d31__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b14__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058454_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x11000fU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hecea8d31__0))))))));
    vlSelf->wasmetal_core__DOT___044850_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127962___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127962___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h06766dbc__0)))))))))));
    vlSelf->wasmetal_core__DOT___044874_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h06766dbc__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127962___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d))))))));
    vlSelf->__VdfgTmp_h4257ff1b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127962___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d)))));
    vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027440_));
    wasmetal_core__DOT___127947___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027376_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127947___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b49__05d));
    wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d)) 
           & (IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128242___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030267_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030266_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030264_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030263_)))) 
           ^ (((IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030198_)))));
    vlSelf->wasmetal_core__DOT___030203_ = ((IData)(vlSelf->wasmetal_core__DOT___030267_)
                                             ? (IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d) {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d;
        vlSelf->wasmetal_core__DOT___023903_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023903_ = vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023766_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023702_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d));
    vlSelf->__VdfgTmp_hf628d2c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h9c980b03__0)));
    vlSelf->__VdfgTmp_h04d557bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h9c980b03__0)))));
    if (vlSelf->wasmetal_core__DOT___005715_) {
        vlSelf->wasmetal_core__DOT___023203_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1ea78a97__0))));
        vlSelf->wasmetal_core__DOT___023198_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hbca1455c__0))));
        vlSelf->wasmetal_core__DOT___023192_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04d557bc__0))));
    } else {
        vlSelf->wasmetal_core__DOT___023203_ = (1U 
                                                & (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h098b01ee__0)));
        vlSelf->wasmetal_core__DOT___023198_ = (1U 
                                                & (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_haeb15d33__0)));
        vlSelf->wasmetal_core__DOT___023192_ = (1U 
                                                & (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf628d2c5__0)));
    }
    vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022485_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013658_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023605_));
    vlSelf->wasmetal_core__DOT___049002_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005982_))));
    vlSelf->wasmetal_core__DOT___050100_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003810_))))));
    vlSelf->wasmetal_core__DOT___006734_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h27384d82__0)))));
    vlSelf->wasmetal_core__DOT___050093_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006092_))));
    vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005875_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023484_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b37__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058498_))));
    wasmetal_core__DOT___016471_ = (1U & (IData)((0xe00000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058535_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058534_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058533_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058432_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058434_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058470_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b5__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058432_))));
    wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0))) 
                 & (9U >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0))));
    vlSelf->wasmetal_core__DOT___060212_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((~ (IData)(vlSelf->wasmetal_core__DOT___017185_)) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___018857_)
                                                             ? (IData)(
                                                                       (0xefffffff2000a000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                                          << 5U) 
                                                                         | ((0x10U 
                                                                             & ((IData)(
                                                                                (0x7f0000ffffULL 
                                                                                >> (IData)(__VdfgTmp_hadd1132f__0))) 
                                                                                << 4U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___017925_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005711_))))))))
                                                             : 
                                                            (0xeU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))))));
    wasmetal_core__DOT___059077_ = (1U & (IData)((0x3222bfff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___017925_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___018081_)))))))));
    vlSelf->__VdfgTmp_h2082f5a2__0 = ((8U & ((IData)(
                                                     (0x7f0000ffffULL 
                                                      >> (IData)(__VdfgTmp_hadd1132f__0))) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                          << 2U) | 
                                         (((IData)(wasmetal_core__DOT___017925_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017924_))));
    wasmetal_core__DOT___018349_ = (1U & (0x40U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0x7f0000ffffULL 
                                                         >> (IData)(__VdfgTmp_hadd1132f__0))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___017925_)))));
    vlSelf->wasmetal_core__DOT___018082_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___017925_))));
    __VdfgTmp_h4f0a13d1__0 = ((2U & ((IData)((0x1000000000000000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___058542_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058541_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058540_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xcc0dULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___051562_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058477_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016486_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058480_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016487_)))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h99986d68__0)) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_ha19857b4__0)))))))))) 
                                     << 1U)) | (1U 
                                                & (0xeee00000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___058538_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058484_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058485_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h32c10bb5__0)))))));
    vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127947___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027378_)
            ? (IData)(wasmetal_core__DOT___127947___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b50__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128543___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033456_)))));
    vlSelf->wasmetal_core__DOT___033460_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)) 
                                            & (IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128243___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030268_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030203_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127633___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024026_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d) {
        vlSelf->wasmetal_core__DOT___024030_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d;
        vlSelf->wasmetal_core__DOT___127603___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024030_ = vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127603___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023903_;
    }
    vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023767_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127617___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023899_)))));
    wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022486_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013719_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___050121_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049002_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___006695_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050097_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050096_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050095_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006676_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050094_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050093_)))))))));
    vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005745_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128862___DOT__CO__BRA__2__KET__ 
        = ((9U >> (IData)(vlSelf->__VdfgTmp_ha5a16447__0)) 
           & (IData)(wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___059925_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059923_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059917_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                : 
                                                                               (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3222bfff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___017925_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018081_)))))))))))))))));
    vlSelf->__VdfgTmp_h3f27e0dd__0 = (((IData)(wasmetal_core__DOT___018349_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018081_)));
    vlSelf->__VdfgTmp_h2b45c525__0 = (((IData)(wasmetal_core__DOT___018349_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018081_)));
    vlSelf->wasmetal_core__DOT___059220_ = (1U & (IData)(
                                                         (0x11fff0ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059210_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017174_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbb0b0bU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                              << 3U) 
                                                                             | (((IData)(wasmetal_core__DOT___018349_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017185_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___059077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xbeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                 ? (IData)(
                                                                                (0xffff30f08aaa0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                 : 
                                                                                (0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017175_)))))))));
    vlSelf->__VdfgTmp_h3c24edc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018080_)));
    vlSelf->wasmetal_core__DOT___017947_ = (1U & ((1U 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016474_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                             >> 1U)))))
                                                   ? (IData)(
                                                             (0x7fff0000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((0x4fU 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016496_) 
                                                                   << 4U) 
                                                                  | (((IData)(wasmetal_core__DOT___016471_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016472_) 
                                                                         << 2U) 
                                                                        | (IData)(__VdfgTmp_h4f0a13d1__0)))))))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (1U 
                                                    & (0x4fU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))));
    vlSelf->wasmetal_core__DOT___017946_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016474_)
                                                   ? 
                                                  ((~ 
                                                    (0x4fU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))) 
                                                   & (IData)(
                                                             (0x7fffffff00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016473_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016472_) 
                                                                   << 4U) 
                                                                  | (((IData)(wasmetal_core__DOT___016471_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & (((0x8000ffffU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058434_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058501_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058500_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058435_)))))) 
                                                                             & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016483_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016482_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016481_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40ff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058543_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058436_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058439_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058506_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058508_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058459_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058466_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058463_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058511_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058510_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058509_))))))))))))) 
                                                                            << 2U)) 
                                                                        | (IData)(__VdfgTmp_h4f0a13d1__0))))))))
                                                   : 
                                                  (~ 
                                                   (0x4fU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))));
    vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127947___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027379_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027378_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027376_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027375_)))) 
           ^ (((IData)(wasmetal_core__DOT___127947___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127947___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127947___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027309_)))));
    vlSelf->wasmetal_core__DOT___027314_ = ((IData)(vlSelf->wasmetal_core__DOT___027379_)
                                             ? (IData)(wasmetal_core__DOT___127947___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b51__05d));
    vlSelf->wasmetal_core__DOT___057498_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d)))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                                >> 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d))))))))))));
    vlSelf->wasmetal_core__DOT___057319_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d))))))))))));
    vlSelf->wasmetal_core__DOT___128544___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033460_));
    vlSelf->wasmetal_core__DOT___128243___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030269_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128243___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d));
    vlSelf->wasmetal_core__DOT___127619___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___024030_));
    vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023768_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d));
    vlSelf->__VdfgTmp_h7be661a5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005948_));
    vlSelf->__VdfgTmp_h6202353f__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005809_));
    vlSelf->__VdfgTmp_hd2dd278c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005882_));
    vlSelf->__VdfgTmp_hdd48e33a__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005802_));
    vlSelf->wasmetal_core__DOT____Vcellout___127429___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022487_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022486_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022484_)))) 
           ^ (((IData)(wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022541_)))));
    vlSelf->wasmetal_core__DOT___022545_ = ((IData)(vlSelf->wasmetal_core__DOT___022487_) 
                                            & (IData)(wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013701_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005921_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128862___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                   << 3U)) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_ha5a16447__0)) 
                                     << 2U)) | ((2U 
                                                 & ((9U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128862___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0))) 
                                          << 1U)))));
}
