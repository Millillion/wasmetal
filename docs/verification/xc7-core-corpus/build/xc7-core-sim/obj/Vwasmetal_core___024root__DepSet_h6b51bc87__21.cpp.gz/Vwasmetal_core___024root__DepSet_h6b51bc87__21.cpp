#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__19(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__19\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006729_;
    wasmetal_core__DOT___006729_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006743_;
    wasmetal_core__DOT___006743_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022514_;
    wasmetal_core__DOT___022514_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022660_;
    wasmetal_core__DOT___022660_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023457_;
    wasmetal_core__DOT___023457_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023578_;
    wasmetal_core__DOT___023578_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026608_;
    wasmetal_core__DOT___026608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026743_;
    wasmetal_core__DOT___026743_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026878_;
    wasmetal_core__DOT___026878_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027078_;
    wasmetal_core__DOT___027078_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027405_;
    wasmetal_core__DOT___027405_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___028718_;
    wasmetal_core__DOT___028718_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029026_;
    wasmetal_core__DOT___029026_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029061_;
    wasmetal_core__DOT___029061_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029062_;
    wasmetal_core__DOT___029062_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029063_;
    wasmetal_core__DOT___029063_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029064_;
    wasmetal_core__DOT___029064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029143_;
    wasmetal_core__DOT___029143_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031029_;
    wasmetal_core__DOT___031029_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033425_;
    wasmetal_core__DOT___033425_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034362_;
    wasmetal_core__DOT___034362_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036630_;
    wasmetal_core__DOT___036630_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036842_;
    wasmetal_core__DOT___036842_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036843_;
    wasmetal_core__DOT___036843_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036844_;
    wasmetal_core__DOT___036844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056735_;
    wasmetal_core__DOT___056735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057091_;
    wasmetal_core__DOT___057091_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057758_;
    wasmetal_core__DOT___057758_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059083_;
    wasmetal_core__DOT___059083_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063168_;
    wasmetal_core__DOT___063168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063174_;
    wasmetal_core__DOT___063174_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063180_;
    wasmetal_core__DOT___063180_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063186_;
    wasmetal_core__DOT___063186_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063192_;
    wasmetal_core__DOT___063192_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063198_;
    wasmetal_core__DOT___063198_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063204_;
    wasmetal_core__DOT___063204_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063210_;
    wasmetal_core__DOT___063210_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127436___O;
    wasmetal_core__DOT____Vcellout___127436___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127437___O;
    wasmetal_core__DOT____Vcellout___127437___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127482___O;
    wasmetal_core__DOT____Vcellout___127482___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127611___O;
    wasmetal_core__DOT____Vcellout___127611___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127870___O;
    wasmetal_core__DOT____Vcellout___127870___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127970___O;
    wasmetal_core__DOT____Vcellout___127970___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128062___O;
    wasmetal_core__DOT____Vcellout___128062___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128107___O;
    wasmetal_core__DOT____Vcellout___128107___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128108___O;
    wasmetal_core__DOT____Vcellout___128108___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127921___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127921___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127922___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127922___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127922___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127922___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127922___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127922___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127939___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127939___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127939___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127939___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127939___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127939___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128071___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128071___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128072___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128072___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128072___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128072___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128072___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128072___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128080___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128080___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128080___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128080___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128081___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128081___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128081___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128081___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128090___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128090___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128090___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128090___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128090___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128090___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128098___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128098___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128098___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128098___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128098___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128098___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128099___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128099___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128099___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128099___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128099___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128099___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128108___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128108___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128108___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128108___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128108___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128108___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128115___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128115___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128115___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128115___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128115___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128115___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128116___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128116___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128116___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128116___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128116___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128116___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128125___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128125___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128125___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128125___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128125___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128125___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128126___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128126___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128126___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128126___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128126___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128126___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128134___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128134___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128134___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128134___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128134___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128134___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128145___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128145___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128145___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128145___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128145___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128145___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128146___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128146___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128146___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128146___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128328___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128328___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128328___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128328___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128328___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128328___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128329___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128329___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128329___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128329___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128438___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128438___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128438___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128438___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128439___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128439___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128439___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128439___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128652___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128652___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128652___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128652___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128652___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128652___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128666___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128666___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128666___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128666___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128667___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128667___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128667___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128667___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128667___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128667___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h5013759b__0;
    __VdfgTmp_h5013759b__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd2b66780__0;
    __VdfgTmp_hd2b66780__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8a9ed06f__0;
    __VdfgTmp_h8a9ed06f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h29c879e7__0;
    __VdfgTmp_h29c879e7__0 = 0;
    CData/*2:0*/ __VdfgTmp_ha1bf32a7__0;
    __VdfgTmp_ha1bf32a7__0 = 0;
    CData/*2:0*/ __VdfgTmp_hfc0d441b__0;
    __VdfgTmp_hfc0d441b__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6ec4eab1__0;
    __VdfgTmp_h6ec4eab1__0 = 0;
    CData/*1:0*/ __VdfgTmp_h635c29e2__0;
    __VdfgTmp_h635c29e2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h986ee838__0;
    __VdfgTmp_h986ee838__0 = 0;
    // Body
    __VdfgTmp_h5013759b__0 = ((2U & ((0x69969669U >> 
                                      ((0x10U & ((1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                 << 4U)) 
                                       | (((IData)(vlSelf->wasmetal_core__DOT___072217_) 
                                           << 3U) | (IData)(vlSelf->__VdfgTmp_h15cdecdf__0)))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xbfab2a022a02bfabULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___072212_) 
                                                             << 5U) 
                                                            | ((0x10U 
                                                                & ((9U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_ha7d2f4a8__0)) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___072198_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___072199_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0x96U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h39564552__0)) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (0xb2U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h39564552__0))))))))))));
    wasmetal_core__DOT___036842_ = (1U & (0x4db2U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___036629_) 
                                            << 3U) 
                                           | (IData)(vlSelf->__VdfgTmp_h1399f995__0))));
    wasmetal_core__DOT___036630_ = (1U & (0x96U >> 
                                          ((4U & ((0xe8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he9efeda2__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___072214_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___072213_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128549___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033480_)))));
    vlSelf->wasmetal_core__DOT___033421_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___067326_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9cfb33d2__0)))));
    vlSelf->wasmetal_core__DOT___067172_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7884ece4__0))))));
    wasmetal_core__DOT___056735_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                    & (IData)((0xf4f4f4f4ffffff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011783_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011782_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdf888c66__0)))))));
    vlSelf->wasmetal_core__DOT___012206_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056988_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056987_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xfaf3U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5b3d01ff__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056985_)))))))));
    vlSelf->wasmetal_core__DOT___065920_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065919_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012216_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012215_)))))));
    vlSelf->__VdfgTmp_h895eb4d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___057167_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057162_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057161_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___011047_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x503U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1c56b6c5__0)))))));
    vlSelf->wasmetal_core__DOT___066103_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012576_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h186e290b__0))));
    vlSelf->__VdfgTmp_h4eea07db__0 = (((IData)(vlSelf->wasmetal_core__DOT___012752_) 
                                       << 3U) | ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                   & (IData)(
                                                             (0x55550f0f00ff3333ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___011299_))))))))) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___012558_))));
    vlSelf->wasmetal_core__DOT___065210_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012567_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h07056034__0))))));
    vlSelf->wasmetal_core__DOT___067913_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012567_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->wasmetal_core__DOT___057330_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 3U)) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                           & (IData)(
                                                                     (0xff33ff00f0f0f5f5ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012576_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___012608_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07e757d2__0)))))))) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xf4U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057322_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xf0feU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2163f181__0)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___057320_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___012567_)
                                                                    : 
                                                                   (1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h07056034__0)))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012620_))))))))));
    vlSelf->wasmetal_core__DOT___067472_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3545ce03__0)))));
    vlSelf->wasmetal_core__DOT___012894_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057447_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3545ce03__0))))))));
    vlSelf->wasmetal_core__DOT___011949_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011907_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    __VdfgTmp_h8a9ed06f__0 = (((IData)(vlSelf->wasmetal_core__DOT___011908_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011907_));
    vlSelf->wasmetal_core__DOT___066148_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hca606f65__0))))));
    vlSelf->wasmetal_core__DOT___057397_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf0fff1100000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                           << 4U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hca606f65__0))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xf4U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057388_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & (((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                                             & (IData)(
                                                                                (0xff00ffaafff0fff3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012806_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012805_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012804_))))))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___057386_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___012818_)
                                                                    : 
                                                                   (1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___012810_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___012809_))))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012811_))))))))));
    vlSelf->wasmetal_core__DOT___065719_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011556_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_haf8803a1__0))))));
    vlSelf->wasmetal_core__DOT___068115_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011556_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    if (vlSelf->wasmetal_core__DOT___010376_) {
        vlSelf->wasmetal_core__DOT___056628_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___011556_)
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_haf8803a1__0))));
        vlSelf->wasmetal_core__DOT___056783_ = (1U 
                                                & (0xf0f000eeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011951_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011949_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d9b5f2a__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___056628_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011549_)));
        vlSelf->wasmetal_core__DOT___056783_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011950_)));
    }
    vlSelf->wasmetal_core__DOT___064529_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd6248a2d__0))));
    vlSelf->wasmetal_core__DOT___068090_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065632_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->wasmetal_core__DOT___056483_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056482_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf72e2656__0)))))));
    vlSelf->wasmetal_core__DOT___056464_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0xf0f00ff11111111ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011025_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011024_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he19177ad__0))))))));
    __VdfgTmp_hd2b66780__0 = (((IData)(vlSelf->wasmetal_core__DOT___011025_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011024_));
    vlSelf->__VdfgTmp_h8267970c__0 = (((IData)(vlSelf->wasmetal_core__DOT___012388_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012387_));
    wasmetal_core__DOT___057091_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012388_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___065434_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013114_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8088f5ad__0))))));
    vlSelf->wasmetal_core__DOT___057542_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057538_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4d745f43__0))))))));
    vlSelf->wasmetal_core__DOT___057661_ = (1U & (IData)(
                                                         (0xfafc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha052db73__0))))))));
    vlSelf->wasmetal_core__DOT___056908_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012255_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->__VdfgTmp_he65514a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___012256_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012255_));
    wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005882_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013796_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___054084_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128097___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054088_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128097___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054092_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128097___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054096_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128097___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    wasmetal_core__DOT___128098___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028644_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028610_)
            : (IData)(vlSelf->wasmetal_core__DOT___004004_));
    vlSelf->wasmetal_core__DOT____Vcellout___128132___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029056_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029055_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029085_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029084_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029051_)))));
    vlSelf->wasmetal_core__DOT___029022_ = ((IData)(vlSelf->wasmetal_core__DOT___029056_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___029060_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001580_))));
    vlSelf->wasmetal_core__DOT___029059_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001568_))));
    vlSelf->wasmetal_core__DOT___029058_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001536_))));
    vlSelf->wasmetal_core__DOT___029057_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001524_))));
    wasmetal_core__DOT___128125___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028956_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028922_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b16__05d));
    wasmetal_core__DOT___128438___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001624_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001624_)
            : (IData)(vlSelf->wasmetal_core__DOT___128438___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128106___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028747_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028746_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028745_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028744_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028710_)))));
    vlSelf->wasmetal_core__DOT___028714_ = ((IData)(vlSelf->wasmetal_core__DOT___028747_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->wasmetal_core__DOT____Vcellout___127886___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026669_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026668_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026667_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026666_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026600_)))));
    vlSelf->wasmetal_core__DOT___026604_ = ((IData)(vlSelf->wasmetal_core__DOT___026669_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->wasmetal_core__DOT___045245_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054342_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___045221_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070694_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054346_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 9U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054342_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070693_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127937___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027139_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027138_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027137_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027136_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027070_)))));
    vlSelf->wasmetal_core__DOT___027074_ = ((IData)(vlSelf->wasmetal_core__DOT___027139_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d));
    wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026566_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127869___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001537_));
    vlSelf->wasmetal_core__DOT___044973_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070796_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___044949_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070797_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054345_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 9U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054341_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070796_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127920___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026939_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026938_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026937_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026936_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026870_)))));
    vlSelf->wasmetal_core__DOT___026874_ = ((IData)(vlSelf->wasmetal_core__DOT___026939_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->wasmetal_core__DOT____Vcellout___127903___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hb96516e6__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_he974eeb2__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5a182b30__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h3daf64ed__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026735_)))));
    vlSelf->wasmetal_core__DOT___026739_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb96516e6__0)))
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->wasmetal_core__DOT___030099_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6e8006f3__0)))));
    vlSelf->wasmetal_core__DOT___030227_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6e8006f3__0)))));
    vlSelf->wasmetal_core__DOT___030098_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h25861896__0)))));
    vlSelf->wasmetal_core__DOT___030226_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h25861896__0)))));
    vlSelf->wasmetal_core__DOT___030097_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8f0618c__0)))));
    vlSelf->wasmetal_core__DOT___030225_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8f0618c__0)))));
    vlSelf->wasmetal_core__DOT___030096_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb05848c8__0)))));
    vlSelf->wasmetal_core__DOT___030224_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb05848c8__0)))));
    wasmetal_core__DOT___128666___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001624_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128666___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128233___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030095_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030094_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030124_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030123_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030090_)))));
    vlSelf->wasmetal_core__DOT___030063_ = ((IData)(vlSelf->wasmetal_core__DOT___030095_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128247___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030223_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030222_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030284_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030283_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030218_)))));
    vlSelf->wasmetal_core__DOT___030159_ = ((IData)(vlSelf->wasmetal_core__DOT___030223_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d));
    vlSelf->wasmetal_core__DOT___063147_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063144_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063143_)))))));
    vlSelf->wasmetal_core__DOT___063153_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063150_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063149_)))))));
    vlSelf->wasmetal_core__DOT___063159_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063156_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063155_)))))));
    vlSelf->wasmetal_core__DOT___063165_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063162_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063161_)))))));
    vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028289_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028224_));
    vlSelf->wasmetal_core__DOT___044881_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O) 
                                                       >> 1U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027466_));
    vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027337_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b13__05d));
    wasmetal_core__DOT____Vcellout___127436___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hadeaba1a__0))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022506_)))));
    vlSelf->wasmetal_core__DOT___022510_ = ((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013692_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023763_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d));
    vlSelf->__VdfgTmp_hd6d3a7f5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->__VdfgTmp_h96e8cece__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005745_));
    vlSelf->__VdfgTmp_h3a9f8450__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005921_));
    vlSelf->__VdfgTmp_ha0adc294__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___023931_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d) {
        wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d;
        wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d;
    } else {
        wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024058_;
        wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006092_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022808_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0))));
    vlSelf->__VdfgTmp_h916673f4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->__VdfgTmp_hed8e8f6b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005745_));
    vlSelf->__VdfgTmp_hbac08a4b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005921_));
    vlSelf->__VdfgTmp_h5774c299__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___022889_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) {
        wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d;
        wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d;
    } else {
        wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022952_;
        wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128650___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000420_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001647_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___001625_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001613_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034353_)))));
    vlSelf->wasmetal_core__DOT___034357_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000420_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128115___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028849_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028814_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    wasmetal_core__DOT___128080___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028469_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128080___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004300_));
    __VdfgTmp_h635c29e2__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O) 
                                     << 1U)) | (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h45f0a758__0))));
    __VdfgTmp_h986ee838__0 = ((2U & ((6U >> (IData)(vlSelf->__VdfgTmp_h45f0a758__0)) 
                                     << 1U)) | (1U 
                                                & (0x2bU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1ffb08a2__0))));
    __VdfgTmp_h6ec4eab1__0 = ((4U & ((0xe8U >> (IData)(vlSelf->__VdfgTmp_h868ae0cf__0)) 
                                     << 2U)) | ((2U 
                                                 & ((0x69U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h1ffb08a2__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0x2bU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5ffdcb06__0)))));
    __VdfgTmp_hfc0d441b__0 = ((4U & ((0x69U >> (IData)(vlSelf->__VdfgTmp_hf5f2577b__0)) 
                                     << 2U)) | ((2U 
                                                 & ((0x69U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5ffdcb06__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0x17U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9a02691e__0)))));
    __VdfgTmp_ha1bf32a7__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                               << 2U) | ((2U & ((0x96U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h7b621139__0)) 
                                                << 1U)) 
                                         | (1U & (0x96U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9a02691e__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128044___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028093_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028092_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028122_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028121_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028088_)))));
    vlSelf->wasmetal_core__DOT___028061_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028093_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0xbU)));
    wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026459_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b14__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128144___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128479___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029134_)))));
    vlSelf->wasmetal_core__DOT___029139_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128479___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128327___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031057_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031056_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031055_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031054_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031020_)))));
    vlSelf->wasmetal_core__DOT___031025_ = ((IData)(vlSelf->wasmetal_core__DOT___031057_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    vlSelf->wasmetal_core__DOT___036845_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036632_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h5013759b__0))));
    wasmetal_core__DOT___036844_ = (1U & (0x8e71U >> 
                                          ((8U & ((9U 
                                                   >> (IData)(__VdfgTmp_h5013759b__0)) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___072214_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((0xe8U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he9efeda2__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___072213_))))));
    wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036842_) ? (IData)(vlSelf->wasmetal_core__DOT___134164___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036629_));
    wasmetal_core__DOT___036843_ = (1U & (IData)((0x8ee8e88e71171771ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___036630_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072203_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072202_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x69U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h84670069__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x17U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h74dc1f9c__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___072201_)))))))));
    vlSelf->wasmetal_core__DOT___011076_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O))))))));
    vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033421_));
    vlSelf->wasmetal_core__DOT___056736_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056735_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he54a047f__0)))))));
    vlSelf->wasmetal_core__DOT___012451_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h895eb4d9__0)))));
    vlSelf->wasmetal_core__DOT___066787_ = (1U & (IData)(
                                                         (0xff0000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4eea07db__0))))));
    vlSelf->wasmetal_core__DOT___012899_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012895_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012894_)))));
    vlSelf->wasmetal_core__DOT___056887_ = (1U & (IData)(
                                                         (0xff11f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x30303000aa0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011955_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056769_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011949_)))))))));
    vlSelf->wasmetal_core__DOT___064775_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h8a9ed06f__0))));
    vlSelf->wasmetal_core__DOT___056860_ = (1U & (IData)(
                                                         (0xf0f3f0f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h8a9ed06f__0))))))));
    vlSelf->wasmetal_core__DOT___056750_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0x33335555000f000fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011910_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011909_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h8a9ed06f__0))))))));
    vlSelf->wasmetal_core__DOT___064540_ = (1U & (0xf0011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064529_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h95aabd6f__0))))));
    vlSelf->wasmetal_core__DOT___064018_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hd2b66780__0))));
    vlSelf->wasmetal_core__DOT___056389_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056388_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00fff400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011082_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdab8ca95__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f5f0f300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_hd2b66780__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xffff8000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056384_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___057177_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8267970c__0))));
    vlSelf->wasmetal_core__DOT___012476_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057091_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xccaaf0f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012387_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h7d32537f__0))))))))));
    vlSelf->wasmetal_core__DOT___057099_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057091_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011026_)))));
    vlSelf->wasmetal_core__DOT___066619_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056909_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056908_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012256_)))))))));
    vlSelf->wasmetal_core__DOT___057046_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056908_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->wasmetal_core__DOT___012171_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he65514a2__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127559___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005802_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005948_)))) 
           ^ (((IData)(wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023449_)))));
    vlSelf->wasmetal_core__DOT___023453_ = ((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                            & (IData)(wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127576___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013797_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h7faa2984__0))) 
           ^ (((IData)(wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023570_)))));
    vlSelf->wasmetal_core__DOT___023574_ = ((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                            & (IData)(wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128098___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028645_)
            ? (IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004300_));
    vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029057_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029022_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    wasmetal_core__DOT___128125___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028957_)
            ? (IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b17__05d));
    wasmetal_core__DOT___128438___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001646_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001646_)
            : (IData)(wasmetal_core__DOT___128438___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045370_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b44__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b46__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___045382_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b46__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b45__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028748_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028714_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    vlSelf->__VdfgTmp_hbe940684__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054083_)))));
    vlSelf->wasmetal_core__DOT___045336_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052263_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052141_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052264_)))))))));
    vlSelf->wasmetal_core__DOT___045348_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052141_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052264_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052263_)))))))));
    vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026670_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026604_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    vlSelf->wasmetal_core__DOT___054354_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054356_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054352_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027140_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027074_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d));
    wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026567_)
            ? (IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001569_));
    vlSelf->wasmetal_core__DOT___054353_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054349_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054355_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054351_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026940_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026874_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    vlSelf->wasmetal_core__DOT___045922_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052255_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052257_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052401_))))))));
    vlSelf->wasmetal_core__DOT___045934_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052257_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052255_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052401_)))))))));
    vlSelf->wasmetal_core__DOT___045404_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha17b8b2d__0))))));
    vlSelf->wasmetal_core__DOT___045416_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004684_)))))))));
    vlSelf->wasmetal_core__DOT___045876_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004152_)))))))));
    vlSelf->wasmetal_core__DOT___045900_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003558_)))))))));
    vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h560b7672__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026739_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    wasmetal_core__DOT___128666___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001646_)) 
           & (IData)(wasmetal_core__DOT___128666___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030096_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030063_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d));
    vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030224_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030159_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d));
    vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028290_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028225_));
    vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027338_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b14__05d));
    vlSelf->__VdfgTmp_h201788e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                                                >> 3U)))))));
    vlSelf->__VdfgTmp_h16a355a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_h3cbf3996__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___127436___O)))))));
    vlSelf->__VdfgTmp_h6ec85b19__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->__VdfgTmp_h21955c47__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h6d7fd34d__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_));
    vlSelf->__VdfgTmp_h445a0824__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_));
    vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003807_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022510_));
    wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013712_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d) {
        wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d;
        wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d;
    } else {
        wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127585___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023774_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023763_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023752_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023741_)))) 
           ^ (((IData)(wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___023711_ = ((IData)(vlSelf->wasmetal_core__DOT___023774_)
                                             ? (IData)(wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d));
    vlSelf->wasmetal_core__DOT___058750_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0))))));
    vlSelf->wasmetal_core__DOT___023801_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d))));
    vlSelf->wasmetal_core__DOT___058864_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d))));
    vlSelf->wasmetal_core__DOT___058736_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                             >> 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0))))))));
    vlSelf->wasmetal_core__DOT___023800_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d))));
    vlSelf->wasmetal_core__DOT___058872_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___023796_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d))));
    vlSelf->wasmetal_core__DOT___058913_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)))))));
    vlSelf->wasmetal_core__DOT___023785_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___127456___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005875_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006085_)))) 
           ^ (((IData)(wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022652_)))));
    vlSelf->wasmetal_core__DOT___022656_ = ((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                            & (IData)(wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) {
        wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d;
        wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d;
    } else {
        wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127469___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022810_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022808_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022797_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022786_)))) 
           ^ (((IData)(wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022779_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022810_)
                                                   ? (IData)(wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7e209046__0))));
    vlSelf->wasmetal_core__DOT___059189_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))))));
    vlSelf->wasmetal_core__DOT___059165_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))))));
    vlSelf->wasmetal_core__DOT___022814_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))))));
    vlSelf->wasmetal_core__DOT___059103_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))))));
    vlSelf->wasmetal_core__DOT___022813_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))))));
    vlSelf->wasmetal_core__DOT___022812_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0))))));
    vlSelf->wasmetal_core__DOT___059082_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))))));
    vlSelf->wasmetal_core__DOT___059166_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))))));
    vlSelf->wasmetal_core__DOT___022811_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))))));
    vlSelf->wasmetal_core__DOT___054558_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001613_)))));
    vlSelf->wasmetal_core__DOT___054559_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001625_)))));
    vlSelf->wasmetal_core__DOT___054560_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001647_)))));
    vlSelf->wasmetal_core__DOT___054561_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000420_)))));
    vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000433_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034357_));
    wasmetal_core__DOT___128115___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028850_)
            ? (IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    wasmetal_core__DOT___128080___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028470_)
            ? (IData)(wasmetal_core__DOT___128080___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004078_));
    vlSelf->__VdfgTmp_h0bfb68a4__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O)) 
                                      | (1U & (8U >> (IData)(__VdfgTmp_h635c29e2__0))));
    vlSelf->__VdfgTmp_h935fcb03__0 = ((2U & ((6U >> (IData)(__VdfgTmp_h635c29e2__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> (IData)(__VdfgTmp_h986ee838__0))));
    vlSelf->__VdfgTmp_hab776b02__0 = ((2U & ((9U >> (IData)(__VdfgTmp_h986ee838__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (IData)(__VdfgTmp_h6ec4eab1__0))));
    vlSelf->wasmetal_core__DOT___036652_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xe8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf5f2577b__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x96U 
                                                           >> (IData)(__VdfgTmp_h6ec4eab1__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x2bU 
                                                            >> (IData)(__VdfgTmp_hfc0d441b__0)))))));
    vlSelf->wasmetal_core__DOT___036651_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7b621139__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x69U 
                                                           >> (IData)(__VdfgTmp_hfc0d441b__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x17U 
                                                            >> (IData)(__VdfgTmp_ha1bf32a7__0)))))));
    vlSelf->__VdfgTmp_h009676e6__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(__VdfgTmp_ha1bf32a7__0)))));
    vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028094_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028061_)
                  : (vlSelf->insn_x >> 0xcU)));
    vlSelf->wasmetal_core__DOT____Vcellout___127853___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026460_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026459_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026458_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026457_)))) 
           ^ (((IData)(wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026423_)))));
    vlSelf->wasmetal_core__DOT___026427_ = ((IData)(vlSelf->wasmetal_core__DOT___026460_)
                                             ? (IData)(wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b15__05d));
    wasmetal_core__DOT___128145___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128480___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029139_));
    wasmetal_core__DOT___128328___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031058_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031025_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___036843_) ? (IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__)
            : (IData)(wasmetal_core__DOT___036630_));
    vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___067742_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064775_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->__VdfgTmp_hb961a9be__0 = (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057177_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((0xc0aU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7d32537f__0)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xf0fe00000000ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057174_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057162_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___010395_))))))))))));
    vlSelf->wasmetal_core__DOT___012166_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012171_))
                                                   : 
                                                  (0xf0faf0fcU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xf0fe00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056962_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012221_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012218_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))))) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h75e79c91__0)))))));
    vlSelf->wasmetal_core__DOT___050114_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005882_))))));
    vlSelf->wasmetal_core__DOT___050102_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005948_))));
    wasmetal_core__DOT___006729_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h76242b02__0))))))));
    vlSelf->__VdfgTmp_hfb6e9604__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005802_));
    vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005955_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023453_));
    vlSelf->wasmetal_core__DOT___057763_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013785_)))))))));
    vlSelf->wasmetal_core__DOT___013774_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8ac5901b__0)))));
    vlSelf->wasmetal_core__DOT___057755_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013797_))));
    vlSelf->wasmetal_core__DOT___013776_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013786_))))));
    vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013795_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023574_));
    wasmetal_core__DOT___128098___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028646_)
            ? (IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004078_));
    vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029058_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    wasmetal_core__DOT___128125___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028958_)
            ? (IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b18__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128438___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128438___S) 
           ^ (((IData)(wasmetal_core__DOT___128438___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128438___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128438___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032264_)))));
    vlSelf->wasmetal_core__DOT___032268_ = ((IData)(vlSelf->wasmetal_core__DOT___000419_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___000419_)
                                             : (IData)(wasmetal_core__DOT___128438___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028749_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->wasmetal_core__DOT___045018_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hbe940684__0)))))))))));
    vlSelf->wasmetal_core__DOT___045042_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbe940684__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054087_)))))))));
    vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026671_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->wasmetal_core__DOT___070697_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054352_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xcU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027141_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127869___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026568_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026567_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026566_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026565_)))) 
           ^ (((IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127869___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026498_)))));
    vlSelf->wasmetal_core__DOT___026502_ = ((IData)(vlSelf->wasmetal_core__DOT___026568_)
                                             ? (IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001581_));
    vlSelf->wasmetal_core__DOT___070800_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054351_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xcU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026941_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h63306680__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->wasmetal_core__DOT____Vcellout___128666___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128438___S) 
           ^ (((IData)(wasmetal_core__DOT___128666___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128666___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128666___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034514_)))));
    vlSelf->wasmetal_core__DOT___034518_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000419_)) 
                                            & (IData)(wasmetal_core__DOT___128666___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030097_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d));
    vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030225_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128061___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028291_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028290_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028289_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028288_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028254_)))));
    vlSelf->wasmetal_core__DOT___028258_ = ((IData)(vlSelf->wasmetal_core__DOT___028291_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028226_));
    vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127954___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027339_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027338_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027337_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027336_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027270_)))));
    vlSelf->wasmetal_core__DOT___027274_ = ((IData)(vlSelf->wasmetal_core__DOT___027339_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b15__05d));
    vlSelf->wasmetal_core__DOT___023226_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6ec85b19__0))));
    vlSelf->wasmetal_core__DOT___023225_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___003810_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h21955c47__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h21955c47__0)))));
    vlSelf->wasmetal_core__DOT___023223_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d7fd34d__0))));
    vlSelf->wasmetal_core__DOT___023222_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h445a0824__0))));
    vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127464___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013690_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h3f696fc8__0))) 
           ^ (((IData)(wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022741_)))));
    vlSelf->wasmetal_core__DOT___022722_ = ((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                            & (IData)(wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d) {
        wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d;
        vlSelf->wasmetal_core__DOT___023873_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d;
    } else {
        wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023873_ = wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023785_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023711_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d));
    vlSelf->wasmetal_core__DOT___050131_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006092_))))));
    vlSelf->__VdfgTmp_h0d021fbc__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005745_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022656_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) {
        wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d;
        vlSelf->wasmetal_core__DOT___022863_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d;
    } else {
        wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022863_ = wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022811_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022779_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))));
    vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000465_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128115___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028851_)
            ? (IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT____Vcellout___128080___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028471_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028470_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028469_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028468_)))) 
           ^ (((IData)(wasmetal_core__DOT___128080___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128080___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128080___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028434_)))));
    vlSelf->wasmetal_core__DOT___028438_ = ((IData)(vlSelf->wasmetal_core__DOT___028471_)
                                             ? (IData)(wasmetal_core__DOT___128080___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003862_));
    vlSelf->wasmetal_core__DOT___036981_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0bfb68a4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h935fcb03__0))));
    vlSelf->wasmetal_core__DOT___036980_ = (1U & (0xb4U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h935fcb03__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab776b02__0))));
    vlSelf->wasmetal_core__DOT___036979_ = (1U & (0x8e71U 
                                                  >> 
                                                  ((8U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hab776b02__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0x96U 
                                                           >> (IData)(__VdfgTmp_h6ec4eab1__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xe8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf5f2577b__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x2bU 
                                                               >> (IData)(__VdfgTmp_hfc0d441b__0))))))));
    vlSelf->wasmetal_core__DOT___036978_ = (1U & (0x8e71U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036652_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x69U 
                                                           >> (IData)(__VdfgTmp_hfc0d441b__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x17U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7b621139__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x17U 
                                                               >> (IData)(__VdfgTmp_ha1bf32a7__0))))))));
    vlSelf->wasmetal_core__DOT___036977_ = (1U & (0x17e8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036651_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h009676e6__0))));
    vlSelf->wasmetal_core__DOT___036976_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x96U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h009676e6__0))))));
    vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028095_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0xdU)));
    vlSelf->wasmetal_core__DOT___044908_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026461_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026427_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b16__05d));
    wasmetal_core__DOT___128145___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128480___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128328___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031059_)
            ? (IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134164___O 
        = ((((IData)(wasmetal_core__DOT___036844_) 
             << 3U) | (((IData)(wasmetal_core__DOT___036843_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036842_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036841_)))) 
           ^ (((IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___134164___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___036837_ = (1U & ((IData)(wasmetal_core__DOT___036844_)
                                                   ? (IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(__VdfgTmp_h5013759b__0))));
    vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006707_ = ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                & (IData)(wasmetal_core__DOT___006729_))
                                             : (IData)(wasmetal_core__DOT___006729_));
    vlSelf->wasmetal_core__DOT___050104_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfb6e9604__0)))));
    vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005788_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___057762_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013776_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O)))))));
    vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013798_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128098___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028647_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028646_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028645_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028644_)))) 
           ^ (((IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028610_)))));
    vlSelf->wasmetal_core__DOT___028614_ = ((IData)(vlSelf->wasmetal_core__DOT___028647_)
                                             ? (IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003862_));
    vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029059_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT____Vcellout___128125___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028959_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028958_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028957_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028956_)))) 
           ^ (((IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028922_)))));
    vlSelf->wasmetal_core__DOT___028926_ = ((IData)(vlSelf->wasmetal_core__DOT___028959_)
                                             ? (IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b19__05d));
    vlSelf->wasmetal_core__DOT___128439___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000432_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000432_)
            : (IData)(vlSelf->wasmetal_core__DOT___032268_));
    vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028750_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026672_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT___070699_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054350_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070697_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)))))))))));
    vlSelf->wasmetal_core__DOT___070698_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027142_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d));
    vlSelf->wasmetal_core__DOT___045494_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071355_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071354_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071353_))))))));
    vlSelf->wasmetal_core__DOT___045518_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071355_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071354_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071353_)))))))));
    vlSelf->wasmetal_core__DOT___045290_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071418_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071417_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071416_))))))));
    vlSelf->wasmetal_core__DOT___045314_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071418_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071417_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071416_)))))))));
    wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026569_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026502_)
            : (IData)(vlSelf->wasmetal_core__DOT___001613_));
    vlSelf->wasmetal_core__DOT___070802_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054349_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070800_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)))))))))));
    vlSelf->wasmetal_core__DOT___070801_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070800_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054349_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d)))))))));
    wasmetal_core__DOT___127921___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026942_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    wasmetal_core__DOT___128071___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h0cc9f882__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->__VdfgTmp_h3b6a361f__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->__VdfgTmp_h5840e4cc__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->__VdfgTmp_h0eee83f1__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->__VdfgTmp_hb291576a__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001612_));
    vlSelf->wasmetal_core__DOT___039999_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039993_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___040012_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___040011_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128666___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b19__05d)))))))));
    wasmetal_core__DOT___128667___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000432_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034518_));
    wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030098_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d));
    wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030226_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d));
    wasmetal_core__DOT___063168_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063174_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063180_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063186_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028292_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028258_)
            : (IData)(vlSelf->wasmetal_core__DOT___028227_));
    wasmetal_core__DOT____Vcellout___127970___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027466_)))));
    wasmetal_core__DOT___027405_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
                                     >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027340_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027274_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b16__05d));
    vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003808_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h87a694d3__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013690_));
    vlSelf->wasmetal_core__DOT___127465___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013654_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022722_));
    vlSelf->wasmetal_core__DOT____Vcellout___127626___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024058_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d) {
        vlSelf->wasmetal_core__DOT___024000_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d;
        wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024000_ = wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023873_;
    }
    vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023796_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127610___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023931_)))));
    vlSelf->wasmetal_core__DOT___050130_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0d021fbc__0)))));
    vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005921_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127489___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022952_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d) {
        vlSelf->wasmetal_core__DOT___022926_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d;
        wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022926_ = wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022863_;
    }
    vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022812_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127481___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022889_)))));
    vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000477_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128115___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028852_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028851_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028850_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028849_)))) 
           ^ (((IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028814_)))));
    vlSelf->wasmetal_core__DOT___028818_ = ((IData)(vlSelf->wasmetal_core__DOT___028852_)
                                             ? (IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->wasmetal_core__DOT___028856_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000419_))));
    vlSelf->wasmetal_core__DOT___028855_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001646_))));
    vlSelf->wasmetal_core__DOT___028854_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001624_))));
    vlSelf->wasmetal_core__DOT___028853_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001612_))));
    vlSelf->wasmetal_core__DOT___128081___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028473_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028438_)
            : (IData)(vlSelf->wasmetal_core__DOT___003936_));
    wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036976_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0)
                  : (0x96U >> (IData)(vlSelf->__VdfgTmp_h009676e6__0))));
    vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028096_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0xeU)));
    vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026462_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b17__05d));
    wasmetal_core__DOT___128145___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128480___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128328___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031060_)
            ? (IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036845_)
            ? (IData)(vlSelf->wasmetal_core__DOT___036837_)
            : (IData)(vlSelf->wasmetal_core__DOT___036632_));
    vlSelf->wasmetal_core__DOT____Vcellout___128550___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033421_)))));
    wasmetal_core__DOT___033425_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005889_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013771_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___054100_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128098___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054104_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128098___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b17__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054108_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128098___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b18__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054112_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128098___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b19__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    wasmetal_core__DOT___128099___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028649_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028614_)
            : (IData)(vlSelf->wasmetal_core__DOT___003936_));
    vlSelf->wasmetal_core__DOT____Vcellout___128133___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029060_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029059_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029058_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029057_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029022_)))));
    wasmetal_core__DOT___029026_ = ((IData)(vlSelf->wasmetal_core__DOT___029060_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    wasmetal_core__DOT___029064_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000419_))));
    wasmetal_core__DOT___029063_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001646_))));
    wasmetal_core__DOT___029062_ = (1U & (6U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001624_))));
    wasmetal_core__DOT___029061_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001612_))));
    wasmetal_core__DOT___128126___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028961_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028926_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b20__05d));
    wasmetal_core__DOT___128439___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000464_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000464_)
            : (IData)(vlSelf->wasmetal_core__DOT___128439___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128107___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028751_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028750_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028749_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028748_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028714_)))));
    wasmetal_core__DOT___028718_ = ((IData)(vlSelf->wasmetal_core__DOT___028751_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT____Vcellout___127887___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026673_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026672_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026671_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026670_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026604_)))));
    wasmetal_core__DOT___026608_ = ((IData)(vlSelf->wasmetal_core__DOT___026673_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___045246_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070698_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054348_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___045222_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070699_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054352_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xcU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054348_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070698_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127938___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027143_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027142_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027141_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027140_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027074_)))));
    wasmetal_core__DOT___027078_ = ((IData)(vlSelf->wasmetal_core__DOT___027143_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d));
    wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026570_)
            ? (IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001625_));
    vlSelf->wasmetal_core__DOT___044974_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070801_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___044950_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070802_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054351_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xcU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054347_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070801_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127921___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026943_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026942_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026941_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026940_)))) 
           ^ (((IData)(wasmetal_core__DOT___127921___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026874_)))));
    wasmetal_core__DOT___026878_ = ((IData)(vlSelf->wasmetal_core__DOT___026943_)
                                     ? (IData)(wasmetal_core__DOT___127921___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT____Vcellout___127904___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h3e3e53ad__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h0cc9f882__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h63306680__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h560b7672__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128071___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026739_)))));
    wasmetal_core__DOT___026743_ = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h3e3e53ad__0)))
                                     ? (IData)(wasmetal_core__DOT___128071___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___030103_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b6a361f__0)))));
    vlSelf->wasmetal_core__DOT___030231_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b6a361f__0)))));
    vlSelf->wasmetal_core__DOT___030102_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5840e4cc__0)))));
    vlSelf->wasmetal_core__DOT___030230_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5840e4cc__0)))));
    vlSelf->wasmetal_core__DOT___030101_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0eee83f1__0)))));
    vlSelf->wasmetal_core__DOT___030229_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0eee83f1__0)))));
    vlSelf->wasmetal_core__DOT___030100_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb291576a__0)))));
    vlSelf->wasmetal_core__DOT___030228_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb291576a__0)))));
    wasmetal_core__DOT___128667___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000464_)) 
           & (IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128234___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030099_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030098_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030097_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030096_)))) 
           ^ (((IData)(wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030063_)))));
    vlSelf->wasmetal_core__DOT___030067_ = ((IData)(vlSelf->wasmetal_core__DOT___030099_)
                                             ? (IData)(wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128248___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030227_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030226_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030225_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030224_)))) 
           ^ (((IData)(wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030159_)))));
    vlSelf->wasmetal_core__DOT___030163_ = ((IData)(vlSelf->wasmetal_core__DOT___030227_)
                                             ? (IData)(wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d));
    vlSelf->wasmetal_core__DOT___063171_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063168_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063167_)))))));
    vlSelf->wasmetal_core__DOT___063177_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063174_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063173_)))))));
    vlSelf->wasmetal_core__DOT___063183_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063180_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063179_)))))));
    vlSelf->wasmetal_core__DOT___063189_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063186_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063185_)))))));
    vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028293_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028228_));
    vlSelf->wasmetal_core__DOT___044885_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127970___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___127970___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127970___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___044884_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127970___O))))));
    wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
           & (IData)(wasmetal_core__DOT___027405_));
    wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027341_)
            ? (IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b17__05d));
    wasmetal_core__DOT____Vcellout___127437___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he473afc4__0))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022510_)))));
    wasmetal_core__DOT___022514_ = ((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013648_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127465___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d) {
        wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d;
        wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d;
    } else {
        wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024000_;
        wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023800_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d));
    vlSelf->__VdfgTmp_h79e73f20__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005982_));
    vlSelf->__VdfgTmp_ha15895e4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->__VdfgTmp_h8b95dc84__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_));
    vlSelf->__VdfgTmp_ha7391b06__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006092_));
    vlSelf->wasmetal_core__DOT___006622_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050131_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006635_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050130_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006015_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O))))))))));
    vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005738_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d) {
        wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d;
        wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d;
    } else {
        wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022926_;
        wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022813_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))));
    vlSelf->__VdfgTmp_h4b2bd90e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005982_));
    vlSelf->__VdfgTmp_hbed85956__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->__VdfgTmp_hedc0f726__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_));
    vlSelf->__VdfgTmp_he0f48724__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006092_));
    vlSelf->wasmetal_core__DOT____Vcellout___128651___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000499_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000477_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___000465_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___000433_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034357_)))));
    wasmetal_core__DOT___034362_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000499_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128116___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028853_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028818_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    wasmetal_core__DOT___128081___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028474_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128081___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003416_));
    wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036977_)
            ? (IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036651_));
    vlSelf->wasmetal_core__DOT____Vcellout___128045___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028097_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028096_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028095_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028094_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028061_)))));
    vlSelf->wasmetal_core__DOT___028065_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028097_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0xfU)));
    wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026463_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b18__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128145___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128480___O) 
           ^ (((IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029139_)))));
    wasmetal_core__DOT___029143_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128480___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128145___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128328___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031061_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031060_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031059_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031058_)))) 
           ^ (((IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031025_)))));
    wasmetal_core__DOT___031029_ = ((IData)(vlSelf->wasmetal_core__DOT___031061_)
                                     ? (IData)(wasmetal_core__DOT___128328___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134165___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036846_) 
             << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036845_)) 
           ^ (((((IData)(vlSelf->wasmetal_core__DOT___036846_)
                  ? (IData)(wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT___036627_)) 
                << 2U) | ((IData)(wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___036837_)));
    vlSelf->wasmetal_core__DOT___012774_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff00aaaaf0f03333ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                              << 1U)) 
                                                                          | ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)) 
           & (IData)(wasmetal_core__DOT___033425_));
    vlSelf->wasmetal_core__DOT____Vcellout___127560___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005795_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005955_)))) 
           ^ (((IData)(wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023453_)))));
    wasmetal_core__DOT___023457_ = ((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                    & (IData)(wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127577___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013770_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h81ac2e72__0))) 
           ^ (((IData)(wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023574_)))));
    wasmetal_core__DOT___023578_ = ((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                    & (IData)(wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128099___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028650_)
            ? (IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003416_));
    wasmetal_core__DOT___128134___DOT__CO__BRA__0__KET__ 
        = ((IData)(wasmetal_core__DOT___029061_) ? (IData)(wasmetal_core__DOT___029026_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    wasmetal_core__DOT___128126___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028962_)
            ? (IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b21__05d));
    wasmetal_core__DOT___128439___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000476_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000476_)
            : (IData)(wasmetal_core__DOT___128439___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045371_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b47__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___045383_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b49__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b48__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b47__05d)))))))));
    wasmetal_core__DOT___128108___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028753_)
            ? (IData)(wasmetal_core__DOT___028718_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___071264_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071263_))));
    vlSelf->wasmetal_core__DOT___045337_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052142_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052446_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052450_)))))))));
    vlSelf->wasmetal_core__DOT___045349_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052142_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052446_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052450_)))))))));
    wasmetal_core__DOT___128090___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026675_)
            ? (IData)(wasmetal_core__DOT___026608_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___054360_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054362_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054358_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054364_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127939___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027145_)
            ? (IData)(wasmetal_core__DOT___027078_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d));
    wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026571_)
            ? (IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001647_));
    vlSelf->wasmetal_core__DOT___054359_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054361_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054357_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127922___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026945_)
            ? (IData)(wasmetal_core__DOT___026878_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___045923_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052400_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052529_)))))))));
    vlSelf->wasmetal_core__DOT___045935_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052529_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052400_)))))))));
    vlSelf->wasmetal_core__DOT___045405_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h73e9a4a1__0)))))));
    vlSelf->wasmetal_core__DOT___045417_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004018_)))))))));
    vlSelf->wasmetal_core__DOT___045878_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___003862_))))))));
    vlSelf->wasmetal_core__DOT___045902_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003862_)))))))));
    vlSelf->wasmetal_core__DOT___045877_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004004_)))))))));
    vlSelf->wasmetal_core__DOT___045901_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004670_)))))))));
    wasmetal_core__DOT___128072___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hd86a0826__0)))
            ? (IData)(wasmetal_core__DOT___026743_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    wasmetal_core__DOT___128667___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000476_)) 
           & (IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030100_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030067_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d));
    wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030228_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030163_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d));
    vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028294_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028229_));
    wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027342_)
            ? (IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b18__05d));
    vlSelf->__VdfgTmp_h6e06acca__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                                                >> 3U)))))));
    vlSelf->__VdfgTmp_he245418c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_he137fc3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___127437___O)))))));
    vlSelf->__VdfgTmp_hd90860df__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127437___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_));
    vlSelf->__VdfgTmp_h6f6c5c03__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hbedf9838__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003805_));
    wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003806_) 
           & (IData)(wasmetal_core__DOT___022514_));
    wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013666_) 
           & (IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d) {
        wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d;
        wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d;
    } else {
        wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127592___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023801_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023800_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023796_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023785_)))) 
           ^ (((IData)(wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023711_)))));
    vlSelf->wasmetal_core__DOT___023738_ = ((IData)(vlSelf->wasmetal_core__DOT___023801_)
                                             ? (IData)(wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d));
    vlSelf->wasmetal_core__DOT___023743_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d))));
    vlSelf->wasmetal_core__DOT___058878_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d))));
    vlSelf->wasmetal_core__DOT___023742_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d))));
    vlSelf->wasmetal_core__DOT___058706_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0))))));
    vlSelf->wasmetal_core__DOT___023803_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d))));
    vlSelf->wasmetal_core__DOT___058870_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0))))))));
    vlSelf->wasmetal_core__DOT___058924_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0))))));
    vlSelf->wasmetal_core__DOT___058707_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___023802_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d))));
    vlSelf->wasmetal_core__DOT___006952_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT____Vcellout___127457___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005935_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005745_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022656_)))));
    wasmetal_core__DOT___022660_ = ((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) {
        wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d;
        wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d;
    } else {
        wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127470___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022814_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022813_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022812_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022811_)))) 
           ^ (((IData)(wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022779_)))));
    vlSelf->wasmetal_core__DOT___022783_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022814_)
                                                   ? (IData)(wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))));
    vlSelf->wasmetal_core__DOT___022788_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0))))));
    vlSelf->wasmetal_core__DOT___059183_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))));
    vlSelf->wasmetal_core__DOT___059191_ = (1U & (1U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5774c299__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))))));
    vlSelf->wasmetal_core__DOT___022787_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))));
    vlSelf->wasmetal_core__DOT___059168_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))))));
    wasmetal_core__DOT___059083_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))))));
    vlSelf->wasmetal_core__DOT___022816_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))))));
    vlSelf->wasmetal_core__DOT___059169_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he0f48724__0))))));
    vlSelf->wasmetal_core__DOT___022815_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he0f48724__0))))));
    vlSelf->wasmetal_core__DOT___054562_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000433_)))));
    vlSelf->wasmetal_core__DOT___054563_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000465_)))));
    vlSelf->wasmetal_core__DOT___054564_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000477_)))));
    vlSelf->wasmetal_core__DOT___054565_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000499_)))));
    wasmetal_core__DOT___128652___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000521_)) 
           & (IData)(wasmetal_core__DOT___034362_));
    wasmetal_core__DOT___128116___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028854_)
            ? (IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    wasmetal_core__DOT___128081___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028475_)
            ? (IData)(wasmetal_core__DOT___128081___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003348_));
    wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036978_)
            ? (IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036652_));
    vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028098_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028065_)
                  : (vlSelf->insn_x >> 0x10U)));
    vlSelf->wasmetal_core__DOT____Vcellout___127854___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026464_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026463_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026462_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026461_)))) 
           ^ (((IData)(wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026427_)))));
    vlSelf->wasmetal_core__DOT___026431_ = ((IData)(vlSelf->wasmetal_core__DOT___026464_)
                                             ? (IData)(wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b19__05d));
    wasmetal_core__DOT___128146___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128481___O) 
           & (IData)(wasmetal_core__DOT___029143_));
    wasmetal_core__DOT___128329___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031062_)
            ? (IData)(wasmetal_core__DOT___031029_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d)) 
           & (IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___006683_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127560___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xceU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005653_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b33__05d))))
                                                      : 
                                                     (0xf0f0fef0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005653_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h312c1c6b__0))))))));
    vlSelf->__VdfgTmp_h90f032b2__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127560___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005788_));
    wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005711_) 
           & (IData)(wasmetal_core__DOT___023457_));
    vlSelf->wasmetal_core__DOT___057748_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013771_))));
    vlSelf->wasmetal_core__DOT___057747_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013798_))));
    wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013805_) 
           & (IData)(wasmetal_core__DOT___023578_));
    wasmetal_core__DOT___128099___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028651_)
            ? (IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003348_));
    wasmetal_core__DOT___128134___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___029062_) ? (IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    wasmetal_core__DOT___128126___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028963_)
            ? (IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b22__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128439___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128439___S) 
           ^ (((IData)(wasmetal_core__DOT___128439___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128439___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128439___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032268_)))));
    vlSelf->wasmetal_core__DOT___032273_ = ((IData)(vlSelf->wasmetal_core__DOT___000498_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___000498_)
                                             : (IData)(wasmetal_core__DOT___128439___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128108___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028754_)
            ? (IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000464_));
    vlSelf->wasmetal_core__DOT___071266_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071264_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d)))))))));
    wasmetal_core__DOT___128090___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026676_)
            ? (IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000464_));
    vlSelf->wasmetal_core__DOT___070702_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054358_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xfU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___070707_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054364_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x11U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d)))))));
    wasmetal_core__DOT___127939___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027146_)
            ? (IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d));
    wasmetal_core__DOT____Vcellout___127870___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___026572_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___026571_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___026570_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026569_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026502_)))));
    vlSelf->wasmetal_core__DOT___026506_ = ((IData)(vlSelf->wasmetal_core__DOT___026572_)
                                             ? (IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000420_));
    vlSelf->wasmetal_core__DOT___070805_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xfU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___070810_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054363_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x11U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d)))))));
    wasmetal_core__DOT___127922___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026946_)
            ? (IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000464_));
    wasmetal_core__DOT___128072___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h9cad1664__0)))
            ? (IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000464_));
    vlSelf->wasmetal_core__DOT____Vcellout___128667___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128439___S) 
           ^ (((IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034518_)))));
    vlSelf->wasmetal_core__DOT___034523_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000498_)) 
                                            & (IData)(wasmetal_core__DOT___128667___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030101_)
            ? (IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d));
    wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030229_)
            ? (IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d));
    wasmetal_core__DOT____Vcellout___128062___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028295_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028294_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028293_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028292_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028258_)))));
    vlSelf->wasmetal_core__DOT___028262_ = ((IData)(vlSelf->wasmetal_core__DOT___028295_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028230_));
    wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127955___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027343_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027342_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027341_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027340_)))) 
           ^ (((IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027274_)))));
    vlSelf->wasmetal_core__DOT___027278_ = ((IData)(vlSelf->wasmetal_core__DOT___027343_)
                                             ? (IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b19__05d));
    vlSelf->wasmetal_core__DOT___023221_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___003807_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_he137fc3d__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_he137fc3d__0)))));
    vlSelf->wasmetal_core__DOT___023220_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd90860df__0))));
    vlSelf->wasmetal_core__DOT___023219_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___003808_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6f6c5c03__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6f6c5c03__0)))));
    vlSelf->wasmetal_core__DOT___023218_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbedf9838__0))));
    wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005855_) 
           & (IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127465___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013658_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h7d2fcfb3__0))) 
           ^ (((IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127465___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022722_)))));
    vlSelf->wasmetal_core__DOT___022726_ = ((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                            & (IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d) {
        wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d;
        vlSelf->wasmetal_core__DOT___023877_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d;
    } else {
        wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023877_ = wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023802_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023738_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d));
    vlSelf->wasmetal_core__DOT___022627_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006952_))));
    vlSelf->wasmetal_core__DOT___006631_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005921_))));
    wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005716_) 
           & (IData)(wasmetal_core__DOT___022660_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d) {
        wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d;
        vlSelf->wasmetal_core__DOT___022867_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d;
    } else {
        wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022867_ = wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___059089_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059083_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059082_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h916673f4__0)))))))))));
    vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022815_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022783_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_he0f48724__0))));
    wasmetal_core__DOT___128652___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000543_)) 
           & (IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128116___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028855_)
            ? (IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT____Vcellout___128081___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028476_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028475_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028474_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028473_)))) 
           ^ (((IData)(wasmetal_core__DOT___128081___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128081___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128081___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028438_)))));
    vlSelf->wasmetal_core__DOT___028443_ = ((IData)(vlSelf->wasmetal_core__DOT___028476_)
                                             ? (IData)(wasmetal_core__DOT___128081___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___005164_));
    vlSelf->wasmetal_core__DOT____Vcellout___134183___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036979_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036978_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036977_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036976_)))) 
           ^ (((IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___036972_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036979_)
                                                   ? (IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hab776b02__0))));
    vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028099_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0x11U)));
    vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026466_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026431_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b20__05d));
    wasmetal_core__DOT___128146___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128481___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128146___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128329___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031063_)
            ? (IData)(wasmetal_core__DOT___128329___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d)) 
           & (IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006706_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006683_)) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                                     << 2U)) 
                                                                 | ((8U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                                              >> 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006151_))))))))));
    wasmetal_core__DOT___006743_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h90f032b2__0))))))));
    wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006215_) 
           & (IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___057758_ = (1U & (IData)((0x8acfULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057755_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057747_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                                << 1U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___013770_)))))))));
    wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002635_) 
           & (IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128099___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028652_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028651_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028650_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028649_)))) 
           ^ (((IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028614_)))));
    vlSelf->wasmetal_core__DOT___028619_ = ((IData)(vlSelf->wasmetal_core__DOT___028652_)
                                             ? (IData)(wasmetal_core__DOT___128099___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___005164_));
    wasmetal_core__DOT___128134___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___029063_) ? (IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT____Vcellout___128126___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028964_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028963_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028962_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028961_)))) 
           ^ (((IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028926_)))));
    vlSelf->wasmetal_core__DOT___028931_ = ((IData)(vlSelf->wasmetal_core__DOT___028964_)
                                             ? (IData)(wasmetal_core__DOT___128126___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b23__05d));
    vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000520_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000520_)
            : (IData)(vlSelf->wasmetal_core__DOT___032273_));
    wasmetal_core__DOT___128108___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028755_)
            ? (IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->wasmetal_core__DOT___045043_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071266_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071265_)))));
    vlSelf->wasmetal_core__DOT___045019_ = (1U & (IData)(
                                                         (0xff737340ff404040ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071263_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071266_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071265_)))))))));
    wasmetal_core__DOT___128090___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026677_)
            ? (IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->wasmetal_core__DOT___070704_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070702_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)))))))))));
    vlSelf->wasmetal_core__DOT___070703_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070702_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___070709_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054362_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070707_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)))))))))));
    vlSelf->wasmetal_core__DOT___070708_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070707_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054362_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d)))))))));
    wasmetal_core__DOT___127939___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027147_)
            ? (IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d));
    vlSelf->wasmetal_core__DOT___045496_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071361_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127870___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071360_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071359_))))))));
    vlSelf->wasmetal_core__DOT___045520_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071361_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071360_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071359_)))))))));
    vlSelf->wasmetal_core__DOT___045495_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071358_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071357_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071356_)))))))));
    vlSelf->wasmetal_core__DOT___045519_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071358_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071357_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071356_)))))))));
    vlSelf->wasmetal_core__DOT___045292_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071424_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127870___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071423_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071422_))))))));
    vlSelf->wasmetal_core__DOT___045316_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071424_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071423_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071422_)))))))));
    vlSelf->wasmetal_core__DOT___045291_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071421_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071420_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071419_)))))))));
    vlSelf->wasmetal_core__DOT___045315_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071421_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071420_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071419_)))))))));
    vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026574_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026506_)
            : (IData)(vlSelf->wasmetal_core__DOT___000433_));
    vlSelf->wasmetal_core__DOT___070807_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054355_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)))))))))));
    vlSelf->wasmetal_core__DOT___070806_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070805_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054355_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___070812_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)))))))))));
    vlSelf->wasmetal_core__DOT___070811_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070810_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054361_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d)))))))));
    wasmetal_core__DOT___127922___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026947_)
            ? (IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000476_));
    wasmetal_core__DOT___128072___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hf0334e7f__0)))
            ? (IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->__VdfgTmp_hf9b1d8fe__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->__VdfgTmp_ha8b85945__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->__VdfgTmp_haa037958__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000464_));
    vlSelf->__VdfgTmp_h8bacc2de__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___040010_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___040009_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___040020_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___040021_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128667___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___128668___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000520_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034523_));
    wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030102_)
            ? (IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d));
    wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030230_)
            ? (IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d));
    wasmetal_core__DOT___063192_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128062___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063198_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128062___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063204_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128062___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063210_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128062___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028297_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028262_)
            : (IData)(vlSelf->wasmetal_core__DOT___028232_));
    vlSelf->wasmetal_core__DOT____Vcellout___127971___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
           ^ (((IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027405_)))));
    vlSelf->wasmetal_core__DOT___027409_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027345_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027278_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b20__05d));
    wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005770_) 
           & (IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__));
    __VdfgTmp_h29c879e7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___013654_));
    vlSelf->__VdfgTmp_h6ae1a845__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013666_));
    vlSelf->__VdfgTmp_haeb5561e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013658_));
    vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013719_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022726_));
    vlSelf->wasmetal_core__DOT____Vcellout___127627___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024000_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d) {
        vlSelf->wasmetal_core__DOT___024004_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d;
        vlSelf->wasmetal_core__DOT___127612___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024004_ = wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127612___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023877_;
    }
    vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023803_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d));
    wasmetal_core__DOT____Vcellout___127611___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023873_)))));
    wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005928_) 
           & (IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127490___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022926_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d) {
        vlSelf->wasmetal_core__DOT___022930_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d;
        vlSelf->wasmetal_core__DOT___127483___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022930_ = wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127483___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022867_;
    }
    vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022816_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))));
    wasmetal_core__DOT____Vcellout___127482___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022863_)))));
    wasmetal_core__DOT___128652___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000565_)) 
           & (IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128116___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028856_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028855_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028854_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028853_)))) 
           ^ (((IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028818_)))));
    vlSelf->wasmetal_core__DOT___028822_ = ((IData)(vlSelf->wasmetal_core__DOT___028856_)
                                             ? (IData)(wasmetal_core__DOT___128116___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___028861_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000498_))));
    vlSelf->wasmetal_core__DOT___028860_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000476_))));
    vlSelf->wasmetal_core__DOT___028859_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000464_))));
    vlSelf->wasmetal_core__DOT___028858_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000432_))));
    vlSelf->wasmetal_core__DOT___128082___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028477_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028443_)
            : (IData)(vlSelf->wasmetal_core__DOT___005096_));
    vlSelf->wasmetal_core__DOT___064905_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134183___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___064472_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134183___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___064737_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134183___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036980_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036972_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h935fcb03__0))));
    vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028100_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0x12U)));
    vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026467_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128146___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128481___O) 
           ^ ((0xfffffff8U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128481___O) 
                               << 1U) & ((IData)(wasmetal_core__DOT___128146___DOT__CO__BRA__1__KET__) 
                                         << 3U))) | 
              (((IData)(wasmetal_core__DOT___128146___DOT__CO__BRA__1__KET__) 
                << 2U) | (((IData)(wasmetal_core__DOT___128146___DOT__CO__BRA__0__KET__) 
                           << 1U) | (IData)(wasmetal_core__DOT___029143_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128329___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031066_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031065_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031063_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031062_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___031065_)
                 ? (IData)(wasmetal_core__DOT___128329___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128329___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128329___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031029_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128551___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033425_)))));
    vlSelf->wasmetal_core__DOT___033429_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d)) 
                                            & (IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___050096_ = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                & (IData)(wasmetal_core__DOT___006743_))
                                             : (IData)(wasmetal_core__DOT___006743_));
    wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006144_) 
           & (IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___057761_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057759_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057758_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057757_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___014245_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002632_) 
           & (IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___054116_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128099___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b20__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054120_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128099___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054124_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128099___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054128_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128099___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b23__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___128100___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028653_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028619_)
            : (IData)(vlSelf->wasmetal_core__DOT___005096_));
    vlSelf->wasmetal_core__DOT____Vcellout___128134___O 
        = ((((IData)(wasmetal_core__DOT___029064_) 
             << 3U) | (((IData)(wasmetal_core__DOT___029063_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___029062_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___029061_)))) 
           ^ (((IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029026_)))));
    vlSelf->wasmetal_core__DOT___029030_ = ((IData)(wasmetal_core__DOT___029064_)
                                             ? (IData)(wasmetal_core__DOT___128134___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___029069_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000498_))));
    vlSelf->wasmetal_core__DOT___029068_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000476_))));
    vlSelf->wasmetal_core__DOT___029067_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000464_))));
    vlSelf->wasmetal_core__DOT___029066_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000432_))));
    vlSelf->wasmetal_core__DOT___128127___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028965_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028931_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b24__05d));
    vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000542_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000542_)
            : (IData)(vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128108___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028756_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028755_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028754_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028753_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___028718_)))));
    vlSelf->wasmetal_core__DOT___028723_ = ((IData)(vlSelf->wasmetal_core__DOT___028756_)
                                             ? (IData)(wasmetal_core__DOT___128108___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT____Vcellout___127888___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026678_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026677_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026676_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026675_)))) 
           ^ (((IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026608_)))));
    vlSelf->wasmetal_core__DOT___026613_ = ((IData)(vlSelf->wasmetal_core__DOT___026678_)
                                             ? (IData)(wasmetal_core__DOT___128090___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT___045247_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070703_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054354_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___045223_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070704_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054358_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xfU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054354_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070703_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU))))))))))))));
    vlSelf->wasmetal_core__DOT___045248_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070708_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054360_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___045224_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070709_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054364_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x11U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054360_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070708_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127939___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027148_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027147_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027146_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027145_)))) 
           ^ (((IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027078_)))));
    vlSelf->wasmetal_core__DOT___027083_ = ((IData)(vlSelf->wasmetal_core__DOT___027148_)
                                             ? (IData)(wasmetal_core__DOT___127939___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d));
    vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026575_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000465_));
    vlSelf->wasmetal_core__DOT___044975_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070806_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054353_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___044951_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070807_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xfU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054353_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070806_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU))))))))))))));
    vlSelf->wasmetal_core__DOT___044976_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070811_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054359_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___044952_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070812_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054363_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x11U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054359_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070811_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127922___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026948_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026947_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026946_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026945_)))) 
           ^ (((IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026878_)))));
    vlSelf->wasmetal_core__DOT___026883_ = ((IData)(vlSelf->wasmetal_core__DOT___026948_)
                                             ? (IData)(wasmetal_core__DOT___127922___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT____Vcellout___127905___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026813_) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_hf0334e7f__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h9cad1664__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hd86a0826__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026743_)))));
    vlSelf->wasmetal_core__DOT___026748_ = ((IData)(vlSelf->wasmetal_core__DOT___026813_)
                                             ? (IData)(wasmetal_core__DOT___128072___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT___030108_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf9b1d8fe__0)))));
    vlSelf->wasmetal_core__DOT___030236_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf9b1d8fe__0)))));
    vlSelf->wasmetal_core__DOT___030107_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha8b85945__0)))));
    vlSelf->wasmetal_core__DOT___030235_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha8b85945__0)))));
    vlSelf->wasmetal_core__DOT___030106_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haa037958__0)))));
    vlSelf->wasmetal_core__DOT___030234_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haa037958__0)))));
    vlSelf->wasmetal_core__DOT___030105_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8bacc2de__0)))));
    vlSelf->wasmetal_core__DOT___030233_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8bacc2de__0)))));
    vlSelf->wasmetal_core__DOT___128668___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000542_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128668___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128235___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030103_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030102_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030101_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030100_)))) 
           ^ (((IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030067_)))));
    vlSelf->wasmetal_core__DOT___030071_ = ((IData)(vlSelf->wasmetal_core__DOT___030103_)
                                             ? (IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128249___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030231_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030230_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030229_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030228_)))) 
           ^ (((IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030163_)))));
    vlSelf->wasmetal_core__DOT___030167_ = ((IData)(vlSelf->wasmetal_core__DOT___030231_)
                                             ? (IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d));
    vlSelf->wasmetal_core__DOT___063195_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063192_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063191_)))))));
    vlSelf->wasmetal_core__DOT___063201_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063198_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063197_)))))));
    vlSelf->wasmetal_core__DOT___063207_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063203_)))))));
    vlSelf->wasmetal_core__DOT___063213_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063210_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063209_)))))));
    vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028298_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028233_));
    vlSelf->wasmetal_core__DOT___044886_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027409_));
    vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027346_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127438___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005868_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003806_)))) 
           ^ (((IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___022514_)))));
    vlSelf->wasmetal_core__DOT___022519_ = ((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                            & (IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___013709_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h29c879e7__0))))))));
    vlSelf->wasmetal_core__DOT___013663_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h29c879e7__0))))))));
    vlSelf->wasmetal_core__DOT___013716_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6ae1a845__0))))))));
    vlSelf->wasmetal_core__DOT___013682_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6ae1a845__0)))));
    vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013701_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127628___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___024004_));
    vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023742_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d));
    vlSelf->__VdfgTmp_hff1f1b74__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127611___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_));
    vlSelf->__VdfgTmp_he6c218f0__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127611___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_));
    vlSelf->__VdfgTmp_h2bc5853c__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127611___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003810_));
    vlSelf->__VdfgTmp_hec73a4f8__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127611___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->wasmetal_core__DOT____Vcellout___127458___O 
        = ((IData)(vlSelf->__VdfgTmp_h68317e95__0) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                & (IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___022660_)))));
    vlSelf->wasmetal_core__DOT___127491___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___022930_));
    vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022787_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))));
    vlSelf->__VdfgTmp_h5308e2ff__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127482___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_));
    vlSelf->__VdfgTmp_h360b04fb__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127482___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_));
    vlSelf->__VdfgTmp_h6a2fda60__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127482___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003810_));
    vlSelf->__VdfgTmp_h607e9020__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127482___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->wasmetal_core__DOT____Vcellout___128652___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000592_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000565_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___000543_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___000521_)))))) 
           ^ (((IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034362_)))));
    vlSelf->wasmetal_core__DOT___034366_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000592_)) 
                                            & (IData)(wasmetal_core__DOT___128652___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128117___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028858_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028822_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___128082___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028478_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128082___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___005368_));
    vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036981_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h0bfb68a4__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128046___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028101_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028100_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028099_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028098_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028065_)))));
    vlSelf->wasmetal_core__DOT___028069_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028101_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0x13U)));
    vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026468_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b22__05d));
    vlSelf->wasmetal_core__DOT___128552___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033429_));
    vlSelf->wasmetal_core__DOT____Vcellout___127561___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006171_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005711_)))) 
           ^ (((IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023457_)))));
    vlSelf->wasmetal_core__DOT___023462_ = ((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                            & (IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127578___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___002631_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0d220f7a__0))) 
           ^ (((IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023578_)))));
    vlSelf->wasmetal_core__DOT___023583_ = ((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                            & (IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128100___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028654_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128100___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___005368_));
    vlSelf->wasmetal_core__DOT___128135___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029066_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029030_)
            : (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___128127___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028966_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128127___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b25__05d));
    vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000564_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000564_)
            : (IData)(vlSelf->wasmetal_core__DOT___128440___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045373_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128108___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b53__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b55__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b54__05d)))))))));
    vlSelf->wasmetal_core__DOT___045385_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b55__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b54__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(wasmetal_core__DOT____Vcellout___128108___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___045372_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT___045384_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128108___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b52__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128107___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b51__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128107___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___128109___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028757_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028723_)
            : (IData)(vlSelf->wasmetal_core__DOT___000520_));
    vlSelf->wasmetal_core__DOT___071273_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071272_))));
    vlSelf->wasmetal_core__DOT___071268_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071267_))));
    vlSelf->wasmetal_core__DOT___045339_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052140_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h23d702b8__0))))))));
    vlSelf->wasmetal_core__DOT___045351_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052140_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052449_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052448_)))))))));
    vlSelf->wasmetal_core__DOT___045338_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052447_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052139_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052445_)))))))));
    vlSelf->wasmetal_core__DOT___045350_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052139_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052447_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052445_)))))))));
    vlSelf->wasmetal_core__DOT___128091___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026679_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026613_)
            : (IData)(vlSelf->wasmetal_core__DOT___000520_));
    vlSelf->wasmetal_core__DOT___054366_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054372_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054368_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054370_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127940___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027149_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027083_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d));
    vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026576_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000477_));
}
