#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__6(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__6\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___046803_;
    wasmetal_core__DOT___046803_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___046936_;
    wasmetal_core__DOT___046936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049218_;
    wasmetal_core__DOT___049218_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___135458___O;
    wasmetal_core__DOT____Vcellout___135458___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127996___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127996___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128157___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128157___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128190___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128190___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128207___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128207___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128224___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128224___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128276___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128276___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128330___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128330___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128354___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128354___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128372___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128372___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128442___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128442___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128475___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128475___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h598a1bee__0;
    __VdfgTmp_h598a1bee__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___053041_ = (1U & (IData)(
                                                         (0xc0000000aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053037_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053036_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053035_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1ce9b3c5__0))))))));
    vlSelf->type_expected = (((0xa3U >> (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___053027_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b31__05d)))) 
                              << 0x1fU) | ((0x40000000U 
                                            & ((0xa3U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053037_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b30__05d)))) 
                                               << 0x1eU)) 
                                           | ((0x20000000U 
                                               & ((0xa3U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053032_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b29__05d)))) 
                                                  << 0x1dU)) 
                                              | ((0x10000000U 
                                                  & ((0xa3U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053031_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b28__05d)))) 
                                                     << 0x1cU)) 
                                                 | ((0x8000000U 
                                                     & ((0xa3U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053028_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b27__05d)))) 
                                                        << 0x1bU)) 
                                                    | ((0x4000000U 
                                                        & ((0xf0f0ccaaU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__expected_type__05b26__05d) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_ha0b2a3dd__0))))) 
                                                           << 0x1aU)) 
                                                       | ((0x2000000U 
                                                           & ((0xa3U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053025_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b25__05d)))) 
                                                              << 0x19U)) 
                                                          | ((0x1000000U 
                                                              & ((0xa3U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053036_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b24__05d)))) 
                                                                 << 0x18U)) 
                                                             | ((0x800000U 
                                                                 & ((0xf0f0ccaaU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__expected_type__05b23__05d) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h1ce9b3c5__0))))) 
                                                                    << 0x17U)) 
                                                                | ((0x400000U 
                                                                    & ((0xa3U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053029_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b22__05d)))) 
                                                                       << 0x16U)) 
                                                                   | ((0x200000U 
                                                                       & ((0xa3U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053024_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b21__05d)))) 
                                                                          << 0x15U)) 
                                                                      | ((0x100000U 
                                                                          & ((0xa3U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053026_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b20__05d)))) 
                                                                             << 0x14U)) 
                                                                         | ((0x80000U 
                                                                             & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053035_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b19__05d)))) 
                                                                                << 0x13U)) 
                                                                            | ((0x40000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053034_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b18__05d)))) 
                                                                                << 0x12U)) 
                                                                               | ((0x20000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053030_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b17__05d)))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053033_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b16__05d)))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053051_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b15__05d)))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053050_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b14__05d)))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053057_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b13__05d)))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053056_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b12__05d)))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053053_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b11__05d)))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053052_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b10__05d)))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053055_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b9__05d)))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053054_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b8__05d)))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052735_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b7__05d)))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052734_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b6__05d)))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053021_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b5__05d)))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053023_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b4__05d)))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053049_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b3__05d)))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053048_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b2__05d)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053047_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b1__05d)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053046_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b0__05d))))))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___053478_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048333_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048380_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048394_)))));
    vlSelf->wasmetal_core__DOT___050361_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048394_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048396_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048395_)))));
    vlSelf->wasmetal_core__DOT___030721_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007203_))));
    vlSelf->wasmetal_core__DOT___030722_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007205_))));
    vlSelf->wasmetal_core__DOT___052730_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048486_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02erunning)))));
    vlSelf->wasmetal_core__DOT___053487_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048486_))));
    vlSelf->wasmetal_core__DOT___019229_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4cc7c9a__0))));
    vlSelf->wasmetal_core__DOT___060720_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4cc7c9a__0))));
    vlSelf->wasmetal_core__DOT___055348_ = (1U & (0x1c1c1c3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048283_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xa3330000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055315_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0xff00ff44440f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055315_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055311_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_x 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048441_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019204_))))))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & vlSelf->insn_op)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048329_)))))));
    vlSelf->wasmetal_core__DOT___055339_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055315_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xccaaf0f0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___055311_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (vlSelf->insn_x 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & vlSelf->insn_x) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8cb32961__0))))));
    vlSelf->wasmetal_core__DOT___055316_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055315_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xefffffff00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055312_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048499_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048500_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (0x3fU 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0xcU)))) 
                                                                                << 2U)) 
                                                                             | (3U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0x1aU)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xefffffffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___055311_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((1U 
                                                                             >> 
                                                                             (0xfU 
                                                                              & (vlSelf->insn_x 
                                                                                >> 0xfU))) 
                                                                            << 4U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054680_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054679_) 
                                                                               << 2U) 
                                                                              | (3U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___012661_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056601_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010378_))));
    vlSelf->wasmetal_core__DOT___012452_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056601_))));
    vlSelf->wasmetal_core__DOT___011101_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___054672_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007207_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hac22065f__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008810_));
    vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___033032_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___008810_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___033032_))));
    vlSelf->wasmetal_core__DOT___000152_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___063007_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048431_))));
    vlSelf->wasmetal_core__DOT___050398_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048431_))));
    vlSelf->__VdfgTmp_h66357502__0 = (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048431_));
    vlSelf->wasmetal_core__DOT___053019_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053018_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053017_))));
    vlSelf->wasmetal_core__DOT___053344_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053273_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053260_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053272_)))));
    vlSelf->wasmetal_core__DOT___053575_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053260_))));
    vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030687_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->__VdfgTmp_h508bc82d__0 = (((IData)(vlSelf->wasmetal_core__DOT___048393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048392_));
    if (vlSelf->wasmetal_core__DOT___003033_) {
        vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003033_)));
    } else {
        vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003033_)));
        vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003033_)));
        vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__2__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003033_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___135025___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                 | (4U >> (IData)(vlSelf->__VdfgTmp_hefabe8e1__0))));
    vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__ 
        = (1U & ((4U >> (IData)(vlSelf->__VdfgTmp_hefabe8e1__0)) 
                 | (8U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))));
    vlSelf->wasmetal_core__DOT___135029___DOT__CO__BRA__0__KET__ 
        = (1U & (5U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0)));
    vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__ 
        = (1U & ((4U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___003030_)));
    vlSelf->wasmetal_core__DOT___070623_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070600_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h360595f8__0)))));
    vlSelf->wasmetal_core__DOT___070604_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070599_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h360595f8__0))))));
    vlSelf->wasmetal_core__DOT___005714_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003031_)) 
                                                  | ((~ (IData)(vlSelf->wasmetal_core__DOT___003032_)) 
                                                     | (IData)(
                                                               (0xfeeffffeffffefffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hb9f44c2b__0)))))))));
    vlSelf->wasmetal_core__DOT___042723_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070601_))));
    vlSelf->wasmetal_core__DOT___070603_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h360595f8__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070601_))));
    vlSelf->wasmetal_core__DOT___005715_ = (1U & ((~ 
                                                   (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0))) 
                                                  | (IData)(
                                                            (0xfff7ff4fffffffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___003033_))))))))));
    vlSelf->wasmetal_core__DOT___005712_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                                                  | (IData)(
                                                            (0xff0fff77ffffffffULL 
                                                             >> 
                                                             ((0x20U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0)) 
                                                                  << 5U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005723_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))))))))))));
    vlSelf->wasmetal_core__DOT___070612_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003028_))));
    vlSelf->wasmetal_core__DOT___070617_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003035_)))));
    vlSelf->wasmetal_core__DOT___070614_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070606_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0))))));
    vlSelf->wasmetal_core__DOT___058559_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003028_))));
    vlSelf->wasmetal_core__DOT___058525_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0))))));
    vlSelf->wasmetal_core__DOT___053429_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053427_))));
    vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036782_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036749_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h85ffa972__0))));
    vlSelf->wasmetal_core__DOT___053093_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053092_))));
    vlSelf->wasmetal_core__DOT___070452_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052650_))));
    vlSelf->wasmetal_core__DOT___063453_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063448_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063449_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052847_)))))))));
    vlSelf->wasmetal_core__DOT___063451_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063449_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063448_)))));
    vlSelf->wasmetal_core__DOT___051188_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050322_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050310_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h87f17c6b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h60760575__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6239803f__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050303_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf690becd__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6a500089__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he6124d0b__0))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050318_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfa693494__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7031c855__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1756308__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___051098_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051082_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051005_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9adc8e2b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h35252d63__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac7d774c__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051078_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc9d2c329__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h745b6463__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h41f0b476__0))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051001_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ee84e09__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h05fef25b__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf75b3db8__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___050252_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050192_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050184_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b16__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b30__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b29__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b28__05d)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050188_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b47__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b46__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b45__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b44__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b39__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b38__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b36__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b35__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b34__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b32__05d)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050180_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b55__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b54__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b52__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b59__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b58__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b56__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b62__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b60__05d)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___050032_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049968_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049956_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b16__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b30__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b29__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b28__05d)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049964_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b47__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b46__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b45__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b44__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b39__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b38__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b36__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b35__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b34__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b32__05d)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049960_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b55__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b54__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b52__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b59__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b58__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b56__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b62__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b60__05d)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___049419_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049399_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0f8ff227__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28f7b227__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed4d342a__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051603_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050918_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h473eb647__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1387689e__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ce46baf__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051682_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051678_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h63b8fe6d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f9812e4__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h40ae3a4f__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050763_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050759_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h43fa682b__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbdf51c76__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0b1aa625__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050654_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050650_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28b8e598__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51b306d7__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3b58ae94__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050771_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050606_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6d99021a__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf4526f03__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc7c61c07__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050583_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050579_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b79__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b78__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b77__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b76__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b71__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b70__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b69__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b68__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b67__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b66__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b65__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b64__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051459_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051023_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b147__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b146__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b145__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b144__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b155__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b154__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b153__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b152__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b159__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b158__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b157__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b156__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___053468_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051847_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b207__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b206__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b205__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b204__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b199__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b198__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b197__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b196__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b195__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b194__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b193__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b192__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___072235_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072231_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b79__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b78__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b77__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b76__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b71__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b70__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b69__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b68__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b67__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b66__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b65__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b64__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___072227_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072223_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b147__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b146__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b145__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b144__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b155__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b154__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b153__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b152__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b159__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b158__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b157__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b156__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051396_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051384_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b207__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b206__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b205__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b204__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b199__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b198__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b197__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b196__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b195__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b194__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b193__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b192__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051043_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051027_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf690becd__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6a500089__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he6124d0b__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050755_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050742_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc9d2c329__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h745b6463__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h41f0b476__0))))))))))))));
    vlSelf->wasmetal_core__DOT___053452_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053444_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b47__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b46__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b45__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b44__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b39__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b38__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b36__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b35__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b34__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b32__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___072251_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072247_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b47__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b46__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b45__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b44__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b39__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b38__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b36__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b35__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b34__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b32__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050264_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044486_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044487_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___044485_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8d479abc__0))))))));
    if (vlSelf->wasmetal_core__DOT___044487_) {
        if (vlSelf->wasmetal_core__DOT___044486_) {
            if (vlSelf->wasmetal_core__DOT___044485_) {
                vlSelf->wasmetal_core__DOT___044476_ 
                    = (1U & ((4U >> (IData)(vlSelf->__VdfgTmp_h8d479abc__0)) 
                             | (IData)(vlSelf->wasmetal_core__DOT___044479_)));
                vlSelf->wasmetal_core__DOT___045768_ 
                    = (1U & ((~ (4U >> (IData)(vlSelf->__VdfgTmp_h8d479abc__0))) 
                             & (1U >> (IData)(vlSelf->__VdfgTmp_h8d479abc__0))));
            } else {
                vlSelf->wasmetal_core__DOT___044476_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044485_)));
                vlSelf->wasmetal_core__DOT___045768_ = 0U;
            }
        } else {
            vlSelf->wasmetal_core__DOT___044476_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044486_)));
            vlSelf->wasmetal_core__DOT___045768_ = 0U;
        }
    } else {
        vlSelf->wasmetal_core__DOT___044476_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044487_)));
        vlSelf->wasmetal_core__DOT___045768_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___050965_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___050961_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b22__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b11__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b10__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b9__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b8__05d)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1000000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___050942_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050941_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050940_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b24__05d))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b29__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b28__05d))))))))))));
    vlSelf->__VdfgTmp_h654859ed__0 = (((IData)(vlSelf->wasmetal_core__DOT___050959_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044459_));
    vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031341_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___063077_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063054_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053434_))));
    vlSelf->wasmetal_core__DOT___052695_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052694_))));
    vlSelf->__VdfgTmp_hd6897962__0 = (((IData)(vlSelf->wasmetal_core__DOT___062601_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___062603_));
    if (vlSelf->wasmetal_core__DOT__sp__05b9__05d) {
        vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
        vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b10__05d) {
        vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
        wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
        wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
        wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128516___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                       >> 1U)) << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                   >> 3U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (0x78U 
                                                   >> 
                                                   (7U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))) {
        vlSelf->wasmetal_core__DOT___033129_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033223_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033995_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033129_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033223_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033995_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128524___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                       >> 1U)) << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                   >> 3U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (6U 
                                                   >> 
                                                   (3U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       >> 1U))))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128601___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                       >> 1U)) << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                   >> 3U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (0x1eU 
                                                   >> 
                                                   (7U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___062959_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053616_))));
    vlSelf->wasmetal_core__DOT___062195_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009541_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009544_))));
    vlSelf->wasmetal_core__DOT___050450_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048518_))));
    vlSelf->wasmetal_core__DOT___062961_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053616_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009544_))));
    vlSelf->wasmetal_core__DOT___050360_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048431_))));
    vlSelf->wasmetal_core__DOT___048488_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009544_))));
    vlSelf->wasmetal_core__DOT___054466_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054459_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf78fffffffffffffULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & (vlSelf->insn_op 
                                                                      << 5U)) 
                                                                  | ((0x10U 
                                                                      & (vlSelf->insn_op 
                                                                         >> 1U)) 
                                                                     | ((8U 
                                                                         & (vlSelf->insn_op 
                                                                            << 1U)) 
                                                                        | ((4U 
                                                                            & (vlSelf->insn_op 
                                                                               >> 1U)) 
                                                                           | ((2U 
                                                                               & vlSelf->insn_op) 
                                                                              | (1U 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U)))))))))))));
    vlSelf->wasmetal_core__DOT__access_size__05b2__05d 
        = (1U & (0xbbb0U >> (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054463_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___054459_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf5557fff57775f5fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & (vlSelf->insn_op 
                                                                      << 3U)) 
                                                                  | ((0x10U 
                                                                      & (vlSelf->insn_op 
                                                                         << 1U)) 
                                                                     | ((8U 
                                                                         & (vlSelf->insn_op 
                                                                            << 2U)) 
                                                                        | ((4U 
                                                                            & (vlSelf->insn_op 
                                                                               >> 2U)) 
                                                                           | ((2U 
                                                                               & (vlSelf->insn_op 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (vlSelf->insn_op 
                                                                                >> 5U)))))))))))))));
    vlSelf->wasmetal_core__DOT__access_size__05b1__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___054459_) 
                              << 3U) | ((4U & ((IData)(
                                                       (0xf74f3fffffffffffULL 
                                                        >> 
                                                        ((0x30U 
                                                          & vlSelf->insn_op) 
                                                         | (IData)(vlSelf->__VdfgTmp_h97facc1b__0)))) 
                                               << 2U)) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT___054460_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___048430_))))));
    vlSelf->wasmetal_core__DOT__access_size__05b0__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___054459_) 
                              << 3U) | ((4U & ((IData)(
                                                       (0xfb8ffff3ffffffffULL 
                                                        >> 
                                                        ((0x20U 
                                                          & vlSelf->insn_op) 
                                                         | ((0x10U 
                                                             & (vlSelf->insn_op 
                                                                << 1U)) 
                                                            | ((8U 
                                                                & (vlSelf->insn_op 
                                                                   << 2U)) 
                                                               | ((4U 
                                                                   & vlSelf->insn_op) 
                                                                  | ((2U 
                                                                      & (vlSelf->insn_op 
                                                                         >> 3U)) 
                                                                     | (1U 
                                                                        & vlSelf->insn_op)))))))) 
                                               << 2U)) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT___054457_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___048430_))))));
    vlSelf->wasmetal_core__DOT___053484_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009541_))));
    vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 0xaU) & (IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x400U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 0xaU) : (IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128157___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128190___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128207___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128372___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128276___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128224___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029944_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029911_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d));
    vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032896_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032863_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    wasmetal_core__DOT___127996___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128946___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063121_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128197___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063127_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128197___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063133_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128197___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063139_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128197___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029775_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029742_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d));
    vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029412_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029379_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b8__05d));
    vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027831_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027798_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b8__05d));
    vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 0xaU) & (IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029251_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029218_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d));
    wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 0xaU)) & (IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___019519_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b33__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071672_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019624_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b97__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071672_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019533_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b35__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071676_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019635_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b99__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071676_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->__VdfgTmp_h7e4d3970__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___071646_));
    vlSelf->__VdfgTmp_h5e77e03a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___071657_));
    vlSelf->wasmetal_core__DOT___071613_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071612_)))));
    vlSelf->__VdfgTmp_h0be8b807__0 = (((IData)(vlSelf->wasmetal_core__DOT___071612_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___071656_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))))));
    vlSelf->wasmetal_core__DOT___019485_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b9__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071625_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019596_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b73__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071625_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019512_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b25__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071663_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019617_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b89__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071663_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019554_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b41__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071687_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019646_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b105__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071687_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___045538_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b7__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b6__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045537_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b3__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O))))))))));
    vlSelf->wasmetal_core__DOT___045550_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b5__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b6__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b7__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045549_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b2__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b3__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b4__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O))))))))));
    vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032224_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032191_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___070637_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b6__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032704_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032671_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___067570_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067560_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067559_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
    vlSelf->wasmetal_core__DOT___067364_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067360_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0x1dU)))))));
    vlSelf->wasmetal_core__DOT___067220_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067216_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0x1bU)))))));
    vlSelf->wasmetal_core__DOT___067508_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067504_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                          << 1U) 
                                                         | (vlSelf->mem_rdata[0U] 
                                                            >> 0x1fU))))));
    vlSelf->__VdfgTmp_hdc8ebfb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___066373_));
    vlSelf->wasmetal_core__DOT___069681_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xd00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___066457_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069676_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069675_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->mem_rdata[1U] 
                                                                                >> 9U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___069912_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067264_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x19U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1aU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___069584_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069607_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069746_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069365_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069726_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069721_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069720_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[1U] 
                                                                           >> 8U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[0U] 
                                                                              >> 0x11U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hede308eb__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x13U))))));
    vlSelf->wasmetal_core__DOT___069769_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069765_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069764_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[2U] 
                                                                     >> 0x12U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___069262_)))))))));
    vlSelf->wasmetal_core__DOT___069813_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069808_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069807_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[1U] 
                                                                           >> 0xcU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[0U] 
                                                                              >> 0x15U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hede308eb__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___069854_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067042_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x16U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x17U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___069936_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067360_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x1aU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1bU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT___070202_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___070217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___070349_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069790_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069786_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (vlSelf->mem_rdata[0U] 
                                                                              >> 0x15U)) 
                                                                          | (1U 
                                                                             & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x16U))))))))));
    vlSelf->wasmetal_core__DOT___069704_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xd00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___066480_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069699_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069698_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->mem_rdata[1U] 
                                                                                >> 0xaU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x12U))))));
    vlSelf->wasmetal_core__DOT___069891_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067216_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x18U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x19U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___070300_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070299_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x12U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x1bU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___069871_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067110_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x17U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x18U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___069974_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067504_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x1cU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1dU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[2U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___069953_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067428_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x1bU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1cU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1eU))))));
    vlSelf->wasmetal_core__DOT___070314_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070313_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x13U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___069319_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069315_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->mem_rdata[2U]) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___067560_)))))));
    vlSelf->wasmetal_core__DOT___070366_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067042_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070365_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0x19U))))))));
    vlSelf->wasmetal_core__DOT___070378_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067110_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070377_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0x1aU))))))));
    vlSelf->wasmetal_core__DOT___070390_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067216_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070389_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0x1bU))))))));
    vlSelf->wasmetal_core__DOT___070264_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070263_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0xfU)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___070276_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070275_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x10U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x19U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___070326_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070325_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x14U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___070440_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067504_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070439_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (vlSelf->mem_rdata[3U] 
                                                               >> 0x1fU)))))));
    vlSelf->wasmetal_core__DOT___070414_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___070426_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->__VdfgTmp_h3313b173__0 = (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___069262_));
    vlSelf->wasmetal_core__DOT___070636_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070634_)))))))));
    vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037214_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037182_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h13ef8f89__0))));
    vlSelf->wasmetal_core__DOT___034697_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128711___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d)))));
    vlSelf->wasmetal_core__DOT___034696_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128711___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d)))));
    vlSelf->wasmetal_core__DOT___034691_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128711___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___034680_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128711___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035146_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035081_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128695___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034925_)))));
    vlSelf->wasmetal_core__DOT___034953_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026291_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026258_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b8__05d));
    vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026195_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026162_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d));
    vlSelf->wasmetal_core__DOT___063487_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063495_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063503_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063511_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___054485_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127835___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054487_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127835___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054489_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127835___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054491_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127835___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026387_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026354_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d));
    vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032829_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                     >> 1U)));
    vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___030820_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b3__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135451___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046799_))))));
    vlSelf->wasmetal_core__DOT___030809_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135451___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046798_))))));
    vlSelf->wasmetal_core__DOT___030798_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135451___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046797_))))));
    vlSelf->wasmetal_core__DOT___030787_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135451___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__))))));
    wasmetal_core__DOT___046803_ = ((IData)(vlSelf->wasmetal_core__DOT___046800_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___046834_));
    wasmetal_core__DOT___128330___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031192_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b2__05d));
    wasmetal_core__DOT___128354___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031480_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d));
    wasmetal_core__DOT___128442___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032503_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___032375_));
    vlSelf->wasmetal_core__DOT___031778_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135467___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046932_))))));
    vlSelf->wasmetal_core__DOT___031767_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135467___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046931_))))));
    vlSelf->wasmetal_core__DOT___031756_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135467___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046930_))))));
    vlSelf->wasmetal_core__DOT___031745_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135467___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__))))));
    wasmetal_core__DOT___046936_ = ((IData)(vlSelf->wasmetal_core__DOT___046933_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___046967_));
    vlSelf->wasmetal_core__DOT___051991_ = (1U & (IData)(
                                                         (0xbb3f3f3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051990_) 
                                                            << 5U) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049599_))))))));
    vlSelf->wasmetal_core__DOT___053216_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x773f3f3fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___053154_) 
                                                                   << 5U) 
                                                                  | ((0x18U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                         << 3U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049599_)))))))))))));
    vlSelf->wasmetal_core__DOT___050983_ = (1U & (IData)(
                                                         (0xee000f00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050796_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050793_)))))))));
    vlSelf->wasmetal_core__DOT___053875_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b117__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051067_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xc0aU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0))))))));
    vlSelf->wasmetal_core__DOT___009524_ = (1U & (IData)(
                                                         (0xef00efef00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b53__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051067_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051066_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))))))));
    vlSelf->wasmetal_core__DOT___053525_ = (1U & (IData)(
                                                         (0xcc0c5505ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053524_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051066_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))));
    vlSelf->wasmetal_core__DOT___053805_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b101__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053524_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051758_))))));
    vlSelf->wasmetal_core__DOT___051859_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049216_))));
    wasmetal_core__DOT___049218_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___049216_))));
    vlSelf->wasmetal_core__DOT___051374_ = (1U & (IData)(
                                                         (0xbf00bfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b58__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051371_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (1U 
                                                                          & (0x8fU 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                              << 2U)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb829d41d__0))))))));
    vlSelf->wasmetal_core__DOT___051588_ = (1U & (0x3b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b61__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051585_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051584_)))))));
    vlSelf->wasmetal_core__DOT___053112_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051584_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128569___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b10__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b9__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b8__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b7__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b10__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___053060_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053059_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053058_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053057_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053056_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053055_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053054_)))))))));
    vlSelf->wasmetal_core__DOT___053044_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053023_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053022_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053021_)))));
    vlSelf->wasmetal_core__DOT___053045_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053043_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053042_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053041_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___053030_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053029_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___053028_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053027_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xc0000000aULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053025_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053024_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha0b2a3dd__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___031968_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053478_))));
    vlSelf->wasmetal_core__DOT___031967_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053478_))));
    vlSelf->wasmetal_core__DOT___069275_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050361_))));
    vlSelf->wasmetal_core__DOT___062606_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053483_)))));
    vlSelf->wasmetal_core__DOT___062605_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050361_))));
    vlSelf->wasmetal_core__DOT___050441_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050361_))));
    vlSelf->wasmetal_core__DOT___050362_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030721_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___019810_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->reset) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052730_))));
    vlSelf->wasmetal_core__DOT___060773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060720_))));
    vlSelf->wasmetal_core__DOT___019220_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060720_))));
    wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b12__05d) {
        wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        vlSelf->wasmetal_core__DOT___032611_ = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
    } else {
        wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___032611_ = wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b11__05d) {
        vlSelf->wasmetal_core__DOT___031875_ = vlSelf->wasmetal_core__DOT__sp__05b11__05d;
        vlSelf->wasmetal_core__DOT___033910_ = vlSelf->wasmetal_core__DOT__sp__05b11__05d;
        vlSelf->wasmetal_core__DOT___032932_ = vlSelf->wasmetal_core__DOT__sp__05b11__05d;
    } else {
        vlSelf->wasmetal_core__DOT___031875_ = wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033910_ = wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032932_ = wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___055325_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055322_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054672_)))))))));
    vlSelf->wasmetal_core__DOT___054686_ = (1U & (IData)(
                                                         (0xbf00bfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_x 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054672_)))))))));
    vlSelf->wasmetal_core__DOT___054676_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054672_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053773_)))));
    vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___033033_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___033033_))));
    vlSelf->wasmetal_core__DOT___063428_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063007_))));
    vlSelf->wasmetal_core__DOT___050401_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050398_))));
    vlSelf->wasmetal_core__DOT___063825_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___010423_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048370_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___054752_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___008018_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___062968_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053019_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0))));
    vlSelf->wasmetal_core__DOT___053491_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053283_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053344_))));
    vlSelf->__VdfgTmp_h5c1295c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___053575_));
    vlSelf->wasmetal_core__DOT___063380_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063375_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053575_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___050405_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050397_))));
    if (vlSelf->wasmetal_core__DOT___003035_) {
        vlSelf->wasmetal_core__DOT___035237_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___003035_)));
        vlSelf->wasmetal_core__DOT___035253_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___003035_)));
        vlSelf->wasmetal_core__DOT___036925_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___003035_)));
    } else {
        vlSelf->wasmetal_core__DOT___035237_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___035253_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___036925_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128722___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                               << 2U) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                                                << 1U)) 
                                         | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128724___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                          << 1U) | 
                                         (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT____Vcellout___134177___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003033_)) 
                                     << 2U)) | (IData)(vlSelf->__VdfgTmp_hefabe8e1__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___037030_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___134190___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003035_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                        << 2U) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___003034_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___042546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070623_))));
    vlSelf->wasmetal_core__DOT___070618_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047979_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070604_)))));
    vlSelf->wasmetal_core__DOT___042535_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042723_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070623_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003033_)))));
    vlSelf->wasmetal_core__DOT___042616_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070603_))));
    vlSelf->wasmetal_core__DOT___042646_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070603_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    vlSelf->wasmetal_core__DOT___070631_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070612_))));
    vlSelf->wasmetal_core__DOT___070613_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070612_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003035_))));
    vlSelf->wasmetal_core__DOT___042558_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070617_))));
    vlSelf->wasmetal_core__DOT___042694_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070614_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070612_))));
    vlSelf->wasmetal_core__DOT___018382_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058559_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___048210_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))))))))));
    vlSelf->wasmetal_core__DOT___058938_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058559_))));
    vlSelf->wasmetal_core__DOT___070605_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058559_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003035_))));
    vlSelf->wasmetal_core__DOT___042740_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070606_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058559_))));
    vlSelf->wasmetal_core__DOT___042581_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058525_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003033_)))));
    vlSelf->wasmetal_core__DOT___070630_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058525_))));
    vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036783_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_haa7ff968__0))));
    vlSelf->wasmetal_core__DOT___063452_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063451_))));
    vlSelf->wasmetal_core__DOT___063464_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063463_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063472_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063471_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063480_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063479_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___051686_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051043_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051031_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfa693494__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7031c855__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1756308__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051035_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h87f17c6b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h60760575__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6239803f__0))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051039_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h980fd1a4__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h12f13bc4__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3ca396d5__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___050775_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050755_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050738_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ee84e09__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h05fef25b__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf75b3db8__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050728_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9adc8e2b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h35252d63__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac7d774c__0))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050751_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb13e555e__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4fc63e3e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b3781b6__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___053472_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053452_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053448_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b55__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b54__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b52__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b59__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b58__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b56__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b62__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b60__05d)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051878_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b16__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b30__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b29__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b28__05d)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b6__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b4__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b8__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b14__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b13__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b12__05d)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___072255_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072251_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051442_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b55__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b54__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b52__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b59__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b58__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b56__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b62__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b60__05d)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072243_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b16__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b30__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b29__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b28__05d)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072239_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b6__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b4__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b8__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b14__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b13__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b12__05d)))))))))))))))))))))))));
    if (vlSelf->wasmetal_core__DOT___044467_) {
        if (vlSelf->wasmetal_core__DOT___044466_) {
            if (vlSelf->wasmetal_core__DOT___044465_) {
                vlSelf->wasmetal_core__DOT___044456_ 
                    = (1U & ((1U >> (IData)(vlSelf->__VdfgTmp_h654859ed__0)) 
                             | (IData)(vlSelf->wasmetal_core__DOT___044459_)));
                vlSelf->wasmetal_core__DOT___045759_ 
                    = (1U & ((~ (1U >> (IData)(vlSelf->__VdfgTmp_h654859ed__0))) 
                             & (4U >> (IData)(vlSelf->__VdfgTmp_h654859ed__0))));
            } else {
                vlSelf->wasmetal_core__DOT___044456_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044465_)));
                vlSelf->wasmetal_core__DOT___045759_ = 0U;
            }
        } else {
            vlSelf->wasmetal_core__DOT___044456_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044466_)));
            vlSelf->wasmetal_core__DOT___045759_ = 0U;
        }
    } else {
        vlSelf->wasmetal_core__DOT___044456_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044467_)));
        vlSelf->wasmetal_core__DOT___045759_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031352_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___062619_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062618_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062617_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062631_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062630_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062629_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062642_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062640_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062653_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062652_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062651_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062664_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062663_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062662_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062675_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062673_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062686_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062685_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062684_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128516___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128516___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))) {
        vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033129_));
        vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033223_));
        vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033995_));
    }
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128524___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128524___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128601___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128601___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT___063059_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063054_))));
    vlSelf->wasmetal_core__DOT___063078_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xfU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063077_)))));
    vlSelf->__VdfgTmp_h277c2e25__0 = (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___063054_)))));
    vlSelf->wasmetal_core__DOT__access_size__05b3__05d 
        = (1U & (IData)((0xffffffff00010000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___054466_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054465_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054460_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054457_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054463_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128028___O 
        = (0xfU & ((vlSelf->insn_z >> 8U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__2__KET__) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__1__KET__) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__0__KET__) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___027958_))))));
    vlSelf->wasmetal_core__DOT___027931_ = ((vlSelf->insn_z 
                                             >> 0xbU) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128268___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0xbU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0xaU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 9U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 8U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030493_)))));
    vlSelf->wasmetal_core__DOT___030466_ = (1U & ((0x800U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 0xbU)
                                                   : (IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128004___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b10__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h5a9aeb48__0))) 
           ^ (((IData)(wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027733_)))));
    vlSelf->wasmetal_core__DOT___027706_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128036___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028023_)))));
    vlSelf->wasmetal_core__DOT___027996_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128157___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128157___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029314_)))));
    vlSelf->wasmetal_core__DOT___029287_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128157___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128190___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b8__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128190___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029676_)))));
    vlSelf->wasmetal_core__DOT___029649_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128190___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128207___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128207___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029845_)))));
    vlSelf->wasmetal_core__DOT___029818_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128207___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128372___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128372___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031615_)))));
    vlSelf->wasmetal_core__DOT___031588_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___128372___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128420___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032096_)))));
    vlSelf->wasmetal_core__DOT___032069_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128276___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128276___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030588_)))));
    vlSelf->wasmetal_core__DOT___030561_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___128276___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128224___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128224___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030014_)))));
    vlSelf->wasmetal_core__DOT___029987_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128224___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029945_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d));
    vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032897_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127996___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128947___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128946___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128945___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128944___Q)))) 
           ^ (((IData)(wasmetal_core__DOT___127996___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027668_)))));
    vlSelf->wasmetal_core__DOT___027641_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128947___Q) 
                                            & (IData)(wasmetal_core__DOT___127996___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029776_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d));
    vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029413_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b9__05d));
    vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027832_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128257___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030374_)))));
    vlSelf->wasmetal_core__DOT___030349_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)
                                             : (IData)(wasmetal_core__DOT___128257___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128052___O 
        = (0xfU & ((vlSelf->insn_x >> 8U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__2__KET__) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__1__KET__) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__0__KET__) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028184_))))));
    vlSelf->wasmetal_core__DOT___028157_ = ((vlSelf->insn_x 
                                             >> 0xbU) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029252_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128020___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___DI) 
           ^ (((IData)(wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027894_)))));
    vlSelf->wasmetal_core__DOT___027867_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128020___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128316___O 
        = (((8U & ((~ (vlSelf->function_params >> 0xbU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0xaU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->function_params 
                                                      >> 9U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 8U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030975_)))));
    vlSelf->wasmetal_core__DOT___030948_ = ((~ (vlSelf->function_params 
                                                >> 0xbU)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___071704_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b70__05d) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0be8b807__0))))));
    vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032225_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___070639_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070637_)))))))));
    vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032705_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___068376_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067570_))));
    vlSelf->wasmetal_core__DOT___068180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067570_))));
    vlSelf->wasmetal_core__DOT___068915_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068912_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067039_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x19U))))))))));
    vlSelf->wasmetal_core__DOT___068982_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068979_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067108_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1aU))))))))));
    vlSelf->wasmetal_core__DOT___069013_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069010_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067215_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1bU))))))))));
    vlSelf->wasmetal_core__DOT___069175_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069172_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067426_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT___068678_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067570_))));
    vlSelf->wasmetal_core__DOT___068622_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068619_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x11U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___068719_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068716_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x13U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___068819_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068816_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x15U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x1eU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___069108_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069105_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067359_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1dU))))))))));
    vlSelf->wasmetal_core__DOT___066380_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066375_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xdU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 6U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066462_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066457_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xeU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 7U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066947_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066943_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x14U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xdU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066674_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066670_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x11U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xaU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066560_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066556_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x10U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 9U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066728_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066724_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x12U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xbU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066483_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066480_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xfU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 8U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066812_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066809_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x13U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xcU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___069586_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069585_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069584_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xaU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xbU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069609_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069608_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069607_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xbU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xcU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069368_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065975_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069365_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067560_)))))))));
    vlSelf->wasmetal_core__DOT___070204_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070203_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070202_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066020_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1dU))))))))));
    vlSelf->wasmetal_core__DOT___070219_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070218_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070217_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066176_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT___070351_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070349_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___068869_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x18U))))))))));
    vlSelf->wasmetal_core__DOT___070415_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070414_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069105_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1dU))))))))));
    vlSelf->wasmetal_core__DOT___070427_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070426_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069172_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT___070288_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070287_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[3U] 
                                                                     >> 0x10U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3313b173__0))))))));
    vlSelf->wasmetal_core__DOT___070338_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070337_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[3U] 
                                                                     >> 0x14U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3313b173__0))))))));
    vlSelf->wasmetal_core__DOT___044805_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070636_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___044793_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070636_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070634_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037215_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h14007945__0))));
    vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034680_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034733_));
    vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035147_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d));
    vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034953_));
    vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026292_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b9__05d));
    vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026196_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d));
    vlSelf->wasmetal_core__DOT___063488_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063487_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063496_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063495_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063504_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063503_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063512_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063511_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___054486_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054485_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054488_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054487_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 3U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054490_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054489_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 4U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054492_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054491_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 5U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026388_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b9__05d));
    wasmetal_core__DOT___128475___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032830_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128500___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032992_)))));
    vlSelf->wasmetal_core__DOT___032965_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030787_) 
           | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b0__05d));
    wasmetal_core__DOT____Vcellout___135458___O = (
                                                   (0xeU 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___046800_)) 
                                                   ^ 
                                                   ((0xeU 
                                                     & ((- (IData)((IData)(wasmetal_core__DOT___046803_))) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___046834_)));
    __VdfgTmp_h598a1bee__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046803_)) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_h54bac186__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046803_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_he0338233__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046803_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_he536c7ea__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046803_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->wasmetal_core__DOT____Vcellout___128330___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031203_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031192_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031181_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031170_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128330___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031139_ = ((IData)(vlSelf->wasmetal_core__DOT___031203_)
                                             ? (IData)(wasmetal_core__DOT___128330___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128354___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031491_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031480_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031469_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031458_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128354___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031427_ = ((IData)(vlSelf->wasmetal_core__DOT___031491_)
                                             ? (IData)(wasmetal_core__DOT___128354___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128442___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032514_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032503_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032492_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032481_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128442___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032450_ = ((IData)(vlSelf->wasmetal_core__DOT___032514_)
                                             ? (IData)(wasmetal_core__DOT___128442___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___032386_));
    vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031745_) 
           | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___135474___O 
        = ((0xeU | (IData)(vlSelf->wasmetal_core__DOT___046933_)) 
           ^ ((0xeU & ((- (IData)((IData)(wasmetal_core__DOT___046936_))) 
                       << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___046967_)));
    vlSelf->__VdfgTmp_h9a63e080__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046936_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_ha1f5c117__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046936_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_hf3cdd6fc__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046936_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_hf01f7256__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046936_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->wasmetal_core__DOT___053731_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051859_))));
    vlSelf->wasmetal_core__DOT___053844_ = (1U & (0x48ccc8ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b109__05d) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___049218_))))));
    vlSelf->wasmetal_core__DOT___049244_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___049218_))));
    vlSelf->wasmetal_core__DOT___053116_ = (1U & (IData)(
                                                         (0x1515153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053113_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053112_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128578___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b8__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b11__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128396___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(wasmetal_core__DOT___128396___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031902_)))));
    vlSelf->wasmetal_core__DOT___053073_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053047_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053046_)))));
    vlSelf->wasmetal_core__DOT___053062_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053061_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053060_))));
    vlSelf->wasmetal_core__DOT___053063_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053045_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053044_))));
    vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031967_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___062609_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x4000000000000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___062603_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___062601_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052645_)))))))))))));
    vlSelf->wasmetal_core__DOT___051210_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048393_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050441_))));
    vlSelf->wasmetal_core__DOT___050443_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050441_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->wasmetal_core__DOT___050363_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048392_))));
    vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030722_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___061348_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019220_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128460___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128460___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032637_)))));
    vlSelf->wasmetal_core__DOT___055870_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055339_))));
    vlSelf->wasmetal_core__DOT___054717_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054685_))));
    vlSelf->wasmetal_core__DOT___035269_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___128506___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___033033_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___033032_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008810_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___062991_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062968_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)))))))));
    vlSelf->wasmetal_core__DOT___062974_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x4000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053087_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062967_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___062966_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062963_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052834_))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___046221_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___062968_))));
    vlSelf->wasmetal_core__DOT___063423_ = (1U & (0xb0fffff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5c1295c2__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128282___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___030687_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___030686_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030679_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT___003028_) {
        vlSelf->wasmetal_core__DOT___128723___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___035237_));
        vlSelf->wasmetal_core__DOT___128725___DOT__CO__BRA__0__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003028_)));
        vlSelf->wasmetal_core__DOT___134191___DOT__CO__BRA__0__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003028_)));
    } else {
        vlSelf->wasmetal_core__DOT___128723___DOT__CO__BRA__0__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003028_)));
        vlSelf->wasmetal_core__DOT___128725___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___035253_));
        vlSelf->wasmetal_core__DOT___134191___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___037030_));
    }
    vlSelf->wasmetal_core__DOT___134178___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003028_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036925_)));
    vlSelf->wasmetal_core__DOT___042591_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070618_))));
    vlSelf->wasmetal_core__DOT___042687_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070618_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    if (vlSelf->wasmetal_core__DOT___042539_) {
        vlSelf->wasmetal_core__DOT___042534_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042576_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
    } else if (vlSelf->wasmetal_core__DOT___042542_) {
        if (vlSelf->wasmetal_core__DOT___042541_) {
            if (vlSelf->wasmetal_core__DOT___042536_) {
                vlSelf->wasmetal_core__DOT___042534_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                vlSelf->wasmetal_core__DOT___042576_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
            } else {
                vlSelf->wasmetal_core__DOT___042534_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042546_)
                              ? (1U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                              : (IData)(vlSelf->wasmetal_core__DOT___042535_)));
                vlSelf->wasmetal_core__DOT___042576_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042581_)
                              ? (IData)(vlSelf->wasmetal_core__DOT___135029___DOT__CO__BRA__0__KET__)
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___042740_))));
            }
        } else {
            vlSelf->wasmetal_core__DOT___042534_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            vlSelf->wasmetal_core__DOT___042576_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___042534_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        vlSelf->wasmetal_core__DOT___042576_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
    }
    vlSelf->wasmetal_core__DOT___042722_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042616_)
                                                         ? 
                                                        (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042723_))))));
    vlSelf->wasmetal_core__DOT___042643_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042646_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042723_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070604_)))));
    vlSelf->wasmetal_core__DOT___042697_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070631_))));
    vlSelf->wasmetal_core__DOT___042606_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070613_))));
    vlSelf->wasmetal_core__DOT___042707_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    vlSelf->wasmetal_core__DOT___042555_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042694_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070617_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003033_)))));
    vlSelf->wasmetal_core__DOT___042636_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058938_))));
    vlSelf->wasmetal_core__DOT___042626_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058938_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    vlSelf->wasmetal_core__DOT___042676_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070605_))));
    vlSelf->wasmetal_core__DOT___042673_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070606_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070605_))));
    vlSelf->wasmetal_core__DOT___042566_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042581_))));
    vlSelf->wasmetal_core__DOT___042664_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070614_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070630_))));
    vlSelf->wasmetal_core__DOT___042653_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070614_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070630_)))));
    vlSelf->wasmetal_core__DOT___042656_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070630_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036784_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h13987860__0))));
    vlSelf->wasmetal_core__DOT___052702_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052648_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044476_)))));
    vlSelf->wasmetal_core__DOT___071252_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__decoded_table))));
    vlSelf->wasmetal_core__DOT____Vcellout___128346___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031355_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031352_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031341_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031330_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031323_ = ((IData)(vlSelf->wasmetal_core__DOT___031355_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128595___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(wasmetal_core__DOT___128595___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033937_)))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))) {
        vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                     >> 3U));
    } else {
        vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128492___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(wasmetal_core__DOT___128492___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032959_)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135426___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__access_size__05b4__05d) 
            << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__access_size__05b3__05d) 
                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__access_size__05b2__05d) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__access_size__05b1__05d) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 0xcU) & (IData)(vlSelf->wasmetal_core__DOT___027931_));
    vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x1000U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 0xcU) : (IData)(vlSelf->wasmetal_core__DOT___030466_)));
    vlSelf->wasmetal_core__DOT___128005___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027706_));
    vlSelf->wasmetal_core__DOT___128037___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027996_));
    vlSelf->wasmetal_core__DOT___128158___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029287_));
    vlSelf->wasmetal_core__DOT___128191___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029649_));
    vlSelf->wasmetal_core__DOT___128208___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029818_));
    vlSelf->wasmetal_core__DOT___128373___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031588_));
    vlSelf->wasmetal_core__DOT____Vcellinp__frames_memory__02e0__02e0__ADDRARDADDR 
        = (0x803fU | ((0x4000U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128420___O) 
                                  << 0xeU)) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128419___O) 
                                                << 0xaU) 
                                               | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128418___O) 
                                                  << 6U))));
    vlSelf->wasmetal_core__DOT___128421___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032069_));
    vlSelf->wasmetal_core__DOT___039828_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 6U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039827_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 7U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039826_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 8U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039825_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 9U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___128277___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030561_));
    vlSelf->wasmetal_core__DOT___039791_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039790_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039801_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039804_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___128225___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029987_));
    vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029915_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d));
    vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032867_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    vlSelf->wasmetal_core__DOT___127997___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128948___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027641_));
    vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029746_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d));
    vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029383_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b10__05d));
    vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027802_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b10__05d));
    vlSelf->wasmetal_core__DOT___062717_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062728_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062739_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062750_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___128258___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030349_));
    vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 0xcU) & (IData)(vlSelf->wasmetal_core__DOT___028157_));
    vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029222_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d));
    vlSelf->wasmetal_core__DOT___128021___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027867_));
    vlSelf->wasmetal_core__DOT___044761_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128316___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128316___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128316___O)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 9U)))))))));
    vlSelf->wasmetal_core__DOT___044773_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128316___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 6U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128316___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 7U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128316___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 8U))))))))));
    vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 0xcU)) & (IData)(vlSelf->wasmetal_core__DOT___030948_));
    vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032195_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d));
    vlSelf->wasmetal_core__DOT___044806_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070639_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___044794_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070639_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070637_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032675_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037185_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h6978beee__0))));
    vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034691_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035085_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d));
    vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026262_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b10__05d));
    vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026166_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b2__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054486_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128516___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b2__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054486_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128524___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b2__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054486_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128601___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b2__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054486_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b3__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054488_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128516___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b3__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054488_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128524___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b3__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054488_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128601___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b3__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054488_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b4__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054490_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b5__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054492_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026358_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128475___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032831_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032830_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032829_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032828_)))) 
           ^ (((IData)(wasmetal_core__DOT___128475___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032795_)))));
    vlSelf->wasmetal_core__DOT___032799_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032831_)
                                                   ? (IData)(wasmetal_core__DOT___128475___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___032804_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032803_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032833_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032832_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O)))));
    vlSelf->wasmetal_core__DOT___128501___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032965_));
    vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030798_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b1__05d));
    vlSelf->wasmetal_core__DOT___030848_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b7__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___135458___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___030847_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b6__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___135458___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___030842_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b5__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___135458___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___030831_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b4__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___135458___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046800_))))));
    vlSelf->wasmetal_core__DOT___030846_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b63__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030841_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b59__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030837_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b55__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030833_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b51__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030828_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b47__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030824_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b43__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030819_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b39__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030815_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b35__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030811_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b31__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030806_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b27__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030802_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b23__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030797_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b19__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030793_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b15__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030789_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b11__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030845_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b62__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030840_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b58__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030836_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b54__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030832_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b50__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030827_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b46__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030823_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b42__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030818_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b38__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030814_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b34__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030810_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b30__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030805_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b26__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030801_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b22__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030796_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b18__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030792_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b14__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030788_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b10__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030844_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b61__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030839_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b57__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030835_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b53__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030830_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b49__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030826_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b45__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030822_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b41__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030817_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b37__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030813_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b33__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030808_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b29__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030804_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b25__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030800_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b21__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030795_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b17__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030791_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b13__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030850_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b9__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he0338233__0))));
    vlSelf->wasmetal_core__DOT___030843_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b60__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030838_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b56__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030834_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b52__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030829_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b48__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030825_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b44__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030821_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b40__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030816_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b36__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030812_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b32__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030807_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b28__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030803_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b24__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030799_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b20__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030794_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b16__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030790_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b12__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___030849_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b8__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he536c7ea__0))));
    vlSelf->wasmetal_core__DOT___128337___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031214_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031139_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d));
    vlSelf->wasmetal_core__DOT___128361___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031502_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031427_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d));
    vlSelf->wasmetal_core__DOT___063098_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128442___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___063104_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128442___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___063110_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128442___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___063116_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128442___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___128449___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032525_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032450_)
            : (IData)(vlSelf->wasmetal_core__DOT___032397_));
    vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031756_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d));
    vlSelf->wasmetal_core__DOT___031806_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135474___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___031805_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135474___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___031800_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135474___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___031789_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135474___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046933_))))));
    vlSelf->wasmetal_core__DOT___031804_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b63__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031799_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031795_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031791_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031786_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031782_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031777_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031773_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031769_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031764_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031760_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031755_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031751_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
    vlSelf->wasmetal_core__DOT___031747_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a63e080__0))));
}
