#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__24(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__24\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___019197_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048666_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001168_))))));
    vlSelf->wasmetal_core__DOT___063801_ = (1U & (0xd00d0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063795_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004857_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h136edfac__0))))));
    vlSelf->__VdfgTmp_h1f51ea8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___054995_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054996_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054998_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055000_))));
    vlSelf->wasmetal_core__DOT___055650_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055001_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h855fc881__0)))));
    vlSelf->wasmetal_core__DOT___007624_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h855fc881__0)))));
    vlSelf->__VdfgTmp_h79c46d44__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007740_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007234_))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf0f333300ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007392_))))))))));
    vlSelf->__VdfgTmp_h0e8d73de__0 = ((2U & ((0x40U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050410_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d)))) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___050407_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___050421_)))));
    vlSelf->wasmetal_core__DOT___055859_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055677_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055047_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1fccf85f__0)))));
    vlSelf->wasmetal_core__DOT___007645_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1fccf85f__0)))));
    vlSelf->wasmetal_core__DOT___010569_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007755_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___006215_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b30__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005185_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6b2c9c37__0)))))));
    vlSelf->__VdfgTmp_hb79381c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008461_));
    vlSelf->wasmetal_core__DOT___055640_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008461_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___027391_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b62__05d))));
    vlSelf->wasmetal_core__DOT___006238_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005430_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005429_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006144_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b29__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005253_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9b25c217__0)))))));
    vlSelf->wasmetal_core__DOT___001711_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4f90e104__0)))))));
    vlSelf->wasmetal_core__DOT___002234_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4f90e104__0)))));
    vlSelf->wasmetal_core__DOT___044418_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063349_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063351_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063353_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haaf717df__0))))))));
    vlSelf->wasmetal_core__DOT___044442_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063353_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063351_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063349_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054243_)))))))));
    vlSelf->wasmetal_core__DOT___055812_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008453_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054948_))))));
    vlSelf->__VdfgTmp_hdf1f98b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008453_));
    vlSelf->wasmetal_core__DOT___027390_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b61__05d))));
    vlSelf->wasmetal_core__DOT___006155_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048206_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048205_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006171_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b28__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004845_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h651d6523__0)))))));
    vlSelf->__VdfgTmp_h8eb0ad88__0 = (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8f6175c0__0));
    vlSelf->__VdfgTmp_h4f306e5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___069133_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___069084_));
    vlSelf->wasmetal_core__DOT___007340_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h504ea901__0)))));
    vlSelf->wasmetal_core__DOT___055796_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008445_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054899_))))));
    vlSelf->wasmetal_core__DOT___027389_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b60__05d))));
    vlSelf->wasmetal_core__DOT___006159_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048167_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048166_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006112_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048167_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048206_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048205_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048166_)))))));
    vlSelf->wasmetal_core__DOT___001710_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd5d1004a__0))))));
    vlSelf->wasmetal_core__DOT___002233_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd5d1004a__0))))));
    vlSelf->__VdfgTmp_h8025ed93__0 = (((IData)(vlSelf->wasmetal_core__DOT___069084_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___069033_));
    vlSelf->wasmetal_core__DOT___055784_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008432_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051493_))))));
    vlSelf->__VdfgTmp_h2577a83c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008432_));
    vlSelf->wasmetal_core__DOT___027387_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b59__05d))));
    vlSelf->wasmetal_core__DOT___005996_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048209_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048208_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006099_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b26__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004913_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9b410c9d__0)))))));
    vlSelf->wasmetal_core__DOT___001315_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfe7af35a__0))))));
    vlSelf->wasmetal_core__DOT___001785_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfe7af35a__0))))));
    vlSelf->wasmetal_core__DOT___044417_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063343_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063347_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he7fbee1d__0))))))));
    vlSelf->wasmetal_core__DOT___044441_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063347_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063343_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054237_)))))))));
    vlSelf->wasmetal_core__DOT___055418_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hd69bf43a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008424_));
    vlSelf->wasmetal_core__DOT___027386_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b58__05d))));
    vlSelf->wasmetal_core__DOT___006065_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048165_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048164_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006116_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048165_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048209_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048208_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048164_)))))));
    vlSelf->wasmetal_core__DOT___001709_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h131eee20__0)))))));
    vlSelf->wasmetal_core__DOT___000923_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h131eee20__0)))));
    vlSelf->wasmetal_core__DOT___055754_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008416_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054767_))))));
    vlSelf->__VdfgTmp_he43dd87d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008416_));
    vlSelf->wasmetal_core__DOT___027385_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b57__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d 
        = (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___005431_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005428_)))));
    vlSelf->wasmetal_core__DOT___063908_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfe7af35a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h60f9d0d9__0))))));
    vlSelf->__VdfgTmp_h78a92bf8__0 = (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h60f9d0d9__0));
    vlSelf->wasmetal_core__DOT___007771_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h528a2190__0)))));
    vlSelf->wasmetal_core__DOT___055320_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008408_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___027384_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b56__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d 
        = (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___005432_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005427_)))));
    vlSelf->wasmetal_core__DOT___006113_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005432_)) 
                                                  & (IData)(
                                                            (0xff80ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___005431_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005430_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005429_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005428_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005427_))))))))));
    vlSelf->wasmetal_core__DOT___001708_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4fe6474e__0))))));
    vlSelf->wasmetal_core__DOT___000922_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4fe6474e__0))))));
    vlSelf->__VdfgTmp_h28180847__0 = (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h2df8dd7f__0)));
    vlSelf->wasmetal_core__DOT___044415_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063337_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063339_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063341_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc7c7ad9a__0))))))));
    vlSelf->wasmetal_core__DOT___044439_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063341_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063339_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063337_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054231_)))))))));
    vlSelf->wasmetal_core__DOT___055666_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008394_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h2225d234__0 = (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008394_));
    vlSelf->wasmetal_core__DOT___027383_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b55__05d))));
    vlSelf->wasmetal_core__DOT___005962_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048149_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048148_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___005770_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h434b0db3__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b22__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003301_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd44758f6__0)))))));
    vlSelf->wasmetal_core__DOT___001313_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h67451104__0))))));
    vlSelf->wasmetal_core__DOT___001783_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h67451104__0))))));
    vlSelf->__VdfgTmp_hd96a7b90__0 = (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008386_));
    vlSelf->wasmetal_core__DOT___055641_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008386_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h99d3b9a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h447558a7__0)));
    vlSelf->wasmetal_core__DOT___048623_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048621_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005486_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005487_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005484_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005485_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b54__05d)))))))));
    vlSelf->wasmetal_core__DOT___048726_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048621_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000992_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000992_))))));
    vlSelf->wasmetal_core__DOT___027382_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b54__05d))));
    vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__ 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___048050_) 
                           << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___048049_) 
                                      << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006115_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048050_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048149_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048148_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048049_)))))));
    vlSelf->wasmetal_core__DOT___005855_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf1e329c9__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b21__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003369_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hadae1421__0)))))));
    vlSelf->wasmetal_core__DOT___001707_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4575751b__0)))))));
    vlSelf->wasmetal_core__DOT___000921_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4575751b__0)))));
    vlSelf->__VdfgTmp_h8de67bd6__0 = (((IData)(vlSelf->wasmetal_core__DOT___008378_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008453_));
    vlSelf->__VdfgTmp_haaeadd36__0 = (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008378_));
    vlSelf->__VdfgTmp_h90c7fdf4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h372c3d93__0)));
    vlSelf->wasmetal_core__DOT___048640_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048638_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005476_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005477_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005474_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005475_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___048725_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048638_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000980_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000980_))))));
    vlSelf->wasmetal_core__DOT___027381_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b53__05d))));
    vlSelf->wasmetal_core__DOT___005896_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048063_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048062_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___003806_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8476215a__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b20__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003889_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he4dfb545__0)))))));
    vlSelf->wasmetal_core__DOT___063902_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h67451104__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1a9e6a0c__0))))));
    vlSelf->__VdfgTmp_had66fb55__0 = (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h1a9e6a0c__0));
    vlSelf->__VdfgTmp_hb8ee9e15__0 = (((IData)(vlSelf->wasmetal_core__DOT___008370_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008445_));
    vlSelf->wasmetal_core__DOT___007341_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3c09d3eb__0)))));
    vlSelf->wasmetal_core__DOT___044414_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063333_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063335_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h351f56c5__0))))))));
    vlSelf->wasmetal_core__DOT___044438_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063335_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063333_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063331_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054225_)))))))));
    vlSelf->wasmetal_core__DOT___048635_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048633_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005466_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005467_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005464_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005465_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___048718_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048633_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001327_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001327_))))));
    vlSelf->wasmetal_core__DOT___002148_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000821_))))));
    vlSelf->wasmetal_core__DOT___027380_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b52__05d))));
    vlSelf->wasmetal_core__DOT___005830_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048052_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048051_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006114_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048052_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048063_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048062_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048051_)))))));
    vlSelf->__VdfgTmp_hf10e2308__0 = (((IData)(vlSelf->wasmetal_core__DOT___008357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008432_));
    vlSelf->__VdfgTmp_h68f6955f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008357_));
    vlSelf->__VdfgTmp_h5e79b823__0 = (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb4c136ee__0)));
    vlSelf->wasmetal_core__DOT___047926_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0ff11ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047924_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde5a6edf__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d 
        = (1U & (IData)((0xffff0000ffffff10ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048903_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048902_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___047924_)))))))));
    vlSelf->wasmetal_core__DOT___068660_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068648_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___010444_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008358_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027379_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b51__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                  ? (0xceU >> (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005514_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b51__05d))))
                  : (0xf0f0fef0U >> (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___005514_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde5a6edf__0)))))));
    vlSelf->wasmetal_core__DOT___055419_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008349_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hb1732b67__0 = (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008349_));
    vlSelf->__VdfgTmp_h107cea9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h797b2590__0)));
    vlSelf->wasmetal_core__DOT___047919_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0ff11ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047917_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005545_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005546_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___014245_ = (1U & (IData)(
                                                         (0xffff000000efULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048920_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048919_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047917_)))))))));
    vlSelf->wasmetal_core__DOT___068611_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068598_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->__VdfgTmp_h9c2489b5__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d));
    vlSelf->wasmetal_core__DOT___010439_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008350_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027378_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b50__05d))));
    vlSelf->__VdfgTmp_h4d3bb7ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___008341_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008416_));
    vlSelf->__VdfgTmp_he7f579a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008341_));
    vlSelf->__VdfgTmp_hfce0919b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hca913760__0)));
    vlSelf->wasmetal_core__DOT___044413_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063327_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063329_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed1a6099__0))))))));
    vlSelf->wasmetal_core__DOT___044437_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063329_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063327_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063325_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054219_)))))))));
    vlSelf->wasmetal_core__DOT___047936_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005537_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005538_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b49__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047933_))))))))))));
    vlSelf->wasmetal_core__DOT___013778_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048921_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047933_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068559_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___042172_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___010434_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008342_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027376_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b49__05d))));
    vlSelf->__VdfgTmp_hab846b7c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055321_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007772_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc859778d__0)))));
    vlSelf->wasmetal_core__DOT___047944_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005655_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005656_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b48__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047941_))))))))))));
    vlSelf->wasmetal_core__DOT___013780_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048918_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047941_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068483_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068472_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->__VdfgTmp_h1e5c31ac__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d));
    vlSelf->__VdfgTmp_h4a43881d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d));
    vlSelf->wasmetal_core__DOT___010429_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008334_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027375_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b48__05d))));
    vlSelf->wasmetal_core__DOT___055663_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h92b02c04__0 = (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008318_));
    if (vlSelf->wasmetal_core__DOT___007204_) {
        vlSelf->wasmetal_core__DOT___010309_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007422_));
        vlSelf->wasmetal_core__DOT___010330_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007395_));
        vlSelf->wasmetal_core__DOT___010320_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007369_));
        vlSelf->wasmetal_core__DOT___010349_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007310_));
        vlSelf->wasmetal_core__DOT___010368_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007283_));
        vlSelf->wasmetal_core__DOT___056183_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf8957689__0)));
    } else {
        vlSelf->wasmetal_core__DOT___010309_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007418_))))));
        vlSelf->wasmetal_core__DOT___010330_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007391_))))));
        vlSelf->wasmetal_core__DOT___010320_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007365_))))));
        vlSelf->wasmetal_core__DOT___010349_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007306_))))));
        vlSelf->wasmetal_core__DOT___010368_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007279_))))));
        vlSelf->wasmetal_core__DOT___056183_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3a577ede__0)));
    }
    vlSelf->wasmetal_core__DOT___047867_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047862_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047861_))))));
    vlSelf->wasmetal_core__DOT___002111_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001300_))))));
    vlSelf->wasmetal_core__DOT___068430_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068419_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->__VdfgTmp_h503e9cd3__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d));
    vlSelf->wasmetal_core__DOT___010710_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008319_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027374_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b47__05d))));
    vlSelf->__VdfgTmp_h8565eee7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008310_));
    vlSelf->wasmetal_core__DOT___055638_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008310_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___044412_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063319_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063321_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063323_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h79eb8028__0))))))));
    vlSelf->wasmetal_core__DOT___044436_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063323_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063321_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063319_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054213_)))))))));
    vlSelf->wasmetal_core__DOT___047860_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005521_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005522_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b46__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047857_))))))))))));
    vlSelf->wasmetal_core__DOT___013918_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048901_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047857_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068406_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___063914_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d))));
    vlSelf->wasmetal_core__DOT___042171_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___010705_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008311_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027373_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b46__05d))));
    vlSelf->__VdfgTmp_ha45fb011__0 = (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_h8744bfbd__0 = (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006274_));
    vlSelf->wasmetal_core__DOT___055813_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008378_))))));
    vlSelf->__VdfgTmp_h4ce8c3b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008302_));
    vlSelf->wasmetal_core__DOT___047842_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005561_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005562_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b45__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047839_))))))))))));
    vlSelf->wasmetal_core__DOT___013738_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048904_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047839_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___001780_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001287_))))));
    vlSelf->wasmetal_core__DOT___002110_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001299_))))));
    vlSelf->wasmetal_core__DOT___068351_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068340_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___010132_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008303_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027372_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b45__05d))));
    vlSelf->wasmetal_core__DOT___055797_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008294_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008370_))))));
    vlSelf->__VdfgTmp_h34f2d08e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008294_));
    vlSelf->wasmetal_core__DOT___047850_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005517_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005518_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b44__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047847_))))))))))));
    vlSelf->__VdfgTmp_ha2b229ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___047847_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_phase));
    vlSelf->wasmetal_core__DOT___002272_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000720_)))))))));
    vlSelf->wasmetal_core__DOT___000168_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000819_)))))))));
    vlSelf->wasmetal_core__DOT___001705_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000719_))))));
    vlSelf->wasmetal_core__DOT___002387_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000819_))))));
    vlSelf->wasmetal_core__DOT___068297_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068286_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->__VdfgTmp_h22bd1162__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d));
    vlSelf->wasmetal_core__DOT___010113_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008295_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027371_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b44__05d))));
    vlSelf->__VdfgTmp_hbacebd3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055785_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008281_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008357_))))));
    vlSelf->__VdfgTmp_h31aacdc1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008281_));
    vlSelf->wasmetal_core__DOT___057083_ = (1U & (0x3f5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfcd73105__0))))));
    vlSelf->wasmetal_core__DOT___044411_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063313_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063315_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063317_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h179c0c32__0))))))));
    vlSelf->wasmetal_core__DOT___044435_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063317_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063315_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063313_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054207_)))))))));
    vlSelf->wasmetal_core__DOT___047900_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005508_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005509_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b43__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047897_))))))))))));
    vlSelf->wasmetal_core__DOT___013737_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048894_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047897_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___002069_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001287_)))))))));
    vlSelf->wasmetal_core__DOT___002289_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001288_)))))))));
    vlSelf->wasmetal_core__DOT___002465_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001288_))))));
    vlSelf->wasmetal_core__DOT___068244_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068233_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___042170_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d)))))))));
    vlSelf->__VdfgTmp_h7b621139__0 = ((4U & ((0x96U 
                                              >> (IData)(vlSelf->__VdfgTmp_h1811a1bb__0)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d)));
    vlSelf->wasmetal_core__DOT___010123_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008282_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027370_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b43__05d))));
    vlSelf->wasmetal_core__DOT___055416_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h3fcf358e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008273_));
    vlSelf->wasmetal_core__DOT___047908_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005504_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005505_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b42__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047905_))))))))))));
    vlSelf->wasmetal_core__DOT___013740_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048897_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047905_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068159_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068148_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___063912_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d))));
    vlSelf->__VdfgTmp_he0af74c9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d)));
    vlSelf->wasmetal_core__DOT___010091_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008274_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027369_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b42__05d))));
    vlSelf->__VdfgTmp_h0283b263__0 = (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055755_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008265_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008341_))))));
    vlSelf->__VdfgTmp_h9d165bb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008265_));
    vlSelf->wasmetal_core__DOT___047890_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005529_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005530_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b41__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047887_))))))))))));
    vlSelf->wasmetal_core__DOT___013786_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048895_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047887_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068108_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068097_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->__VdfgTmp_hae598e91__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d));
    vlSelf->wasmetal_core__DOT___010103_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008266_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027368_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b41__05d))));
    vlSelf->__VdfgTmp_hd64632c9__0 = (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055317_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008257_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___061467_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007251_))));
    vlSelf->__VdfgTmp_h5ad8b1f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007432_));
    vlSelf->__VdfgTmp_hb9d2a0bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008257_));
    vlSelf->wasmetal_core__DOT___044410_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063307_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063309_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063311_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8df568d0__0))))))));
    vlSelf->wasmetal_core__DOT___044434_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063311_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063309_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063307_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054201_)))))))));
    vlSelf->wasmetal_core__DOT___047882_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005533_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005534_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b40__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047879_))))))))))));
    vlSelf->wasmetal_core__DOT___013787_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048896_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047879_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068083_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068072_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->__VdfgTmp_ha5696d37__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d));
    vlSelf->wasmetal_core__DOT___042169_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___010672_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008258_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027367_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b40__05d))));
    vlSelf->__VdfgTmp_h9fed8b62__0 = (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_h92c59f9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___008243_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008318_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008394_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008469_))));
    vlSelf->__VdfgTmp_hd3c93d4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008243_));
    vlSelf->wasmetal_core__DOT___047822_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005565_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005566_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b39__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047819_))))))))))));
    vlSelf->wasmetal_core__DOT___013785_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048905_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047819_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->__VdfgTmp_hca6242ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___001286_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001285_));
    vlSelf->wasmetal_core__DOT___001290_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001286_))))));
    vlSelf->wasmetal_core__DOT___019404_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___068024_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___063961_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d))));
    vlSelf->wasmetal_core__DOT___010836_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008244_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027365_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b39__05d))));
    vlSelf->__VdfgTmp_h3cb929d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_hf366d942__0 = (((IData)(vlSelf->wasmetal_core__DOT___008235_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008310_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008386_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008461_))));
    vlSelf->__VdfgTmp_h7e30f70e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008235_));
    vlSelf->wasmetal_core__DOT___047830_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005549_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005550_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b38__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047827_))))))))))));
    vlSelf->wasmetal_core__DOT___013788_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048912_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047827_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___000722_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000718_))))));
    vlSelf->wasmetal_core__DOT___067972_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___067967_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->__VdfgTmp_h46a92a2b__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d));
    vlSelf->wasmetal_core__DOT___010831_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008236_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027364_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b38__05d))));
    vlSelf->__VdfgTmp_hfa88dfaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055602_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008227_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008302_))))));
    vlSelf->__VdfgTmp_h93fbfa25__0 = (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008227_));
    vlSelf->wasmetal_core__DOT___044409_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063301_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063303_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063305_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e211f59__0))))))));
    vlSelf->wasmetal_core__DOT___044433_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063305_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063303_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063301_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054195_)))))))));
    vlSelf->wasmetal_core__DOT___047812_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005541_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005542_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b37__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047809_))))))))))));
    vlSelf->wasmetal_core__DOT___013796_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048907_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047809_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___067906_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___067901_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___010142_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008228_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027363_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b37__05d))));
    vlSelf->wasmetal_core__DOT___055526_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008219_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008294_))))));
    vlSelf->__VdfgTmp_h29bca591__0 = (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008219_));
    vlSelf->wasmetal_core__DOT___047804_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005557_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005558_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b36__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047800_))))))))))));
    vlSelf->wasmetal_core__DOT___013797_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048906_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047800_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___000721_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000717_))))));
    vlSelf->__VdfgTmp_h0fd3d582__0 = (((IData)(vlSelf->wasmetal_core__DOT___000718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000717_));
    vlSelf->__VdfgTmp_hec35f81b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000717_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000574_));
    vlSelf->wasmetal_core__DOT___019399_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h101b2914__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d));
    vlSelf->wasmetal_core__DOT___067814_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->__VdfgTmp_ha0d25e26__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d)));
    vlSelf->wasmetal_core__DOT___010152_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008220_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027362_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b36__05d))));
    vlSelf->__VdfgTmp_h89d79bf3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055506_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008206_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008281_))))));
    vlSelf->__VdfgTmp_h9cbd3d8a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008206_));
    vlSelf->__VdfgTmp_h4ae2b9ea__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h37472320__0))) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4c136ee__0)))));
    vlSelf->wasmetal_core__DOT___048688_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0ff11ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048686_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005647_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005648_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___013795_ = (1U & (IData)(
                                                         (0xffff000000efULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048914_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048913_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048686_)))))))));
    vlSelf->wasmetal_core__DOT___067758_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___067753_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->__VdfgTmp_h8c76b9e6__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d));
    vlSelf->wasmetal_core__DOT___010810_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008207_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027361_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b35__05d))));
    vlSelf->__VdfgTmp_hf7ef4e0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_he719985b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008198_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008273_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008349_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008424_))));
    vlSelf->__VdfgTmp_hb372eb0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008198_));
    vlSelf->__VdfgTmp_hb587b232__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h05980b33__0))) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h797b2590__0)))));
    vlSelf->wasmetal_core__DOT___044408_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063295_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063297_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063299_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1c632a11__0))))))));
    vlSelf->wasmetal_core__DOT___044432_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063299_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063297_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063295_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054189_)))))))));
    vlSelf->wasmetal_core__DOT___049138_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0ff11ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048915_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005659_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005660_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___013798_ = (1U & (IData)(
                                                         (0xffff000000efULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048917_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048916_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048915_)))))))));
    vlSelf->wasmetal_core__DOT___067734_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___063918_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d))));
    vlSelf->wasmetal_core__DOT___067729_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___042167_ = (1U & (0x9000U 
                                                  >> 
                                                  ((8U 
                                                    & ((9U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((9U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d))))));
    vlSelf->wasmetal_core__DOT___010805_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008199_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027360_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b34__05d))));
    vlSelf->__VdfgTmp_h13911493__0 = (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___063800_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063792_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063791_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((6U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h483290db__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((6U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h268e4ef9__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h0f13542d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___026819_)))))))));
    vlSelf->wasmetal_core__DOT___055381_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008190_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008265_))))));
    vlSelf->__VdfgTmp_ha7da5f58__0 = (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008190_));
    vlSelf->__VdfgTmp_h422a580d__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h860ce20a__0))) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hca913760__0)))));
    vlSelf->wasmetal_core__DOT___049136_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h312c1c6b__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b33__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___048910_))))))))))));
    vlSelf->wasmetal_core__DOT___013771_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355ffff0f0f0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048910_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))));
    vlSelf->wasmetal_core__DOT___067668_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___067663_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___011995_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008191_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027359_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_imm[1U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b33__05d))));
    vlSelf->wasmetal_core__DOT___005889_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005653_)) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b33__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005652_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005651_))))))))));
    vlSelf->__VdfgTmp_hd4ed2ab6__0 = (((IData)(vlSelf->wasmetal_core__DOT___008182_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008257_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008333_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008408_))));
    vlSelf->__VdfgTmp_h69457925__0 = (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008182_));
    vlSelf->wasmetal_core__DOT___061468_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061465_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061464_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007339_)))))))));
    vlSelf->wasmetal_core__DOT___049129_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005553_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005554_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b32__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___048908_))))))))))));
    vlSelf->wasmetal_core__DOT___013770_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355ffff0f0f0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048908_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))))));
    vlSelf->wasmetal_core__DOT___002562_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff00ff55ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001774_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001285_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001662_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001661_)))))))));
    vlSelf->wasmetal_core__DOT___002181_ = (1U & (0xcdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001774_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001661_))))));
    vlSelf->wasmetal_core__DOT___067601_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h7c266aa9__0 = (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d));
    vlSelf->wasmetal_core__DOT___067591_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___063964_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d))))));
    vlSelf->wasmetal_core__DOT___010173_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008183_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027358_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b32__05d))));
    vlSelf->__VdfgTmp_hc6c88546__0 = (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___048701_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005795_))))));
    vlSelf->wasmetal_core__DOT___063810_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063807_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063806_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063805_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___026816_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___026815_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((6U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd06fbc0c__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (6U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2b7d2fec__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___026856_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___026855_))))))))))));
    vlSelf->wasmetal_core__DOT___055855_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008168_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008243_))))));
    vlSelf->__VdfgTmp_h567d9bb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008168_));
    vlSelf->wasmetal_core__DOT___028309_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028244_))));
    vlSelf->wasmetal_core__DOT___044407_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063281_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063287_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063293_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h561bfeb8__0))))))));
    vlSelf->wasmetal_core__DOT___044431_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063293_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063287_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054182_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054178_)))))))));
    vlSelf->wasmetal_core__DOT___063867_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d))));
    vlSelf->__VdfgTmp_ha04cce4c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d));
    vlSelf->wasmetal_core__DOT___070494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d))));
    vlSelf->__VdfgTmp_he88617ec__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d));
    vlSelf->__VdfgTmp_hf0c7a5d6__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)));
    vlSelf->wasmetal_core__DOT___012286_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___010424_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010423_))));
    vlSelf->wasmetal_core__DOT___008169_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027357_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b31__05d))));
    vlSelf->wasmetal_core__DOT___059198_ = (1U & (0x41U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))));
    vlSelf->wasmetal_core__DOT___006247_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005711_))));
    vlSelf->wasmetal_core__DOT___028308_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028243_))));
    vlSelf->wasmetal_core__DOT___055832_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008160_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008235_))))));
    vlSelf->__VdfgTmp_h7102b895__0 = (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008160_));
    vlSelf->wasmetal_core__DOT___027356_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b30__05d))));
    vlSelf->wasmetal_core__DOT___071972_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071968_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071971_)))));
    vlSelf->wasmetal_core__DOT___049019_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005253_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9b25c217__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b29__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002760_)))))))));
    vlSelf->wasmetal_core__DOT___000573_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2bd8c9ed__0))))));
    vlSelf->wasmetal_core__DOT___028306_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028241_))));
    vlSelf->wasmetal_core__DOT___055811_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008152_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008227_))))));
    vlSelf->__VdfgTmp_h584cbf3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008152_));
    vlSelf->wasmetal_core__DOT___027354_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b29__05d))));
    vlSelf->wasmetal_core__DOT___052577_ = (1U & (IData)(
                                                         (0x1f00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052576_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052575_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052574_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x7fffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052109_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052108_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052107_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052103_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h128bed99__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052101_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052100_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052099_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052089_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0e2ba734__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052091_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0352b565__0)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052087_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7762895e__0)))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052085_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052083_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052071_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h587b33f1__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052069_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052067_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8fdf3668__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc4d9060a__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x7fff7fff7fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052371_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052370_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052369_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052365_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052364_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6e2b8153__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h11abcf6d__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd9174715__0))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052314_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052313_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052312_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha0b12c43__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052300_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005205_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005273_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h36fcb829__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hce3a0449__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052305_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005069_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005589_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9ff07be6__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfb9f47b1__0)))))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xac00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052326_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052324_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6806bd5e__0))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___049016_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004845_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h651d6523__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002720_)))))))));
    vlSelf->wasmetal_core__DOT___042342_ = (1U & (IData)(
                                                         (0xbb2bffff2b220000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070509_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0f13542d__0))))))));
    vlSelf->wasmetal_core__DOT___067336_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha86315e0__0))));
    vlSelf->wasmetal_core__DOT___042141_ = (1U & (IData)(
                                                         (0xf571ffff71500000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3b20cbca__0))))))));
    vlSelf->wasmetal_core__DOT___042165_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063937_)))));
    vlSelf->wasmetal_core__DOT___001660_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h717e9861__0))))));
    vlSelf->wasmetal_core__DOT___044406_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063269_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063275_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he3a468d3__0))))))));
    vlSelf->wasmetal_core__DOT___044430_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063269_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054170_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054166_)))))))));
    vlSelf->wasmetal_core__DOT___028305_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028240_))));
    vlSelf->wasmetal_core__DOT___055795_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008144_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008219_))))));
    vlSelf->__VdfgTmp_h169cd931__0 = (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008144_));
    vlSelf->wasmetal_core__DOT___027353_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b28__05d))));
    vlSelf->wasmetal_core__DOT___042092_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h22be3b3b__0)))))));
    vlSelf->wasmetal_core__DOT___045825_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x15U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x17U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x19U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h22be3b3b__0)))))));
    vlSelf->wasmetal_core__DOT___067306_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd466e7f__0))));
    vlSelf->wasmetal_core__DOT___000572_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_had26118d__0))))));
    vlSelf->wasmetal_core__DOT___028304_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028239_))));
    vlSelf->wasmetal_core__DOT___055783_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008131_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008206_))))));
    vlSelf->__VdfgTmp_h2596a796__0 = (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008131_));
    vlSelf->wasmetal_core__DOT___027352_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b27__05d))));
    vlSelf->wasmetal_core__DOT___060102_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005989_))));
    vlSelf->wasmetal_core__DOT___071970_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071966_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___000635_)))))));
    vlSelf->wasmetal_core__DOT___071967_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071966_)))));
    vlSelf->wasmetal_core__DOT___067202_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h992e16df__0))));
    vlSelf->__VdfgTmp_h7da480c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___063932_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063931_));
    vlSelf->wasmetal_core__DOT___001657_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdba97a87__0))))));
    vlSelf->wasmetal_core__DOT___028303_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028238_))));
    vlSelf->wasmetal_core__DOT___055761_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008123_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008198_))))));
    vlSelf->__VdfgTmp_h03e9ae47__0 = (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008123_));
    vlSelf->wasmetal_core__DOT___027351_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b26__05d))));
    vlSelf->wasmetal_core__DOT___026492_ = (1U & (IData)(
                                                         (0xfff0f0f88ff8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071969_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071971_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071910_)))))))));
    vlSelf->wasmetal_core__DOT___049034_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005321_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hea3adbd3__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b25__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002681_)))))))));
    vlSelf->wasmetal_core__DOT___067161_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9e2f527__0))));
    vlSelf->wasmetal_core__DOT___042362_ = (1U & (IData)(
                                                         (0xbb2bffff2b220000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070508_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2be29f89__0))))))));
    vlSelf->wasmetal_core__DOT___042161_ = (1U & (IData)(
                                                         (0xf571ffff71500000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd856a856__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h879a663d__0))))))));
    vlSelf->wasmetal_core__DOT___000179_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf4e6deac__0))))));
    vlSelf->wasmetal_core__DOT___044426_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063245_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063251_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063257_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6e6c7922__0))))))));
    vlSelf->wasmetal_core__DOT___044450_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063257_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063251_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054158_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063245_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054135_)))))))));
    vlSelf->wasmetal_core__DOT___028302_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028237_))));
    vlSelf->wasmetal_core__DOT___055753_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008115_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008190_))))));
    vlSelf->__VdfgTmp_h6deef1cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008115_));
    vlSelf->wasmetal_core__DOT___027350_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b25__05d))));
    vlSelf->wasmetal_core__DOT___060056_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006022_))));
    vlSelf->wasmetal_core__DOT___042091_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3948b92c__0)))))));
    vlSelf->wasmetal_core__DOT___045824_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x12U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x14U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x16U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3948b92c__0)))))));
    vlSelf->wasmetal_core__DOT___049037_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005049_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h04914456__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b24__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002642_)))))))));
    vlSelf->wasmetal_core__DOT___067083_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfc0b7a98__0))));
    vlSelf->wasmetal_core__DOT___063872_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0))))));
    vlSelf->wasmetal_core__DOT___001656_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6cb2731d__0))))));
    vlSelf->wasmetal_core__DOT___061460_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061458_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061457_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007335_)))))))));
    vlSelf->wasmetal_core__DOT___028301_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028236_))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135196___B 
        = ((0x3ff80U & ((- (IData)((1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x555533330f0f00ffULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008168_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008469_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055036_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___055046_)))))))))))))) 
                        << 7U)) | ((0x40U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                << 1U) 
                                               | (1U 
                                                  & (IData)(
                                                            (0x555533330f0f00ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008160_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008461_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054990_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___055000_))))))))))) 
                                             << 6U)) 
                                   | ((0x20U & ((4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0x555533330f0f00ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008152_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008453_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054951_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054959_))))))))))) 
                                                << 5U)) 
                                      | ((0x10U & (
                                                   (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008144_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008445_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054901_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054909_))))))))))) 
                                                   << 4U)) 
                                         | ((8U & (
                                                   (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008131_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008432_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054865_))))))))))) 
                                                   << 3U)) 
                                            | ((4U 
                                                & ((4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008123_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008424_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054810_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054820_))))))))))) 
                                                   << 2U)) 
                                               | ((2U 
                                                   & ((4U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008115_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008416_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054770_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054781_))))))))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008107_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008408_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054698_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054674_)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___055723_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008107_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008182_))))));
    vlSelf->__VdfgTmp_hc63c8631__0 = (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008107_));
    vlSelf->wasmetal_core__DOT___027349_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b24__05d))));
    vlSelf->wasmetal_core__DOT___060032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006106_))));
    vlSelf->wasmetal_core__DOT___052802_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052761_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4c543443__0)) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052759_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052758_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___052757_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8f3a812b__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052584_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremainder_op))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001568_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001612_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000432_))))))))))))))))))))))))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x8000000000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052780_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052779_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052778_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x4000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052770_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034476_))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052776_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))))))))))))))))))))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052583_)))));
    vlSelf->wasmetal_core__DOT___050426_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050424_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050423_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050422_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001612_)))))))));
    vlSelf->wasmetal_core__DOT___049068_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005117_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc2abfe6d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b23__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002924_)))))))));
    vlSelf->wasmetal_core__DOT___066979_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c78c397__0))));
    vlSelf->wasmetal_core__DOT___042103_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063942_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd856a856__0))))));
    vlSelf->wasmetal_core__DOT___000178_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4438b1a5__0))))));
    vlSelf->__VdfgTmp_h1dd2f13b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5b76ab14__0)));
    vlSelf->wasmetal_core__DOT___054854_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5b76ab14__0))))))));
    vlSelf->wasmetal_core__DOT___028300_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028235_))));
    vlSelf->__VdfgTmp_h78e7e4d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___008093_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008168_));
    vlSelf->__VdfgTmp_hd8562240__0 = (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008093_));
    vlSelf->wasmetal_core__DOT___027348_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b23__05d))));
    vlSelf->wasmetal_core__DOT___060000_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005868_))));
    vlSelf->wasmetal_core__DOT___051505_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006106_))));
    vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006106_) 
           | (IData)(vlSelf->wasmetal_core__DOT___005868_));
    vlSelf->wasmetal_core__DOT___066897_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cc94077__0))));
    vlSelf->wasmetal_core__DOT___042184_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063952_))));
    vlSelf->wasmetal_core__DOT___001655_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf22a37d9__0))))));
    vlSelf->__VdfgTmp_hd9d9e38d__0 = (((IData)(vlSelf->wasmetal_core__DOT___008085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008160_));
    vlSelf->__VdfgTmp_hf0027c26__0 = (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008085_));
    vlSelf->__VdfgTmp_h1e1103c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha38d193b__0)));
    vlSelf->wasmetal_core__DOT___010955_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha38d193b__0))))))));
    vlSelf->wasmetal_core__DOT___044425_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063227_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063239_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h42ef1750__0))))))));
    vlSelf->wasmetal_core__DOT___044449_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063239_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063227_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054123_)))))))));
    vlSelf->wasmetal_core__DOT___028299_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028234_))));
    vlSelf->wasmetal_core__DOT___027347_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b22__05d))));
    vlSelf->wasmetal_core__DOT___042090_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hbb13730a__0)))))));
    vlSelf->wasmetal_core__DOT___045823_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xfU)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x12U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbb13730a__0))))));
    vlSelf->wasmetal_core__DOT___071961_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071956_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071960_)))));
    vlSelf->wasmetal_core__DOT___071957_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071952_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071956_)))));
    vlSelf->wasmetal_core__DOT___066860_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1479cba4__0))));
    vlSelf->wasmetal_core__DOT___000177_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2a3dbf89__0))))));
    vlSelf->wasmetal_core__DOT___063816_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063813_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063812_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((6U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h379ad787__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((6U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h375e931a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb948b455__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h5dede88d__0)))))))))));
    vlSelf->__VdfgTmp_h90a7e66d__0 = (((IData)(vlSelf->wasmetal_core__DOT___008077_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008152_));
    vlSelf->__VdfgTmp_h7ef390f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008077_));
    vlSelf->__VdfgTmp_h9e64b929__0 = (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf20faaf0__0)));
    vlSelf->wasmetal_core__DOT___054851_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf20faaf0__0))))))));
    vlSelf->wasmetal_core__DOT___028298_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028233_))));
    vlSelf->wasmetal_core__DOT___027346_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b21__05d))));
    vlSelf->wasmetal_core__DOT___066773_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h19f2f351__0))));
    vlSelf->wasmetal_core__DOT___042102_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063952_))));
    vlSelf->wasmetal_core__DOT___063878_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0))))));
    vlSelf->wasmetal_core__DOT___001654_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8b010904__0))))));
    vlSelf->__VdfgTmp_hc06d6619__0 = (((IData)(vlSelf->wasmetal_core__DOT___008069_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008144_));
    vlSelf->__VdfgTmp_h9ba8d2dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008069_));
    vlSelf->__VdfgTmp_h7208d2a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007333_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb187f8bb__0)));
    vlSelf->wasmetal_core__DOT___054805_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb187f8bb__0))))))));
    vlSelf->wasmetal_core__DOT___028297_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028232_))));
    vlSelf->wasmetal_core__DOT___027345_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b20__05d))));
    vlSelf->wasmetal_core__DOT___049092_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003815_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he16d2f4f__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b19__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000156_)))))))));
    vlSelf->wasmetal_core__DOT___066651_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5145bf91__0))));
    vlSelf->wasmetal_core__DOT___042183_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063950_))));
    vlSelf->wasmetal_core__DOT___000176_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h898e287a__0))))));
    vlSelf->__VdfgTmp_h9a7588ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___008056_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008131_));
    vlSelf->__VdfgTmp_h0cb45e24__0 = (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008056_));
    vlSelf->wasmetal_core__DOT___061898_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8499ba72__0))));
    vlSelf->__VdfgTmp_habef704b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8499ba72__0)));
    vlSelf->wasmetal_core__DOT___010986_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8499ba72__0))))))));
    vlSelf->wasmetal_core__DOT___044424_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063209_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063215_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063221_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5eac1f1__0))))))));
    vlSelf->wasmetal_core__DOT___044448_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063221_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063215_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063209_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054111_)))))))));
    vlSelf->wasmetal_core__DOT___028295_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028230_))));
    vlSelf->wasmetal_core__DOT___027343_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b19__05d))));
    vlSelf->wasmetal_core__DOT___042089_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4c89c552__0)))))));
    vlSelf->wasmetal_core__DOT___045822_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xcU)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0xfU)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4c89c552__0))))));
    vlSelf->wasmetal_core__DOT___071955_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071950_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071954_)))));
    vlSelf->wasmetal_core__DOT___071951_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071946_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071950_)))));
    vlSelf->wasmetal_core__DOT___066610_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb776b144__0))));
    vlSelf->wasmetal_core__DOT___001498_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3613bfb2__0))))));
    vlSelf->__VdfgTmp_h384cc7f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008048_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008123_));
    vlSelf->__VdfgTmp_ha7321d4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008048_));
    vlSelf->wasmetal_core__DOT___061830_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h80fea7fc__0))));
    vlSelf->__VdfgTmp_hcd50fd36__0 = (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h80fea7fc__0)));
    vlSelf->wasmetal_core__DOT___010980_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h80fea7fc__0))))))));
    vlSelf->wasmetal_core__DOT___028294_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028229_))));
    vlSelf->wasmetal_core__DOT___027342_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b18__05d))));
    vlSelf->wasmetal_core__DOT___059857_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003808_))));
    vlSelf->wasmetal_core__DOT___071953_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071948_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071952_)))));
    vlSelf->wasmetal_core__DOT___066529_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h061491a4__0))));
    vlSelf->wasmetal_core__DOT___042101_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063951_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063950_))));
    vlSelf->__VdfgTmp_h66324e1d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x6996U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((0x96U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2e3bd00c__0)) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___072034_))))))));
    vlSelf->wasmetal_core__DOT___001731_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9e6b526c__0))))));
    vlSelf->__VdfgTmp_hfa99a91b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008040_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008115_));
    vlSelf->__VdfgTmp_h2c8d302e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008040_));
    vlSelf->wasmetal_core__DOT___061758_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h551248b6__0))));
    vlSelf->__VdfgTmp_hf6b3ca0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007246_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h551248b6__0)));
    vlSelf->wasmetal_core__DOT___010192_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h551248b6__0))))))));
    vlSelf->wasmetal_core__DOT___028293_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028228_))));
    vlSelf->wasmetal_core__DOT___048760_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048759_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048757_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))))))))));
    vlSelf->wasmetal_core__DOT___027341_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b17__05d))));
    vlSelf->wasmetal_core__DOT___066403_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd14327b4__0))));
    vlSelf->wasmetal_core__DOT___042182_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063945_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063951_))));
    vlSelf->wasmetal_core__DOT___063877_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he924c244__0))))));
    vlSelf->wasmetal_core__DOT___001497_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he924c244__0))))));
    vlSelf->__VdfgTmp_h9ea6e74c__0 = (((IData)(vlSelf->wasmetal_core__DOT___008032_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008107_));
    vlSelf->__VdfgTmp_h84d44246__0 = (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008032_));
    vlSelf->wasmetal_core__DOT___061459_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007336_)))))))));
    vlSelf->wasmetal_core__DOT___044423_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063191_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063203_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfa74de2f__0))))))));
    vlSelf->wasmetal_core__DOT___044447_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063203_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063191_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054099_)))))))));
    vlSelf->wasmetal_core__DOT___028292_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028227_))));
    vlSelf->wasmetal_core__DOT___048821_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048818_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))))))))))));
    vlSelf->wasmetal_core__DOT___027340_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b16__05d))));
    vlSelf->__VdfgTmp_he473afc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003807_));
    vlSelf->wasmetal_core__DOT___042088_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc87c06e6__0)))))));
    vlSelf->wasmetal_core__DOT___045821_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 9U)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0xcU)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc87c06e6__0))))));
    vlSelf->wasmetal_core__DOT___071949_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071944_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071948_)))));
    vlSelf->wasmetal_core__DOT___071945_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071940_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071944_)))));
    vlSelf->wasmetal_core__DOT___066323_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89e0a965__0))));
    vlSelf->wasmetal_core__DOT___067488_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066281_)))));
    vlSelf->wasmetal_core__DOT___001730_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h238b010e__0))))));
    vlSelf->__VdfgTmp_h69142c13__0 = (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008007_));
    vlSelf->wasmetal_core__DOT___061654_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061651_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048403_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061649_)))))))));
    vlSelf->wasmetal_core__DOT___028291_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028226_))));
    vlSelf->wasmetal_core__DOT___048733_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___047862_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048731_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047861_)))))))));
    vlSelf->wasmetal_core__DOT___027339_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b15__05d))));
    vlSelf->wasmetal_core__DOT___066266_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h688ac52f__0))));
    vlSelf->wasmetal_core__DOT___042100_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063945_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063935_))));
    vlSelf->wasmetal_core__DOT___001496_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7dd7d539__0))))));
    vlSelf->__VdfgTmp_h8f3d454e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007999_));
    vlSelf->wasmetal_core__DOT___028290_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028225_))));
    vlSelf->wasmetal_core__DOT___048826_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048825_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048823_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h132c3402__0))))))))))));
    vlSelf->wasmetal_core__DOT___027338_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b14__05d))));
    vlSelf->wasmetal_core__DOT___059752_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006204_))));
    vlSelf->wasmetal_core__DOT___066131_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09210432__0))));
    vlSelf->wasmetal_core__DOT___042181_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063954_))));
    vlSelf->wasmetal_core__DOT___001729_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9040377d__0))))));
    vlSelf->__VdfgTmp_h744f9b35__0 = (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007991_));
    vlSelf->wasmetal_core__DOT___044422_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063173_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063179_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063185_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcc1441d8__0))))))));
    vlSelf->wasmetal_core__DOT___044446_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063185_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063179_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063173_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054087_)))))))));
    vlSelf->wasmetal_core__DOT___028289_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028224_))));
    vlSelf->wasmetal_core__DOT___048813_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048812_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h98d262dd__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048810_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))))))))));
    vlSelf->wasmetal_core__DOT___027337_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b13__05d))));
    vlSelf->wasmetal_core__DOT___042087_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdd349d37__0)))))));
    vlSelf->wasmetal_core__DOT___045820_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 6U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 8U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xaU)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdd349d37__0)))))));
    vlSelf->wasmetal_core__DOT___066074_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hea943ba9__0))));
    vlSelf->wasmetal_core__DOT___063892_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0))))));
    vlSelf->wasmetal_core__DOT___001495_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb5d0a138__0))))));
    vlSelf->__VdfgTmp_h413b142d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007983_));
    vlSelf->wasmetal_core__DOT___057235_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc5a57f40__0))))));
    vlSelf->wasmetal_core__DOT___028288_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028223_))));
    vlSelf->wasmetal_core__DOT___048837_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048836_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048834_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))))))))));
    vlSelf->wasmetal_core__DOT___027336_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b12__05d))));
    vlSelf->__VdfgTmp_hadeaba1a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->wasmetal_core__DOT___065929_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfdfbee0__0))));
    vlSelf->wasmetal_core__DOT___042099_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063955_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063954_))));
    vlSelf->__VdfgTmp_h3a315b1c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5b878e76__0)))));
    vlSelf->wasmetal_core__DOT___001726_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdd9104ee__0))))));
    vlSelf->__VdfgTmp_h64194573__0 = (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007970_));
    vlSelf->wasmetal_core__DOT___057005_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdc04b3f0__0))))));
    vlSelf->wasmetal_core__DOT___028287_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028222_))));
    vlSelf->wasmetal_core__DOT___048776_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048775_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048773_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))))))))));
    vlSelf->wasmetal_core__DOT___027335_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b11__05d))));
    vlSelf->wasmetal_core__DOT___052677_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052671_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052670_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x100000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___051956_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___051955_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051954_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___004210_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004192_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004152_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x1000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051941_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051940_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005096_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003360_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003348_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x1000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___050354_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050353_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050352_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___004944_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004926_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005164_)))))))))))))));
    vlSelf->wasmetal_core__DOT___026570_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071947_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071939_))))));
    vlSelf->wasmetal_core__DOT___065905_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e67285f__0))));
    vlSelf->wasmetal_core__DOT___042180_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063939_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063955_))));
    vlSelf->wasmetal_core__DOT___001342_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9d768121__0))))));
    vlSelf->__VdfgTmp_h67f18e55__0 = (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007962_));
    vlSelf->wasmetal_core__DOT___044421_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063155_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063161_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063167_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h33545cb0__0))))))));
    vlSelf->wasmetal_core__DOT___044445_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063167_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063161_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063155_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054075_)))))))));
    vlSelf->wasmetal_core__DOT___028286_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028221_))));
    vlSelf->wasmetal_core__DOT___048783_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048782_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h585a3ceb__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048780_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))))))))))));
    vlSelf->wasmetal_core__DOT___027334_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b10__05d))));
    vlSelf->__VdfgTmp_h28ae1e0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->wasmetal_core__DOT___042086_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4b9179fb__0)))))));
    vlSelf->wasmetal_core__DOT___045819_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 3U)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 6U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4b9179fb__0))))));
    vlSelf->wasmetal_core__DOT___071937_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071932_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071936_)))));
    vlSelf->wasmetal_core__DOT___071933_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071928_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071932_)))));
    vlSelf->wasmetal_core__DOT___065809_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hadcc7972__0))));
    vlSelf->wasmetal_core__DOT___001725_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h06dc5af9__0))))));
    vlSelf->__VdfgTmp_h83053a2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007246_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007954_));
    vlSelf->wasmetal_core__DOT___028316_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028251_))));
    vlSelf->wasmetal_core__DOT___048768_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048767_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048765_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))))))))))));
    vlSelf->wasmetal_core__DOT___027396_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b9__05d))));
    vlSelf->wasmetal_core__DOT___059647_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006015_))));
    vlSelf->wasmetal_core__DOT___071935_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071930_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071934_)))));
    vlSelf->wasmetal_core__DOT___071931_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071926_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071930_)))));
    vlSelf->wasmetal_core__DOT___065707_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h42e273c2__0))));
    vlSelf->wasmetal_core__DOT___042098_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063939_))));
    vlSelf->wasmetal_core__DOT___063891_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_haa154e86__0))))));
    vlSelf->wasmetal_core__DOT___001341_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_haa154e86__0))))));
    vlSelf->__VdfgTmp_hfd347d5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007431_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007946_));
    vlSelf->wasmetal_core__DOT___028315_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028250_))));
    vlSelf->wasmetal_core__DOT___048740_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048739_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_he0c10a9d__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048737_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hc231438f__0))))))))))));
    vlSelf->wasmetal_core__DOT___027395_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b8__05d))));
    vlSelf->__VdfgTmp_hbc1c04e5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006092_));
    vlSelf->wasmetal_core__DOT___003128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006400_))));
    vlSelf->wasmetal_core__DOT___066321_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066319_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065607_))));
    vlSelf->wasmetal_core__DOT___065616_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8926b37c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065607_))));
    vlSelf->wasmetal_core__DOT___066283_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8926b37c__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065611_)))));
    vlSelf->wasmetal_core__DOT___042179_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063949_))));
    vlSelf->wasmetal_core__DOT___001724_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h61294ca4__0))))));
    vlSelf->__VdfgTmp_h57d78adc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007931_));
    vlSelf->wasmetal_core__DOT___044420_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063137_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063143_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063149_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb28d3ef__0))))))));
    vlSelf->wasmetal_core__DOT___044444_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063149_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063143_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063137_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054063_)))))))));
    vlSelf->wasmetal_core__DOT___028314_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028249_))));
    vlSelf->wasmetal_core__DOT___048753_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048752_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048750_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))))))))));
    vlSelf->wasmetal_core__DOT___027394_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b7__05d))));
    vlSelf->wasmetal_core__DOT___042085_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hbe9a07d7__0)))))));
    vlSelf->wasmetal_core__DOT___045818_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & vlSelf->insn_y) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 2U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 4U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hbe9a07d7__0)))))));
    vlSelf->wasmetal_core__DOT___065424_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf2f5c69c__0))));
    vlSelf->wasmetal_core__DOT___001340_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h03893f91__0))))));
    vlSelf->__VdfgTmp_hc326eb38__0 = (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007923_));
    vlSelf->wasmetal_core__DOT___028313_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028248_))));
    vlSelf->wasmetal_core__DOT___048893_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048892_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048890_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))))))))));
    vlSelf->wasmetal_core__DOT___027393_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b6__05d))));
    vlSelf->wasmetal_core__DOT___059542_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005745_))));
    vlSelf->wasmetal_core__DOT___065307_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46c82ccf__0))));
    vlSelf->wasmetal_core__DOT___063948_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063947_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063946_))));
    vlSelf->__VdfgTmp_h144113a8__0 = ((2U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h5b878e76__0)) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_hdbb03d5c__0))));
    vlSelf->wasmetal_core__DOT___001723_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbfd77ec1__0))))));
    vlSelf->wasmetal_core__DOT___063739_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063734_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063733_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063732_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((6U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h560b7672__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb96516e6__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd3bfd495__0)))))))))));
    vlSelf->__VdfgTmp_h57efbd27__0 = (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007915_));
    vlSelf->__VdfgTmp_h5aecec62__0 = (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (~ (IData)(vlSelf->wasmetal_core__DOT___035269_)))));
    vlSelf->wasmetal_core__DOT___028312_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028247_))));
    vlSelf->wasmetal_core__DOT___048886_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048885_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048883_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))))))))))));
    vlSelf->wasmetal_core__DOT___027388_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b5__05d))));
    vlSelf->__VdfgTmp_hbbe1bed2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005921_));
    vlSelf->wasmetal_core__DOT___042355_ = (1U & (IData)(
                                                         (0xf571ffff71500000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070507_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001476_)))))))));
    vlSelf->wasmetal_core__DOT___065199_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h425ce738__0))));
    vlSelf->wasmetal_core__DOT___042154_ = (1U & (IData)(
                                                         (0xbb2bffff2b220000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0))))))));
    vlSelf->wasmetal_core__DOT___063886_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h776ad714__0))))));
    vlSelf->wasmetal_core__DOT___001339_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h776ad714__0))))));
    vlSelf->__VdfgTmp_hc9c602ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007907_));
    vlSelf->wasmetal_core__DOT___011102_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (~ (IData)(vlSelf->wasmetal_core__DOT___035269_))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___044419_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063119_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063125_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063131_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6661b389__0))))))));
    vlSelf->wasmetal_core__DOT___044443_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063131_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063125_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063119_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054051_)))))))));
    vlSelf->wasmetal_core__DOT___028311_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028246_))));
    vlSelf->wasmetal_core__DOT___048878_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048877_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h7cf17ecc__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048875_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))))))))));
    vlSelf->wasmetal_core__DOT___027377_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b4__05d))));
    vlSelf->__VdfgTmp_he7a338fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    vlSelf->wasmetal_core__DOT___044492_ = ((IData)(vlSelf->wasmetal_core__DOT___044515_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044524_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044523_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044522_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044521_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044520_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044519_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044518_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044517_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044516_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044514_) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044502_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044504_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044505_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044506_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044507_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044508_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044509_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044510_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044511_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044512_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044503_));
    vlSelf->wasmetal_core__DOT___042084_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc7b853f6__0)))))));
    vlSelf->wasmetal_core__DOT___045817_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc7b853f6__0)))))));
    vlSelf->wasmetal_core__DOT___049163_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004697_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hfcbc0180__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001996_)))))))));
    vlSelf->wasmetal_core__DOT___001937_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcc4a801d__0))))));
    vlSelf->__VdfgTmp_h1327a702__0 = (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007894_));
    vlSelf->wasmetal_core__DOT___010722_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                                   >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___061899_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8d9b1452__0))));
    vlSelf->wasmetal_core__DOT___010348_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8d9b1452__0))))))));
    vlSelf->wasmetal_core__DOT___028310_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028245_))));
    vlSelf->wasmetal_core__DOT___027366_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b3__05d))));
    vlSelf->wasmetal_core__DOT___071923_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071918_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071922_)))));
    vlSelf->wasmetal_core__DOT___049155_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004771_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd09f2908__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001951_)))))))));
    vlSelf->wasmetal_core__DOT___064901_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11b4d04e__0))));
    vlSelf->wasmetal_core__DOT___042096_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063934_))));
    vlSelf->__VdfgTmp_hef814ba9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007886_));
    vlSelf->wasmetal_core__DOT___010721_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___061831_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5af86920__0))));
    vlSelf->wasmetal_core__DOT___010369_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5af86920__0))))))));
    vlSelf->wasmetal_core__DOT___028307_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028242_))));
    vlSelf->wasmetal_core__DOT___027355_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b2__05d))));
    vlSelf->wasmetal_core__DOT___026592_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071929_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071921_))))));
    vlSelf->wasmetal_core__DOT___026588_ = (1U & (0xcf30aa55U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071921_)))))));
    vlSelf->wasmetal_core__DOT___044308_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044354_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044353_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044351_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044350_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044349_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044348_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044347_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044346_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044345_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044344_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044343_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044342_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044362_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044361_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044360_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044359_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044358_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044357_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___044356_)
                                                                     ? 
                                                                    ((IData)(vlSelf->wasmetal_core__DOT___044355_)
                                                                      ? 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___044352_)
                                                                       ? 
                                                                      (0xeU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hc01d1a00__0))
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___044328_))
                                                                      : (IData)(vlSelf->wasmetal_core__DOT___044331_))
                                                                     : (IData)(vlSelf->wasmetal_core__DOT___044332_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___044333_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___044334_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___044335_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044336_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044337_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044338_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044318_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044319_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044320_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044321_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044322_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044323_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044324_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044325_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044326_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044327_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044329_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044330_)));
    vlSelf->__VdfgTmp_ha9869a20__0 = (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007870_));
    vlSelf->wasmetal_core__DOT___010531_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___008974_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___061759_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf8763693__0))));
    vlSelf->wasmetal_core__DOT___007250_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8763693__0))))))));
    vlSelf->wasmetal_core__DOT___044416_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063113_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h66f1f037__0))))))));
    vlSelf->wasmetal_core__DOT___044440_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063113_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063101_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054039_)))))))));
    vlSelf->wasmetal_core__DOT___028296_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_y) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028231_))));
    vlSelf->wasmetal_core__DOT___048808_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048807_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048805_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))))))))))));
    vlSelf->wasmetal_core__DOT___064480_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063857_))))));
    vlSelf->wasmetal_core__DOT___042352_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h87854ac5__0))))))));
    vlSelf->wasmetal_core__DOT___042151_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h87854ac5__0))))))));
    vlSelf->__VdfgTmp_h769a413d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d));
    vlSelf->wasmetal_core__DOT___063930_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___010341_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___007873_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027344_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_imm[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b1__05d))));
    vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001444_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128076___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028486_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028483_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028472_) 
                                   << 1U) | (1U & (~ 
                                                   (9U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4ae0787e__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028454_ = ((IData)(vlSelf->wasmetal_core__DOT___028486_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___004744_));
    vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028659_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004818_));
    vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028971_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128434___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001886_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001874_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128434___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128434___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032283_ = ((IData)(vlSelf->wasmetal_core__DOT___001886_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___001886_)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128434___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028752_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026454_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b0__05d));
    vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026674_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127876___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027144_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d));
    vlSelf->wasmetal_core__DOT___071919_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071914_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071918_)))));
    vlSelf->wasmetal_core__DOT___071915_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071914_))));
    vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026562_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___003189_));
    vlSelf->wasmetal_core__DOT___026590_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071925_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071917_))))));
    vlSelf->wasmetal_core__DOT___026584_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071917_)))));
    vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026944_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___048829_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0643d6d2__0))));
    vlSelf->__VdfgTmp_h2b3c1bbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___001286_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcbbf7a95__0));
    vlSelf->wasmetal_core__DOT___002288_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___001289_)
                                                   : 
                                                  (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001286_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001662_)))))));
    vlSelf->wasmetal_core__DOT___063783_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063775_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((6U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h77a25d8c__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0d1a9c72__0)))))));
    vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hc8dfb864__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127893___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->__VdfgTmp_h014e1215__0 = (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007882_));
    vlSelf->wasmetal_core__DOT___010530_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056274_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___010124_ = (1U & (0xfbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056274_))))));
    vlSelf->__VdfgTmp_h4dc07bf4__0 = ((2U & ((IData)(
                                                     (0x1000000000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___061452_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061451_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___007333_)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x1000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___061450_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061449_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007334_))))))))));
    vlSelf->__VdfgTmp_h27ece1ce__0 = ((2U & ((0xcaU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_hd163f969__0))) 
                                             << 1U)) 
                                      | (1U & (0xacU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5d6eeee4__0)))));
    vlSelf->__VdfgTmp_heab1a15e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5d6eeee4__0)));
    vlSelf->wasmetal_core__DOT___034541_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001886_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128656___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128656___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001886_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001874_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128656___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128656___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___044405_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063095_))));
    vlSelf->wasmetal_core__DOT___044429_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063095_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053990_))));
    vlSelf->wasmetal_core__DOT___028285_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028220_))));
    vlSelf->wasmetal_core__DOT___048797_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048796_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048794_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))))))))))));
    vlSelf->__VdfgTmp_h78ac86a2__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->wasmetal_core__DOT___042140_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))));
    vlSelf->__VdfgTmp_hdd7e24a1__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->wasmetal_core__DOT___072046_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hdbb03d5c__0)))))))));
    vlSelf->__VdfgTmp_hab155f14__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d));
    vlSelf->wasmetal_core__DOT___007883_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027333_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b0__05d))));
    vlSelf->wasmetal_core__DOT___017175_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005731_))));
    vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005928_) 
           & (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->__VdfgTmp_h76ba8332__0 = (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->__VdfgTmp_h68317e95__0 = (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005716_)));
    vlSelf->wasmetal_core__DOT___007869_ = (1U & (IData)(
                                                         (0xfefffeff0000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048503_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048502_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSelf->wasmetal_core__DOT___135425___DOT__alu_sum 
                                                                                >> 2U)) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                                >> 7U))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128140___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029149_)))));
    vlSelf->wasmetal_core__DOT___029153_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128323___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031071_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031070_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031069_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031068_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031035_)))));
    vlSelf->wasmetal_core__DOT___031039_ = ((IData)(vlSelf->wasmetal_core__DOT___031071_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->__VdfgTmp_hf131a410__0 = (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054815_));
    vlSelf->wasmetal_core__DOT___049026_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004913_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9b410c9d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b26__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002800_)))))))));
    vlSelf->wasmetal_core__DOT___055432_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055425_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055424_)))));
    vlSelf->__VdfgTmp_h7c4aea26__0 = (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007259_));
    vlSelf->__VdfgTmp_h6b40768b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007259_))));
    vlSelf->__VdfgTmp_h8c85186d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054810_));
    vlSelf->wasmetal_core__DOT___007778_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007257_))))));
    vlSelf->wasmetal_core__DOT___010371_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007257_)))))))));
    vlSelf->wasmetal_core__DOT___010290_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007260_)))))))));
    vlSelf->wasmetal_core__DOT___049029_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004981_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h6305c07b__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002842_)))))))));
    vlSelf->wasmetal_core__DOT___061916_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4ab1d453__0))))));
    vlSelf->wasmetal_core__DOT___055502_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055495_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055494_)))));
    vlSelf->wasmetal_core__DOT___061486_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007259_))));
    vlSelf->__VdfgTmp_hf4e23b72__0 = (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007286_));
    vlSelf->__VdfgTmp_h883d5f24__0 = (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007286_))));
    vlSelf->__VdfgTmp_h08beb063__0 = (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051496_));
    vlSelf->wasmetal_core__DOT___007782_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007284_))))));
    vlSelf->wasmetal_core__DOT___010350_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007284_)))))))));
    vlSelf->wasmetal_core__DOT___007473_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf224ceca__0)))));
    vlSelf->wasmetal_core__DOT___007586_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf224ceca__0)))));
    vlSelf->__VdfgTmp_hf89db412__0 = (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007346_));
    vlSelf->__VdfgTmp_h379220a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007346_))));
    vlSelf->__VdfgTmp_hd8993186__0 = (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054951_));
    vlSelf->wasmetal_core__DOT___007786_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007344_))))));
    vlSelf->__VdfgTmp_hba71a165__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007344_))))));
    vlSelf->wasmetal_core__DOT___010252_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007347_)))))))));
    vlSelf->wasmetal_core__DOT___049008_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005185_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h6b2c9c37__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b30__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002884_)))))))));
    vlSelf->__VdfgTmp_h6b713560__0 = (((IData)(vlSelf->wasmetal_core__DOT___055646_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055649_));
    vlSelf->__VdfgTmp_hfb017232__0 = (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007372_));
    vlSelf->__VdfgTmp_h7b1ed1fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007372_))));
    vlSelf->__VdfgTmp_h61af7368__0 = (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054990_));
    vlSelf->wasmetal_core__DOT___007789_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007370_))))));
}
