#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__23(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__23\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___049218_;
    wasmetal_core__DOT___049218_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049641_;
    wasmetal_core__DOT___049641_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051292_;
    wasmetal_core__DOT___051292_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051636_;
    wasmetal_core__DOT___051636_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052602_;
    wasmetal_core__DOT___052602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053655_;
    wasmetal_core__DOT___053655_ = 0;
    CData/*1:0*/ __VdfgTmp_h8e6178a2__0;
    __VdfgTmp_h8e6178a2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h40aa5d33__0;
    __VdfgTmp_h40aa5d33__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___050847_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x30aU 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha09ba029__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048676_)))));
    vlSelf->wasmetal_core__DOT___053418_ = (1U & (IData)(
                                                         (0x5cc0ccc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0xcU 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5eca347b__0))))));
    vlSelf->wasmetal_core__DOT___049766_ = (1U & (0x5cccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5eca347b__0))));
    vlSelf->wasmetal_core__DOT___050974_ = (1U & (0xa333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5eca347b__0))));
    vlSelf->wasmetal_core__DOT___049899_ = (1U & (0x30aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049599_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048676_)))));
    vlSelf->wasmetal_core__DOT___051524_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049599_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___050040_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049599_))));
    vlSelf->wasmetal_core__DOT___049606_ = (1U & (0xa333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049599_)))));
    vlSelf->wasmetal_core__DOT___067953_ = (1U & (0x3b00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b38__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049599_))))));
    vlSelf->wasmetal_core__DOT___055140_ = (1U & (0x1f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b40__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___053628_ = (1U & (0xfcaa0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049537_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))));
    vlSelf->wasmetal_core__DOT___050867_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (1U 
                                                          & (0x8fU 
                                                             >> 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                              << 2U))))))));
    vlSelf->wasmetal_core__DOT___050642_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050561_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049607_)))));
    vlSelf->wasmetal_core__DOT___053194_ = (1U & (0xff100000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x10U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                               << 2U)) 
                                                             << 2U)) 
                                                         | (2U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 1U)))))));
    vlSelf->wasmetal_core__DOT___049833_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049607_))));
    vlSelf->wasmetal_core__DOT___049539_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049525_))));
    wasmetal_core__DOT___052602_ = (1U & (0x70U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b28__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___052601_) 
                                               << 1U) 
                                              | (1U 
                                                 & (8U 
                                                    >> 
                                                    (3U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                        >> 2U))))))));
    vlSelf->__VdfgTmp_hb7578f7f__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h4795829e__0));
    vlSelf->wasmetal_core__DOT___051774_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051773_))));
    vlSelf->wasmetal_core__DOT___053879_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b118__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff00ff00ff1fffULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053553_))))));
    vlSelf->wasmetal_core__DOT___053641_ = (1U & (0x3000aU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e2bcde2__0))));
    vlSelf->wasmetal_core__DOT___052720_ = (1U & (0x30aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e2bcde2__0))));
    vlSelf->wasmetal_core__DOT___051789_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051659_))));
    vlSelf->wasmetal_core__DOT___053654_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051523_))));
    vlSelf->wasmetal_core__DOT___051837_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050825_))));
    vlSelf->wasmetal_core__DOT___050795_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050794_))));
    vlSelf->wasmetal_core__DOT___052634_ = (1U & (0x5cccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h25173009__0))));
    vlSelf->__VdfgTmp_heaed7142__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                             << 3U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h25173009__0));
    vlSelf->wasmetal_core__DOT___053519_ = (1U & (0x30aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051735_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->wasmetal_core__DOT___051736_ = (1U & (0xa333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051735_)))));
    wasmetal_core__DOT___053655_ = (1U & (4U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___051735_)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___050707_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___009534_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___049720_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))));
    vlSelf->wasmetal_core__DOT___066714_ = (1U & (IData)(
                                                         (0x1fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066711_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___049720_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (1U 
                                                                              & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___050640_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049720_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___009534_))))));
    vlSelf->wasmetal_core__DOT___009496_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfffe000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h0467adbf__0)))))));
    vlSelf->wasmetal_core__DOT___053389_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1ffffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h0467adbf__0)))))));
    vlSelf->wasmetal_core__DOT___050860_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049215_))));
    vlSelf->wasmetal_core__DOT___051065_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049215_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->wasmetal_core__DOT___051421_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049215_))))));
    __VdfgTmp_h8e6178a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___049215_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009534_));
    __VdfgTmp_h40aa5d33__0 = (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049215_));
    vlSelf->wasmetal_core__DOT___049724_ = (1U & (IData)(
                                                         (0x1515153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049720_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))))));
    vlSelf->wasmetal_core__DOT___050832_ = (1U & (0x3700U 
                                                  >> 
                                                  ((8U 
                                                    & ((0x3700U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b43__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___049599_))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  >> 2U))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050825_))))));
    vlSelf->wasmetal_core__DOT___053811_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051773_))));
    vlSelf->wasmetal_core__DOT___053711_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050904_))));
    vlSelf->wasmetal_core__DOT___053719_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049595_))));
    vlSelf->wasmetal_core__DOT___049767_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049764_))));
    vlSelf->wasmetal_core__DOT___049900_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049897_))));
    vlSelf->wasmetal_core__DOT___051353_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051351_))));
    vlSelf->wasmetal_core__DOT___051525_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051523_))));
    vlSelf->wasmetal_core__DOT___053815_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051659_))));
    vlSelf->wasmetal_core__DOT___053703_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051700_))));
    wasmetal_core__DOT___051292_ = (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___050794_))));
    wasmetal_core__DOT___049641_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfffe000000000000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0467adbf__0)))))));
    wasmetal_core__DOT___051636_ = (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x1ffffffffULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0467adbf__0)))))));
    vlSelf->wasmetal_core__DOT___051901_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050483_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050482_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc489de0__0))))))));
    vlSelf->wasmetal_core__DOT___053526_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0ebff551__0))));
    vlSelf->wasmetal_core__DOT___050818_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfb07bbea__0))));
    vlSelf->wasmetal_core__DOT___051362_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h228e0a62__0))));
    vlSelf->wasmetal_core__DOT___051577_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h03f43c88__0))));
    vlSelf->wasmetal_core__DOT___051803_ = (1U & (IData)(
                                                         (0xbbbbb00ffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051352_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051351_)))))))));
    vlSelf->wasmetal_core__DOT___065725_ = (1U & (IData)(
                                                         (0x3f003f3f5555ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050847_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050846_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))));
    vlSelf->wasmetal_core__DOT___050978_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xc5U 
                                                         >> 
                                                         ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050974_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___048676_))))))));
    vlSelf->wasmetal_core__DOT___050068_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xc1d3f3fU 
                                                         >> 
                                                         ((0x10U 
                                                           & ((1U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050041_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((8U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            >> 2U))) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___050040_))))))))));
    vlSelf->wasmetal_core__DOT___050501_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (2U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___049606_)))))));
    vlSelf->wasmetal_core__DOT___053120_ = (1U & (IData)(
                                                         (0x7f00007f7f7f7fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049833_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                       << 1U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050798_)))))))));
    vlSelf->wasmetal_core__DOT___052605_ = (1U & (IData)(
                                                         (0xbb000f00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(wasmetal_core__DOT___052602_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (2U 
                                                                             & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))))))));
    vlSelf->wasmetal_core__DOT___051990_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051774_))));
    vlSelf->wasmetal_core__DOT___053863_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b114__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xf0f0f77U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052720_))))));
    vlSelf->wasmetal_core__DOT___053154_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051837_))));
    vlSelf->wasmetal_core__DOT___050796_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b23__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050795_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___053828_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b105__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x5dc0000U 
                                                         >> 
                                                         ((0x1cU 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050846_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xfa33f333U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_heaed7142__0))))))))));
    vlSelf->wasmetal_core__DOT___053658_ = (1U & (0xfe540000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(wasmetal_core__DOT___053655_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053654_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))));
    vlSelf->wasmetal_core__DOT___051331_ = (1U & (0x222dfffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050561_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050640_)))))));
    vlSelf->wasmetal_core__DOT___053391_ = (1U & (IData)(
                                                         (0x1515153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053390_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053389_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))))));
    vlSelf->wasmetal_core__DOT___065823_ = (1U & (IData)(
                                                         (0x3f003f3f5555ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050867_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050860_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))));
    vlSelf->wasmetal_core__DOT___050868_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050860_))));
    vlSelf->wasmetal_core__DOT___051067_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051065_))));
    vlSelf->wasmetal_core__DOT___053524_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051421_))));
    vlSelf->wasmetal_core__DOT___053647_ = (1U & (0xa300U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h8e6178a2__0))));
    vlSelf->wasmetal_core__DOT___049216_ = (1U & (0xa300U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (IData)(__VdfgTmp_h8e6178a2__0))));
    vlSelf->wasmetal_core__DOT___051371_ = (1U & (0x333aU 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h40aa5d33__0))));
    vlSelf->wasmetal_core__DOT___051584_ = (1U & (0x333aU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (IData)(__VdfgTmp_h40aa5d33__0))));
    vlSelf->wasmetal_core__DOT___053714_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b98__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053711_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xa333U 
                                                               >> (IData)(vlSelf->__VdfgTmp_heaed7142__0))))))));
    vlSelf->wasmetal_core__DOT___053721_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b99__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053719_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051736_))))));
    vlSelf->wasmetal_core__DOT___053859_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b113__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049767_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052634_))))));
    vlSelf->wasmetal_core__DOT___053867_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b115__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049900_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053519_))))));
    vlSelf->wasmetal_core__DOT___053891_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b121__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051353_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053641_))))));
    vlSelf->wasmetal_core__DOT___053898_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b123__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051525_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___053655_))))));
    vlSelf->wasmetal_core__DOT___053817_ = (1U & (0xe600ff00U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b103__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051790_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053815_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___053705_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b97__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053703_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051701_))))));
    vlSelf->wasmetal_core__DOT___053883_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b119__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___051292_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053582_))))));
    vlSelf->wasmetal_core__DOT___051294_ = (1U & (IData)(
                                                         (0xef00efef00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b55__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(wasmetal_core__DOT___051292_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050793_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))))))));
    vlSelf->wasmetal_core__DOT___053852_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b111__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___049641_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051884_))))));
    vlSelf->wasmetal_core__DOT___049650_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___049641_))));
    vlSelf->wasmetal_core__DOT___051637_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___051636_))));
    vlSelf->wasmetal_core__DOT___053914_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b127__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___051636_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053695_))))));
    vlSelf->wasmetal_core__DOT___051991_ = (1U & (IData)(
                                                         (0xbb3f3f3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051990_) 
                                                            << 5U) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049599_))))))));
    vlSelf->wasmetal_core__DOT___053216_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x773f3f3fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___053154_) 
                                                                   << 5U) 
                                                                  | ((0x18U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                         << 3U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049599_)))))))))))));
    vlSelf->wasmetal_core__DOT___050983_ = (1U & (IData)(
                                                         (0xee000f00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050796_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050793_)))))))));
    vlSelf->wasmetal_core__DOT___053875_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b117__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051067_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xc0aU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0))))))));
    vlSelf->wasmetal_core__DOT___009524_ = (1U & (IData)(
                                                         (0xef00efef00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b53__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051067_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051066_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))))))));
    vlSelf->wasmetal_core__DOT___053525_ = (1U & (IData)(
                                                         (0xcc0c5505ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053524_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051066_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))));
    vlSelf->wasmetal_core__DOT___053805_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b101__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053524_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051758_))))));
    vlSelf->wasmetal_core__DOT___051859_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049216_))));
    wasmetal_core__DOT___049218_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___049216_))));
    vlSelf->wasmetal_core__DOT___051374_ = (1U & (IData)(
                                                         (0xbf00bfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b58__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051371_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (1U 
                                                                          & (0x8fU 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                              << 2U)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb829d41d__0))))))));
    vlSelf->wasmetal_core__DOT___051588_ = (1U & (0x3b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b61__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051585_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051584_)))))));
    vlSelf->wasmetal_core__DOT___053112_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051584_))));
    vlSelf->wasmetal_core__DOT___053731_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051859_))));
    vlSelf->wasmetal_core__DOT___053844_ = (1U & (0x48ccc8ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b109__05d) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___049218_))))));
    vlSelf->wasmetal_core__DOT___049244_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___049218_))));
    vlSelf->wasmetal_core__DOT___053116_ = (1U & (IData)(
                                                         (0x1515153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053113_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053112_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))))));
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__26(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__26\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___070572_;
    wasmetal_core__DOT___070572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071474_;
    wasmetal_core__DOT___071474_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071477_;
    wasmetal_core__DOT___071477_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071479_;
    wasmetal_core__DOT___071479_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071483_;
    wasmetal_core__DOT___071483_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071487_;
    wasmetal_core__DOT___071487_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071494_;
    wasmetal_core__DOT___071494_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071496_;
    wasmetal_core__DOT___071496_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071500_;
    wasmetal_core__DOT___071500_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071502_;
    wasmetal_core__DOT___071502_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071505_;
    wasmetal_core__DOT___071505_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071508_;
    wasmetal_core__DOT___071508_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071511_;
    wasmetal_core__DOT___071511_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071517_;
    wasmetal_core__DOT___071517_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071522_;
    wasmetal_core__DOT___071522_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128793___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128793___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hcd919103__0;
    __VdfgTmp_hcd919103__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040094_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040095_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040092_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040093_));
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d = 0U;
    } else if (vlSelf->wasmetal_core__DOT___020524_) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d 
            = (1U & (0x8f88U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 2U) 
                                            | ((2U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128793___O)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___058085_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d 
            = (1U & (IData)((0xffffffffffffbf00ULL 
                             >> (((IData)(vlSelf->wasmetal_core__DOT___058084_) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___071562_) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d)))))))));
    }
    vlSelf->wasmetal_core__DOT___071532_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->__VdfgTmp_hc1ba27eb__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d));
    __VdfgTmp_hcd919103__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d));
    vlSelf->wasmetal_core__DOT___128793___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d));
    wasmetal_core__DOT___071477_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d))));
    vlSelf->__VdfgTmp_ha330fec4__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d));
    vlSelf->wasmetal_core__DOT___048947_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(__VdfgTmp_hcd919103__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1ba27eb__0))));
    wasmetal_core__DOT___128793___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128793___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___071516_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071477_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(__VdfgTmp_hcd919103__0))))));
    vlSelf->wasmetal_core__DOT___071493_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(__VdfgTmp_hcd919103__0)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___071477_))));
    vlSelf->wasmetal_core__DOT___071478_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071477_))));
    vlSelf->wasmetal_core__DOT___071521_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(__VdfgTmp_hcd919103__0))))));
    vlSelf->wasmetal_core__DOT___071514_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(__VdfgTmp_hcd919103__0))))));
    vlSelf->wasmetal_core__DOT___071499_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(__VdfgTmp_hcd919103__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0))))));
    vlSelf->wasmetal_core__DOT___071491_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(__VdfgTmp_hcd919103__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0))))));
    vlSelf->wasmetal_core__DOT___071486_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0))))));
    vlSelf->wasmetal_core__DOT___071482_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0))))));
    vlSelf->wasmetal_core__DOT___071473_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0))))));
    vlSelf->wasmetal_core__DOT___070571_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d))));
    vlSelf->wasmetal_core__DOT___058083_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048947_))));
    vlSelf->wasmetal_core__DOT___048948_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048947_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___128793___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128793___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128793___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035884_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d)
                                             : (IData)(wasmetal_core__DOT___128793___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___071543_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc1ba27eb__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071516_))));
    wasmetal_core__DOT___071517_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071516_))));
    vlSelf->wasmetal_core__DOT___071534_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071493_))));
    wasmetal_core__DOT___071494_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071493_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    wasmetal_core__DOT___071505_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071478_))));
    wasmetal_core__DOT___071479_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071478_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d))));
    vlSelf->wasmetal_core__DOT___071545_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc1ba27eb__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071521_))));
    wasmetal_core__DOT___071522_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071521_))));
    vlSelf->wasmetal_core__DOT___071542_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc1ba27eb__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071514_))));
    vlSelf->wasmetal_core__DOT___071515_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071514_))));
    vlSelf->wasmetal_core__DOT___071536_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071499_))));
    wasmetal_core__DOT___071500_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071499_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071533_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071491_))));
    vlSelf->wasmetal_core__DOT___071492_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071491_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    wasmetal_core__DOT___071511_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071486_))));
    wasmetal_core__DOT___071487_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071486_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d))));
    wasmetal_core__DOT___071508_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071482_))));
    wasmetal_core__DOT___071483_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071482_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d))));
    wasmetal_core__DOT___071502_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071473_))));
    wasmetal_core__DOT___071474_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071473_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d))));
    wasmetal_core__DOT___071496_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___070571_))));
    wasmetal_core__DOT___070572_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___070571_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d))));
    vlSelf->wasmetal_core__DOT___052586_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d))));
    vlSelf->wasmetal_core__DOT___048949_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048948_))));
    vlSelf->wasmetal_core__DOT___128794___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___035884_));
    vlSelf->wasmetal_core__DOT___071556_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071517_))));
    vlSelf->wasmetal_core__DOT___071518_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071517_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071549_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071494_))));
    vlSelf->wasmetal_core__DOT___071495_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071538_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071505_))));
    vlSelf->wasmetal_core__DOT___071506_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071505_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071526_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071479_))));
    vlSelf->wasmetal_core__DOT___071480_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071479_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071558_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071522_))));
    vlSelf->wasmetal_core__DOT___071523_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071551_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071500_))));
    vlSelf->wasmetal_core__DOT___071501_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071500_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->__VdfgTmp_h2c6daa45__0 = (((IData)(vlSelf->wasmetal_core__DOT___071492_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d));
    vlSelf->wasmetal_core__DOT___071540_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071511_))));
    vlSelf->wasmetal_core__DOT___071512_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071530_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071487_))));
    vlSelf->wasmetal_core__DOT___071488_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071539_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071508_))));
    vlSelf->wasmetal_core__DOT___071509_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071508_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->__VdfgTmp_he775e720__0 = ((2U & ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                << 1U) 
                                               | (IData)(wasmetal_core__DOT___071483_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d));
    vlSelf->wasmetal_core__DOT___071484_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071502_))));
    vlSelf->wasmetal_core__DOT___071503_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071502_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071524_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071474_))));
    vlSelf->wasmetal_core__DOT___071475_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071474_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071535_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071496_))));
    vlSelf->wasmetal_core__DOT___071497_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071496_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071519_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___070572_))));
    vlSelf->wasmetal_core__DOT___070573_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___128794___O 
        = (((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d)) 
                   << 1U)) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d)))) 
           ^ (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d)
                  ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d)
                  : (IData)(vlSelf->wasmetal_core__DOT___128794___DOT__CO__BRA__0__KET__)) 
                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128794___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035884_)));
    vlSelf->wasmetal_core__DOT___071553_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071506_))));
    vlSelf->wasmetal_core__DOT___071507_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071506_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071560_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071526_))));
    vlSelf->wasmetal_core__DOT___071527_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071526_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071480_))));
    vlSelf->wasmetal_core__DOT___071481_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071480_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071555_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071512_))));
    vlSelf->wasmetal_core__DOT___071513_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071512_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071561_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071530_))));
    vlSelf->wasmetal_core__DOT___071531_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071530_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071548_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071488_))));
    vlSelf->wasmetal_core__DOT___071489_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071554_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071509_))));
    vlSelf->wasmetal_core__DOT___071510_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071509_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071547_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071484_))));
    vlSelf->wasmetal_core__DOT___071485_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071552_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071503_))));
    vlSelf->wasmetal_core__DOT___071504_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071503_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071559_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071524_))));
    vlSelf->wasmetal_core__DOT___071525_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071524_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071476_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071550_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071497_))));
    vlSelf->wasmetal_core__DOT___071498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071497_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071557_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071519_))));
    vlSelf->wasmetal_core__DOT___071520_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071544_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070573_))));
    vlSelf->wasmetal_core__DOT___070574_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__27(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__27\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___019356_;
    wasmetal_core__DOT___019356_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063583_;
    wasmetal_core__DOT___063583_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063591_;
    wasmetal_core__DOT___063591_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063599_;
    wasmetal_core__DOT___063599_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063607_;
    wasmetal_core__DOT___063607_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063679_;
    wasmetal_core__DOT___063679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063687_;
    wasmetal_core__DOT___063687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063695_;
    wasmetal_core__DOT___063695_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063703_;
    wasmetal_core__DOT___063703_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070648_;
    wasmetal_core__DOT___070648_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070657_;
    wasmetal_core__DOT___070657_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070660_;
    wasmetal_core__DOT___070660_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070663_;
    wasmetal_core__DOT___070663_ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___052587_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045744_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->busy))));
    vlSelf->__VdfgTmp_h2df5fb6a__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h73f978ac__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->cmd_kind) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048483_));
    vlSelf->wasmetal_core__DOT___053733_ = (1U & (IData)(
                                                         (0xffff3c3fffff23ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))))))));
    vlSelf->wasmetal_core__DOT___053285_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0))))));
    vlSelf->wasmetal_core__DOT___053422_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0))))));
    vlSelf->wasmetal_core__DOT___052696_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))));
    vlSelf->wasmetal_core__DOT___053618_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053615_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))));
    vlSelf->wasmetal_core__DOT___053007_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xaaaa02aaaaaa282aULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052997_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053002_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))));
    vlSelf->wasmetal_core__DOT___070621_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 0x10U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054455_)))));
    vlSelf->wasmetal_core__DOT___053737_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xfaf0f0f3U 
                                                         >> 
                                                         ((0x18U 
                                                           & ((IData)(vlSelf->cmd_kind) 
                                                              << 2U)) 
                                                          | ((4U 
                                                              & ((IData)(vlSelf->cmd_kind) 
                                                                 >> 1U)) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->cmd_kind) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___038805_)))))))));
    vlSelf->wasmetal_core__DOT___063392_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063391_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063389_) 
                                                                  << 3U) 
                                                                 | (vlSelf->function_locals 
                                                                    >> 0x1dU)))))));
    vlSelf->wasmetal_core__DOT___063418_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051236_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d))));
    vlSelf->wasmetal_core__DOT___019798_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___038805_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051236_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)))))));
    vlSelf->wasmetal_core__DOT___039415_ = (1U & (0xeaaa2aaaU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->cmd_kind) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051236_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___038805_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__query_table)))))));
    vlSelf->wasmetal_core__DOT___063013_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050385_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___050389_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050385_))));
    vlSelf->wasmetal_core__DOT___048001_ = (1U & (IData)(
                                                         (0xdfff7555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b63__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xfffeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___063407_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063382_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00f1f100000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052985_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->mem_fault))))))))))));
    vlSelf->wasmetal_core__DOT___052988_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052986_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052985_)))));
    vlSelf->wasmetal_core__DOT___054476_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050467_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___051277_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050467_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___050454_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050438_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___053331_ = (1U & (0x7fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044604_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053330_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x9009000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___053314_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053313_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b85__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x13U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b81__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x11U))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x9009000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___053326_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053325_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b95__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1dU)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b94__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1eU))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___053324_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053323_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053322_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x9009U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b77__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xbU)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b73__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 9U)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x9009000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053318_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053317_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b92__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1aU)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b75__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xbU))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1001000000001001ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b84__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x10U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b80__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xeU)) 
                                                                                | ((2U 
                                                                                & ((6U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b67__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 3U)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (6U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b66__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 2U)))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___054481_ = (1U & (IData)(
                                                         (0xfcf3ff3ffffffff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___005571_ = (1U & (0x7fd5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b31__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048005_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))));
    vlSelf->wasmetal_core__DOT___047979_ = (1U & (0xfff8f8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          >> 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___047793_)))))));
    vlSelf->wasmetal_core__DOT___054736_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___054737_ = (1U & (0x75U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & vlSelf->insn_op)))));
    vlSelf->wasmetal_core__DOT___054729_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048307_))));
    vlSelf->__VdfgTmp_hbec427aa__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048307_));
    vlSelf->wasmetal_core__DOT___042536_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044061_))));
    wasmetal_core__DOT___019356_ = (1U & (0xca00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052953_))))));
    vlSelf->wasmetal_core__DOT___063445_ = (1U & (IData)(
                                                         (0xa03fafc0a000a00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->mem_fault) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0faaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052953_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0ff1168c__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___053282_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052953_))));
    vlSelf->wasmetal_core__DOT___052955_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))));
    vlSelf->wasmetal_core__DOT___046017_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070486_))));
    vlSelf->wasmetal_core__DOT___046019_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070489_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070486_))));
    vlSelf->wasmetal_core__DOT___060659_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007190_))));
    vlSelf->wasmetal_core__DOT___061648_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048385_))));
    vlSelf->wasmetal_core__DOT___003034_ = (1U & (0xfff8f8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x8000000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___047969_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___047968_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___047967_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047966_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x7f7f7fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28012a28__0))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047964_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___047963_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047962_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047961_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x777ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002985_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf1ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xfffeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xbfbfbfbfbfbfbfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha37d1f60__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___047988_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003045_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___003044_)) 
                                                     & (IData)(
                                                               (0x80ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___003043_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003042_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003013_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003041_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003040_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___003039_)))))))))));
    vlSelf->wasmetal_core__DOT___036595_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_x 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051253_)))));
    vlSelf->wasmetal_core__DOT___036767_ = (1U & (0x8e71U 
                                                  >> 
                                                  ((8U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8befad22__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051253_))))));
    vlSelf->wasmetal_core__DOT___053260_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003092_))));
    vlSelf->wasmetal_core__DOT___048393_ = (1U & (0xf8880000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045672_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___044092_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___045682_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02ewide)))))));
    vlSelf->__VdfgTmp_h223d2b22__0 = (((IData)(vlSelf->wasmetal_core__DOT___003013_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___003012_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003011_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003010_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h88a73cb4__0)))));
    vlSelf->wasmetal_core__DOT___044791_ = (1U & (IData)(
                                                         (0xf0aaf000f0ccfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070633_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___044803_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070633_)))))))));
    vlSelf->wasmetal_core__DOT___070619_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003013_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053264_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003039_)))));
    vlSelf->wasmetal_core__DOT___061665_ = (1U & (IData)(
                                                         (0xfeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052731_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048412_)))))))));
    vlSelf->wasmetal_core__DOT___052680_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fifth_ready))));
    vlSelf->wasmetal_core__DOT___009643_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_x 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (vlSelf->insn_op 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___009642_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->insn_x) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8cb32961__0))))));
    vlSelf->wasmetal_core__DOT___060664_ = (1U & (0x5ff01fbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007060_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048448_)))))));
    vlSelf->wasmetal_core__DOT___061645_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061644_))));
    vlSelf->wasmetal_core__DOT___061646_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061644_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048514_)))));
    vlSelf->wasmetal_core__DOT___062618_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062630_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062641_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062652_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O))))))))));
    vlSelf->wasmetal_core__DOT___062663_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062674_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062685_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062696_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O))))))))));
    vlSelf->wasmetal_core__DOT___062707_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062718_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062729_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062740_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O))))))))));
    vlSelf->wasmetal_core__DOT___062751_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062762_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062773_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062784_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O))))))))));
    vlSelf->wasmetal_core__DOT___062795_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062806_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062817_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062828_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O))))))))));
    vlSelf->wasmetal_core__DOT___062839_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062850_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062861_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062872_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O))))))))));
    vlSelf->wasmetal_core__DOT___062883_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062894_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062905_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062916_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O))))))))));
    vlSelf->wasmetal_core__DOT___062927_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062938_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062949_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062617_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062629_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062640_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062651_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062662_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062673_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062684_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062695_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062706_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062717_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062728_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062739_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062750_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062761_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062772_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062783_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062794_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062805_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062816_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062827_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062838_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062849_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062860_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062871_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062882_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062893_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062904_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062915_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062926_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062937_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128262___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062948_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128262___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___019293_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019336_))));
    vlSelf->wasmetal_core__DOT___019291_ = (1U & (0xfff80000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048416_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055311_)))))));
    vlSelf->wasmetal_core__DOT___030686_ = (1U & (0x78U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003147_)))));
    vlSelf->wasmetal_core__DOT___047978_ = (1U & (IData)(
                                                         (0x80000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047977_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___047975_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002977_)))))))));
    vlSelf->wasmetal_core__DOT___070599_ = (1U & (0xf88U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 5U)) 
                                                      | ((2U 
                                                          & ((0x8000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___047790_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___047953_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___002965_))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x4000000000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___070596_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___070595_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047975_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002977_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x777ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_phase))))))))))))));
    vlSelf->wasmetal_core__DOT___031341_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3030300fffffffeULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & (vlSelf->insn_y 
                                                                      << 4U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051568_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051564_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053427_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051567_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051569_))))))))))));
    vlSelf->__VdfgTmp_hde1d4dea__0 = (((IData)(vlSelf->wasmetal_core__DOT___044260_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052853_));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b10__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 8U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b10__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xaU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xaU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b24__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x16U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b24__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x18U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x18U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b20__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x12U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b20__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x14U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x14U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b21__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x13U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b21__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x15U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x15U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b30__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x1cU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b30__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1eU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1eU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b18__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x10U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b18__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x12U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x12U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b14__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xcU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b14__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xeU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xeU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b15__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xdU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b15__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xfU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xfU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b26__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x18U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b26__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1aU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b27__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x19U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b27__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1bU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               << 1U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b1__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 1U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 1U))))));
    vlSelf->wasmetal_core__DOT___052849_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___060678_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060655_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8cb32961__0)))));
    vlSelf->wasmetal_core__DOT___060672_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060655_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha01e8f2f__0))));
    vlSelf->wasmetal_core__DOT___060656_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060655_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___019222_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060719_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019204_))))));
    vlSelf->wasmetal_core__DOT___055322_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052732_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & vlSelf->insn_x)))))));
    vlSelf->wasmetal_core__DOT___055319_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019204_))));
    vlSelf->wasmetal_core__DOT___019221_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))));
    vlSelf->wasmetal_core__DOT___000157_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047785_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047784_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___003093_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047785_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047784_))))));
    vlSelf->wasmetal_core__DOT___053373_ = (1U & (IData)(
                                                         (0xff00e000ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053371_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (2U 
                                                                             & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053122_)))))))));
    vlSelf->wasmetal_core__DOT___053385_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x11ff0fffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053383_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 3U)) 
                                                                       | ((8U 
                                                                           & ((1U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048679_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b12__05d)))));
    vlSelf->wasmetal_core__DOT___003030_ = (1U & (IData)(
                                                         (0xff00ff0f0f8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_op 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x80U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___003039_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x53ffffffffffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & (vlSelf->insn_op 
                                                                                << 4U)) 
                                                                                | ((0x10U 
                                                                                & (vlSelf->insn_op 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & vlSelf->insn_op) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h11a2e1d4__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047792_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((0x777ffffU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                               | ((8U 
                                                                                & ((0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002984_)))))) 
                                                                             & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___002981_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002980_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002979_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002978_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002977_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x777ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001234_))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___003028_ = (1U & (0xf0f33aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_op 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___047955_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047954_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047953_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h88a73cb4__0))))))))))))));
    vlSelf->wasmetal_core__DOT___003033_ = (1U & (0xfff8f8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h50379cea__0))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b7__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 6U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050764_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 7U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b5__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 4U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___049400_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 5U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b2__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048524_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 2U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b3__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 2U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048526_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 3U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b0__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048522_)))))) 
                                     << 1U)) | (1U 
                                                & vlSelf->cmd_index)))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b6__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 5U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050766_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 6U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b4__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 3U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___049402_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 4U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b31__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b31__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1eU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050924_)))))) 
                                     << 1U)) | (vlSelf->cmd_index 
                                                >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b19__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b19__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x12U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050945_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x13U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b16__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b16__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xfU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050947_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x10U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b8__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b8__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 7U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050959_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 8U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b22__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b22__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x15U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050952_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x16U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b29__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b29__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1cU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050937_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b25__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b25__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x18U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050927_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x19U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b28__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b28__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1bU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050919_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b23__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b23__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x16U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050950_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x17U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b17__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b17__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x10U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050943_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x11U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b9__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b9__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 8U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050957_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 9U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b13__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b13__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xcU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050935_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xdU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b11__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b11__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xaU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050954_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xbU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b12__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b12__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xbU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050933_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xcU))))));
    vlSelf->wasmetal_core__DOT___031354_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1eU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031353_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1dU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031351_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1cU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031350_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1bU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031349_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1aU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031348_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x19U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031347_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x18U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031346_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x17U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031345_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x16U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031344_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x15U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031343_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x14U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031342_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x13U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031340_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x12U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031339_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x11U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031338_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x10U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031337_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xfU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031336_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xeU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031335_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xdU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031334_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xcU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031333_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xbU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031332_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xaU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031331_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 9U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031361_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 8U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031360_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 7U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031359_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 6U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031358_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 5U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031357_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 4U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031356_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 3U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031355_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031352_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031330_ = (1U & (0xf40bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051564_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071847_))))));
    vlSelf->wasmetal_core__DOT___063788_ = (1U & (0x7077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000358_))))));
    vlSelf->wasmetal_core__DOT___066983_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061519_))));
    vlSelf->wasmetal_core__DOT___056541_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011740_))));
    vlSelf->wasmetal_core__DOT___048431_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044819_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048286_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048429_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048285_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf8000000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048426_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048425_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h9fdaf630__0))))))))))));
    vlSelf->wasmetal_core__DOT___000666_ = (1U & (0xb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044819_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048286_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048285_)))))));
    vlSelf->wasmetal_core__DOT___053272_ = (1U & (IData)(
                                                         (0x1010000101000ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053271_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0x80000000U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___047790_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___047792_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x1fff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___047964_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047786_)))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x1f00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053264_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003010_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047954_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048328_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1fff000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___002978_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053266_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047783_)))))))))))))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                                        >> 2U)) 
                                                                    | (1U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O)))))))));
    vlSelf->wasmetal_core__DOT___030687_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048391_))));
    vlSelf->wasmetal_core__DOT___063463_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063471_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063479_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063487_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063495_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063503_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063511_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063519_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063527_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063535_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063543_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063551_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063559_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063567_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063575_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063583_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063591_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063599_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063607_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063615_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063623_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063631_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063639_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063647_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063655_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063663_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063671_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063679_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063687_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063695_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063703_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___070485_ = (1U & (0xf088U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052864_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052908_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052885_))))));
    vlSelf->type_expected = (((0xa3U >> (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___053027_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b31__05d)))) 
                              << 0x1fU) | ((0x40000000U 
                                            & ((0xa3U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053037_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b30__05d)))) 
                                               << 0x1eU)) 
                                           | ((0x20000000U 
                                               & ((0xa3U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053032_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b29__05d)))) 
                                                  << 0x1dU)) 
                                              | ((0x10000000U 
                                                  & ((0xa3U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053031_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b28__05d)))) 
                                                     << 0x1cU)) 
                                                 | ((0x8000000U 
                                                     & ((0xa3U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053028_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b27__05d)))) 
                                                        << 0x1bU)) 
                                                    | ((0x4000000U 
                                                        & ((0xf0f0ccaaU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__expected_type__05b26__05d) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_ha0b2a3dd__0))))) 
                                                           << 0x1aU)) 
                                                       | ((0x2000000U 
                                                           & ((0xa3U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053025_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b25__05d)))) 
                                                              << 0x19U)) 
                                                          | ((0x1000000U 
                                                              & ((0xa3U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053036_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b24__05d)))) 
                                                                 << 0x18U)) 
                                                             | ((0x800000U 
                                                                 & ((0xf0f0ccaaU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__expected_type__05b23__05d) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h1ce9b3c5__0))))) 
                                                                    << 0x17U)) 
                                                                | ((0x400000U 
                                                                    & ((0xa3U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053029_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b22__05d)))) 
                                                                       << 0x16U)) 
                                                                   | ((0x200000U 
                                                                       & ((0xa3U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053024_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b21__05d)))) 
                                                                          << 0x15U)) 
                                                                      | ((0x100000U 
                                                                          & ((0xa3U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053026_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b20__05d)))) 
                                                                             << 0x14U)) 
                                                                         | ((0x80000U 
                                                                             & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053035_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b19__05d)))) 
                                                                                << 0x13U)) 
                                                                            | ((0x40000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053034_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b18__05d)))) 
                                                                                << 0x12U)) 
                                                                               | ((0x20000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053030_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b17__05d)))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053033_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b16__05d)))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053051_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b15__05d)))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053050_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b14__05d)))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053057_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b13__05d)))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053056_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b12__05d)))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053053_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b11__05d)))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053052_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b10__05d)))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053055_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b9__05d)))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053054_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b8__05d)))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052735_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b7__05d)))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052734_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b6__05d)))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053021_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b5__05d)))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053023_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b4__05d)))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053049_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b3__05d)))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053048_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b2__05d)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053047_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b1__05d)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053046_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__expected_type__05b0__05d))))))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___030721_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007203_))));
    vlSelf->wasmetal_core__DOT___030722_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007205_))));
    vlSelf->wasmetal_core__DOT___052730_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048486_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02erunning)))));
    vlSelf->wasmetal_core__DOT___019229_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4cc7c9a__0))));
    vlSelf->wasmetal_core__DOT___055348_ = (1U & (0x1c1c1c3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048283_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xa3330000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055315_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0xff00ff44440f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055315_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055311_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_x 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048441_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019204_))))))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & vlSelf->insn_op)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048329_)))))));
    vlSelf->wasmetal_core__DOT___055339_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055315_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xccaaf0f0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___055311_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (vlSelf->insn_x 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & vlSelf->insn_x) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8cb32961__0))))));
    vlSelf->wasmetal_core__DOT___011101_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___063453_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063448_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063449_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052847_)))))))));
    vlSelf->wasmetal_core__DOT___062959_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053616_))));
    vlSelf->wasmetal_core__DOT___062961_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053616_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009544_))));
    vlSelf->wasmetal_core__DOT___070636_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070634_)))))))));
    vlSelf->wasmetal_core__DOT___070639_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070637_)))))))));
    vlSelf->wasmetal_core__DOT___031968_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053478_))));
    vlSelf->wasmetal_core__DOT___031967_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053478_))));
    vlSelf->wasmetal_core__DOT___069275_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050361_))));
    vlSelf->wasmetal_core__DOT___019220_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060720_))));
    vlSelf->wasmetal_core__DOT___054686_ = (1U & (IData)(
                                                         (0xbf00bfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_x 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054672_)))))))));
    vlSelf->wasmetal_core__DOT___063452_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063451_))));
    vlSelf->wasmetal_core__DOT___062610_ = (1U & (IData)(
                                                         (0xb0b0b000ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062609_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x777000007770777ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062603_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052645_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___048279_))))))))))));
    vlSelf->wasmetal_core__DOT___034181_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d))));
    vlSelf->wasmetal_core__DOT___034180_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d))));
    vlSelf->wasmetal_core__DOT___034179_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d))));
    vlSelf->wasmetal_core__DOT___034178_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    vlSelf->wasmetal_core__DOT___008495_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___008500_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___008017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___007208_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O)))));
    vlSelf->wasmetal_core__DOT___070642_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070640_)))))))));
    vlSelf->wasmetal_core__DOT___070645_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070643_)))))))));
    wasmetal_core__DOT___070648_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070646_)))))))));
    vlSelf->wasmetal_core__DOT___070651_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070649_)))))))));
    vlSelf->wasmetal_core__DOT___070654_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070652_)))))))));
    wasmetal_core__DOT___070657_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070655_)))))))));
    vlSelf->wasmetal_core__DOT___067478_ = (1U & (0x7077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b31__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000358_))))));
    wasmetal_core__DOT___070660_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070658_)))))))));
    wasmetal_core__DOT___070663_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b31__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070661_)))))))));
    vlSelf->wasmetal_core__DOT___072274_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x44474444U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___072258_) 
                                                          << 4U) 
                                                         | ((8U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                                << 3U)) 
                                                            | ((4U 
                                                                & ((0xf38f2778U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->mem_write)))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x4000ffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053285_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                                           << 4U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045785_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->cmd_kind) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h73f978ac__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->cmd_kind) 
                                                                                >> 1U))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053345_)))));
    vlSelf->wasmetal_core__DOT___053752_ = (1U & (0xb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053618_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048487_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->mem_ready)))))));
    vlSelf->wasmetal_core__DOT___053751_ = (1U & (IData)(
                                                         (0xf4ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053421_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->mem_ready) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053002_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052986_)))))))));
    vlSelf->wasmetal_core__DOT___063417_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063392_))));
    vlSelf->wasmetal_core__DOT___050456_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050454_))));
    vlSelf->wasmetal_core__DOT___053332_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053331_))));
    vlSelf->wasmetal_core__DOT___054482_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054480_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->result_index) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054484_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054483_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054486_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054485_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054488_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054487_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 3U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054490_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054489_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 4U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054492_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054491_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 5U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054494_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054493_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 6U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054496_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054495_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 7U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054498_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054497_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 8U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054500_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054499_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 9U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054504_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054503_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xbU)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054506_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054505_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xcU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054508_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054507_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xdU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054502_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xaU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054510_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054509_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xeU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054512_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054511_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xfU)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054514_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054513_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x10U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054516_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054515_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x11U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054518_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054517_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x12U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054520_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054522_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054521_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x14U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054524_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054523_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x15U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054526_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054525_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x16U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054528_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054527_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x17U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054530_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054529_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x18U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054532_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x19U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054534_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054533_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1aU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054536_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054535_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1bU)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054538_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054537_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1cU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054540_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054539_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1dU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___003032_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047979_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 7U))))));
    vlSelf->wasmetal_core__DOT___054696_ = (1U & (IData)(
                                                         (0xf0fbbbb00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbec427aa__0))))))));
    vlSelf->wasmetal_core__DOT___063395_ = (1U & ((~ (IData)(
                                                             (0xf00000dd00000000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053308_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053343_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill))))))))) 
                                                  & (IData)(
                                                            (0x3300ff3033f0fbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___019356_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->mem_fault) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d))))))))));
    vlSelf->wasmetal_core__DOT___063425_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063422_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___019356_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___038870_)))))));
    vlSelf->wasmetal_core__DOT___053333_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053331_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052955_))));
    vlSelf->wasmetal_core__DOT___052989_ = (1U & (0x7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052956_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052955_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052954_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02edone)))))));
    vlSelf->wasmetal_core__DOT___003031_ = (1U & (IData)(
                                                         (0x40ff000000ff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047988_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (vlSelf->insn_op 
                                                                                >> 0x1aU))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___042542_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042590_))));
    vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036767_) 
                 | (6U >> (IData)(vlSelf->__VdfgTmp_h8befad22__0))));
    vlSelf->wasmetal_core__DOT___053475_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053260_))));
    vlSelf->wasmetal_core__DOT___052806_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ebusy) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->wasmetal_core__DOT___052805_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048393_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02ebusy))));
    vlSelf->wasmetal_core__DOT___050362_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->__VdfgTmp_h508bc82d__0 = (((IData)(vlSelf->wasmetal_core__DOT___048393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048392_));
    vlSelf->wasmetal_core__DOT___003035_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___002966_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___003014_)
                                                    ? (IData)(
                                                              (0x8000000000000000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h223d2b22__0)))
                                                    : (IData)(
                                                              (0x80000000ffffffffULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h223d2b22__0))))
                                                   : 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___003014_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___003013_)))));
    vlSelf->wasmetal_core__DOT___042683_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070619_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & (vlSelf->insn_op 
                                                          >> 0x11U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___070632_ = (1U & (0xffff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070619_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003045_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003044_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___003043_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003042_)))))));
    vlSelf->wasmetal_core__DOT___042541_ = (1U & (0x1f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070621_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070619_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 0x12U)))))));
    vlSelf->wasmetal_core__DOT___062619_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062618_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062617_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062631_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062630_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062629_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062642_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062640_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062653_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062652_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062651_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062664_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062663_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062662_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062675_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062673_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062686_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062685_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062684_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062697_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062695_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062708_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062707_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062706_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062719_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062718_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062717_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062730_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062729_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062728_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062741_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062740_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062739_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062752_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062751_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062750_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062763_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062762_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062761_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062774_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062772_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062785_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062784_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062783_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062796_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062795_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062794_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062807_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062806_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062805_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062818_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062817_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062816_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062829_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062828_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062827_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062840_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062839_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062838_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062851_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062850_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062849_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062862_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062861_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062860_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062873_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062872_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062871_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062884_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062883_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062882_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062895_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062894_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062893_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062906_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062905_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062904_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062917_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062916_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062915_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062928_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062927_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062926_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062939_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062938_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062937_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062950_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062949_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062948_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030686_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___003029_ = (1U & (0xf0fff88U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047978_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_op 
                                                             >> 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009501_)))))));
    vlSelf->wasmetal_core__DOT___070600_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047979_))));
    vlSelf->wasmetal_core__DOT___070606_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047979_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070599_))));
    vlSelf->wasmetal_core__DOT___063367_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053263_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052883_)))));
    vlSelf->wasmetal_core__DOT___050941_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b20__05d))));
    vlSelf->wasmetal_core__DOT___055325_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055322_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054672_)))))))));
    if (vlSelf->wasmetal_core__DOT___003030_) {
        vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003030_)));
        vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)));
        vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003030_)));
    } else {
        vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)));
        vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003030_)));
        vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)));
    }
    vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                 | (~ (IData)(vlSelf->wasmetal_core__DOT___003034_))));
    vlSelf->__VdfgTmp_hefabe8e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003034_));
    vlSelf->__VdfgTmp_hc058618d__0 = (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003030_));
    vlSelf->wasmetal_core__DOT___049411_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h295e0579__0))))));
    vlSelf->wasmetal_core__DOT___049407_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2b062dd4__0))))));
    vlSelf->wasmetal_core__DOT___049415_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8dc4790b__0))))));
    vlSelf->wasmetal_core__DOT___048531_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4f25bbf3__0))))));
    vlSelf->wasmetal_core__DOT___049908_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc4635290__0))))));
    vlSelf->wasmetal_core__DOT___051599_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb256bb9f__0))))));
    vlSelf->wasmetal_core__DOT___051666_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h738a13de__0))))));
    vlSelf->wasmetal_core__DOT___051670_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc793c4ac__0))))));
    vlSelf->wasmetal_core__DOT___051674_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hff3ab0b7__0))))));
    vlSelf->wasmetal_core__DOT___050682_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8b69f170__0))))));
    vlSelf->wasmetal_core__DOT___050673_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7982dd07__0))))));
    vlSelf->wasmetal_core__DOT___050669_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1157f8a3__0))))));
    vlSelf->wasmetal_core__DOT___050646_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h51560923__0))))));
    vlSelf->wasmetal_core__DOT___050618_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h29fa0da7__0))))));
    vlSelf->wasmetal_core__DOT___050614_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc0d4cc40__0))))));
    vlSelf->wasmetal_core__DOT___050597_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1dd2dede__0))))));
    vlSelf->wasmetal_core__DOT___050589_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7d1b01d9__0))))));
    vlSelf->wasmetal_core__DOT___050560_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h38f4df47__0))))));
    vlSelf->wasmetal_core__DOT___050575_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b83__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b82__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b81__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b80__05d)))))))));
    vlSelf->wasmetal_core__DOT___050571_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b103__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b102__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b100__05d)))))))));
    vlSelf->wasmetal_core__DOT___050491_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b115__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b114__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b113__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b112__05d)))))))));
    vlSelf->wasmetal_core__DOT___051447_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b139__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b138__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b137__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b136__05d)))))))));
    vlSelf->wasmetal_core__DOT___051455_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b167__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b166__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b165__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b164__05d)))))))));
    vlSelf->wasmetal_core__DOT___051451_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b179__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b178__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b177__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b176__05d)))))))));
    vlSelf->wasmetal_core__DOT___053464_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b211__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b210__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b209__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b208__05d)))))))));
    vlSelf->wasmetal_core__DOT___053460_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b231__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b230__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b229__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b228__05d)))))))));
    vlSelf->wasmetal_core__DOT___053456_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b243__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b242__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b241__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b240__05d)))))))));
    vlSelf->wasmetal_core__DOT___051482_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b83__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b82__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b81__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b80__05d)))))))));
    vlSelf->wasmetal_core__DOT___051478_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b103__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b102__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b100__05d)))))))));
    vlSelf->wasmetal_core__DOT___051472_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b115__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b114__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b113__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b112__05d)))))))));
    vlSelf->wasmetal_core__DOT___051400_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b139__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b138__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b137__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b136__05d)))))))));
    vlSelf->wasmetal_core__DOT___051465_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b167__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b166__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b165__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b164__05d)))))))));
    vlSelf->wasmetal_core__DOT___050567_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b179__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b178__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b177__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b176__05d)))))))));
    vlSelf->wasmetal_core__DOT___050593_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b211__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b210__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b209__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b208__05d)))))))));
    vlSelf->wasmetal_core__DOT___051392_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b231__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b230__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b229__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b228__05d)))))))));
    vlSelf->wasmetal_core__DOT___051388_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b243__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b242__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b241__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b240__05d)))))))));
    vlSelf->wasmetal_core__DOT___049399_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5760b542__0))))));
    vlSelf->wasmetal_core__DOT___050918_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7a6ef80c__0))))));
    vlSelf->wasmetal_core__DOT___051678_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he052d4e7__0))))));
    vlSelf->wasmetal_core__DOT___050759_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0a9f8029__0))))));
    vlSelf->wasmetal_core__DOT___050650_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5864b2ba__0))))));
    vlSelf->wasmetal_core__DOT___050606_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1968304e__0))))));
    vlSelf->wasmetal_core__DOT___051031_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8546e85d__0))))));
    vlSelf->wasmetal_core__DOT___051035_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h02a1ae9a__0))))));
    vlSelf->wasmetal_core__DOT___051039_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf05a0261__0))))));
    vlSelf->wasmetal_core__DOT___050738_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6727edf3__0))))));
    vlSelf->wasmetal_core__DOT___050728_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefac84ff__0))))));
    vlSelf->wasmetal_core__DOT___050751_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_haf724a20__0))))));
    vlSelf->wasmetal_core__DOT___050579_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___051023_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b151__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b150__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b149__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b148__05d)))))))));
    vlSelf->wasmetal_core__DOT___051847_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b203__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b202__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b201__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b200__05d)))))))));
    vlSelf->wasmetal_core__DOT___072231_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___072223_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b151__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b150__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b149__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b148__05d)))))))));
    vlSelf->wasmetal_core__DOT___051384_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b203__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b202__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b201__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b200__05d)))))))));
    vlSelf->wasmetal_core__DOT___051027_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8c9e90c9__0))))));
    vlSelf->wasmetal_core__DOT___050742_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf782be94__0))))));
    vlSelf->wasmetal_core__DOT___053448_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___051878_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___049430_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___051442_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___072243_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___072239_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___053444_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___072247_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__ADDRARDADDR 
        = (0x803fU | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d) 
                       << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                    << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                 << 0xbU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                    << 0xaU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                       << 9U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                          << 8U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                             << 7U) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                               << 6U)))))))));
    vlSelf->wasmetal_core__DOT___050942_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b30__05d))));
    vlSelf->wasmetal_core__DOT___050961_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b18__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b17__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___050940_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031330_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___063007_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048431_))));
    vlSelf->wasmetal_core__DOT___050441_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050361_))));
    vlSelf->wasmetal_core__DOT___050360_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048431_))));
    vlSelf->wasmetal_core__DOT___048488_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009544_))));
    vlSelf->wasmetal_core__DOT___050398_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048431_))));
    vlSelf->__VdfgTmp_h66357502__0 = (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048431_));
    vlSelf->wasmetal_core__DOT___000152_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___053575_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053260_))));
    vlSelf->wasmetal_core__DOT___053344_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053273_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053260_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053272_)))));
    vlSelf->wasmetal_core__DOT___063464_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063463_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063472_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063471_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063480_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063479_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063488_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063487_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063496_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063495_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063504_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063503_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063512_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063511_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063520_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063519_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063528_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063527_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063536_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063535_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063544_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063543_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063552_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063560_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063559_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063568_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063567_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063576_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063575_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063584_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063583_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063592_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063591_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063600_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063599_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063608_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063616_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063615_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063624_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063623_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063632_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063631_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063640_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063639_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063648_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063647_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063656_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063655_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063664_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063663_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063672_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063671_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063680_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063688_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063687_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063696_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063704_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063703_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030721_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___019810_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->reset) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052730_))));
    vlSelf->wasmetal_core__DOT___060773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060720_))));
    vlSelf->wasmetal_core__DOT___063059_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063054_))));
    vlSelf->wasmetal_core__DOT___063078_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xfU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063077_)))));
    vlSelf->__VdfgTmp_h277c2e25__0 = (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___063054_)))));
    vlSelf->wasmetal_core__DOT___044805_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070636_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___044793_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070636_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070634_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___044806_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070639_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___044794_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070639_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070637_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031967_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___061348_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019220_))));
    vlSelf->wasmetal_core__DOT___054717_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054685_))));
    vlSelf->wasmetal_core__DOT___062616_ = (1U & (IData)(
                                                         (0xf0f033aa00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128010___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff8fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062610_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062601_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053989_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->cmd_aux))))))))));
    vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034178_) 
           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d));
    vlSelf->wasmetal_core__DOT___007693_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053782_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008495_)))));
    vlSelf->wasmetal_core__DOT___010101_ = (1U & (0xf004444U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053782_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008495_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___008500_)))))));
    vlSelf->wasmetal_core__DOT___007235_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053782_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008500_)))));
    vlSelf->wasmetal_core__DOT___007234_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053782_))));
    vlSelf->wasmetal_core__DOT___007204_ = ((IData)(vlSelf->wasmetal_core__DOT___007208_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___007197_)) 
                                               | (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007196_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007207_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007193_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007192_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007191_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007195_))))))))));
    vlSelf->wasmetal_core__DOT___044807_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070642_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___044795_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070640_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O))))))))));
    vlSelf->wasmetal_core__DOT___044808_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070645_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___044796_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070643_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___044809_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070648_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___044797_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070648_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070646_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___044810_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070651_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___044798_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070651_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070649_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___044811_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070654_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___044799_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070652_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O))))))))));
    vlSelf->wasmetal_core__DOT___044812_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070657_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___044800_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070657_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070655_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___044813_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070660_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___044801_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070660_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070658_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___044804_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070663_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___044792_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070663_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070661_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b31__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___053438_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050389_))));
    vlSelf->wasmetal_core__DOT___063410_ = (1U & (IData)(
                                                         (0xccf05500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ff1168c__0))))))));
    vlSelf->wasmetal_core__DOT___039792_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b32__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039763_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b33__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039764_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b34__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039765_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b35__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039762_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039410_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b37__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039767_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b38__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039768_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b39__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039769_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b40__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039770_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b41__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039771_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b42__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039772_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b43__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b11__05d)))))));
}
